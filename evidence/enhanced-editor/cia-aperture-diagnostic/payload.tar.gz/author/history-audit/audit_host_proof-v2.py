from pathlib import Path
import json,hashlib,re,ast
r=Path('/private/tmp/protracker-cia-aperture-8cku0nh5');qdir=Path('/private/tmp/protracker-cia-aperture-owner-probe-final-8cku0nh5')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=lambda p:{'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
m=json.loads((r/'source-manifest.json').read_text());host=json.loads((r/'host-final/host-checks.json').read_text());probe=json.loads((qdir/'result.json').read_text())
checks=[]
def check_file(p,h,n=None):
 p=Path(p);assert sha(p)==h,str(p)
 if n is not None:assert p.stat().st_size==n,str(p)
 checks.append(str(p))
def refs(v):
 if isinstance(v,dict):
  if 'sha256' in v and isinstance(v.get('path'),str):
   p=Path(v['path']);check_file(p if p.is_absolute() else r/'source-final'/p,v['sha256'],v.get('bytes'))
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
for name,mapkey in [('baseline','baseline_files'),('source-final','files')]:
 src=r/name
 actual={p.relative_to(src).as_posix():sha(p) for p in src.rglob('*') if p.is_file()}
 assert not any(p.is_symlink() for p in src.rglob('*')) and actual==m[mapkey]
assert len(m['baseline_files'])==8012 and len(m['files'])==8020
assert [p for p in m['files'] if m['files'][p]!=m['baseline_files'].get(p)]==[o['path'] for o in m['owned_overlays']]
refs(host);refs(probe)
assert host['passed'] and len(host['groups'])==2 and len(host['commands'])==4 and len(host['products'])==2 and not host['generated_inputs']
assert all(c['returncode']==0 and c['stage']=='complete' for c in host['commands'])
assert host['source_files_before']==host['source_files_after']==8020
for p,h in host['canonical_dependencies'].items():assert h==m['files'][p];check_file(r/'source-final'/p,h)
for p,h in host['external_sdk_dependencies'].items():check_file(p,h)
for c in host['commands']:
 for d in c['dependency_commands']:assert d['returncode']==0
for x in host['products']:check_file(x['archive_path'],x['sha256'],x['bytes'])
assert probe['passed'] and len(probe['commands'])==8 and len(probe['cases'])==2
expected=[0,0,0,0,20,0,0,0];assert [x['returncode'] for x in probe['commands']]==expected
for x in probe['cases']:
 key='baseline_files' if x['name']=='baseline' else 'files';src='baseline' if x['name']=='baseline' else 'source-final'
 assert x['actual_returncode']==x['expected_returncode']==(20 if src=='baseline' else 0)
 assert x['source_files_before']==x['source_files_after']==len(m[key])
 for p,h in x['dependencies']['canonical'].items():assert h==m[key][p];check_file(r/src/p,h)
 for p,h in x['dependencies']['system'].items():check_file(p,h)
 require='enabled=28/28 before=31/29 adds=4 removes=4 changes=4' if src=='baseline' else 'enabled=31/29 before=31/29 adds=0 removes=0 changes=0'
 text=(qdir/(x['name']+'-runtime.log')).read_text();assert require in text,text
 pins=json.loads((r/'tools-host/toolchain-pins.json').read_text())['host']
 for k in ['compiler','python']:check_file(pins[k]['path'],pins[k]['sha256'])
 for k in ['runtime_inputs','sdk_inputs']:
  for p,h in pins[k].items():check_file(p,h)
assert ast.literal_eval(next(n.value for n in ast.parse((r/'source-final/tests/test_cia_aperture.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets)))==['tests/cia_aperture_test.c','tests/cia_aperture_model.c','src/core/elapsed_clock.c']
all_native=json.loads((r/'toolchain-pins-aperture.json').read_text());original=json.loads((r/'tools-host/toolchain-pins.json').read_text());assert all_native['host']==original['host'] and all_native['native']['runtime_inputs']==original['native']['runtime_inputs']
for p in all_native['native']['assembler']['allowed_paths']:check_file(p,all_native['native']['assembler']['sha256'])
out={'passed':True,'scope':'Author read-only source/provenance audit; no test/compiler/target rerun','source_counts':[8012,8020],'owned_paths':len(m['owned_overlays']),'host_groups':2,'host_RC0_commands':4,'host_full_M_queries':sum(len(c['dependency_commands']) for c in host['commands']),'host_canonical':len(host['canonical_dependencies']),'host_system':len(host['external_sdk_dependencies']),'host_archived_products':2,'host_elapsed_s':host['elapsed_s'],'probe_commands':8,'probe_expected_codes':expected,'probe_same_C':record(r/'owner-probe/probe.c'),'probe_observations':[(qdir/'baseline-runtime.log').read_text(),(qdir/'candidate-runtime.log').read_text()],'unique_verified_record_paths':len(set(checks)),'controls':[record(r/'source-manifest.json'),record(r/'host-final/host-checks.json'),record(r/'host-final/host-checks.log'),record(qdir/'result.json')],'native':'NOT BUILT/NOT RUN','unchanged_earlier_native_failures':True}
(r/'author-host-proof-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'passed':True,'review':record(r/'author-host-proof-review.json'),'controls':out['controls'],'counts':[out['host_full_M_queries'],out['host_canonical'],out['host_system']]}))
