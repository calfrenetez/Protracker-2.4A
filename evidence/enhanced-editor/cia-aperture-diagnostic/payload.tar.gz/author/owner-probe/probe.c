#define main inherited_fixture_not_run
#include "cia_owner_test.c"
#undef main
int main(void)
{
    struct pt_diagnostic_cia t={0};struct CIA image[2];unsigned before_enabled[2],before_pending[2];int data=1,acquired,preserved;
    reset();host_hardware[0]=(struct CIA){0xc1,0x81,1,2,3,4};host_hardware[1]=(struct CIA){0xc1,0x81,5,6,7,8};
    enabled[0]=0x1f;enabled[1]=0x1d;pending[0]=0x1f;pending[1]=0x1d;
    memcpy(image,host_hardware,sizeof(image));memcpy(before_enabled,enabled,sizeof(enabled));memcpy(before_pending,pending,sizeof(pending));
    acquired=pt_diagnostic_cia_acquire(&t,handler,&data);
    preserved=!acquired && !memcmp(image,host_hardware,sizeof(image)) && !memcmp(before_enabled,enabled,sizeof(enabled)) && !memcmp(before_pending,pending,sizeof(pending)) && !vectors[0][0] && !vectors[0][1] && !vectors[1][0] && !vectors[1][1] && !depth;
    printf("CIA RUNNING MASK PROBE acquired=%d preserved=%d enabled=%u/%u before=%u/%u adds=%u removes=%u changes=%u control_writes=%u\n",acquired,preserved,enabled[0],enabled[1],before_enabled[0],before_enabled[1],adds,removes,changes,writes);
    if(acquired)assert(pt_diagnostic_cia_close(&t));
    else assert(pt_diagnostic_cia_close(&t));
    return preserved?0:20;
}
