#!/usr/bin/env python3
"""Pinned identical host-only running-CIA-mask probe; never native/target IO."""
import argparse,hashlib,json,os,shlex,re,subprocess,sys,time,traceback
from pathlib import Path

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def row(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def require(p,h):
 if sha(p)!=h:raise ValueError('Pinned input changed: '+str(p))
def snapshot(root):
 values={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError('Source symlink refused')
  if p.is_file():values[p.relative_to(root).as_posix()]=sha(p)
 return values
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def main():
 sys.dont_write_bytecode=True
 ap=argparse.ArgumentParser(description=__doc__)
 for key in ['root','manifest','pins','out']:ap.add_argument('--'+key,type=Path,required=True)
 ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--pins-sha256',required=True)
 a=ap.parse_args();r=a.root.resolve();out=a.out.resolve();manifest=a.manifest.resolve();pinsfile=a.pins.resolve()
 if out.exists() or r==out or out in r.parents or r in out.parents:raise ValueError('Fresh sibling proof output required')
 require(manifest,a.manifest_sha256);require(pinsfile,a.pins_sha256)
 m=json.loads(manifest.read_text());allpins=json.loads(pinsfile.read_text());p=allpins['host'];cc=p['compiler']['path'];probe=Path(__file__).with_name('probe.c').resolve()
 if Path(sys.executable).resolve()!=Path(p['python']['path']).resolve() or sys.version!=p['python']['version']:raise ValueError('Pinned Python required')
 controls=[row(manifest),row(pinsfile),row(probe),row(__file__)]
 pinned={cc:p['compiler']['sha256'],p['python']['path']:p['python']['sha256'],**p['runtime_inputs'],**p['sdk_inputs']}
 for path,h in pinned.items():require(path,h)
 cases=[('baseline',r/'baseline',m['baseline_files'],20),('candidate',r/'source-final',m['files'],0)]
 for name,source,expected,rc in cases:
  if snapshot(source)!=expected:raise ValueError(name+' complete source changed')
 out.mkdir();started=time.monotonic();result={'scope':'Identical ASan/UBSan host-only running-mask preservation probe; no native/target/hardware qualification','passed':False,'controls':controls,'toolchain':p,'commands':[],'cases':[]}
 def persist():result['elapsed_s']=time.monotonic()-started;write(out/'result.json',result)
 def run(argv,name,cwd):
  rec={'argv':argv,'directory':str(cwd),'label':name};result['commands'].append(rec);persist()
  done=subprocess.run(argv,cwd=cwd,capture_output=True,text=True,timeout=120)
  log=out/(name+'.log');log.write_text(done.stdout+done.stderr);rec.update(returncode=done.returncode,log=row(log));persist();return done
 try:
  v=run([cc,'--version'],'compiler-version',r);q=run([cc,'-print-resource-dir'],'compiler-resource',r)
  if v.returncode or q.returncode or v.stdout!=p['compiler']['version'] or q.stdout.strip()!=p['compiler']['resource_dir']:raise ValueError('Compiler query mismatch')
  sdkroots=[Path(x).resolve() for x in p['allowed_sdk_roots']]
  for name,source,expected,expectedrc in cases:
   binary=out/(name+'-probe');flags=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Itests']
   deps=run([cc,*flags,'-M',str(probe)],name+'-dependencies',source)
   if deps.returncode:raise ValueError('Host full-M failure')
   text=re.sub(r'\\\r?\n',' ',deps.stdout);names=[]
   for line in text.splitlines():
    c=re.search(r'(?<!\\):',line)
    if c:names.extend(shlex.split(line[c.end():]))
   closure={'canonical':{},'system':{},'actual_probe':row(probe)}
   for item in dict.fromkeys(names):
    path=(source/item).resolve()
    if path==probe:continue
    if path==source or source in path.parents:
     rel=path.relative_to(source).as_posix()
     if rel not in expected:raise ValueError('Unknown source dependency')
     require(path,expected[rel]);closure['canonical'][rel]=expected[rel]
    elif any(path==root or root in path.parents for root in sdkroots):closure['system'][str(path)]=sha(path)
    else:raise ValueError('Unknown dependency outside source/SDK: '+str(path))
   built=run([cc,*flags,str(probe),'-o',str(binary)],name+'-compile',source)
   if built.returncode:raise ValueError('Compile failed')
   executed=run([str(binary)],name+'-runtime',source)
   if executed.returncode!=expectedrc:raise ValueError('Expected preservation status mismatch')
   want='preserved=0' if name=='baseline' else 'preserved=1'
   if want not in executed.stdout:raise ValueError('Preservation observation absent')
   result['cases'].append({'name':name,'scope':'Expected baseline defect' if name=='baseline' else 'Corrected software preservation','expected_returncode':expectedrc,'actual_returncode':executed.returncode,'binary':row(binary),'dependencies':closure,'source_files_before':len(expected),'source_files_after':len(snapshot(source))});persist()
   for path,h in closure['system'].items():require(path,h)
   if snapshot(source)!=expected:raise ValueError('Source changed during probe')
  result['passed']=True
 except Exception as e:result['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
 finally:
  try:
   for path,h in pinned.items():require(path,h)
   for x in controls:require(x['path'],x['sha256'])
   for name,source,expected,rc in cases:
    if snapshot(source)!=expected:raise ValueError('Final complete source changed')
  except Exception as e:result['passed']=False;result['final_provenance_error']={'type':type(e).__name__,'message':str(e)}
  persist()
 print(json.dumps({'passed':result['passed'],'result':str(out/'result.json')}));return 0 if result['passed'] else 1
if __name__=='__main__':sys.exit(main())
