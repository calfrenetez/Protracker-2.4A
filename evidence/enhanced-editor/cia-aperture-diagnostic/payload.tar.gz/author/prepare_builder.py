from pathlib import Path
import json,hashlib
root=Path('/private/tmp/protracker-cia-aperture-8cku0nh5')
s=(root/'baseline/tools/build_scheduled_readers_test.py').read_text()
start=s.index('"""');end=s.index('"""',start+3)+3
s=s[:start]+'''"""Pinned one-target CIA aperture diagnostic compile/link check; never runs it.

The product contains owned-CIA timer/IRQ software-commit experiments, but this
builder establishes compilation only. No target resource ownership, IRQ-safe
WCET, timer precision, DMA/audio or hardware output is qualified by linking.
The original frame grid is retained. Native execution requires separate explicit
scope, fresh identity/ownership, stack assessment and cleanup/recovery gates.
"""'''+s[end:]
s=s.replace("SOURCES = ['tests/scheduled_readers_test.c', 'src/core/elapsed_clock.c']", "HOST_SOURCES = ['tests/cia_aperture_test.c', 'tests/cia_aperture_model.c', 'src/core/elapsed_clock.c']\nSOURCES = ['tests/native_exec_cia_aperture_test.c', 'tests/cia_aperture_model.c', 'src/core/elapsed_clock.c', 'tests/native_cia_aperture_irq.s']")
s=s.replace("TARGET = 'PTScheduledReadersTest'", "TARGET = 'PTExecCiaApertureTest'")
s=s.replace("MARKER = 'SCHEDULED READERS PASS: independent command detach and persistent reader retirement; 20 controls with command capacity2'", "MARKER = 'CIA APERTURE PASS: original-frame actual RAM commit brackets and zero-effect negative gates; timer/software diagnostic only, no DMA or audio proof'\nMODEL_MARKER = 'CIA APERTURE MODEL PASS: original windows, bounded actual reads, exact keys and irreversible postcommit failure; software diagnostic only'")
s=s.replace("host = source / 'tests/test_scheduled_readers.py'", "host = source / 'tests/test_cia_aperture.py'")
s=s.replace('if units != SOURCES or len(units) != len(set(units)):', 'if units != HOST_SOURCES or len(units) != len(set(units)):')
s=s.replace("    return {'committed_flag_recipe':", """    wrapper = (source / SOURCES[0]).read_text()
    if wrapper.count('#include "cia_aperture_test.c"') != 1 or '#define PT_APERTURE_EMBEDDED' not in wrapper:
        raise ValueError('Shared fixture must be embedded exactly once without assertion reinclusion')
    if SOURCES[:3] != ['tests/native_exec_cia_aperture_test.c', *HOST_SOURCES[1:]] or len(SOURCES) != len(set(SOURCES)):
        raise ValueError('Explicit native wrapper substitution/order changed')
    assembly = (source / SOURCES[3]).read_text()
    if re.search(r'^\\s*(?:\\.include|\\.incbin|#\\s*include)\\b', assembly, re.MULTILINE):
        raise ValueError('Assembly must have no untracked external include/incbin')
    return {'committed_flag_recipe':""")
s=s.replace("'host_declaration': record(host), 'exact_ordered_translation_units': SOURCES,", "'host_declaration': record(host), 'exact_ordered_host_units': HOST_SOURCES,\n            'exact_ordered_translation_units': SOURCES, 'assembly': record(source / SOURCES[3]),\n            'wrapper_substitution': 'Shared C fixture embedded exactly once by native wrapper; GAS .s is a separate fourth unit',")
s=s.replace("    require_pin(compiler, pins['compiler']['sha256'])\n    if set(pins['runtime_inputs'])", "    require_pin(compiler, pins['compiler']['sha256'])\n    assembler = pins['assembler']\n    require_pin(assembler['path'], assembler['sha256'])\n    if set(pins['runtime_inputs'])")
s=s.replace("'compiler': pins['compiler'], 'python': python, 'builder': builder,", "'compiler': pins['compiler'], 'assembler': assembler, 'python': python, 'builder': builder,")
s=s.replace("        require_pin(compiler, pins['compiler']['sha256'])\n        require_pin(python", "        require_pin(compiler, pins['compiler']['sha256'])\n        require_pin(assembler['path'], assembler['sha256'])\n        require_pin(python")
s=s.replace("        if '-fbbb=' not in run", "        actual_as = Path(run([compiler, '-print-prog-name=as'], 'assembler-path').strip()).resolve()\n        if actual_as != Path(assembler['path']).resolve():\n            raise ValueError('Compiler selected another assembler')\n        require_pin(actual_as, assembler['sha256'])\n        if '-fbbb=' not in run")
s=s.replace("text = run([compiler, *FLAGS, '-M', unit], 'dependencies-%02d' % index)", "dependency_flags = ['-x', 'assembler-with-cpp'] if unit.endswith('.s') else []\n            text = run([compiler, *FLAGS, *dependency_flags, '-M', unit], 'dependencies-%02d' % index)")
s=s.replace("if text.count(MARKER) != 1:\n            raise ValueError('Shared lineage fixture marker missing')", "if text.count(MARKER) != 1 or text.count(MODEL_MARKER) != 1:\n            raise ValueError('Both exact diagnostic completion markers required once')")
s=s.replace("if raw.count(MARKER.encode()) != 1:", "if raw.count(MARKER.encode()) != 1 or raw.count(MODEL_MARKER.encode()) != 1:")
s=s.replace("'last_assert_macro': assertion,", "'last_assert_macro': assertion, 'markers': [MARKER, MODEL_MARKER],\n                                     'hunk_executed': False, 'native_resource_or_timing_qualified': False,")
s=s.replace("'tests/test_scheduled_lineage.py'", "'tests/test_cia_aperture.py'")
(root/'candidate/tools/build_cia_aperture_diagnostic.py').write_text(s)
pins_origin=Path('/private/tmp/protracker-scheduled-readers-current-native-kd9zrg6c/toolchain-pins.json')
pins=json.loads(pins_origin.read_text())
aspath=Path('/Users/james1/Documents/Codex/2026-08-20/work-from-the-design-spec-v1/repo/.cache/amiga/bin/m68k-amigaos-as')
pins['native']['assembler']={'path':str(aspath),'bytes':aspath.stat().st_size,'sha256':hashlib.sha256(aspath.read_bytes()).hexdigest(), 'scope':'Read-only binary fingerprint; actual GCC assembler selection must match during authorized build'}
pins['cia_aperture_pin_origin']={'path':str(pins_origin),'bytes':pins_origin.stat().st_size,'sha256':hashlib.sha256(pins_origin.read_bytes()).hexdigest(),'change':'Only added native.assembler and this origin attribution; seven runtimes unchanged'}
(root/'toolchain-pins-aperture.json').write_text(json.dumps(pins,indent=2)+'\n')
