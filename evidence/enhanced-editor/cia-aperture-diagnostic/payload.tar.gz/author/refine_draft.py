from pathlib import Path
p=Path('/private/tmp/protracker-cia-aperture-8cku0nh5/candidate/tests/cia_aperture_model.h')
s=p.read_text().replace('unsigned entry_valid,before_valid,after_valid,reads,commits;', 'uint64_t last_read;uint32_t last_read_frequency;\n    unsigned last_read_valid,entry_valid,before_valid,after_valid,reads,commits;')
p.write_text(s)
p=Path('/private/tmp/protracker-cia-aperture-8cku0nh5/candidate/tests/cia_aperture_model.c')
s=p.read_text().replace('    *now=0;*frequency=0;++s->reads;\n    return read(context,now,frequency)==1;', '    int ok;\n    *now=0;*frequency=0;++s->reads;\n    ok=read(context,now,frequency)==1;\n    s->last_read=*now;s->last_read_frequency=*frequency;s->last_read_valid=(unsigned)ok;\n    return ok;')
p.write_text(s)
p=Path('/private/tmp/protracker-cia-aperture-8cku0nh5/candidate/tests/native_exec_cia_aperture_test.c')
s=p.read_text().replace('unsigned arm_count,mode;ULONG wake,calls,before_frequency,after_frequency;', 'unsigned arm_count,mode,phase,prepared,arm_valid,arm_after_valid,delivered;\n    ULONG wake,calls,before_frequency,after_frequency;')
start=s.index('#define HI(value)')
end=s.index('int main(void)',start)
s=s[:start]+'''#define HI(value) ((unsigned long)((value)>>32))
#define LO(value) ((unsigned long)(value))
/* Caller excludes the owned handler while copying. An unresolved-close record
 * is only this snapshot, never proof that the handler cannot run afterward. */
static void trace_snapshot(struct native_trace *entry,const struct native_irq *irq)
{
    if(irq->state!=&entry->state)return;
    entry->calls=irq->calls;
    entry->dispatch_before=((uint64_t)irq->dispatch_before.ev_hi<<32)|irq->dispatch_before.ev_lo;
    entry->dispatch_after=((uint64_t)irq->dispatch_after.ev_hi<<32)|irq->dispatch_after.ev_lo;
    entry->before_frequency=irq->dispatch_before_frequency;entry->after_frequency=irq->dispatch_after_frequency;
}
static void trace_report(const struct native_trace *trace,unsigned attempted,unsigned closed)
{
    unsigned i;
    for(i=0;i<attempted;++i) {
        const struct native_trace *e=trace+i;const struct pt_aperture_state *s=&e->state;
        unsigned dispatch_valid=e->before_frequency && e->after_frequency && e->dispatch_after>=e->dispatch_before;
        unsigned aperture_valid=s->entry_valid && s->last_read_valid && s->last_read>=s->entry;
        printf("CIA APERTURE OBS index=%u mode=%u phase=%u prepared=%u arm_valid=%u arm_after_valid=%u delivered=%u closed=%u result=%u first=%lu:%lu last=%lu:%lu arm_target=%lu:%lu arm_observed=%lu:%lu arm_after=%lu:%lu count=%u entry=%lu:%lu before=%lu:%lu after=%lu:%lu last_observed=%lu:%lu last_read=%lu:%lu last_read_frequency=%lu last_read_valid=%u valid=%u/%u/%u reads=%u commits=%u shadow=%lu aperture_span_valid=%u aperture_span=%lu:%lu dispatch_span_valid=%u dispatch_before=%lu:%lu dispatch_after=%lu:%lu dispatch_span=%lu:%lu dispatch_frequency=%lu/%lu wake=%lu calls=%lu\\n",
            i,e->mode,e->phase,e->prepared,e->arm_valid,e->arm_after_valid,e->delivered,closed,(unsigned)s->result,
            HI(s->first),LO(s->first),HI(s->last),LO(s->last),HI(e->arm_target),LO(e->arm_target),HI(e->arm_observed),LO(e->arm_observed),HI(e->arm_after),LO(e->arm_after),e->arm_count,
            HI(s->entry),LO(s->entry),HI(s->before),LO(s->before),HI(s->after),LO(s->after),HI(s->last_observed),LO(s->last_observed),HI(s->last_read),LO(s->last_read),
            (unsigned long)s->last_read_frequency,s->last_read_valid,s->entry_valid,s->before_valid,s->after_valid,s->reads,s->commits,(unsigned long)s->shadow,
            aperture_valid,HI(aperture_valid?s->last_read-s->entry:0),LO(aperture_valid?s->last_read-s->entry:0),
            dispatch_valid,HI(e->dispatch_before),LO(e->dispatch_before),HI(e->dispatch_after),LO(e->dispatch_after),
            HI(dispatch_valid?e->dispatch_after-e->dispatch_before:0),LO(dispatch_valid?e->dispatch_after-e->dispatch_before:0),
            (unsigned long)e->before_frequency,(unsigned long)e->after_frequency,(unsigned long)e->wake,(unsigned long)e->calls);
    }
    fflush(stdout);
}
''' + s[end:]
s=s.replace('unsigned i,completed=0,positive=0,failures=0,negative=0,acquired=0,chip=0,bit=0;', 'unsigned i,attempted=0,completed=0,positive=0,failures=0,negative=0,acquired=0,chip=0,bit=0;')
s=s.replace('struct native_trace *entry=trace+i;unsigned count;uint64_t observed;', 'struct native_trace *entry=trace+i;unsigned count=0;uint64_t observed=0;')
s=s.replace('entry->control.publication=i+1;entry->mode=i<12?0:i-11;', 'entry->control.publication=i+1;entry->mode=i<12?0:i-11;entry->phase=1;attempted=i+1;')
s=s.replace('entry->arm_target=entry->state.arm_at;', 'entry->prepared=1;entry->arm_target=entry->state.arm_at;')
s=s.replace('Disable();SetSignal(0,irq->signal);irq->state=&entry->state;irq->control=&entry->control;irq->armed=1;', 'Disable();SetSignal(0,irq->signal);irq->state=&entry->state;irq->control=&entry->control;irq->armed=1;\n        memset((void *)&irq->dispatch_before,0,sizeof(irq->dispatch_before));\n        memset((void *)&irq->dispatch_after,0,sizeof(irq->dispatch_after));\n        irq->dispatch_before_frequency=irq->dispatch_after_frequency=0;entry->phase=2;')
s=s.replace('entry->arm_observed=observed;entry->arm_count=count;', 'entry->arm_observed=observed;entry->arm_count=count;entry->arm_valid=1;entry->phase=3;')
s=s.replace('entry->arm_after=now;Enable();CHECK(actual_frequency==frequency);', 'entry->arm_after=now;entry->arm_after_valid=1;entry->phase=4;Enable();CHECK(actual_frequency==frequency);')
s=s.replace('wake=Wait(irq->signal|termination_mask|SIGBREAKF_CTRL_C);', 'entry->phase=5;wake=Wait(irq->signal|termination_mask|SIGBREAKF_CTRL_C);entry->wake=wake;')
a='''        entry->dispatch_before=((uint64_t)irq->dispatch_before.ev_hi<<32)|irq->dispatch_before.ev_lo;
        entry->dispatch_after=((uint64_t)irq->dispatch_after.ev_hi<<32)|irq->dispatch_after.ev_lo;
        entry->before_frequency=irq->dispatch_before_frequency;entry->after_frequency=irq->dispatch_after_frequency;
        Enable();++completed;'''
b='''        trace_snapshot(entry,irq);entry->delivered=1;entry->phase=6;
        Enable();++completed;'''
assert a in s;s=s.replace(a,b)
s=s.replace('    if(!pt_diagnostic_cia_close(&owner))return aperture_hold("owned timer/vector close unresolved");', '''    if(!pt_diagnostic_cia_close(&owner)) {
        if(irq && attempted){Disable();trace_snapshot(trace+attempted-1,irq);Enable();}
        trace_report(trace,attempted,0);return aperture_hold("owned timer/vector close unresolved");
    }
    if(irq && attempted){Disable();trace_snapshot(trace+attempted-1,irq);Enable();}
    trace_report(trace,attempted,1);''')
start=s.index('    for(i=0;i<completed;++i) {',s.index('CIA APERTURE CLOSED'))
end=s.index('    native_release(trace);',start)
s=s[:start]+s[end:]
p.write_text(s)
