from pathlib import Path
p=Path('/private/tmp/protracker-cia-aperture-8cku0nh5/candidate/tests/native_exec_cia_aperture_test.c');s=p.read_text()
s=s.replace('    ULONG wake,calls,before_frequency,after_frequency;', '    ULONG wake,calls,before_frequency,after_frequency;\n    uint32_t arm_frequency,arm_after_frequency;unsigned arm_read_valid,arm_reads;')
anchor='static int aperture_hold(const char *reason) __attribute__((noreturn));'
s=s.replace(anchor,'''struct task_arm_reader {struct pt_native_eclock *clock;uint64_t actual;uint32_t frequency;unsigned valid,reads;};
static int task_arm_clock(void *context,uint64_t *ticks,uint32_t *frequency)
{
    struct task_arm_reader *r=context;int ok;
    *ticks=0;*frequency=0;++r->reads;ok=pt_native_eclock_read(r->clock,ticks,frequency);
    r->actual=*ticks;r->frequency=*frequency;r->valid=ok?1U:0U;return ok;
}
'''+anchor)
s=s.replace('unsigned dispatch_valid=e->before_frequency && e->after_frequency && e->dispatch_after>=e->dispatch_before;', 'unsigned dispatch_valid=e->before_frequency==s->frequency && e->after_frequency==s->frequency && s->frequency && e->dispatch_after>=e->dispatch_before;')
s=s.replace('unsigned aperture_valid=s->entry_valid && s->last_read_valid && s->last_read>=s->entry;', 'unsigned aperture_valid=s->entry_valid && s->last_read_valid && s->entry_frequency==s->frequency && s->last_read_frequency==s->frequency && s->last_read>=s->entry;')
s=s.replace('arm_after=%lu:%lu count=%u entry=', 'arm_after=%lu:%lu arm_frequency=%lu/%lu arm_read_valid=%u arm_reads=%u count=%u entry=')
s=s.replace('HI(e->arm_after),LO(e->arm_after),e->arm_count,', 'HI(e->arm_after),LO(e->arm_after),(unsigned long)e->arm_frequency,(unsigned long)e->arm_after_frequency,e->arm_read_valid,e->arm_reads,e->arm_count,')
s=s.replace('struct native_trace *entry=trace+i;unsigned count=0;uint64_t observed=0;', 'struct native_trace *entry=trace+i;unsigned count=0;uint64_t observed=0;int armed,read_ok;\n        struct task_arm_reader arm_reader={&clock,0,0,0,0};')
a='''        if(!pt_diagnostic_cia_arm_at(&owner,pt_native_eclock_read,&clock,entry->arm_target,frequency,&observed,&count)) {
            irq->armed=0;Enable();CHECK(0);
        }
        entry->arm_observed=observed;entry->arm_count=count;entry->arm_valid=1;entry->phase=3;
        if(!pt_native_eclock_read(&clock,&now,&actual_frequency)) {irq->armed=0;Enable();CHECK(0);}
        entry->arm_after=now;entry->arm_after_valid=1;entry->phase=4;Enable();CHECK(actual_frequency==frequency);'''
b='''        armed=pt_diagnostic_cia_arm_at(&owner,task_arm_clock,&arm_reader,entry->arm_target,frequency,&observed,&count);
        entry->arm_observed=arm_reader.actual;entry->arm_frequency=arm_reader.frequency;
        entry->arm_read_valid=arm_reader.valid;entry->arm_reads=arm_reader.reads;
        if(!armed) {irq->armed=0;Enable();CHECK(0);}
        entry->arm_count=count;entry->arm_valid=1;entry->phase=3;
        now=0;actual_frequency=0;read_ok=pt_native_eclock_read(&clock,&now,&actual_frequency);
        entry->arm_after=now;entry->arm_after_frequency=actual_frequency;entry->arm_after_valid=read_ok?1U:0U;
        if(!read_ok) {irq->armed=0;Enable();CHECK(0);}
        entry->phase=4;Enable();CHECK(actual_frequency==frequency);'''
assert a in s;s=s.replace(a,b);p.write_text(s)
