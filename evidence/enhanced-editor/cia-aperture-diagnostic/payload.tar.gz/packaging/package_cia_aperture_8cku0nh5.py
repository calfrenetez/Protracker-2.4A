#!/usr/bin/env python3
"""Host-only lossless CIA aperture proof packet; no producer imports/subprocesses."""
import argparse,gzip,hashlib,io,json,os,stat,tarfile
from pathlib import Path,PurePosixPath
A=Path('/private/tmp/protracker-cia-aperture-8cku0nh5')
N=Path('/private/tmp/protracker-cia-aperture-current-native-243nfher')
P=Path('/private/tmp/protracker-cia-aperture-owner-probe-final-8cku0nh5')
D=Path('/private/tmp/protracker-native-conditional-design-zdwa84b3')
O=Path('/private/tmp/protracker-cia-aperture-evidence-final-8cku0nh5')
G=Path('/private/tmp/protracker-cia-aperture-packet-derived-8cku0nh5')
QA=Path('/private/tmp/protracker-cia-aperture-evidence-final-8cku0nh5-qa.json')
REVIEWS=[
'/private/tmp/protracker-cia-aperture-builder-abi-independent-review-1791073285715125000.json',
'/private/tmp/protracker-cia-aperture-draft-independent-review-1791073447403275000.json',
'/private/tmp/protracker-cia-aperture-host-independent-review-1791074060205070000.json',
'/private/tmp/protracker-cia-aperture-host-export-independent-review-1791074061624341000.json',
'/private/tmp/protracker-cia-aperture-native-actual-independent-review-1791074286094090000.json']
PIN_REVIEW='33d8b9a2d6cba9a52800d1d09800fc00cf1fd4bcd4c7358836faf4671454ca60'
def sha(b):return hashlib.sha256(b).hexdigest()
def data(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
 return p.read_bytes()
def j(p):return json.loads(data(p))
def writej(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def safe(n):
 p=PurePosixPath(n);assert n and not p.is_absolute() and str(p)==n and all(x not in ('..','.') for x in p.parts)
def ident(p):
 p=Path(p);b=data(p);return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.lstat().st_mode)}
def checkrecord(r):
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'],r['path']
 if 'bytes' in r:assert len(b)==r['bytes'],r['path']
def full(root,expected):
 actual={str(p.relative_to(root)):sha(data(p)) for p in root.rglob('*') if p.is_file()}
 assert actual==expected,(str(root),len(actual),len(expected));return len(actual)
def main():
 assert not O.exists() and not G.exists() and not QA.exists(),'fresh output required'
 ah=j(A/'source-manifest.json');nm=j(N/'source-manifest-native.json');h=j(A/'host-final/host-checks.json');n=j(N/'native-final-v1/manifest.json');probe=j(P/'result.json')
 assert sha(data(REVIEWS[-1]))==PIN_REVIEW
 assert n['passed'] and h['passed'] and probe['passed']
 target=n['targets']['PTExecCiaApertureTest'];assert target['hunk_executed'] is False and target['native_resource_or_timing_qualified'] is False
 assert target['binary']['bytes']==47576 and target['binary']['sha256']=='f9441121833d46ddd1d3b96c1677576414fa14e78d3a638d93d91246ee69f007'
 assert len(n['commands'])==16 and all(c['returncode']==0 for c in n['commands'])
 assert len(h['commands'])==4 and all(c['product_returncode']==0 for c in h['commands'])
 assert len(h['canonical_dependencies'])==7 and len(h['external_sdk_dependencies'])==61
 assert len(target['dependencies'])==12 and len(target['external_sdk_dependencies'])==70
 assert len(target['source_inputs'])==4 and len(n['runtime_inputs'])==7
 assert [c['actual_returncode'] for c in probe['cases']]==[20,0]
 assert len(ah['baseline_files'])==8012 and len(ah['files'])==8020 and len(nm['files'])==8025
 before=[full(A/'baseline',ah['baseline_files']),full(A/'source-final',ah['files']),full(N/'source-final-native',nm['files'])]
 members={};originals={}
 def add(name,p,role):
  safe(name);p=Path(p);assert name not in members,name
  r=ident(p);r.update({'name':name,'role':role,'derivation':'exact original bytes'})
  members[name]=r;originals[name]=data(p)
 def tree(prefix,root,role):
  for p in sorted(root.rglob('*')):
   if p.is_file():add(prefix+'/'+str(p.relative_to(root)),p,role)
 # Complete proof trees, excluding unrecorded optional debug symbol directories.
 tree('records/host',A/'host-final','Final host ASan/UBSan command/dependency/log/product original')
 tree('records/native',N/'native-final-v1','One actual native compiler/assembler build original; HUNK NOT RUN')
 for p in sorted(P.iterdir()):
  if p.is_file():add('records/probe/'+p.name,p,'Identical running-mask probe original: baseline expected RC20, corrected RC0')
 for p in sorted(A.iterdir()):
  if p.is_file():add('author/'+p.name,p,'Author frozen proof, attribution or unexecuted preparation history; original bytes')
 for sub in ['history-audit','history-before-owner-fix','owner-probe','tools-host']:
  tree('author/'+sub,A/sub,'Author helper/probe or original before-image/history; exact original bytes')
 for p in [N/'source-manifest-native.json',N/'root-export-review.json',N/'native-build-root-invocation.json',N/'native-build-root.log',N/'toolchain-pins.json']:
  add('root/'+p.name,p,'Root fresh current-85a export/build attribution or actual compiler invocation')
 for p in REVIEWS:add('reviews/'+Path(p).name,p,'Independent saved read-only scope/source/proof review')
 for p in sorted(D.iterdir()):
  if p.is_file():add('design/'+p.name,p,'Earlier read-only native conditional feasibility proposal; not timing proof')
 # Preserve all own source and every actual canonical compiled dependency.
 own=[r['path'] for r in ah['owned_overlays']]
 hostset=set(h['canonical_dependencies'])|{str(Path(r['path']).relative_to(A/'source-final')) for r in h['module_inputs']}|set(own)
 for name in sorted(hostset):add('source/host-final/'+name,A/'source-final'/name,'Exact final host/own source or executed Python declaration')
 basenames={name for case in probe['cases'] for name in case['dependencies']['canonical']}
 for name in sorted(basenames):add('source/probe-baseline/'+name,A/'baseline'/name,'Exact original source used by expected-failure baseline probe')
 nativeset=set(target['dependencies'])|set(own)|{'tools/build_core_tests.py','tools/build_diagnostic.py','tests/test_cia_owner.py'}
 for name in sorted(nativeset):add('source/native-final/'+name,N/'source-final-native'/name,'Exact fresh native canonical closure/AST recipe or own input')
 # Required original recipe/declarations also present in old accepted host baseline.
 for name in ['tools/build_core_tests.py','tools/build_diagnostic.py','tests/test_cia_owner.py']:
  add('source/host-final/'+name,A/'source-final'/name,'Accepted-source original recipe/declaration; never executed for shared native build') if 'source/host-final/'+name not in members else None
 tree('history/prior-cia-critical-failure',A/'baseline/evidence/enhanced-editor/cia-critical-native','Prior distinct critical-arm failed native qualification/recovery originals; failure remains')
 # Probe/host/native pins are checked on their explicit current filesystem paths; SDK/toolchain trees are not copied.
 for r in h['products']:checkrecord({'path':r['archive_path'],'bytes':r['bytes'],'sha256':r['sha256']})
 for r in h['helper_inputs']+h['module_inputs']:checkrecord(r)
 for name,v in h['external_sdk_dependencies'].items():checkrecord({'path':name,'sha256':v})
 for r in [h['compiler'],h['python'],n['compiler'],n['python'],n['selected_assembler']]:checkrecord(r)
 for name,v in h['sanitizer_runtime_inputs'].items():checkrecord({'path':name,'sha256':v})
 for name,v in target['external_sdk_dependencies'].items():checkrecord({'path':name,'sha256':v})
 for name,v in n['runtime_inputs'].items():checkrecord({'path':n['runtime_paths'][name],'sha256':v})
 for case in probe['cases']:
  checkrecord(case['binary'])
  for name,v in case['dependencies']['system'].items():checkrecord({'path':name,'sha256':v})
 for c in h['commands']:
  checkrecord(c['output_log'])
  for d in c['dependency_commands']:assert d['returncode']==0;checkrecord(d['output'])
 for c in n['commands']+probe['commands']:checkrecord(c['log'])
 # Derive a complete inventory from the exact huge original committed archive without extracting it.
 archive=N/'committed-export.tar';archive_id=ident(archive)
 assert archive_id['sha256']=='c28a69c53fa1dfb18c72f2765ba91ca72c27c51fdbfd7e46cf337a5cb66bbfef'
 inv={}
 with tarfile.open(archive,'r:') as tf:
  for m in tf:
   if m.isdir():continue
   assert m.isfile() and not m.issym() and not m.islnk();safe(m.name);assert m.name not in inv
   b=tf.extractfile(m).read();assert len(b)==m.size
   inv[m.name]={'bytes':m.size,'sha256':sha(b),'mode':m.mode}
 assert len(inv)==8017
 ownmap={r['path']:r for r in ah['owned_overlays']}
 for name,r in inv.items():
  if name in ownmap:
   assert ownmap[name]['before_sha256']==r['sha256']
  else:assert nm['files'][name]==r['sha256'],name
 assert set(nm['files'])-set(inv)==set(own)-set(inv)
 G.mkdir()
 inventory=G/'committed-85a-archive-inventory.json';writej(inventory,{'scope':'Derived by read-only tar reader from exact original committed-85a archive; no extraction or source execution','archive_origin':archive_id,'base_commit':nm['base_commit'],'base_tree':nm['base_tree'],'regular_files':inv})
 add('derived/committed-85a-archive-inventory.json',inventory,'Derived complete committed archive member inventory; original archive omitted')
 members['derived/committed-85a-archive-inventory.json']['derivation']='Complete read-only tar member hash/bytes/mode inventory; not an exact copy of the omitted tar'
 add('packaging/'+Path(__file__).name,Path(__file__),'Exact host-only packet writer source; not a product/runtime helper')
 # Deterministic USTAR, fixed owners/time, original modes, regular files only.
 def build():
  buf=io.BytesIO()
  with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tf:
   for name,r in sorted(members.items()):
    b=originals[name];t=tarfile.TarInfo(name);t.size=len(b);t.mode=r['mode'];t.uid=t.gid=t.mtime=0;t.uname=t.gname='';tf.addfile(t,io.BytesIO(b))
  return gzip.compress(buf.getvalue(),compresslevel=9,mtime=0)
 payload=build();assert build()==payload
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  seen=set()
  for t in tf:
   assert t.isfile() and t.name not in seen and t.name in members
   r=members[t.name];b=tf.extractfile(t).read();assert b==originals[t.name] and sha(b)==r['sha256'] and len(b)==r['bytes'] and t.mode==r['mode']
   assert t.uid==t.gid==t.mtime==0 and t.uname==t.gname=='';seen.add(t.name)
  assert seen==set(members)
 after=[full(A/'baseline',ah['baseline_files']),full(A/'source-final',ah['files']),full(N/'source-final-native',nm['files'])];assert after==before
 for name,r in members.items():assert data(r['path'])==originals[name]
 O.mkdir();(O/'payload.tar.gz').write_bytes(payload)
 manifest={'schema':1,'scope':'CIA aperture host-model/ownership correction and one native compile/link only; native diagnostic NOT RUN','acceptance':{'host_groups':2,'host_RC0_commands':4,'host_full_M_queries':4,'host_canonical_inputs':7,'host_system_inputs':61,'host_products':2,'probe_baseline_expected_RC20':True,'probe_corrected_RC0':True,'native_RC0_commands':16,'native_ordered_TUs':4,'native_full_M_queries':4,'native_canonical_inputs':12,'native_SDK_inputs':70,'native_runtimes':7,'native_binary':target['binary'],'native_run':False,'timing_WCET_stack_device_qualified':False},'source_inventories':{'accepted_baseline':8012,'host_final':8020,'fresh_native_final':8025,'derived_committed_85a':8017,'own_new':8,'own_modified':2},'large_origin_omitted':archive_id,'omitted':'Full source export trees, SDK/compiler/runtime trees and unreferenced probe dSYM directories; exact inventories and pin controls remain','deterministic_archive':{'format':'USTAR + gzip','uid':0,'gid':0,'mtime':0,'owners':'empty','modes':'exact origin file mode','second_write_byte_identical':True},'members':[members[k] for k in sorted(members)],'members_count':len(members),'original_member_bytes':sum(r['bytes'] for r in members.values()),'payload':{'path':'payload.tar.gz','bytes':len(payload),'sha256':sha(payload)}}
 writej(O/'manifest.json',manifest)
 (O/'README.md').write_text(README)
 (O/'verify_payload.py').write_text(VERIFY)
 sums=''.join(f"{sha(data(O/name))}  {name}\n" for name in ['README.md','manifest.json','payload.tar.gz','verify_payload.py']);(O/'SHA256SUMS').write_text(sums)
 assert len(list(O.iterdir()))==5
 rows=(O/'SHA256SUMS').read_text().splitlines();assert len(rows)==4
 for row in rows:
  v,name=row.split('  ',1);assert sha(data(O/name))==v
 writej(QA,{'scope':'Packet integrity only; no producer helper imports/tests/compiler/HUNK/target execution','passed':True,'controls':[ident(p) for p in sorted(O.iterdir())],'members':len(members),'original_member_bytes':manifest['original_member_bytes'],'safe_unique_regular_members':True,'exact_origin_bytes_modes_verified':True,'deterministic_second_payload_identical':True,'complete_source_before_after':before,'omitted_large_archive':archive_id,'derived_archive_member_count':len(inv),'native_diagnostic_NOT_RUN':True})
 print(json.dumps({'passed':True,'packet':str(O),'QA':ident(QA),'members':len(members),'member_bytes':manifest['original_member_bytes'],'payload_bytes':len(payload),'payload_sha256':sha(payload),'total_controls_bytes':sum(p.stat().st_size for p in O.iterdir())},indent=2))
README='''# CIA deadline-aperture diagnostic evidence

The two scoped ASan/UBSan host groups passed. The identical enabled-running-timer probe preserves the original expected RC20 defect and the corrected RC0 result. The fix refuses a running CIA timer before adding/removing its vector or changing its interrupt mask. Complete source and mask/control/vector before-images remain in the packet.

The single pinned 68k compiler/assembler build passed all 16 commands. Its four ordered translation units, 12 canonical dependencies, 70 SDK dependencies, seven runtimes, selected assembler, active SDK assertions, 11 C/GAS offset checks and both literal markers are recorded. The HUNK is 47,576 bytes, SHA256 `f9441121833d46ddd1d3b96c1677576414fa14e78d3a638d93d91246ee69f007`.

**The HUNK has not been run.** Native timer ownership/restoration, the provisional Stack262144, actual scheduling, total IRQ residency/WCET, sample-reader transfer, DMA, audio and physical-device behavior are unqualified. The assembly clock bracket measures dispatcher/aperture work and excludes its ABI prefix and Signal/epilogue. Finite reads and observed spans cannot prove total IRQ WCET.

The software diagnostic keeps the original frame epoch/window. It brackets one RAM shadow-word write with actual clock reads. Precommit refusal has zero writes; a late or otherwise invalid postcommit check remains a failure after one irreversible write. Synthetic keys do not provide a native scheduled-output capability. The earlier critical-arm failure with 44–47 tick lateness remains failed and is preserved separately; no timing compensation or rebased deadline is introduced.

Host proof uses the accepted 8,012-file compiled-input baseline plus eight new files and two corrected ownership files (8,020 final files). Native proof uses a distinct clean committed `85a34d27296248ac8d9a7d61b54ee032eace7265` archive (8,017 files) plus the same ten overlays (8,025 final files). Exact original inventories, root attribution, six common host/native compiled inputs, host-only `cia_owner_test.c`, declarations and standalone AST-read recipes remain separate. The complete committed archive inventory is derived by a read-only tar reader; the large original archive/export/SDK trees are omitted. Root's later status prose and source commit are not silently substituted for the frozen build inputs.

`manifest.json` lists every member's original path, role, exact hash, byte length and mode. Originals are copied unchanged; the single derived archive inventory is labelled. The deterministic regular-file USTAR/gzip payload was independently read back and constructed twice identically. Original draft preparations, owner before-images, auxiliary author-audit path/schema failures and saved independent reviews are retained. Those auxiliary failures did not repeat product tests or change accepted records. No native fixture, compiler or product test was rerun while packaging.

Run `python3 -B verify_payload.py` for archive/control integrity without extraction, eval or producer imports. Optional `--origins` also compares members to still-available original private files. Original historical commands retain their absolute preparation locations; moving the packet alone does not make those paths runnable. The verifier proves packet integrity, not timing or hardware acceptance.
'''
VERIFY='''#!/usr/bin/env python3
"""Verify packet bytes without producer imports, archive extraction or execution."""
import argparse,hashlib,json,stat,tarfile
from pathlib import Path,PurePosixPath

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--origins',action='store_true');args=ap.parse_args()
 root=Path(__file__).resolve().parent
 names={'README.md','manifest.json','payload.tar.gz','verify_payload.py','SHA256SUMS'}
 assert {p.name for p in root.iterdir()}==names
 rows=(root/'SHA256SUMS').read_text().splitlines();seen=set()
 for row in rows:
  digest,name=row.split('  ',1);assert name in names-{'SHA256SUMS'} and name not in seen
  p=root/name;assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink() and sha(p.read_bytes())==digest;seen.add(name)
 assert seen==names-{'SHA256SUMS'}
 m=json.loads((root/'manifest.json').read_text());rows=m['members'];expected={r['name']:r for r in rows};assert len(expected)==len(rows)==m['members_count']
 payload=root/'payload.tar.gz';assert payload.stat().st_size==m['payload']['bytes'] and sha(payload.read_bytes())==m['payload']['sha256']
 found=set();total=0
 with tarfile.open(payload,'r:gz') as tf:
  for t in tf:
   p=PurePosixPath(t.name);assert t.isfile() and not p.is_absolute() and str(p)==t.name and all(v not in ('.','..') for v in p.parts)
   assert t.name in expected and t.name not in found
   r=expected[t.name];b=tf.extractfile(t).read()
   assert len(b)==t.size==r['bytes'] and sha(b)==r['sha256'] and t.mode==r['mode']
   assert t.uid==t.gid==t.mtime==0 and t.uname==t.gname==''
   if args.origins:
    origin=Path(r['path']);s=origin.lstat();assert stat.S_ISREG(s.st_mode) and not origin.is_symlink() and stat.S_IMODE(s.st_mode)==r['mode'] and origin.read_bytes()==b
   found.add(t.name);total+=len(b)
 assert found==set(expected) and total==m['original_member_bytes']
 print(json.dumps({'passed':True,'members':len(found),'member_bytes':total,'origins_checked':args.origins,'scope':'Archive/control integrity only; native diagnostic NOT RUN'},sort_keys=True))
if __name__=='__main__':main()
'''
if __name__=='__main__':main()
