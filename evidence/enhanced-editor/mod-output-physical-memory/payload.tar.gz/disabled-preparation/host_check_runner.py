#!/usr/bin/env python3
"""Private host-only author proof: file/Git reads and dependency-injected mocks."""
import hashlib,json,pathlib,subprocess,time,sys
root=pathlib.Path('/private/tmp/protracker-mod-physical-prepared-yn29dvhf')
py=pathlib.Path('/opt/homebrew/opt/python@3.14/bin/python3.14')
expected_py='60ab7f8bb944386c0022689716e405a77117111d65110532a1889d713dddf757'
def h(data):return hashlib.sha256(data).hexdigest()
def record(path):
 b=pathlib.Path(path).read_bytes();return {'bytes':len(b),'sha256':h(b)}
assert h(py.read_bytes())==expected_py
out=root/'host-checks-v1';out.mkdir()
plan=json.loads((root/'plan.json').read_text())
paths=set(plan['pinned_files']) | {str(root/n) for n in ['physical_mod_stream.py','test_prepared_guards.py','plan.json','origin.json','exact-emulator-qualification.json','emulator-independent-review.json','emulator-separate-idle-result.json','emulator-coordinator-release122.json']}
paths |= {str(pathlib.Path(plan['immutable_source'])/n) for n in plan['source_dependencies']}
paths |= {str(pathlib.Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')/n) for n in plan['source_dependencies']}
before={path:record(path) for path in sorted(paths)}
(root/'host-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
proof={'scope':'Host-only synthetic orchestration checks and saved source/toolchain/emulator receipt reads; no actual target/network/locks/Guest/process discovery/browser/coordination/native execution','physical_execution_ready':False,'physical_NOT_RUN':True,'python':{'path':str(py),**record(py)},'inputs_before':before,'commands':[],'passed':False}
def run(label,args):
 row={'label':label,'argv':args,'cwd':str(root),'complete':False}
 proof['commands'].append(row)
 started=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr,timeout=45)
 row.update(returncode=result.returncode,complete=True,elapsed_s=time.monotonic()-started,stdout={'path':str(out/(label+'.stdout')),**record(out/(label+'.stdout'))},stderr={'path':str(out/(label+'.stderr')),**record(out/(label+'.stderr'))})
 (out/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
 if result.returncode:raise RuntimeError(label+' host check refused; original result/logs preserved')
run('synthetic',[str(py),'-I','-B',str(root/'test_prepared_guards.py')])
run('source-only',[str(py),'-I','-B',str(root/'physical_mod_stream.py'),'--verify-source-only'])
code="import importlib.util,json,pathlib; r=pathlib.Path("+repr(str(root))+");s=importlib.util.spec_from_file_location('private_prepared',r/'physical_mod_stream.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p);plan=json.loads((r/'plan.json').read_text());print(json.dumps({'passed':True,'scope':'Saved exact MOD emulator qualification/release/source byte checks only; no live ownership inferred','physical_execution_ready':False,'physical_NOT_RUN':True,'host_qualification':p.host_qualification(plan,plan['emulator_qualification'],plan['emulator_qualification_sha256'])},indent=2))"
run('saved-receipt',[str(py),'-I','-B','-c',code])
after={path:record(path) for path in sorted(paths)}
proof['inputs_after']=after;proof['input_count']=len(before);proof['inputs_unchanged']=before==after
assert before==after
proof['passed']=True
proof['mock_result']=json.loads((root/'host-mock-proof.json').read_text())
proof['source_result']=json.loads((out/'source-only.stdout').read_text())
proof['saved_receipt_result']=json.loads((out/'saved-receipt.stdout').read_text())
proof['author_harness']={'path':str(pathlib.Path(__file__)),**record(__file__)}
(out/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'passed':True,'input_count':len(before),'commands':len(proof['commands']),'mock_methods':proof['mock_result']['tests'],'current_commit':proof['source_result']['host_inputs']['current_source_commit'],'report':str(out/'result.json')},indent=2))
