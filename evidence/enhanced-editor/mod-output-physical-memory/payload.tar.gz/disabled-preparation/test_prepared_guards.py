"""Host synthetic tests ONLY; never import central live APIs or touch locks."""
import asyncio
import ast
import importlib.util
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prepared_physical', HERE / 'physical_mod_stream.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
PLAN = json.loads((HERE / 'plan.json').read_text());PLAN['emulator_fast_allocations']=13
BINARY = Path(PLAN['binary'])
LOG = b'EXEC MEMORY pool_limit=130734232 reserve=262144 flags=4\nMOD OUTPUT PRESERVATION PASS: analysis and direct/round8/TPDF/playback outputs, all source tables and full 8/16/24-bit capacities, mutual outputs, fail-closed capacity/address spans, refusal precedence and unchanged streamed/padded bytes\nMOD STREAM PASS: direct/round8/TPDF exact multi-block bytes, legacy headers, loops, 65 patterns, source and destination protection; workspace=7164\nEXEC MEMORY PASS: 13 Fast allocations, zero owned bytes, budget refusal without Chip fallback\n'



class Fake:
    def __init__(self, fault=None):
        self.plan, self.fault = PLAN, fault
        self.target, self.calls, self.connections = 'amiberry-030', [], []
        self.clock, self.inventory_calls, self.guards = 0.0, 0, 0

    def guard_original(self, local=False):
        self.guards += 1
        if self.fault == 'original' and self.guards == 4:
            raise RuntimeError('original changed')
        return {'synthetic': True}

    def require_target(self, name):
        p.require(self.target == name, 'wrong target')
        return {'host': name, 'connected': True}

    async def connect(self, name):
        self.connections.append(name)
        if self.fault == 'connect' or (self.fault == 'return' and name == 'amiberry-030'):
            raise RuntimeError('synthetic unknown connection')
        self.target = name

    def checksum(self, text, data):
        if self.fault == 'checksum':
            raise RuntimeError('bad CRC/size')

    async def pause(self, seconds):
        if self.fault != 'no-observed-time':self.clock += seconds

    async def call(self, name, arguments):
        self.calls.append((name, arguments))
        if self.fault != 'no-observed-time':self.clock += 0.1
        if name == 'amiga_checksum':
            return 'synthetic checksum'
        if name == 'amiga_push_file':
            if self.fault == 'upload':
                raise TimeoutError('synthetic upload incomplete')
            return 'synthetic pushed'
        if name == 'amiga_pull_file':
            target = Path(arguments['local_path'])
            data = LOG if arguments['amiga_path'].endswith('/mod.log') else BINARY.read_bytes()
            if self.fault == 'readback' and target.name == 'staged-readback.bin':
                data = b'wrong'
            if self.fault == 'log' and target.name == 'mod.log':
                data = LOG.replace(b'13 Fast allocations', b'12 Fast allocations')
            target.write_bytes(data)
            return 'synthetic pulled'
        script = arguments['script']
        if 'PTG-PHYSICAL-IDENTITY-DONE' in script:
            return ('68020' if self.fault == 'identity' else '68030') + "\n192.168.0.156 (on interface 'plipbox')\nPTG-PHYSICAL-IDENTITY-DONE\n"
        if 'PTG-FRESH-ABSENT' in script:
            return '' if self.fault == 'existing' else 'PTG-FRESH-ABSENT\n'
        if 'PTG-DIRECTORY-CREATED' in script:
            return 'PTG-DIRECTORY-CREATED\n'
        if 'PTG-FILES-BEGIN' in script:
            self.inventory_calls += 1
            names = [[], [p.NAME], [p.NAME, 'mod.log']][self.inventory_calls - 1]
            if self.fault == 'unexpected' and self.inventory_calls == 2:
                names += ['foreign.file']
            if self.fault == 'temporary' and self.inventory_calls == 3:
                names += ['foreign.tmp']
            directories = [p.NAME] if self.fault == 'directory' and self.inventory_calls == 2 else []
            return ('PTG-FILES-BEGIN\n' + ''.join(x + '\n' for x in names) + 'PTG-FILES-END\nPTG-DIRS-BEGIN\n' +
                    ''.join(x + '\n' for x in directories) + 'PTG-DIRS-END\n')
        if 'Stack 65536' in script:
            if self.fault == 'native-timeout':
                raise TimeoutError('synthetic native still running')
            return 'PTG-MOD-RC ' + ('20' if self.fault == 'native-fail' else '0') + '\nPTG-MOD-DONE\n'
        if 'PTG-CLEANUP-ABSENT' in script:
            if self.fault == 'cleanup':
                raise TimeoutError('synthetic cleanup unknown')
            return 'PTG-CLEANUP-ABSENT\n'
        if 'PTG-INDEPENDENT-ABSENT-' in script:
            marker = script.split('Echo ')[-1].strip()
            return '' if self.fault == 'absence' and marker.endswith('-3') else marker + '\n'
        raise AssertionError('Unexpected fake call: ' + repr((name, arguments)))


class PreparedGuards(unittest.TestCase):
    def transaction(self, fault=None, seconds=300):
        with tempfile.TemporaryDirectory(prefix='ptg-mock-', dir='/private/tmp') as temp:
            out = Path(temp) / 'physical-mod-stream-123456789'
            out.mkdir()
            backend = Fake(fault)
            budget = p.Budget(seconds, lambda: backend.clock)
            result = {'passed': False, 'recovery_hold': False, 'target_switch_attempted': False}
            error = None
            try:
                asyncio.run(p.transaction(out, BINARY, backend, result, budget))
            except BaseException as caught:
                error = caught
            return backend, result, error

    def test_complete_one_case(self):
        backend, result, error = self.transaction()
        self.assertIsNone(error)
        self.assertTrue(result['passed'])
        self.assertFalse(result['recovery_hold'])
        self.assertEqual(result['native_launches'], 1)
        self.assertEqual(backend.connections, ['real-a1200', 'amiberry-030'])
        self.assertEqual(len(result['physical_absence_observations']), 11)
        self.assertGreater(result['physical_absence_seconds'], 10)
        completed = [row['completed_elapsed_seconds'] for row in result['physical_absence_observations']]
        self.assertEqual(result['physical_absence_seconds'], completed[-1] - completed[0]);self.assertTrue(all(row['completed'] is True for row in result['physical_absence_observations']))
        native = [a for n, a in backend.calls if n == 'amiga_run_script' and 'Stack 65536' in a['script']]
        self.assertEqual(len(native), 1)
        self.assertEqual(native[0]['timeout'], 90)
        self.assertIn(p.NAME + ' sample.mod >mod.log\n', native[0]['script'])
        self.assertEqual(result['native_markers']['fast_allocations'], 13)
        self.assertEqual(result['native_markers']['bounded_file_workspace'], 7164)
        self.assertFalse(any('chip' in key.lower() for key in result['native_markers']))
        identity_index = next(i for i, (n,a) in enumerate(backend.calls) if n == 'amiga_run_script' and 'PTG-PHYSICAL-IDENTITY-DONE' in a['script'])
        bridge_index = next(i for i, (n,a) in enumerate(backend.calls) if n == 'amiga_checksum' and a['path'] == PLAN['bridge_path'])
        mkdir_index = next(i for i, (n,a) in enumerate(backend.calls) if n == 'amiga_run_script' and 'MakeDir ' in a['script'])
        push_index = next(i for i, (n,a) in enumerate(backend.calls) if n == 'amiga_push_file')
        self.assertLess(identity_index, bridge_index)
        self.assertLess(bridge_index, mkdir_index)
        self.assertLess(mkdir_index, push_index)
        deletes = [a['script'] for n, a in backend.calls if n == 'amiga_run_script' and 'Delete ' in a['script']]
        self.assertEqual(len(deletes), 1)
        self.assertEqual(deletes[0].count('Delete '), 3)
        self.assertNotIn(' ALL', deletes[0])
        self.assertNotIn('#?', deletes[0])

    def test_preselection_budget_refusal(self):
        backend, result, error = self.transaction(seconds=180)
        self.assertIsNotNone(error)
        self.assertFalse(result['target_switch_attempted'])
        self.assertFalse(result['recovery_hold'])
        self.assertEqual(backend.connections, [])

    def test_all_failures_stop_and_retain_no_retry(self):
        for fault in ['connect', 'identity', 'existing', 'upload', 'checksum', 'readback', 'unexpected', 'directory', 'native-timeout', 'native-fail', 'log', 'temporary', 'cleanup', 'absence', 'return', 'original']:
            with self.subTest(fault=fault):
                backend, result, error = self.transaction(fault)
                self.assertIsNotNone(error)
                self.assertFalse(result['passed'])
                self.assertTrue(result['recovery_hold'])
                self.assertLessEqual(result['native_launches'], 1)
                self.assertEqual(backend.connections.count('real-a1200'), 1)
                if fault != 'return':
                    self.assertNotIn('amiberry-030', backend.connections)
                if fault in ['native-fail', 'native-timeout', 'log', 'temporary']:
                    self.assertFalse(any('Delete ' in a.get('script', '') for _, a in backend.calls))
                if fault == 'native-timeout':
                    self.assertTrue(result['native_running_or_unknown'])
                if fault == 'absence':
                    self.assertEqual(len(result['physical_absence_observations']), 4)
                    self.assertFalse(result['physical_absence_observations'][-1]['completed'])

    def test_inventory_and_marker_negative_controls(self):
        for text in ['PTG-FILES-BEGIN\nextra\nPTG-FILES-END\nPTG-DIRS-BEGIN\nPTG-DIRS-END\n',
                     'PTG-FILES-END\nPTG-FILES-BEGIN\nPTG-DIRS-BEGIN\nPTG-DIRS-END\n',
                     'PTG-FILES-BEGIN\nPTG-FILES-BEGIN\nPTG-FILES-END\nPTG-DIRS-BEGIN\nPTG-DIRS-END\n',
                     'PTG-FILES-BEGIN\nPTG-FILES-END\nPTG-DIRS-BEGIN\nproject.log\nPTG-DIRS-END\n']:
            with self.assertRaises(RuntimeError):
                p.inventory(text, [])
        for bad in [LOG + b'extra\n', LOG.replace(b'workspace=7164', b'workspace=7165'), LOG.replace(b'zero owned bytes', b'owned bytes unknown')]:
            with self.assertRaises(RuntimeError):
                p.native_log(bad)

    def test_root_gate_exact_scope_and_freshness(self):
        with tempfile.TemporaryDirectory(prefix='mod-gate-MOCK-', dir='/private/tmp') as temp:
            path = Path(temp) / 'gate.json';now = datetime.now(timezone.utc)
            identity = {'process': [900001, 'MOCK sole full command, not a real target'], 'profile_sha256': 'mock-profile-sha'}
            base = {'scope': p.SCOPE, 'target': 'real-a1200', 'candidate_sha256': p.SHA,
                    'original_process': identity['process'], 'original_profile_sha256': identity['profile_sha256'],
                    'no_conflicting_claims': True, 'recovery_holds_clear': True, 'safari_view_only': True,
                    'browser_control_not_acquired': True, 'physical_identity_contract_checked': True,
                    'expected_physical_identity': PLAN['expected_physical_identity'],
                    'coordination_take_ack': 'synthetic test only, not an actual TAKE', 'observed_utc': now.isoformat()}
            def check(value):
                data = (json.dumps(value) + '\n').encode();path.write_bytes(data)
                return p.gate_record(path, p.digest(data), identity, PLAN['expected_physical_identity'], now)
            self.assertEqual(check(base), base)
            old_wording = dict(base)
            old_wording.pop('physical_identity_contract_checked')
            old_wording['physical_identity_checked'] = True
            with self.assertRaisesRegex(RuntimeError, 'physical_identity_contract_checked'):
                check(old_wording)
            for key, value in [('target', 'amiberry-030'), ('candidate_sha256', 'bad'), ('original_process', [1, 'different']),
                               ('original_profile_sha256', 'bad'), ('physical_identity_contract_checked', False), ('expected_physical_identity', {}),
                               ('recovery_holds_clear', False), ('safari_view_only', False), ('browser_control_not_acquired', False),
                               ('coordination_take_ack', ''), ('observed_utc', (now - timedelta(seconds=601)).isoformat()),
                               ('observed_utc', (now + timedelta(seconds=1)).isoformat())]:
                with self.subTest(key=key), self.assertRaises(RuntimeError):check({**base, key: value})

    def test_four_markers_and_receipt_fast_count_binding(self):
        self.assertEqual(p.native_log(LOG, 13)['fast_allocations'], 13)
        with self.assertRaises(RuntimeError):p.native_log(LOG, 12)
        self.assertNotIn('chip_allocations', p.native_log(LOG))
        with self.assertRaises(RuntimeError):p.native_log(LOG.replace(b'13 Fast', b'0 Fast'))

    def test_no_observed_time_refuses_after_exact_cleanup(self):
        backend, result, error = self.transaction('no-observed-time')
        self.assertIsNotNone(error);self.assertFalse(result['passed']);self.assertTrue(result['recovery_hold'])
        self.assertEqual(len(result['physical_absence_observations']), 11)
        self.assertNotIn('amiberry-030', backend.connections)

    def test_missing_exact_emulator_receipt_is_not_ready(self):
        with self.assertRaisesRegex(RuntimeError, 'receipt is not yet supplied'):
            p.emulator_receipt(None, None, PLAN)

    def test_exact_emulator_receipt_positive_and_negative_guards(self):
        import copy
        with tempfile.TemporaryDirectory(prefix='mod-receipt-MOCK-', dir='/private/tmp') as temp:
            path = Path(temp) / 'MOCK-receipt.json'
            off = 'OK\t' + '\t'.join('ch%d_dma=0' % i for i in range(4))
            value = {'scope': 'SYNTHETIC ONLY, no real emulator result', 'passed': True,
                     'original_processes': [[900001, 'MOCK original sole command']], 'identity_record': {'process': [900001, 'MOCK original sole command'], 'profile': str(p.INFRA / 'runtime/amiberry/Configurations/A1200-030-DEV.uae'), 'profile_sha256': 'a' * 64},
                     'cases': [{'run': str(Path(temp)/'runner-mod-stream/build/dev/render-files-900001'), 'candidate': {'binary': p.NAME, 'label': 'mod-stream', 'mode': ['--mod-stream'], 'sha256': p.SHA, 'bytes': p.BYTES},
                                'result': {'passed': True, 'mod-stream_returncode': '0', p.NAME + '_sha256': p.SHA, 'run_files_cleaned': True, 'cleanup_audio': off},
                                'native_log': LOG.decode(),
                                'independent_cleanup': {'passed': True, 'observations': [{str(p.INFRA/'runtime/Dev/Tests/render-files-900001'): False, str(p.INFRA/'runtime/Dev/Tests/launch-render-files-900001'): False} for _ in range(11)],
                                                        'observed_elapsed_s': 10.2, 'observation_elapsed_s': [i * 1.01 for i in range(11)], 'processes': [[900001, 'MOCK original sole command']], 'final_idle': {'cpu': 'OK\tmodel=68030', 'status': 'OK\tPaused=false', 'audio': off}}}],
                     'verified_manifest': {'targets': {p.NAME: {'dependencies': PLAN['source_dependencies'], 'binary_sha256': p.SHA}}, 'runtime_inputs': PLAN['runtime_hashes']}}
            def check(v):
                raw = (json.dumps(v) + '\n').encode();path.write_bytes(raw)
                return p.emulator_receipt(path, p.digest(raw), PLAN)
            self.assertEqual(check(value)['expected_fast_allocations'], 13)
            faults = ['old-candidate', 'top', 'candidate', 'returncode', 'cleanup', 'dma', 'absence', 'wrong-paths', 'duration', 'missing-times', 'short-span', 'unordered-times', 'nonfinite-time', 'process', 'identity', 'run-name', 'final-cpu', 'source', 'runtime', 'marker']
            for fault in faults:
                v = copy.deepcopy(value);c = v['cases'][0]
                if fault == 'old-candidate':c['candidate']['sha256']='6ef3f3b2f35f130116af7febd326826266a5dc4684326d887f029cd2d5801d4d';c['candidate']['bytes']=123244
                if fault == 'top':v['passed'] = False
                if fault == 'candidate':c['candidate']['sha256'] = 'bad'
                if fault == 'returncode':c['result']['mod-stream_returncode'] = '20'
                if fault == 'cleanup':c['result']['run_files_cleaned'] = False
                if fault == 'dma':c['result']['cleanup_audio'] = off.replace('ch0_dma=0', 'ch0_dma=1')
                if fault == 'absence':c['independent_cleanup']['observations'][3][str(p.INFRA/'runtime/Dev/Tests/render-files-900001')] = True
                if fault == 'wrong-paths':c['independent_cleanup']['observations'] = [{'arbitrary-run': False, 'arbitrary-launch': False} for _ in range(11)]
                if fault == 'duration':c['independent_cleanup']['observed_elapsed_s'] = 10
                if fault == 'missing-times':del c['independent_cleanup']['observation_elapsed_s']
                if fault == 'short-span':c['independent_cleanup']['observation_elapsed_s'] = [99 + i * .1 for i in range(11)];c['independent_cleanup']['observed_elapsed_s'] = 120
                if fault == 'unordered-times':c['independent_cleanup']['observation_elapsed_s'][5] = 0
                if fault == 'nonfinite-time':c['independent_cleanup']['observation_elapsed_s'][5] = float('nan')
                if fault == 'process':c['independent_cleanup']['processes'] = [[900002, 'replacement']]
                if fault == 'identity':v['identity_record']['process'] = [900002, 'replacement']
                if fault == 'run-name':c['run'] = str(Path(temp)/'different-run')
                if fault == 'final-cpu':c['independent_cleanup']['final_idle']['cpu'] = 'OK\tmodel=68020'
                if fault == 'source':v['verified_manifest']['targets'][p.NAME]['dependencies'] = {}
                if fault == 'runtime':v['verified_manifest']['runtime_inputs'] = {}
                if fault == 'marker':c['native_log'] = LOG.decode().replace('workspace=7164', 'workspace=7165')
                with self.subTest(fault=fault), self.assertRaises(RuntimeError):check(v)

    def test_unready_new_candidate_live_entry_refuses_before_any_action(self):
        from unittest.mock import patch
        with patch.object(p.sys, 'argv', ['physical_mod_stream.py', '--execute-approved-single-case']), patch.object(p, 'RealBackend', side_effect=AssertionError('Forbidden live backend')), patch.object(p, 'lock_existing', side_effect=AssertionError('Forbidden lock')):
            with self.assertRaisesRegex(RuntimeError, 'remains NOT READY'):p.main()

    def test_old_candidate_cannot_qualify_new_receipt(self):
        self.assertNotEqual(p.SHA, '6ef3f3b2f35f130116af7febd326826266a5dc4684326d887f029cd2d5801d4d')
        self.assertEqual(p.BYTES, 70824)
        self.assertFalse(PLAN['physical_execution_ready'])
        self.assertIsNotNone(PLAN['emulator_qualification'])
        self.assertEqual(json.loads((HERE/'plan.json').read_text())['emulator_fast_allocations'],13)

    def test_pending_committed_source_is_preparation_only(self):
        import copy,shutil
        from unittest.mock import patch
        with tempfile.TemporaryDirectory(prefix='mod-commit-MOCK-', dir='/private/tmp') as temp:
            fake_repo=Path(temp);frozen=Path(PLAN['immutable_source']);plan=copy.deepcopy(PLAN)
            key='src/core/mod_project.c';old=b'SYNTHETIC pending base only, never compiled or accepted'
            plan['pending_base_dependencies'][key]=p.digest(old)
            for path in PLAN['source_dependencies']:
                dst=fake_repo/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(frozen/path,dst)
            def committed(argv,**kwargs):
                self.assertEqual(argv[0], 'git')
                if argv[1:]==['rev-parse','HEAD']:return 'mock-commit'
                if argv[1:]==['rev-parse','mock-commit^{tree}']:return 'mock-tree'
                self.assertEqual(argv[1], 'show');path=argv[2].split(':',1)[1]
                return old if path==key else (frozen/path).read_bytes()
            with patch.object(p,'REPO',fake_repo),patch.object(p.subprocess,'check_output',side_effect=committed):
                proof=p.host_inputs(plan,require_committed=False)
                self.assertFalse(proof['committed_source_eligible']);self.assertEqual(set(proof['pending_compiled_inputs']),{key})
                with self.assertRaisesRegex(RuntimeError,'Current committed source changed'):p.host_inputs(plan)
                plan['pending_base_dependencies'][key]='0'*64
                with self.assertRaisesRegex(RuntimeError,'Current committed source changed'):p.host_inputs(plan,require_committed=False)

    def test_host_qualification_requires_literal_actual_receipt_binding(self):
        from unittest.mock import patch
        with patch.object(p,'host_inputs',return_value={'synthetic':True}) as host, patch.object(p,'emulator_receipt',return_value={'expected_fast_allocations':13}) as receipt, patch.object(p,'emulator_context',return_value={'synthetic':True}):
            exact=Path(PLAN['emulator_qualification']);h=PLAN['emulator_qualification_sha256']
            self.assertEqual(p.host_qualification(PLAN,exact,h)['expected_fast_allocations'],13)
            host.reset_mock();receipt.reset_mock()
            for path,expected in [(None,None),(exact,'0'*64),(HERE/'mock-other-receipt.json',h)]:
                with self.assertRaisesRegex(RuntimeError,'Exactly bound actual emulator receipt'):p.host_qualification(PLAN,path,expected)
            host.assert_not_called();receipt.assert_not_called()

    def test_substituted_bridge_snapshot_refuses_before_checksum_or_staging(self):
        from unittest.mock import patch
        original_read = Path.read_bytes
        bridge = Path(PLAN['bridge_snapshot'])
        for bad in (b'not the pinned installed bridge', b'X' * 150192):
            def substituted(path):
                return bad if path == bridge else original_read(path)
            with self.subTest(bytes=len(bad)), patch.object(Path, 'read_bytes', substituted):
                backend, result, error = self.transaction()
            self.assertIsInstance(error, RuntimeError)
            self.assertIn('local snapshot changed', str(error))
            self.assertTrue(result['recovery_hold'])
            self.assertEqual(result['native_launches'], 0)
            self.assertEqual(len(backend.calls), 1)
            self.assertIn('PTG-PHYSICAL-IDENTITY-DONE', backend.calls[0][1]['script'])
            self.assertFalse(any(n in ('amiga_push_file', 'amiga_checksum') or 'MakeDir ' in a.get('script', '') for n,a in backend.calls))

    def test_inherited_infra_pins_and_ram_only_source_scope(self):
        inherited = PLAN['inherited_infrastructure_pins']
        self.assertEqual(inherited['central_harness_config_docs_bridge_count'], 11)
        self.assertEqual(inherited['original_030_profile_count'], 1)
        self.assertEqual(len(inherited['records']), 12)
        for path, record in inherited['records'].items():
            self.assertEqual(PLAN['pinned_files'][path], record)
        self.assertEqual(inherited['records'][PLAN['bridge_snapshot']], {'bytes':150192, 'sha256':'e5c8b4ad13776e59d7792c00b0ea664ca2e4f47fe0a2478ef133839b40f2df8c'})
        self.assertEqual(len(PLAN['native_source_order']), 9)
        self.assertEqual(len(PLAN['source_dependencies']), 23)
        self.assertFalse(any('playback_pcm' in name or '/slices.' in name for name in PLAN['source_dependencies']))
        self.assertFalse(PLAN['physical_execution_ready'])
        self.assertTrue(PLAN['physical_NOT_RUN'])
        self.assertIsNone(PLAN['fresh_physical_gate'])

    def test_saved_emulator_context_binding_negative_controls(self):
        import copy
        with tempfile.TemporaryDirectory(prefix='mod-context-MOCK-', dir='/private/tmp') as temp:
            root = Path(temp)
            plan = copy.deepcopy(PLAN)
            base = {}
            for key in ('emulator_saved_record_review', 'emulator_separate_return', 'emulator_release_ack'):
                base[key] = json.loads(Path(PLAN[key]['path']).read_bytes())
                plan[key]['path'] = str(root / (key + '.json'))
            qualification = json.loads(Path(PLAN['emulator_qualification']).read_bytes())
            plan['emulator_qualification'] = str(root/'qualification.json')
            def check(values, changed_qualification=None, mismatched_record=None):
                data=(json.dumps(changed_qualification or qualification)+'\n').encode()
                Path(plan['emulator_qualification']).write_bytes(data)
                plan['emulator_qualification_sha256']=p.digest(data)
                # The independent saved review binds the exact qualification bytes.
                values=copy.deepcopy(values)
                values['emulator_saved_record_review']['qualification']['sha256']=plan['emulator_qualification_sha256']
                for key,value in values.items():
                    raw=(json.dumps(value)+'\n').encode();Path(plan[key]['path']).write_bytes(raw)
                    plan[key]['bytes']=len(raw);plan[key]['sha256']=p.digest(raw)
                if mismatched_record:plan[mismatched_record]['sha256']='0'*64
                return p.emulator_context(plan)
            proof=check(base)
            self.assertEqual(proof['release_revision'],122)
            self.assertEqual(proof['native_fast_allocations'],13)
            self.assertEqual(proof['file_workspace'],7164)
            self.assertTrue(proof['no_live_ownership_inferred'])
            faults=['audit-pass','candidate','closure','sdk','fast','workspace','owned','idle-pass','idle-path','idle-process','idle-span','idle-times','idle-dma','release-error','release-revision','release-status','release-body','record-hash']
            for fault in faults:
                values=copy.deepcopy(base);audit=values['emulator_saved_record_review'];idle=values['emulator_separate_return'];release=values['emulator_release_ack']
                if fault=='audit-pass':audit['passed']=False
                if fault=='candidate':audit['candidate']['sha256']='0'*64
                if fault=='closure':audit['candidate']['canonical_dependencies']=24
                if fault=='sdk':audit['candidate']['sdk_headers']=73
                if fault=='fast':audit['native']['fast_allocations']=48
                if fault=='workspace':audit['native']['workspace']=7165
                if fault=='owned':audit['native']['zero_owned_bytes']=False
                if fault=='idle-pass':idle['passed']=False
                if fault=='idle-path':idle['observations'][0]['paths']={'wrong-run':False,'wrong-launch':False}
                if fault=='idle-process':idle['final_processes']=[[900002,'MOCK different']]
                if fault=='idle-span':
                    for i,row in enumerate(idle['observations']):row['elapsed_s']=i
                if fault=='idle-times':idle['observations'][5]['elapsed_s']=float('nan')
                if fault=='idle-dma':idle['final_idle']['audio']=idle['final_idle']['audio'].replace('ch0_dma=0','ch0_dma=1')
                if fault=='release-error':release['isError']=True
                if fault in ('release-revision','release-status','release-body'):
                    body=json.loads(release['content'][0]['text']);poll=body['polls'][-1]
                    if fault=='release-revision':poll['revision']=121
                    if fault=='release-status':poll['latestTurn']['status']='running'
                    if fault=='release-body':poll['latestAssistantMessage']['text']='MOCK pending; no release'
                    release['content'][0]['text']=json.dumps(body)
                with self.subTest(fault=fault), self.assertRaises(RuntimeError):
                    check(values, mismatched_record='emulator_release_ack' if fault=='record-hash' else None)

    def test_ast_no_top_level_live_import_or_finally_cleanup(self):
        tree = ast.parse((HERE / 'physical_mod_stream.py').read_text())
        top_imports = [node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom))]
        names = [node.module if isinstance(node, ast.ImportFrom) else item.name for node in top_imports for item in ([None] if isinstance(node, ast.ImportFrom) else node.names)]
        self.assertFalse(set(names) & {'amiga', 'shared_guest', 'emulator', 'bridge_checks', 'mcp'})
        main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
        final = next(node for node in main.body if isinstance(node, ast.Try)).finalbody
        self.assertFalse(any(isinstance(node, ast.Attribute) and node.attr in ['connect', 'call', 'unlink', 'rmdir'] for statement in final for node in ast.walk(statement)))


if __name__ == '__main__':
    import hashlib,time
    started=time.monotonic();suite=unittest.defaultTestLoader.loadTestsFromTestCase(PreparedGuards)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    proof={'scope':'Host-only synthetic physical-MOD orchestration/receipt/guard tests. No real target/network/locks/Guest/ps/browser/native execution or coordination. Fast count13 and all gate/receipt identities are synthetic.','passed':result.wasSuccessful(),'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'elapsed_s':time.monotonic()-started,'helper_sha256':hashlib.sha256((HERE/'physical_mod_stream.py').read_bytes()).hexdigest(),'test_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'host-mock-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
