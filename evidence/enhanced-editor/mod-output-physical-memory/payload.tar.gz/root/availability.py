import fcntl,hashlib,json,os,stat,sys,time
from pathlib import Path
assert __debug__
ROOT=Path(__file__).resolve().parent
INFRA=Path('/Users/james1/Documents/Codex/shared-tools/amiga-dev-infra')
sys.path.insert(0,str(INFRA/'scripts'))
from emulator import processes,owns
from bridge_checks import target
profile=INFRA/'runtime/amiberry/Configurations/A1200-030-DEV.uae'
expected_sha='894aa5a61a2bf6267b461c6774a0bdc913a96e7f581ea7e4e3762c4d71709a30'
r={'scope':'Fresh passive local dual-lock/process/health check; no target selection, guest command or physical probe','observed_time_ns':time.time_ns(),'locks':[]};fds=[]
try:
 for name in ('test.lock','real-a1200-safari.lock'):
  path=INFRA/'runtime'/name
  fd=os.open(path,os.O_RDWR|os.O_NOFOLLOW);fds.append(fd)
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);a=os.fstat(fd);b=path.lstat()
  assert stat.S_ISREG(a.st_mode) and a.st_size==0 and (a.st_dev,a.st_ino,a.st_mode)==(b.st_dev,b.st_ino,b.st_mode),'Unsafe or redirected lock'
  r['locks'].append({'path':str(path),'identity':[a.st_dev,a.st_ino,a.st_mode],'free':True})
 rows=[list(x) for x in processes()]
 assert len(rows)==1 and owns(rows[0][1],'amiberry-030') and isinstance(rows[0][0],int) and rows[0][0]>0,'Sole original030 process unknown'
 sha=hashlib.sha256(profile.read_bytes()).hexdigest();assert sha==expected_sha,'Profile pin changed'
 state=target(INFRA,'amiberry-030')
 r.update(passed=True,process=rows[0],profile=str(profile),profile_sha256=sha,serial={k:state.get(k) for k in ('host','port','connected')})
except BaseException as e:r.update(passed=False,error=str(e));raise
finally:
 for fd in reversed(fds):os.close(fd)
 with (ROOT/'fresh-identity.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r))
