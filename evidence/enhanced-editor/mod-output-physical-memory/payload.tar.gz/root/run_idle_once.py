import hashlib,json,subprocess,time
from pathlib import Path
assert __debug__
ROOT=Path(__file__).resolve().parent
invocation=json.loads((ROOT/'physical-invocation-result.json').read_bytes());assert invocation['passed'] is True
physical_args=invocation['arguments'];assert physical_args.count('--identity-sha256')==1
saved_identity_sha=physical_args[physical_args.index('--identity-sha256')+1]
identity=ROOT/'fresh-identity.json';assert hashlib.sha256(identity.read_bytes()).hexdigest()==saved_identity_sha,'Original physical identity record changed'
native_path=Path(invocation['native_result']['path']);native_raw=native_path.read_bytes();assert hashlib.sha256(native_raw).hexdigest()==invocation['native_result']['sha256'],'Saved physical result changed'
assert json.loads(native_raw)['fresh_original_identity']==json.loads(identity.read_bytes()),'Completed physical original differs'
out=ROOT/('idle-verification-'+str(time.time_ns()))
args=['/Users/james1/Documents/Codex/shared-tools/amiga-dev-infra/.venv/bin/python','-I','-B',str(ROOT/'verify_idle_return.py'),'--identity',str(identity),'--identity-sha256',saved_identity_sha,'--out',str(out)]
r={'passed':False,'scope':'Separate60s dual-locked read-only original030 idle return; physical absence is separate prior evidence','arguments':args,'timeout_seconds':60,'root_release_not_performed':True};start=time.monotonic()
with (ROOT/'idle-execution-claim.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
try:
 with (ROOT/'idle-execution.log').open('x') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 r['returncode']=p.returncode;assert p.returncode==0,'Separate original idle check failed; preserve HOLD/reservation'
 data=(out/'result.json').read_bytes();result=json.loads(data);r['result']={'path':str(out/'result.json'),'sha256':hashlib.sha256(data).hexdigest()}
 assert result['passed'] is True and len(result['observations'])==11
 r['passed']=True
except BaseException as e:r['error']=str(e) or type(e).__name__;raise
finally:
 r['elapsed_seconds']=time.monotonic()-start
 with (ROOT/'idle-invocation-result.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
