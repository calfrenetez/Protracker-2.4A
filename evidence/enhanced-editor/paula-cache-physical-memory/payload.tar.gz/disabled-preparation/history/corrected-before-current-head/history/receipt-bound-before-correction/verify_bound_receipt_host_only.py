"""Saved-record/local-file reads only; no Guest/lock/bridge/browser/target."""
from pathlib import Path
import importlib.util,json
here=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('bound_host_only',here/'physical_paula_cache.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
plan=json.loads((here/'plan.json').read_bytes());proof=p.host_qualification(plan,Path(plan['emulator_qualification']),plan['emulator_qualification_sha256']);assert proof['expected_fast_allocations']==48 and proof['committed_source_eligible'] is True and plan['physical_execution_ready'] is False
print(json.dumps({'passed':True,'scope':'Host-only exact saved emulator receipt/source/toolchain binding. No physical operation or readiness authorization.','proof':proof,'physical_execution_ready':False,'physical_execution':'NOT RUN'},indent=2))
