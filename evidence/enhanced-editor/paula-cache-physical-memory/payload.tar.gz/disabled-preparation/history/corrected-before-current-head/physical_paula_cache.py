#!/usr/bin/env python3
"""Prepared ONLY: one exact physical selective Paula-cache case after root TAKE.

This uses the shared DevBench, not an independent Safari transport. It acquires
both documented global and dedicated physical locks. It never retries, starts or
stops an emulator, changes hardware/driver settings, or automatically recovers.
Imports of central live APIs are deferred until explicitly approved execution.
"""
import argparse
import asyncio
import fcntl
import gzip
import hashlib
import json
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
INFRA = Path('/Users/james1/Documents/Codex/shared-tools/amiga-dev-infra')
NAME = 'PTExecSamplerPaulaTest'
SHA = 'b6c79b4c7c5455702f4ea6817bebd8cdf648c19d5bd77dee20df6282e1cba32d'
BYTES = 123732
SCOPE = 'single-physical-paula-cache'
TOTAL_SECONDS = 300
NATIVE_SECONDS = 90


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    data = Path(path).read_bytes()
    return json.loads(gzip.decompress(data) if str(path).endswith('.gz') else data)


def prepared_package(expected_sha):
    raw = (HERE / 'prepared-files.json').read_bytes()
    require(digest(raw) == expected_sha, 'Prepared package provenance changed')
    records = json.loads(raw)['files']
    for name, record in records.items():
        require(Path(name).name == name and name not in ('.', '..'), 'Unsafe prepared package member')
        data = (HERE / name).read_bytes()
        require(len(data) == record['bytes'] and digest(data) == record['sha256'], 'Prepared package member changed: ' + name)


def require(value, message):
    if not value:
        raise RuntimeError(message)


def ack(text, marker):
    require(text.splitlines().count(marker) == 1, 'Exact script marker missing/duplicated: ' + marker)


def inventory(text, expected):
    lines = text.splitlines()
    markers = ['PTG-FILES-BEGIN', 'PTG-FILES-END', 'PTG-DIRS-BEGIN', 'PTG-DIRS-END']
    for marker in markers:
        ack(text, marker)
    indexes = [lines.index(marker) for marker in markers]
    require(indexes == sorted(indexes), 'Typed inventory markers reversed')
    names = lines[indexes[0] + 1:indexes[1]]
    directories = lines[indexes[2] + 1:indexes[3]]
    require(not directories, 'Unexpected directory in private physical run; retain: ' + repr(directories))
    require(len(names) == len(expected) and set(names) == set(expected),
            'Unexpected physical child/type/listing output; retain files: ' + repr(names))
    return names


def native_log(data, expected_allocations=None):
    text = data.decode('utf-8', errors='strict')
    lines = [line for line in text.splitlines() if line]
    require(len(lines) == 4, 'Unexpected native output; complete cache marker proof required')
    match = re.fullmatch(r'EXEC MEMORY pool_limit=(\d+) reserve=262144 flags=4', lines[0])
    require(match is not None and int(match.group(1)) > 65536, 'Fast pool marker invalid')
    require(lines[1] == 'PAULA CHIP JOB PASS: bounded256-byte conversion, unpublished leases, exact master pins, cancellation and stale/pressure/close refusal', 'Chip job marker invalid')
    require(lines[2] == 'SAMPLER PAULA PASS: selected routed8-bit copies, explicit stereo side, odd padding, master preservation, revisions/undo/routes, pressure eviction and retained active leases; no DMA or mixed-backend playback', 'Sampler Paula marker invalid')
    finish = re.fullmatch(r'EXEC MEMORY PASS: (\d+) Fast allocations, zero owned bytes, budget refusal without Chip fallback', lines[3])
    require(finish is not None and int(finish.group(1)) > 0, 'Fast allocator-zero marker invalid')
    count = int(finish.group(1))
    if expected_allocations is not None:
        require(count == expected_allocations, 'Physical Fast allocation count differs from exact emulator receipt')
    return dict(pool_limit=int(match.group(1)), fast_allocations=count, fast_owned_bytes=0,
                chip_zero_lifetime_assertions_completed=True, type_of_mem_assertions_completed=True)


def identity_record(path, expected_sha):
    raw = Path(path).read_bytes()
    require(digest(raw) == expected_sha, 'Fresh identity record hash changed')
    value = json.loads(raw);process = value.get('process')
    require(isinstance(process, list) and len(process) == 2 and
            isinstance(process[0], int) and not isinstance(process[0], bool) and process[0] > 0 and
            isinstance(process[1], str) and bool(process[1].strip()), 'Fresh sole process/full command malformed')
    profile = INFRA / 'runtime/amiberry/Configurations/A1200-030-DEV.uae'
    require(value.get('profile') == str(profile), 'Fresh original shared030 profile mismatch')
    require(digest(profile.read_bytes()) == value.get('profile_sha256'), 'Fresh original profile hash changed')
    return value


def gate_record(path, expected_sha, identity, expected_physical, now=None):
    raw = Path(path).read_bytes()
    require(digest(raw) == expected_sha, 'Root coordination gate hash changed')
    gate = json.loads(raw)
    require(gate.get('scope') == SCOPE and gate.get('target') == 'real-a1200' and
            gate.get('candidate_sha256') == SHA and gate.get('original_process') == identity['process'] and
            gate.get('original_profile_sha256') == identity['profile_sha256'],
            'Root gate scope/target/candidate/process mismatch')
    for field in ('no_conflicting_claims', 'recovery_holds_clear', 'safari_view_only', 'browser_control_not_acquired', 'physical_identity_contract_checked'):
        require(gate.get(field) is True, 'Root gate missing positive condition: ' + field)
    # This preconnection flag checks the expected pinned contract only. It is
    # not a fresh physical observation; transaction checks actual CPU/network
    # and installed bridge after connection, before every RAM write.
    require(gate.get('expected_physical_identity') == expected_physical, 'Root-reported physical identity contract mismatch')
    require(isinstance(gate.get('coordination_take_ack'), str) and bool(gate['coordination_take_ack'].strip()),
            'Fresh actual root-reported TAKE acknowledgment required')
    observed = datetime.fromisoformat(gate['observed_utc'].replace('Z', '+00:00'))
    require(observed.tzinfo is not None, 'Timezone-aware gate timestamp required')
    age = ((now or datetime.now(timezone.utc)) - observed).total_seconds()
    require(0 <= age <= 600, 'Root ownership/Safari gate is stale or future-dated')
    return gate


def host_inputs(plan, require_committed=True):
    """File/git reads only; no compiler, Guest, bridge, locks or native execution."""
    for path, record in plan['pinned_files'].items():
        data = Path(path).read_bytes()
        require(len(data) == record['bytes'] and digest(data) == record['sha256'], 'Pinned host input changed: ' + path)
    raw = Path(plan['native_manifest']).read_bytes()
    require(digest(raw) == plan['native_manifest_sha256'], 'Native manifest pin changed')
    manifest = json.loads(raw)
    require(manifest.get('passed') is True and set(manifest['targets']) == {NAME}, 'One successful native build required')
    target = manifest['targets'][NAME]
    require(target['binary_bytes'] == BYTES and target['binary_sha256'] == SHA and len(target['dependencies']) == 48 and
            target['dependencies'] == plan['source_dependencies'] and target['source_inputs'] == plan['native_source_order'] and
            target['flags'] == plan['flags'] == manifest['flags'], 'Candidate identity/closure/recipe changed')
    frozen = Path(plan['immutable_source'])
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True, timeout=10).strip()
    pending = {}
    for path, expected in target['dependencies'].items():
        data = (REPO / path).read_bytes()
        require(digest((frozen / path).read_bytes()) == expected == digest(data), 'Immutable/current source changed: ' + path)
        committed = subprocess.check_output(['git', 'show', tree + ':' + path], cwd=REPO, timeout=10)
        committed_hash = digest(committed)
        if committed_hash != expected:
            require(not require_committed and plan['pending_base_dependencies'].get(path) == committed_hash,
                    'Current committed source changed: ' + path)
            pending[path] = {'committed_sha256': committed_hash, 'candidate_sha256': expected}
    # Declaration/recipe bytes come only from the immutable pinned build export
    # and committed HEAD. The unrelated dirty working recipe is never imported.
    for path, expected in {**plan['python_declaration_inputs'], 'tools/build_core_tests.py': plan['canonical_recipe_sha256']}.items():
        committed = subprocess.check_output(['git', 'show', tree + ':' + path], cwd=REPO, timeout=10)
        require(digest(committed) == expected, 'Committed canonical declaration changed: ' + path)
    require(manifest['runtime_inputs'] == plan['runtime_hashes'], 'Runtime manifest mismatch')
    for name, expected in manifest['runtime_inputs'].items():
        require(digest(Path(manifest['runtime_paths'][name]).read_bytes()) == expected, 'Runtime changed: ' + name)
    for path, expected in target['external_sdk_dependencies'].items():
        require(digest(Path(path).read_bytes()) == expected, 'SDK header changed: ' + path)
    require(digest(Path(manifest['compiler']).read_bytes()) == manifest['compiler_sha256'], 'Compiler changed')
    binary = Path(plan['binary'])
    require(binary.stat().st_size == BYTES and digest(binary.read_bytes()) == SHA and binary.read_bytes()[:4] == bytes.fromhex('000003f3'), 'Candidate binary changed')
    pp = plan['preprocessed_wrapper'];text = Path(pp['path']).read_bytes()
    require(len(text) == pp['bytes'] and digest(text) == pp['sha256'], 'Preprocessed wrapper pin changed')
    macros = [line for line in text.decode().splitlines() if line.startswith('#define assert(')]
    expected_macro = '#define assert(__e) ((__e) ? (void)0 : __assert_func (__FILE__, __LINE__, __ASSERT_FUNC, #__e))'
    require(macros and macros[-1] == expected_macro == target['last_assert_macro'] == plan['last_assert_macro'], 'Original SDK assert contract changed')
    return dict(source_tree=tree, canonical_dependencies=48, sdk_headers=len(target['external_sdk_dependencies']), binary_sha256=SHA, binary_bytes=BYTES, committed_source_eligible=not pending, pending_compiled_inputs=pending, immutable_source=plan['immutable_source'], frozen_source_manifest_sha256=plan['frozen_source_manifest_sha256'])


def emulator_receipt(path, expected_sha, plan):
    require(path and expected_sha, 'Exact-current emulator PASS receipt is not yet supplied; physical execution forbidden')
    raw = Path(path).read_bytes()
    require(digest(raw) == expected_sha, 'Exact emulator receipt hash changed')
    qualification = json.loads(gzip.decompress(raw) if str(path).endswith('.gz') else raw)
    require(qualification.get('passed') is True and len(qualification.get('cases', [])) == 1, 'Exact emulator top PASS missing')
    case = qualification['cases'][0];candidate = case['candidate'];result = case['result']
    require(candidate.get('binary') == NAME and candidate.get('label') == 'sampler-paula' and candidate.get('mode') == ['--paula-memory', 'cache'] and
            candidate.get('sha256') == SHA and candidate.get('bytes') == BYTES and result.get('passed') is True and
            result.get('sampler-paula_returncode') == '0' and result.get(NAME + '_sha256') == SHA and result.get('run_files_cleaned') is True,
            'Exact emulator native completion/candidate/cleanup missing')
    require(all('ch%d_dma=0' % i in result.get('cleanup_audio', '').split('\t') for i in range(4)), 'Exact emulator cleanup DMA guard missing')
    independent = case['independent_cleanup']
    run = Path(case.get('run', ''))
    require(run.is_absolute() and re.fullmatch(r'render-files-[0-9]+', run.name) is not None, 'Exact emulator run identity malformed')
    share = INFRA / 'runtime/Dev/Tests'
    expected_paths = {str(share / run.name), str(share / ('launch-' + run.name))}
    observations = independent.get('observations', [])
    require(independent.get('passed') is True and len(observations) == 11 and
            all(isinstance(row, dict) and set(row) == expected_paths and all(value is False for value in row.values()) for row in observations),
            'Independent exact emulator run/launch absence missing')
    times = independent.get('observation_elapsed_s', [])
    require(len(times) == 11 and all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0 for value in times) and
            all(right > left for left, right in zip(times, times[1:])) and times[-1] - times[0] > 10,
            'Independent emulator eleven ordered observations span is not >10s')
    require(independent.get('observed_elapsed_s', -1) >= times[-1], 'Independent emulator final elapsed precedes last observation')
    original = qualification.get('original_processes', [])
    require(isinstance(original, list) and len(original) == 1 and isinstance(original[0], list) and len(original[0]) == 2 and
            isinstance(original[0][0], int) and not isinstance(original[0][0], bool) and original[0][0] > 0 and
            isinstance(original[0][1], str) and bool(original[0][1].strip()) and independent.get('processes') == original,
            'Exact emulator original/independent sole-process identity mismatch')
    identity = qualification.get('identity_record')
    require(isinstance(identity, dict) and identity.get('process') == original[0] and
            identity.get('profile') == str(INFRA / 'runtime/amiberry/Configurations/A1200-030-DEV.uae') and
            isinstance(identity.get('profile_sha256'), str) and re.fullmatch(r'[0-9a-f]{64}', identity['profile_sha256']) is not None,
            'Exact emulator original receipt identity binding missing')
    final = independent.get('final_idle', {})
    require('model=68030' in final.get('cpu', '').split('\t') and 'Paused=false' in final.get('status', '').split('\t') and
            all('ch%d_dma=0' % i in final.get('audio', '').split('\t') for i in range(4)), 'Original emulator final idle proof missing')
    verified = qualification.get('verified_manifest', {})
    require(verified.get('targets', {}).get(NAME, {}).get('dependencies') == plan['source_dependencies'] and
            verified.get('targets', {}).get(NAME, {}).get('binary_sha256') == SHA and verified.get('runtime_inputs') == plan['runtime_hashes'],
            'Exact emulator source/runtime binding missing')
    markers = native_log(case['native_log'].encode())
    return dict(receipt_path=str(path), receipt_sha256=expected_sha, native_markers=markers,
                expected_fast_allocations=markers['fast_allocations'])


def host_qualification(plan, receipt_path, receipt_sha):
    require(receipt_path and receipt_sha and plan.get('emulator_qualification') and
            Path(receipt_path).resolve() == Path(plan['emulator_qualification']).resolve() and
            receipt_sha == plan.get('emulator_qualification_sha256'),
            'Exactly bound actual emulator receipt required; no substituted/mock/old-candidate receipt')
    return {**host_inputs(plan), **emulator_receipt(receipt_path, receipt_sha, plan)}


class Budget:
    def __init__(self, seconds=TOTAL_SECONDS, clock=time.monotonic):
        self.clock = clock
        self.started = clock()
        self.deadline = self.started + seconds

    def remaining(self, minimum=0):
        value = self.deadline - self.clock()
        require(value > minimum, 'Bounded physical window expired/insufficient; no next operation')
        return value

    async def wait(self, operation, limit):
        return await asyncio.wait_for(operation(), timeout=min(limit, self.remaining()))


def list_script(destination):
    return ('Echo PTG-FILES-BEGIN\nList ' + destination + ' FILES NOHEAD LFORMAT "%N"\n'
            'If WARN\n Quit 20\nEndIf\nEcho PTG-FILES-END\n'
            'Echo PTG-DIRS-BEGIN\nList ' + destination + ' DIRS NOHEAD LFORMAT "%N"\n'
            'If WARN\n Quit 20\nEndIf\nEcho PTG-DIRS-END\n')


def absence_script(destination, marker):
    return ('If EXISTS ' + destination + '\n Quit 20\nEndIf\nEcho ' + marker + '\n')


async def transaction(out, binary, backend, result, budget):
    """Dependency-injected transaction; fake backend is used for host tests."""
    destination = 'RAM:ptg-paula-cache-' + out.name
    require(re.fullmatch(r'physical-paula-cache-\d+', out.name) is not None, 'Unsafe unique run name')
    result.update(guest_directory=destination, calls=[], physical_absence_observations=[], native_launches=0)
    remote = destination + '/' + NAME
    logfile = destination + '/cache.log'

    def save():
        (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

    async def call(name, arguments, limit=25):
        backend.guard_original()
        backend.require_target('real-a1200')
        budget.remaining()
        row = dict(tool=name, arguments=arguments, complete=False)
        result['calls'].append(row)
        result['operation_pending'] = True
        save()
        text = await budget.wait(lambda: backend.call(name, arguments), limit)
        row.update(complete=True, result=text)
        result['operation_pending'] = False
        save()
        backend.guard_original()
        backend.require_target('real-a1200')
        return text

    backend.guard_original()
    backend.require_target('amiberry-030')
    budget.remaining(185)
    result['target_switch_attempted'] = True
    result['recovery_hold'] = True
    save()
    await budget.wait(lambda: backend.connect('real-a1200'), 25)
    backend.guard_original()
    result['physical_target'] = backend.require_target('real-a1200')
    save()
    identity = await call('amiga_run_script', dict(script='Version\nCPU\nAvail\nVersion bsdsocket.library\nShowNetStatus\nEcho PTG-PHYSICAL-IDENTITY-DONE\n', timeout=20))
    ack(identity, 'PTG-PHYSICAL-IDENTITY-DONE')
    require(backend.plan['expected_physical_identity']['cpu'] in identity and backend.plan['expected_physical_identity']['network_line'] in identity, 'Physical CPU/network identity mismatch')
    result['physical_identity'] = identity
    bridge = Path(backend.plan['bridge_snapshot']).read_bytes()
    require(len(bridge) == 150192 and digest(bridge) == backend.plan['expected_physical_identity']['bridge_sha256'],
            'Pinned local bridge snapshot changed before installed checksum; retain without RAM writes')
    check = await call('amiga_checksum', dict(path=backend.plan['bridge_path']))
    backend.checksum(check, bridge)
    result['installed_bridge_sha256'] = digest(bridge)
    fresh = await call('amiga_run_script', dict(script=absence_script(destination, 'PTG-FRESH-ABSENT'), timeout=20))
    ack(fresh, 'PTG-FRESH-ABSENT')
    made = await call('amiga_run_script', dict(script='MakeDir ' + destination + '\nIf WARN\n Quit 20\nEndIf\nEcho PTG-DIRECTORY-CREATED\n', timeout=20))
    ack(made, 'PTG-DIRECTORY-CREATED')
    result['directory_created'] = True
    inventory(await call('amiga_run_script', dict(script=list_script(destination), timeout=20)), [])
    await call('amiga_push_file', dict(local_path=str(binary), amiga_path=remote), 40)
    backend.checksum(await call('amiga_checksum', dict(path=remote)), binary.read_bytes())
    returned = out / 'staged-readback.bin'
    await call('amiga_pull_file', dict(amiga_path=remote, local_path=str(returned)), 40)
    require(returned.stat().st_size == BYTES and digest(returned.read_bytes()) == SHA, 'Physical staged binary readback changed')
    result['binary_readback_sha256'] = SHA
    inventory(await call('amiga_run_script', dict(script=list_script(destination), timeout=20)), [NAME])
    budget.remaining(150)
    result['native_launches'] = 1
    result['native_running_or_unknown'] = True
    save()
    script = ('FailAt 21\nStack 65536\nCD ' + destination + '\n' + NAME + ' >cache.log\n'
              'Echo PTG-PAULA-RC $RC\nCD RAM:\nEcho PTG-PAULA-DONE\n')
    execution = await call('amiga_run_script', dict(script=script, timeout=NATIVE_SECONDS), 105)
    ack(execution, 'PTG-PAULA-DONE')
    require(sum(line.startswith('PTG-PAULA-RC ') for line in execution.splitlines()) == 1, 'Native RC marker incomplete')
    result['native_completed'] = True
    result['native_running_or_unknown'] = False
    ack(execution, 'PTG-PAULA-RC 0')
    local_log = out / 'cache.log'
    await call('amiga_pull_file', dict(amiga_path=logfile, local_path=str(local_log)), 30)
    result['native_markers'] = native_log(local_log.read_bytes(), backend.plan['emulator_fast_allocations'])
    backend.checksum(await call('amiga_checksum', dict(path=logfile)), local_log.read_bytes())
    result['native_log_sha256'] = digest(local_log.read_bytes())
    inventory(await call('amiga_run_script', dict(script=list_script(destination), timeout=20)), [NAME, 'cache.log'])
    result['exact_two_files_no_temporary_children_or_directories'] = True
    # No cleanup in finally: any preceding native/protocol/guard failure retains
    # target/owned paths. Exactly these two verified files and empty directory.
    clean = ('CD RAM:\nDelete ' + remote + '\nIf WARN\n Quit 20\nEndIf\nDelete ' + logfile +
             '\nIf WARN\n Quit 20\nEndIf\nDelete ' + destination + '\nIf WARN\n Quit 20\nEndIf\n' +
             absence_script(destination, 'PTG-CLEANUP-ABSENT'))
    ack(await call('amiga_run_script', dict(script=clean, timeout=20)), 'PTG-CLEANUP-ABSENT')
    result['exact_nonrecursive_cleanup_acknowledged'] = True
    started = budget.clock()
    for index in range(11):
        marker = 'PTG-INDEPENDENT-ABSENT-' + str(index)
        observation = {'index': index, 'elapsed_seconds': budget.clock() - started, 'completed': False}
        result['physical_absence_observations'].append(observation)
        save()
        response = await call('amiga_run_script', dict(script=absence_script(destination, marker), timeout=15), 20)
        ack(response, marker)
        observation.update(completed=True, path=destination, exists=False, completed_elapsed_seconds=budget.clock() - started)
        save()
        if index < 10:
            await budget.wait(lambda: backend.pause(1.01), 2)
    observations = result['physical_absence_observations']
    times = [row.get('completed_elapsed_seconds') for row in observations]
    require(len(observations) == 11 and all(row.get('completed') is True and row.get('path') == destination and row.get('exists') is False and row.get('index') == index for index, row in enumerate(observations)) and
            all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) for value in times) and
            all(right > left for left, right in zip(times, times[1:])) and times[-1] - times[0] > 10,
            'Physical independent completed eleven observations span is not >10s')
    result['physical_independent_absence_passed'] = True
    result['physical_absence_seconds'] = times[-1] - times[0]
    result['physical_absence_elapsed_since_start_seconds'] = budget.clock() - started
    budget.remaining(25)
    backend.guard_original()
    backend.require_target('real-a1200')
    result['return_target_switch_attempted'] = True
    save()
    await budget.wait(lambda: backend.connect('amiberry-030'), 25)
    result['returned_target'] = backend.require_target('amiberry-030')
    result['final_original_idle'] = backend.guard_original(local=True)
    result['devbench_returned'] = True
    budget.remaining()
    result['passed'] = True
    result['recovery_hold'] = False
    result['root_separate_release_check_required'] = True
    save()


class RealBackend:
    def __init__(self, plan, out, lock_records):
        # This class is constructed ONLY after explicit root gate + both locks.
        sys.path.insert(0, str(INFRA / 'scripts'))
        from amiga import connect
        from bridge_checks import target, require_reply, checksum
        from emulator import processes
        from shared_guest import Guest
        from mcp import ClientSession
        from mcp.client.streamable_http import streamable_http_client
        self.connect_api, self.target_api = connect, target
        self.reply_api, self.checksum = require_reply, checksum
        self.processes, self.Guest = processes, Guest
        self.ClientSession, self.stream_client = ClientSession, streamable_http_client
        self.plan, self.out, self.lock_records = plan, out, lock_records
        self.guest = Guest(INFRA, out)
        self.session = None

    def guard_original(self, local=False):
        gate_record(self.plan['live_gate_path'], self.plan['live_gate_sha256'], self.plan['identity_record'], self.plan['expected_physical_identity'])
        for path, fd, identity in self.lock_records:
            a, b = os.fstat(fd), Path(path).lstat()
            require((a.st_dev, a.st_ino, a.st_mode) == identity == (b.st_dev, b.st_ino, b.st_mode), 'Lock path/inode redirected')
        require(self.processes() == [tuple(row) for row in self.plan['original_processes']], 'Original sole PID/full command changed')
        profile = Path(self.plan['original_profile'])
        require(digest(profile.read_bytes()) == self.plan['original_profile_sha256'], 'Original command profile changed')
        cpu = self.guest.command('GET_CPU_MODEL')
        status = self.guest.command('GET_STATUS')
        audio = self.guest.command('GET_AUDIO_STATE')
        require('model=68030' in cpu.split('\t') and 'Paused=false' in status.split('\t') and all('ch%d_dma=0' % i in audio.split('\t') for i in range(4)), 'Original030 not running/DMA-off')
        if local:
            self.require_target('amiberry-030')
            self.Guest(INFRA, self.out)
        return dict(processes=self.plan['original_processes'], cpu=cpu, status=status, audio=audio,
                    command_profile=str(profile), profile_sha256=self.plan['original_profile_sha256'])

    def require_target(self, name):
        return self.target_api(INFRA, name)

    async def connect(self, name):
        await self.connect_api(name)

    async def call(self, name, arguments):
        if name == 'amiga_run_script':
            require(1 <= arguments['timeout'] <= NATIVE_SECONDS, 'Unbounded native script timeout')
        reply = await self.session.call_tool(name, arguments)
        text = self.reply_api(reply)
        if name == 'amiga_run_script':
            require('[OK]' in text, 'Native script completion acknowledgment absent')
        return text

    async def pause(self, seconds):
        await asyncio.sleep(seconds)

    async def run(self, out, binary, result, budget):
        async with self.stream_client('http://127.0.0.1:3000/mcp') as (rd, wr, _):
            async with self.ClientSession(rd, wr) as session:
                self.session = session
                await budget.wait(session.initialize, 10)
                await transaction(out, binary, self, result, budget)


def lock_existing(path):
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    try:
        a, b = os.fstat(fd), Path(path).lstat()
        require(stat.S_ISREG(a.st_mode) and (a.st_dev, a.st_ino, a.st_mode) == (b.st_dev, b.st_ino, b.st_mode), 'Redirected/nonregular lock')
        # Existing coordination users leave these lock files empty. A nonempty
        # lock is an unrecognized lease format, not authorization to overwrite it.
        require(a.st_size == 0, 'Unrecognized lock lease metadata; root must inspect')
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return (str(path), fd, (a.st_dev, a.st_ino, a.st_mode))
    except BaseException:
        os.close(fd)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-approved-single-case', action='store_true')
    parser.add_argument('--verify-source-only', action='store_true')
    parser.add_argument('--emulator-qualification', type=Path)
    parser.add_argument('--emulator-qualification-sha256')
    parser.add_argument('--identity', type=Path)
    parser.add_argument('--identity-sha256')
    parser.add_argument('--coordination-gate', type=Path)
    parser.add_argument('--coordination-gate-sha256')
    parser.add_argument('--prepared-manifest-sha256')
    args = parser.parse_args()
    plan = read_json(HERE / 'plan.json')
    if args.verify_source_only:
        require(not args.execute_approved_single_case, 'Source verification cannot request physical execution')
        print(json.dumps({'passed': True, 'scope': 'Host source/toolchain reads only; exact emulator receipt absent, physical execution NOT READY/NOT RUN', 'host_inputs': host_inputs(plan, require_committed=False)}, indent=2))
        return
    require(plan.get('candidate_withdrawn') is not True, 'Obsolete candidate withdrawn before target run; template is NOT READY for physical execution')
    require(plan.get('physical_execution_ready') is True, 'Prepared candidate remains NOT READY: fresh physical root ownership/control/gate review is not supplied')
    require(args.execute_approved_single_case and args.coordination_gate and args.coordination_gate_sha256 and args.prepared_manifest_sha256 and
            args.identity and args.identity_sha256 and args.emulator_qualification and args.emulator_qualification_sha256,
            'Preparation only until exact emulator PASS plus fresh root TAKE/original identity/Safari/physical identity contract gate supplied')
    prepared_package(args.prepared_manifest_sha256)
    budget = Budget()
    out = HERE / ('physical-paula-cache-' + str(time.time_ns()))
    out.mkdir()
    result = dict(passed=False, scope='One exact physical RAM-only selective 8-bit Chip cache/Fast master pool/ownership fixture; no DMA, card/MMIO/IRQ/AHI/input/settings/lifecycle/audio/timing/listening acceptance',
                  native_launches=0, target_switch_attempted=False, recovery_hold=False, root_release_not_performed=True)
    locks = []
    try:
        result['host_qualification'] = host_qualification(plan, args.emulator_qualification, args.emulator_qualification_sha256)
        plan['emulator_fast_allocations'] = result['host_qualification']['expected_fast_allocations']
        identity = identity_record(args.identity, args.identity_sha256)
        plan['original_processes'] = [identity['process']]
        plan['original_profile_sha256'] = identity['profile_sha256']
        plan['identity_record'] = identity
        plan['live_gate_path'] = str(args.coordination_gate)
        plan['live_gate_sha256'] = args.coordination_gate_sha256
        result['fresh_original_identity'] = identity
        result['root_reported_coordination_gate'] = gate_record(args.coordination_gate, args.coordination_gate_sha256, identity, plan['expected_physical_identity'])
        result['root_gate_path'] = str(args.coordination_gate)
        result['root_gate_sha256'] = args.coordination_gate_sha256
        binary = out / NAME
        shutil.copyfile(plan['binary'], binary)
        require(digest(binary.read_bytes()) == SHA and binary.stat().st_size == BYTES, 'Private candidate copy changed')
        for name in ('test.lock', 'real-a1200-safari.lock'):
            locks.append(lock_existing(INFRA / 'runtime' / name))
        # Recheck root freshness after acquiring both resources. Free locks alone
        # are not a current peer reservation or Safari/remote-control clearance.
        gate_record(args.coordination_gate, args.coordination_gate_sha256, identity, plan['expected_physical_identity'])
        backend = RealBackend(plan, out, locks)
        result['initial_original_idle'] = backend.guard_original(local=True)
        # Exclusive one-attempt receipt: an interrupted process consumes the
        # scope too. No second target attempt from this prepared package.
        with (HERE / 'physical-execution-claim.json').open('x') as claim:
            claim.write(json.dumps({'scope': SCOPE, 'out': str(out), 'gate_sha256': args.coordination_gate_sha256,
                                    'candidate_sha256': SHA, 'created_utc': datetime.now(timezone.utc).isoformat()}, indent=2) + '\n')
        result['exclusive_one_attempt_claim'] = str(HERE / 'physical-execution-claim.json')
        asyncio.run(asyncio.wait_for(backend.run(out, binary, result, budget), timeout=budget.remaining()))
    except BaseException as error:
        result['passed'] = False
        result['error'] = str(error) or type(error).__name__
        result['recovery_hold'] = bool(result.get('target_switch_attempted'))
        result['host_prelaunch_not_run'] = not result.get('target_switch_attempted')
        raise
    finally:
        result['elapsed_seconds'] = budget.clock() - budget.started
        (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        for _, fd, _ in reversed(locks):
            os.close(fd)
        print(out, flush=True)


if __name__ == '__main__':
    main()
