import hashlib,json,os,re,subprocess,time
from pathlib import Path
assert __debug__
ROOT=Path(__file__).resolve().parent
op=json.loads((ROOT/'operation.json').read_bytes())
PREP=Path(op['execution_clone']);GATE=ROOT/'gate.json';IDENTITY=ROOT/'fresh-identity.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert PREP.parent==Path('/private/tmp') and PREP.name.startswith('protracker-paula-physical-execution-')
assert sha(PREP/'physical_paula_cache.py')==op['helper_sha256'] and sha(PREP/'plan.json')==op['plan_sha256'] and sha(PREP/'prepared-files.json')==op['prepared_manifest_sha256']
gate=json.loads(GATE.read_bytes());identity=json.loads(IDENTITY.read_bytes())
assert gate['scope']=='single-physical-paula-cache' and gate['candidate_sha256']=='b6c79b4c7c5455702f4ea6817bebd8cdf648c19d5bd77dee20df6282e1cba32d'
assert gate['physical_identity_contract_checked'] is True and gate['no_conflicting_claims'] is True and gate['recovery_holds_clear'] is True and gate['safari_view_only'] is True and gate['browser_control_not_acquired'] is True
assert identity['passed'] is True and gate['original_process']==identity['process'] and gate['original_profile_sha256']==identity['profile_sha256']
assert op['helper_sha256']==gate['helper_sha256'] and op['prepared_manifest_sha256']==gate['prepared_manifest_sha256']
assert 0<=time.time()-gate['take_epoch_seconds']<90 and bool(gate['coordination_take_ack'])
args=['/Users/james1/Documents/Codex/shared-tools/amiga-dev-infra/.venv/bin/python','-I','-B',str(PREP/'physical_paula_cache.py'),'--execute-approved-single-case','--prepared-manifest-sha256',op['prepared_manifest_sha256'],'--coordination-gate',str(GATE),'--coordination-gate-sha256',sha(GATE),'--identity',str(IDENTITY),'--identity-sha256',sha(IDENTITY),'--emulator-qualification',op['emulator_qualification'],'--emulator-qualification-sha256',op['emulator_qualification_sha256']]
r={'scope':'Single externally bounded physical RAM-only cache invocation; no retry or automatic recovery','arguments':args,'timeout_seconds':310,'gate_sha256':sha(GATE),'passed':False,'root_release_not_performed':True,'recovery_hold':True,'run_may_be_pending':True};start=time.monotonic()
fd=os.open(ROOT/'root-execution-claim.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'w') as f:json.dump({'arguments':args,'gate_sha256':sha(GATE),'time_ns':time.time_ns(),'retry_allowed':False},f,indent=2);f.write('\n')
with (ROOT/'physical-invocation-prelaunch.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
try:
 with (ROOT/'physical-execution.log').open('x') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=310)
 r['returncode']=p.returncode
 assert p.returncode==0,'Physical helper failed; preserve target/HOLD/files, no retry'
 claim=json.loads((PREP/'physical-execution-claim.json').read_bytes());out=Path(claim['out'])
 assert out.parent==PREP and re.fullmatch(r'physical-paula-cache-[0-9]+',out.name),'Returned output is not owned by this execution clone'
 result=json.loads((out/'result.json').read_bytes())
 r['native_result']={'path':str(out/'result.json'),'sha256':sha(out/'result.json')}
 assert result['passed'] is True and result['recovery_hold'] is False and result['devbench_returned'] is True and result['physical_independent_absence_passed'] is True and result['native_launches']==1,'Physical completion/cleanup/return incomplete'
 assert result['fresh_original_identity']==identity and result['root_gate_sha256']==sha(GATE)
 r['passed']=True;r['run_may_be_pending']=False
except BaseException as e:r['error']=str(e) or type(e).__name__;raise
finally:
 r['elapsed_seconds']=time.monotonic()-start
 with (ROOT/'physical-invocation-result.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
