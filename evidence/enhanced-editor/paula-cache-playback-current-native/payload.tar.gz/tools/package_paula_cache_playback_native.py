#!/usr/bin/env python3
"""Preserve exact build/emulator records without running or contacting anything."""
import argparse, gzip, hashlib, io, json, stat, tarfile
from pathlib import Path, PurePosixPath

REPO = Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
BUILD = Path('/private/tmp/protracker-paula-cache-playback-current-stuk75hj')
ROOT = Path('/private/tmp/protracker-cache-current-root-r7anu_dk')
QUAL = REPO / 'build/dev/paula-cache-memory-qualification-1791048742445491000'
NESTED = QUAL / 'runner-sampler-paula/build/dev/render-files-1791048744242842000'
HOST = REPO / 'evidence/enhanced-editor/playback-master-storage-host'
OUT = REPO / 'evidence/enhanced-editor/paula-cache-playback-current-native'
BUILD_REVIEW = Path('/private/tmp/protracker-cache-playback-current-independent-review.json')
WITHDRAWAL = Path('/private/tmp/protracker-mod-current-root-1cn1g3y0/coordinator-release122.json')
WITHDRAWAL_SHA = '874a6c6640dd7ffcb8b5d5402b88a388706506e5342823b5105259ac58c05f8f'
RUNTIME_REVIEW_SHA = '8b0ed862a24ba5607fcd6638731444a887daa1f7dbd67a1af400c5cf877f1e99'
BINARY_SHA = 'b6c79b4c7c5455702f4ea6817bebd8cdf648c19d5bd77dee20df6282e1cba32d'
MANIFEST_SHA = 'eba7fb37bb4b25dac8596cea4891274194f25963b2a88f2af549a2a5f841a67a'
TOP_SHA = '22805c50507c8dfe5ee46a9a1716376688b806fa234389d5ecc5a8079e9f20ae'
RELEASE_SHA = 'af25bf85579a5efeee542eab6f57d503a70efea36814f52788e19136b2e3ddc5'
HEAD = 'ddee2dbe7bf99d73bb4b80b9ed91382f928d3c46'
TREE = '7e3bd5759893a14f285f0cf322c374651f60732a'

def sha(data):
 return hashlib.sha256(data).hexdigest()

def read_regular(path):
 path = Path(path)
 before = path.lstat()
 if not stat.S_ISREG(before.st_mode):
  raise ValueError('Nonregular original ' + str(path))
 data = path.read_bytes()
 after = path.lstat()
 fields = ('st_dev','st_ino','st_mode','st_size','st_mtime_ns')
 if tuple(getattr(before,x) for x in fields) != tuple(getattr(after,x) for x in fields):
  raise ValueError('Changed original ' + str(path))
 return data, stat.S_IMODE(before.st_mode)

def doc(path, digest=None):
 data, _ = read_regular(path)
 if digest is not None and sha(data) != digest:
  raise ValueError('Pinned original changed ' + str(path))
 return json.loads(data)

def record(path):
 data, mode = read_regular(path)
 return {'path':str(Path(path).absolute()), 'bytes':len(data), 'sha256':sha(data), 'mode':mode}

def verify(rec, external=False):
 path = Path(rec.get('path',rec.get('archive_path','')))
 if external:
  path = path.resolve(strict=True)
 data, _ = read_regular(path)
 assert sha(data) == rec['sha256'], str(path)
 if 'bytes' in rec:
  assert len(data) == rec['bytes'], str(path)
 return path

def originals(runtime_review):
 selected = {}
 def add(path, name, role):
  p = PurePosixPath(name)
  assert not p.is_absolute() and '..' not in p.parts and str(p) == name and name not in selected
  selected[name] = {**record(path),'role':role}
 for path in sorted(BUILD.rglob('*')):
  if stat.S_ISDIR(path.lstat().st_mode):
   continue
  add(path,'build/'+path.relative_to(BUILD).as_posix(),'exact original new build or qualifier preparation record')
 for path in sorted(ROOT.rglob('*')):
  if stat.S_ISDIR(path.lstat().st_mode):
   continue
  add(path,'root/'+path.relative_to(ROOT).as_posix(),'exact original orchestration/identity/idle/coordination record')
 add(QUAL/'qualification-result.json','qualification/top-result.json','original successful pre-release qualification ledger, unchanged')
 add(QUAL/'sampler-paula-runner.log','qualification/sampler-paula-runner.log','original executed runner output')
 add(QUAL/'runner-sampler-paula/tools/shared_infra_render_files.py','qualification/executed-shared_infra_render_files.py','actual executed runner source, not unused copied tools')
 add(QUAL/'runner-sampler-paula/build/dev/PTExecSamplerPaulaTest','qualification/staged-PTExecSamplerPaulaTest','exact staged candidate copy')
 for path in sorted(NESTED.iterdir()):
  assert stat.S_ISREG(path.lstat().st_mode)
  add(path,'qualification/nested/'+path.name,'original nested native/cleanup receipt')
 add(BUILD_REVIEW,'review/build-independent-review.json','independent historical build/preparation review, NOT RUN fields retained')
 add(runtime_review,'review/native-independent-review.json','independent recorded native/cleanup/release review')
 add(WITHDRAWAL,'prior/coordinator-old-cache-withdrawn122.json','literal preceding withdrawal statement, no old cache native result')
 m = doc(BUILD/'native-final/manifest.json',MANIFEST_SHA)
 source = Path(m['source_export'])
 t = m['targets']['PTExecSamplerPaulaTest']
 for name, digest in sorted(t['dependencies'].items()):
  assert sha(read_regular(source/name)[0]) == digest
  add(source/name,'compiled-source/'+name,'exact compiled canonical source/header closure')
 for name in sorted(set(m['python_declaration_inputs'])|{'tools/build_core_tests.py'}):
  add(source/name,'declarations/'+name,'canonical recipe and original host source-list declarations')
 for name in ['manifest.json','packet-provenance.json','SHA256SUMS']:
  add(HOST/name,'host-reference/'+name,'reference controls for separate immutable host packet; its payload is not duplicated')
 add(Path(__file__),'tools/package_paula_cache_playback_native.py','exact executed archival helper')
 return selected

def validate(runtime_review):
 m = doc(BUILD/'native-final/manifest.json',MANIFEST_SHA)
 top = doc(QUAL/'qualification-result.json',TOP_SHA)
 release = doc(ROOT/'coordinator-release128.json',RELEASE_SHA)
 audit = doc(runtime_review,RUNTIME_REVIEW_SHA)
 buildreview = doc(BUILD_REVIEW,'6f5bb5384f6930f7bc225aab2b3d4b31fa67a856f031d1c45752a2ef7c7c7ce6')
 assert audit['passed'] and buildreview['passed']
 for rec in audit['original_records']:
  verify(rec)
 assert audit['qualification']['sha256']==TOP_SHA and audit['candidate']['sha256']==BINARY_SHA
 withdrawal = doc(WITHDRAWAL,WITHDRAWAL_SHA)
 assert 'old cache request remains withdrawn' in json.loads(withdrawal['content'][0]['text'])['polls'][-1]['latestAssistantMessage']['text']
 assert m['passed'] and len(m['commands']) == 30 and all(c['returncode']==0 for c in m['commands'])
 assert set(m['targets']) == {'PTExecSamplerPaulaTest'}
 t = m['targets']['PTExecSamplerPaulaTest']
 assert len(t['source_inputs']) == 19 and len(set(t['source_inputs'])) == 19
 assert len(t['dependencies']) == 48 and len(t['external_sdk_dependencies']) == 49
 assert t['binary_bytes'] == 123732 and t['binary_sha256'] == BINARY_SHA
 binary = read_regular(BUILD/'native-final/PTExecSamplerPaulaTest')[0]
 assert len(binary) == 123732 and sha(binary) == BINARY_SHA and binary[:4] == bytes.fromhex('000003f3')
 verify(m['source_manifest']); verify(m['pins']); verify(m['python'],external=True)
 assert sha(read_regular(Path(m['compiler']).resolve(strict=True))[0]) == m['compiler_sha256']
 assert len(m['runtime_inputs']) == 7 and set(m['runtime_paths']) == set(m['runtime_inputs'])
 for name, digest in m['runtime_inputs'].items():
  assert sha(read_regular(Path(m['runtime_paths'][name]).resolve(strict=True))[0]) == digest
 for path, digest in t['external_sdk_dependencies'].items():
  assert sha(read_regular(Path(path).resolve(strict=True))[0]) == digest
 for c in m['commands']:
  verify(c['log'])
 for r in m['helper_inputs']:
  verify(r)
 verify(t['preprocessed_wrapper']); verify(t['build_log']); verify(m['canonical_recipe'])
 assert len([c for c in m['commands'] if '-M' in c['argv']]) == 19
 assert m['recipe_comparison']['PTExecSamplerPaulaTest']['same_order']
 assert m['source_files_before'] == m['source_files_after'] == 7756
 assert t['last_assert_macro'].startswith('#define assert(__e)') and '__assert_func' in t['last_assert_macro']
 cc_data = read_regular(BUILD/'native-final/compile-commands.json')[0]
 assert sha(cc_data)==m['compile_commands_sha256'] and len(cc_data)==m['compile_commands_bytes']
 current = doc(BUILD/'current-committed-and-working-inputs.json')
 committed = doc(BUILD/'qualifier-current/committed-ddee2db-receipt.json')
 assert current['passed'] and current['head']==committed['head']==HEAD and current['dependencies']==t['dependencies']
 assert current['protected16_byte_identical'] and committed['returncode']==0 and committed['verified']['source_tree']==TREE
 assert top['passed'] and top['source_tree']==TREE and len(top['cases'])==1
 assert top['release_not_performed'] and not top['run_may_be_pending'] and not top['recovery_hold']
 case = top['cases'][0]
 assert case['candidate']['sha256']==BINARY_SHA and case['candidate']['bytes']==123732
 assert case['result']==doc(NESTED/'result.json') and case['independent_cleanup']==doc(NESTED/'independent-cleanup.json')
 assert case['result']['passed'] and case['result']['sampler-paula_returncode']=='0' and case['result']['run_files_cleaned']
 assert case['result']['PTExecSamplerPaulaTest_sha256']==BINARY_SHA
 log = read_regular(NESTED/'sampler-paula.log')[0].decode()
 assert log == case['native_log']
 assert 'EXEC MEMORY PASS: 48 Fast allocations, zero owned bytes, budget refusal without Chip fallback' in log
 assert 'PAULA CHIP JOB PASS:' in log and 'SAMPLER PAULA PASS:' in log
 assert len(case['independent_cleanup']['observations'])==11 and case['independent_cleanup']['absence_observation_span_s']>10
 assert all(not value for obs in case['independent_cleanup']['observations'] for value in obs.values())
 idle = doc(ROOT/'separate-idle-result.json')
 assert idle['passed'] and len(idle['observations'])==11 and idle['observation_span_s']>10
 assert all(not value for obs in idle['observations'] for value in obs['paths'].values())
 assert idle['initial_processes']==idle['final_processes']==top['original_processes']
 assert idle['initial_processes'][0][0]==19081
 for state in [idle['initial_idle'],idle['final_idle']]:
  assert 'Paused=false' in state['status'].split('\t') and 'model=68030' in state['cpu'].split('\t')
  assert all('ch%d_dma=0'%i in state['audio'].split('\t') for i in range(4))
 nativeouter = doc(ROOT/'native-execution-next.json')
 idleouter = doc(ROOT/'separate-idle-execution.json')
 assert nativeouter['passed'] and nativeouter['returncode']==0 and nativeouter['release_not_performed']
 assert nativeouter['run_may_be_pending'] and nativeouter['recovery_hold']
 assert idleouter['passed'] and idleouter['returncode']==0
 assert top['boundaries']=={'native_runner_s':90,'process_s':140,'overall_s':250}
 assert not release['isError']
 reply = json.loads(release['content'][0]['text'])
 poll = reply['polls'][-1]
 assert poll['revision']==128 and poll['latestTurn']['status']=='completed'
 body = poll['latestAssistantMessage']['text']
 assert 'window is released' in body and 'No recovery hold remains' in body and 'no reservation' in body.lower()
 mock = doc(BUILD/'qualifier-current/mock-proof.json')
 watchdog = doc(BUILD/'qualifier-current/watchdog-mock-proof.json')
 assert mock['passed'] and mock['tests']==19 and watchdog['passed'] and watchdog['scenario_count']==7
 for report in [mock,watchdog]:
  for key in ['qualifier','mock_test','helper','test']:
   if key in report:
    verify(report[key])
 host_index = doc(HOST/'manifest.json','167d45c0fa22955b974531566edf306bc8ecbca35cd1b4dcc8419b17d0384674')
 ref = host_index['members']['records/source-manifest-v3.json']
 assert ref['sha256']==m['source_manifest']['sha256'] and ref['bytes']==m['source_manifest']['bytes']
 return m, top, nativeouter, idle, idleouter, poll, audit

def main():
 if not __debug__:
  raise RuntimeError('Optimization disables archival assertions')
 p = argparse.ArgumentParser(description=__doc__)
 p.add_argument('--runtime-review',type=Path,required=True)
 p.add_argument('--inputs',type=Path,required=True)
 p.add_argument('--inputs-sha256')
 p.add_argument('--prepare-only',action='store_true')
 p.add_argument('--qa',type=Path)
 args=p.parse_args()
 m,top,nativeouter,idle,idleouter,poll,audit=validate(args.runtime_review)
 selected=originals(args.runtime_review)
 prepared={'scope':'Pinned exact archival originals; not a target action','members':selected}
 if args.prepare_only:
  assert args.inputs.parent==Path('/private/tmp') and not args.inputs.exists()
  data=(json.dumps(prepared,indent=2,sort_keys=True)+'\n').encode()
  args.inputs.write_bytes(data)
  print(json.dumps({'path':str(args.inputs),'bytes':len(data),'sha256':sha(data),'members':len(selected)}))
  return
 assert args.inputs_sha256 and args.qa and args.qa.parent==Path('/private/tmp') and not OUT.exists() and not args.qa.exists()
 expected=doc(args.inputs,args.inputs_sha256)
 assert expected==prepared
 members={}
 for name,rec in sorted(selected.items()):
  data,mode=read_regular(rec['path'])
  assert sha(data)==rec['sha256'] and len(data)==rec['bytes'] and mode==rec['mode']
  members[name]={**rec,'origin':rec['path'],'data':data}
 data,mode=read_regular(args.inputs)
 members['controls/prepared-inputs.json']={**record(args.inputs),'origin':str(args.inputs),'data':data,'role':'exact pinned original selection before archive execution'}
 def archive_bytes():
  out=io.BytesIO()
  with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=9) as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
    for name,rec in sorted(members.items()):
     info=tarfile.TarInfo(name);info.size=rec['bytes'];info.mode=rec['mode'];info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
     tar.addfile(info,io.BytesIO(rec['data']))
  return out.getvalue()
 payload=archive_bytes();assert payload==archive_bytes()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
  seen=set()
  for info in tar:
   assert info.isfile() and info.name not in seen and info.name in members
   seen.add(info.name);rec=members[info.name];data=tar.extractfile(info).read()
   assert data==rec['data'] and info.mode==rec['mode'] and info.uid==info.gid==info.mtime==0 and info.uname==info.gname==''
  assert seen==set(members)
 for rec in members.values():
  data,mode=read_regular(rec['origin']);assert data==rec['data'] and mode==rec['mode']
 assert originals(args.runtime_review)==expected['members']
 index={'scope':'Exact original regular member bytes/modes; normalized archive timestamps/ownership','members':{n:{k:v for k,v in r.items() if k!='data'} for n,r in sorted(members.items())}}
 t=m['targets']['PTExecSamplerPaulaTest']
 provenance={
  'scope':'Archival integrity of one exact cache build and completed shared030 RAM-only fixture; no new tests/builds/targets',
  'candidate':{'bytes':123732,'sha256':BINARY_SHA},'committed_head':HEAD,'committed_tree':TREE,
  'compiled_canonical_inputs':48,'ordered_translation_units':t['source_inputs'],'build_RC0_commands':30,
  'full_M_queries':19,'external_SDK_fingerprints':t['external_sdk_dependencies'],'runtime_inputs':m['runtime_inputs'],'runtime_paths':m['runtime_paths'],
  'source_snapshot_reference':{'original':m['source_manifest'],'separate_host_packet':str(HOST),'host_manifest_sha256':'167d45c0fa22955b974531566edf306bc8ecbca35cd1b4dcc8419b17d0384674','inventory_member':'records/source-manifest-v3.json','full_export_not_duplicated':True},
  'native_fixture_RC':'0','Fast_allocations':48,'owned_bytes_after_fixture':0,
  'native_watchdog_elapsed_s':nativeouter['elapsed_s'],'separate_idle_watchdog_elapsed_s':idleouter['elapsed_s'],
  'qualification_independent_span_s':top['cases'][0]['independent_cleanup']['absence_observation_span_s'],
  'separate_idle_span_s':idle['observation_span_s'],'separate_idle_observations':11,'original_pid':19081,
  'bounds':top['boundaries'],'release_ack_revision':128,'release_ack_turn':poll['latestTurn']['id'],
  'historical_ledger':'Original outer pending/hold and top release_not_performed fields retained; later separate cleanup/idle/ACK128 establishes release',
  'host_mocks':{'qualifier_cases':19,'watchdog_scenarios':7},'preservation_attribution':'Copied root current committed/working48 and protected16 record, no fresh checkout comparison',
  'independent_runtime_review':record(args.runtime_review),'members':len(members),'original_member_bytes':sum(r['bytes'] for r in members.values()),
  'payload':{'bytes':len(payload),'sha256':sha(payload)},
  'physical_DMA_MMIO_audio_timing_listening_acceptance':'None; actual physical Fast/Chip allocator/cache qualification remains separately gated',
 }
 readme='''This packet preserves the replacement PTExecSamplerPaulaTest build and its one completed shared A1200-030 emulator cache-memory fixture. Exact candidate: 123,732 bytes, SHA256 b6c79b4c7c5455702f4ea6817bebd8cdf648c19d5bd77dee20df6282e1cba32d. Current committed input equivalence was verified at ddee2dbe7bf99d73bb4b80b9ed91382f928d3c46, tree 7e3bd5759893a14f285f0cf322c374651f60732a. The earlier 123,244-byte candidate was superseded before execution according to the parent task. The preceding literal coordinator acknowledgement122 says the old cache request remains withdrawn, and the new pin-change preparation record binds the old/new byte counts and hashes; neither is converted into an old native result.

The original build has 19 ordered translation units, 19 full-M dependency queries, 48 canonical source/header inputs, 49 external SDK fingerprints, seven pinned runtimes and 30 RC0 commands. Exact binary, compiler/runtime identities, SDK assertions, preprocessed wrapper, declaration/recipe comparison, command/log records and the complete compiled 48-input closure are archived. The full 7,756-file source export and SDK trees are omitted. Its exact source inventory is referenced through the separate immutable playback-master-storage-host packet controls, which are copied here as references; that host payload is not duplicated.

Host-only preparation records preserve 19 qualifier mock cases and seven watchdog scenarios, with live interfaces simulated, plus committed-source verify-only and the root current-working/protected16 check. Prepared NOT RUN statements remain historical. The actual emulator fixture ran once under unchanged 90-second native, 140-second runner and 250-second overall bounds, returned RC0 and recorded 48 Fast allocations with zero owned bytes after cleanup. Active SDK assertions cover real emulator Fast/Chip allocation classes, selective routed copies, bounded conversion, version invalidation, pinned leases, eviction pressure and cancellation. Callbacks were injected; no native Paula DMA/MMIO or audio output ran.

The qualifier's independent cleanup recorded 11 exact-path absence observations over more than ten seconds. A separate locked read-only return check recorded another 11 observations over more than ten seconds, preserved original PID 19081/profile/68030 identity, found the emulator running and all four DMA channels idle. Both actual receipts and their independent read-only review are retained. The outer invocation's conservative pending/hold fields and the top ledger's release_not_performed field are unchanged historical records. A later literal AmiConnect RELEASE acknowledgement at revision128 confirms no hold or reservation remains; it is a separate receipt, not an edit to the earlier ledger.

manifest.json binds every regular archive member to original path, byte count, SHA256, mode and role. Archive timestamps/ownership are normalized; duplicate in-memory writes and a full tar-reader byte/mode verification establish deterministic archival integrity. SHA256SUMS binds the four other packet files. Historical helpers retain original paths and must be explicitly rebound for reproduction. Packaging makes no live ownership claim and runs no tests, builds, native binaries, target actions, locks, processes, network or browser operations.

Acceptance is this exact emulator Fast-master/selective Chip-cache ownership fixture only. It does not qualify the real A1200's allocation pools, Paula voice-stop/DMA/music timing, AmiGUS RAM capacity or transfer ordering/completion, physical playback or human listening. Those need separate authorization, candidates and observations.
'''
 contents={'payload.tar.gz':payload,'manifest.json':(json.dumps(index,indent=2,sort_keys=True)+'\n').encode(),'packet-provenance.json':(json.dumps(provenance,indent=2,sort_keys=True)+'\n').encode(),'README.md':readme.encode()}
 contents['SHA256SUMS']=''.join(sha(d)+'  '+n+'\n' for n,d in sorted(contents.items())).encode()
 OUT.mkdir()
 for name,data in contents.items():
  with (OUT/name).open('xb') as handle:handle.write(data)
 assert {p.name for p in OUT.iterdir()}==set(contents)
 for name,data in contents.items():assert read_regular(OUT/name)[0]==data
 qa={'scope':'Archive integrity only; no new qualification','passed':True,'output':str(OUT),'files':len(contents),'bytes':sum(len(d) for d in contents.values()),'members':len(members),'original_member_bytes':sum(r['bytes'] for r in members.values()),'all_origins_byte_mode_verified':True,'deterministic_second_write_equal':True,'controls':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in contents.items()}}
 args.qa.write_text(json.dumps(qa,indent=2,sort_keys=True)+'\n')
 print(json.dumps(qa))

if __name__=='__main__':main()
