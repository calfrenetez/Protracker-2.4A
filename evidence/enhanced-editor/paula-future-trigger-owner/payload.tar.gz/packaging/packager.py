#!/usr/bin/env python3
"""Private deterministic evidence packager; reads saved evidence, never runs a product."""
if not __debug__:
    raise RuntimeError('Optimized Python disables evidence guards')
from pathlib import Path
import argparse, gzip, hashlib, io, json, stat, tarfile

BASE=Path('/private/tmp/protracker-paula-future-owner-vpbs9_ci')
BUILDER_REVIEW=Path('/private/tmp/protracker-future-native-builder-independent-review.json')
V2_REVIEW=Path('/private/tmp/protracker-paula-future-owner-v2-independent-review.json')
V3_REVIEW=Path('/private/tmp/protracker-paula-future-owner-v3-format-independent-review.json')
ROOT_IMPORT=Path('/private/tmp/protracker-native-foundation-current-root-YYUDKM4i/future-root-import.json')
ROOT_IMPORT_SHA='f30d3e369cd51e3bf39828f0177d9837076d4da472bfd79ee8f4b97436bd90ad'
NATIVE_REVIEW_SHA='8b2de2d2e78f05eebd58506126c252d84ba21314f5296a779bb8efc4c0b08dbe'
PINNED={
 'handoff-v2.json':'f03f419280aba02b8816330da51dc69dd0b270328435882591919ef4e36c8038',
 'handoff-v3.json':'54c4a7d2429b14212bb2dfbab03a9017dfad0be32f8b44386da04563eda56ccd',
 'source-manifest-v2.json':'16e31fdafcba336cab9fd151fe122d23cfd158c3664e1489fcbbae8c88af86ac',
 'source-manifest-v3.json':'e81a0589e3ed5e3babec191be3ff9e83e514abcfe826316eaedd3829903915cf',
 'host-final-v2/host-checks.json':'1f56286bc0dfc78e759c9b8b36fb3cd1d5e5e2f484416e4d37000b22ee267175',
 'formatting-equivalence-v3.json':'a79aede60797c41bd9edbe7516bbab586d7622246381685f0c31edcc32be8b5a',
}
REVIEW_SHA={BUILDER_REVIEW:'aa5e27530768a509a3d7098ad3c1cb4186058c186eb93f91f5ac7a62d06f5004',
 V2_REVIEW:'f9913844339ccdee84ee7ff816939b1573cd6139bac0e3bbb1fa7538f16e5915',
 V3_REVIEW:'5c68f00f41400313686d8e483e592b49d36b3ce627617f7f3dd6f36509c3d749'}
TARGET='PTPaulaFutureTriggerTest'
BINARY_SHA='f6247401a54eae94cb36adf07aee9aac2ee70acd4085a0e2fedde51db5624c3f'
RUNTIMES={'ncrt0.o','libnix20.a','libnixmain.a','libnix.a','libstubs.a','libamiga.a','libgcc.a'}
CONTROLS=('README.md','manifest.json','packet-provenance.json','payload.tar.gz','SHA256SUMS')

def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(path):return json.loads(path.read_bytes())
def regular(path):
    info=path.lstat()
    if not stat.S_ISREG(info.st_mode):raise RuntimeError('Regular non-symlink origin required: '+str(path))
    return info

def pinned(path,expected,bytes_=None):
    regular(path);raw=path.read_bytes()
    if sha(raw)!=expected or (bytes_ is not None and len(raw)!=bytes_):
        raise RuntimeError('Exact pinned input changed: '+str(path))
    return raw

def record(path):
    info=regular(path);raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw),'mode':stat.S_IMODE(info.st_mode)}

def safe(relative):
    path=Path(relative)
    if path.is_absolute() or '..' in path.parts or not relative or path.as_posix()!=relative:
        raise RuntimeError('Unsafe noncanonical archive member: '+relative)
    return path

def overlaps(a,b):return a==b or a.is_relative_to(b) or b.is_relative_to(a)

def fingerprint_tree(source,manifest,expected_count):
    files=manifest['files']
    if len(files)!=expected_count:raise RuntimeError('Unexpected complete source count')
    actual={p.relative_to(source).as_posix() for p in source.rglob('*') if not p.is_dir()}
    if actual!=set(files):raise RuntimeError('Frozen source inventory paths changed: '+str(source))
    for rel,value in files.items():pinned(source/safe(rel),value)
    return {'source':str(source),'count':len(files),'ordered_path_hash_fingerprint':sha(json.dumps(sorted(files.items()),separators=(',',':')).encode())}

def verify_metadata_fingerprints(proof):
    # Check original toolchain/system bytes without copying SDK or toolchain trees.
    for key in ('compiler','python'):
        info=proof[key];path=Path(info['path']).resolve(strict=True)
        pinned(path,info['sha256'])
    for key in ('external_sdk_dependencies','sanitizer_runtime_inputs','pinned_sdk_inputs'):
        for path,value in proof.get(key,{}).items():
            expected=value['sha256'] if isinstance(value,dict) else value
            pinned(Path(path).resolve(strict=True),expected)
    if 'runtime_inputs' in proof:
        if set(proof['runtime_inputs'])!=RUNTIMES or set(proof['runtime_paths'])!=RUNTIMES:
            raise RuntimeError('Exactly seven native runtime fingerprints required')
        for name,value in proof['runtime_inputs'].items():
            pinned(Path(proof['runtime_paths'][name]).resolve(strict=True),value)

class Packet:
    def __init__(self):self.raws={};self.members={}
    def add(self,name,path,role,expected=None):
        safe(name)
        if name in self.members:raise RuntimeError('Duplicate destination: '+name)
        info=regular(path);raw=path.read_bytes()
        if expected is not None and sha(raw)!=expected:raise RuntimeError('Source closure mismatch: '+str(path))
        self.raws[name]=raw
        self.members[name]={'original_path':str(path),'bytes':len(raw),'sha256':sha(raw),
                            'mode':stat.S_IMODE(info.st_mode),'role':role}
    def tree(self,prefix,folder,role):
        for path in sorted(folder.rglob('*')):
            if not path.is_dir():self.add(prefix+'/'+path.relative_to(folder).as_posix(),path,role)
    def origin_check(self):
        for member in self.members.values():
            path=Path(member['original_path']);info=regular(path)
            pinned(path,member['sha256'],member['bytes'])
            if stat.S_IMODE(info.st_mode)!=member['mode']:raise RuntimeError('Original mode changed')
    def make(self):
        buffer=io.BytesIO()
        with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0,filename='') as gz:
            with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
                for name in sorted(self.members):
                    entry=tarfile.TarInfo(name);entry.size=len(self.raws[name]);entry.mode=self.members[name]['mode']
                    entry.mtime=0;entry.uid=entry.gid=0;entry.uname=entry.gname=''
                    tar.addfile(entry,io.BytesIO(self.raws[name]))
        return buffer.getvalue()
    def verify_archive(self,payload):
        with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
            entries=tar.getmembers();names=[entry.name for entry in entries]
            if len(names)!=len(set(names)) or set(names)!=set(self.members):raise RuntimeError('Archive member mismatch')
            for entry in entries:
                safe(entry.name);wanted=self.members[entry.name]
                if not entry.isfile() or entry.mode!=wanted['mode'] or entry.uid or entry.gid or entry.mtime or entry.uname or entry.gname:
                    raise RuntimeError('Archive regular member metadata changed')
                raw=tar.extractfile(entry).read()
                if raw!=self.raws[entry.name] or len(raw)!=wanted['bytes'] or sha(raw)!=wanted['sha256']:
                    raise RuntimeError('Archive bytes/hash changed')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-review',type=Path,required=True)
    parser.add_argument('--native-review-sha256',required=True)
    parser.add_argument('--out',type=Path,required=True);parser.add_argument('--qa',type=Path,required=True)
    args=parser.parse_args();out=args.out.resolve();qa=args.qa.resolve()
    if not out.is_relative_to(Path('/private/tmp')) or not qa.is_relative_to(Path('/private/tmp')) or overlaps(out,BASE.resolve()) or overlaps(out,qa) or out.exists() or qa.exists():
        raise RuntimeError('Fresh separate private output and external QA required')
    origins=[BASE,*REVIEW_SHA,ROOT_IMPORT.parent,args.native_review.resolve(),Path(__file__).resolve()]
    if any(overlaps(out,path.resolve()) for path in origins) or any(overlaps(qa,path.resolve()) for path in origins):
        raise RuntimeError('Output overlaps an original evidence input')
    for rel,value in PINNED.items():pinned(BASE/rel,value)
    for path,value in REVIEW_SHA.items():
        raw=pinned(path,value)
        if json.loads(raw).get('passed') is not True:raise RuntimeError('Actual independent review is not CLEAR')
    if args.native_review_sha256!=NATIVE_REVIEW_SHA:raise RuntimeError('Exact actually completed native review binding required')
    native_review_raw=pinned(args.native_review,args.native_review_sha256)
    native_review=json.loads(native_review_raw)
    if native_review.get('passed') is not True or native_review.get('native_execution_performed') is not False:raise RuntimeError('Actual final native crossbuild-only review is not CLEAR')
    for key in ('manifest','source_manifest','binary','original_failure_manifest','audit_schema_failure_history'):
        item=native_review[key];pinned(Path(item['path']),item['sha256'],item['bytes'])
    pinned(ROOT_IMPORT,ROOT_IMPORT_SHA)
    host=parse(BASE/'host-final-v2/host-checks.json');native=parse(BASE/'native-final-v3/manifest.json');failed=parse(BASE/'native-final-v2/manifest.json')
    if host['passed'] is not True or len(host['groups'])!=3 or len(host['commands'])!=6 or any(c['product_returncode']!=0 for c in host['commands']):
        raise RuntimeError('Exact final three host groups/six RC0 commands required')
    if len(host['canonical_dependencies'])!=52 or len(host['external_sdk_dependencies'])!=105 or len(host['products'])!=3 or host['generated_inputs']:
        raise RuntimeError('Exact host closure/products scope changed')
    if native.get('passed') is not True or set(native['targets'])!={TARGET} or len(native['commands'])!=33 or any(c['returncode']!=0 for c in native['commands']):
        raise RuntimeError('Exact final standalone33-RC0 crossbuild required')
    target=native['targets'][TARGET]
    if len(target['source_inputs'])!=22 or len(target['dependencies'])!=50 or len(target['external_sdk_dependencies'])!=32:
        raise RuntimeError('Exact22TU/50canonical/32SDK native closure required')
    if target['binary']['bytes']!=150852 or target['binary']['sha256']!=BINARY_SHA or pinned(Path(target['binary']['path']),BINARY_SHA,150852)[:4]!=b'\0\0\3\xf3':
        raise RuntimeError('Exact final HUNK required')
    if '__assert_func' not in target['last_assert_macro']:raise RuntimeError('Default SDK assertions required')
    if failed.get('passed') is not False or not failed.get('failure') or failed['targets'] or not any(c['returncode']!=0 for c in failed['commands']) or (BASE/'native-final-v2'/TARGET).exists():
        raise RuntimeError('Original native compiler failure must stay distinct without product')
    inventories=[('baseline','baseline-manifest.json',7973),('source-final','source-manifest.json',7978),
                 ('source-final-v2','source-manifest-v2.json',7978),('source-final-v3','source-manifest-v3.json',7978),
                 ('source-native-final-v2','source-native-manifest-v2.json',7979),('source-native-final-v3','source-native-manifest-v3.json',7979)]
    tree_facts=[fingerprint_tree(BASE/source,parse(BASE/manifest),count) for source,manifest,count in inventories]
    manifest_v2=parse(BASE/'source-manifest-v2.json');manifest_v3=parse(BASE/'source-manifest-v3.json');manifest_nv3=parse(BASE/'source-native-manifest-v3.json')
    changed={rel for rel in manifest_v2['files'] if manifest_v2['files'][rel]!=manifest_v3['files'][rel]}
    if changed!={'tests/sampler_paula_future_test.c'} or set(manifest_nv3['files'])!=set(manifest_v3['files'])|{'tools/build_paula_future_test.py'}:
        raise RuntimeError('Source lineage delta changed')
    if any(manifest_nv3['files'][rel]!=value for rel,value in manifest_v3['files'].items()):raise RuntimeError('Native final source differs from final-v3')
    verify_metadata_fingerprints(host);verify_metadata_fingerprints(native)
    for path,value in target['external_sdk_dependencies'].items():pinned(Path(path).resolve(strict=True),value)
    packet=Packet()
    for path in sorted(BASE.iterdir()):
        if path.is_file() and path.name!='committed.tar':
            packet.add('original/'+path.name,path,'Exact original handoff, complete source inventory, patch/equivalence or historical development outcome; mutable-draft logs are not reproducible source qualification')
    for folder in ('tools','host-final','host-final-v2','native-final-v2','native-final-v3'):
        packet.tree('original/'+folder,BASE/folder,'Exact original helper/commands/dependency logs/products; host v1 is superseded history, native v2 is compiler failure, native v3 is compiler-only PASS')
    for source,closure,prefix in [('source-final-v2',host['canonical_dependencies'],'host-compiled-inputs'),
                                  ('source-native-final-v3',target['dependencies'],'native-compiled-inputs')]:
        for rel,value in sorted(closure.items()):packet.add(prefix+'/'+rel,BASE/source/safe(rel),'Exact canonical compiled source/header; closure and full frozen inventory bound',value)
    for item in host['module_inputs']:
        path=Path(item['path']);packet.add('host-declarations/'+path.relative_to(BASE/'source-final-v2').as_posix(),path,'Actual executed/imported Python module bytes',item['sha256'])
    for key in ('committed_flag_recipe','committed_runtime_recipe','host_declaration','host_parent_declaration'):
        item=native['recipe_contract'][key];path=Path(item['path']);packet.add('native-declarations/'+path.relative_to(BASE/'source-native-final-v3').as_posix(),path,'Actual canonical standalone build declaration or committed flags/runtime recipe',item['sha256'])
    packet.add('native-declarations/tools/build_paula_future_test.py',Path(native['builder']['path']),'Exact executed root standalone builder',native['builder']['sha256'])
    for revision,source,manifest in [('v1','source-final','source-manifest.json'),('v2','source-final-v2','source-manifest-v2.json'),('v3','source-final-v3','source-manifest-v3.json')]:
        for overlay in parse(BASE/manifest)['overlays']:
            packet.add('own-overlays/'+revision+'/'+overlay['path'],BASE/source/safe(overlay['path']),'Exact seven-path source overlay history',overlay['sha256'])
    for rel in ('src/editor/sampler.c','src/editor/sampler_internal.h'):
        packet.add('baseline-inputs/'+rel,BASE/'baseline'/rel,'Exact baseline bytes of the two existing modified paths',parse(BASE/'baseline-manifest.json')['files'][rel])
    for path in REVIEW_SHA:packet.add('independent/'+path.name,path,'Actual independent source/host/equivalence/standalone builder review',REVIEW_SHA[path])
    packet.add('independent/native-build-review.json',args.native_review,'Actual separately supplied native crossbuild independent review',args.native_review_sha256)
    history=native_review['audit_schema_failure_history']
    packet.add('independent/native-review-initial-schema-history.json',Path(history['path']),'Original independent audit schema error; no producer/compiler/target rerun',history['sha256'])
    packet.add('root/root-import.json',ROOT_IMPORT,'Exact root-reported eight-path import and protected16 preservation; no compiler/target operation',ROOT_IMPORT_SHA)
    packet.add('root/root-import-initial-schema-history.json',ROOT_IMPORT.with_name('future-root-import-initial-schema-history.json'),'Original root import schema error before mutations; later successful import is separate')
    packet.add('packaging/packager.py',Path(__file__).resolve(),'Exact host-only evidence packaging helper; no product/runtime execution')
    packet.origin_check();payload=packet.make()
    if payload!=packet.make():raise RuntimeError('Duplicate deterministic archive differs')
    packet.verify_archive(payload);packet.origin_check()
    final_tree_facts=[fingerprint_tree(BASE/source,parse(BASE/manifest),count) for source,manifest,count in inventories]
    if final_tree_facts!=tree_facts:raise RuntimeError('Original complete source changed while packaging')
    out.mkdir()
    (out/'payload.tar.gz').write_bytes(payload)
    (out/'manifest.json').write_text(json.dumps({'scope':'Exact original regular member bytes/modes and original paths; normalized archive ownership/timestamps; full source exports and SDK/toolchain trees omitted',
                                               'members':packet.members},indent=2)+'\n')
    provenance={'scope':'Host evidence packaging only; no test/compiler/native target/Guest/lock/browser/network/Git operation',
                'base_commit':host['base_commit'],'base_tree':host['base_tree'],'member_count':len(packet.members),
                'original_bytes':sum(m['bytes'] for m in packet.members.values()),'payload_bytes':len(payload),'payload_sha256':sha(payload),
                'complete_source_tree_verification':tree_facts,'baseline_tar_fingerprint':record(BASE/'committed.tar'),
                'host':{'groups':3,'commands_RC0':6,'canonical_inputs':52,'system_inputs':105,'products':3,'generated_inputs':0,
                        'report':record(BASE/'host-final-v2/host-checks.json'),'scope':'ASan/UBSan software-only synthetic future backend; final-v2 runtime proof'},
                'native':{'ordered_TUs':22,'canonical_inputs':50,'SDK_inputs':32,'runtime_inputs':7,'commands_RC0':33,
                          'manifest':record(BASE/'native-final-v3/manifest.json'),'binary':target['binary'],'scope':'Crossbuild only; default SDK assertions/HUNK; NOT RUN'},
                'original_native_compiler_failure':record(BASE/'native-final-v2/manifest.json'),
                'native_independent_review':record(args.native_review),'root_import':record(ROOT_IMPORT),'packager':record(Path(__file__).resolve()),
                'duplicate_archive_equal':True,'complete_tar_reader_verified':True,'all_original_bytes_modes_verified':True,
                'native_execution':False,'physical_acceptance':False,'IRQ_acceptance':False,'audio_acceptance':False,'hardware_timing_acceptance':False}
    (out/'packet-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    readme='''The future Paula TRIGGER owner seam passed three final host sanitizer groups (six RC0 commands, 52 canonical and 105 system inputs, three archived products). The seven-path implementation owns bounded master pins and selective signed 8-bit cache leases, hides partial preparation, publishes only verified TRIGGER batches, transfers ownership only on queue success, and retains resources until positive task-side retirement. CONTROL/STOP and actual active-reader activation lineage remain unfinished. The separate generic queue/backend and callbacks are synthetic software; the code is not wired to Paula DMA, IRQ, native song output or hardware timing. Full storage-capacity protection and stale/retired/address-reuse cases are covered. Opaque queue/callback-context extents remain the documented caller disjointness contract.

Final-v2 host source has 7,978 files. Final-v3 differs only by a newline separating two existing C statements in one shared test; the exact byte and token-equivalence records plus independent reviews are preserved. The host tests were not repeated for that formatting-only change. Root added one standalone builder, producing a 7,979-file native source tree. Its 22 ordered translation units, 50 canonical inputs, 32 SDK fingerprints, seven runtime inputs and 33 RC0 compile/dependency commands produced the 150,852-byte PTPaulaFutureTriggerTest HUNK (SHA256 f6247401a54eae94cb36adf07aee9aac2ee70acd4085a0e2fedde51db5624c3f). Default SDK assertions remain active. This native program has NOT RUN. Future native qualification must provide a separately assessed explicit stack sufficient for this candidate (not yet qualified) and fresh separately reviewed route, ownership, identity, cleanup and release gates.

The original native-final-v2 compiler failure remains intact and separate from native-final-v3 PASS; it has no linked product. The failure was a misleading-indentation warning in the unchanged test statement, corrected solely by the final-v3 newline. Original source manifests, patches, source history, superseded host proof, all failed compiler logs/commands and final successful compiler logs/product are preserved without substituting outcomes. Mutable development logs are historical outcomes only; they do not imply archived exact mutable-source reproduction.

manifest.json maps every safe regular archive member to its exact original path, SHA256, byte size and original mode. The complete 7,973-file baseline, 7,978-file host revisions and 7,979-file native revisions are fingerprinted and all listed bytes verified before and after packaging. Only canonical compiled inputs, all declared Python inputs, the standalone builder/committed recipe bytes, seven own overlays, helpers, products, logs, full source inventories and actual reviews are archived; full frozen exports and SDK/toolchain trees are omitted. The baseline export tar is fingerprinted without duplicating its full payload. Archive ownership and timestamps are normalized; member bytes and modes are exact. Duplicate deterministic generation and a complete tar-reader check passed. SHA256SUMS binds the other four controls. The exact eight-path root import record and original pre-mutation schema-error history are included; later repository documentation-only status edits are distinct and are not used to replace the immutable original source documentation. Historical absolute paths require deliberate rebinding for reproduction.

This packet provides host software/runtime and compiler-only evidence. It provides no native execution, physical Fast/Chip allocation, TypeOfMem, DMA, IRQ, device control, audio, listening, frame-scheduling deadline or hardware timing acceptance. Packaging performed no product test, compiler rerun or target operation.
'''
    (out/'README.md').write_text(readme)
    (out/'SHA256SUMS').write_text(''.join(sha((out/name).read_bytes())+'  '+name+'\n' for name in CONTROLS if name!='SHA256SUMS'))
    checks={name:record(out/name) for name in CONTROLS}
    lines=(out/'SHA256SUMS').read_text().splitlines()
    if len(lines)!=4:raise RuntimeError('Four control checksum rows required')
    for row in lines:
        value,name=row.split('  ',1);pinned(out/name,value)
    packet.verify_archive((out/'payload.tar.gz').read_bytes());packet.origin_check()
    qa_record={'passed':True,'scope':'Host-only complete packet byte/origin/mode/checksum/archive QA; no product rerun',
               'packet':str(out),'file_count':5,'file_bytes':sum(item['bytes'] for item in checks.values()),'controls':checks,
               'member_count':len(packet.members),'original_member_bytes':sum(m['bytes'] for m in packet.members.values()),
               'duplicate_deterministic_archive_equal':True,'full_tar_reader_verified':True,'all_originals_unchanged':True,
               'source_inventories_before_after_equal':True,'checksums_unique_complete_verified':True}
    qa.write_text(json.dumps(qa_record,indent=2)+'\n')
    print(json.dumps({'packet':str(out),'QA':record(qa),'member_count':len(packet.members),'original_member_bytes':provenance['original_bytes'],
                     'controls':checks,'file_bytes':qa_record['file_bytes']},indent=2))

if __name__=='__main__':main()
