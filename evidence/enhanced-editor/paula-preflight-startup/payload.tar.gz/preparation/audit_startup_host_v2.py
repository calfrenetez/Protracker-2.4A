"""Read saved source/compiler/product proof only. Does not run a product/compiler."""
from pathlib import Path
import argparse, hashlib, json, shlex, shutil, tarfile, sys, re
if not __debug__:
    raise RuntimeError('Optimized audit invocation refused')
sys.path.insert(0,str(Path(__file__).resolve().parent/'host-tools-v1'))
from provenance_common import cpp_arguments, compiler_input_arguments

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def record(p):
    p=Path(p)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}

def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--proof',type=Path,required=True)
    ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();source=args.root/'candidate-v2'
    m=json.loads(args.manifest.read_text())
    actual={p.relative_to(source).as_posix():digest(p) for p in sorted(source.rglob('*')) if p.is_file()}
    assert actual==m['source']
    baseline=json.loads((args.root/'baseline-manifest.json').read_text())
    old={k:v['sha256'] for k,v in baseline['files'].items()}
    with tarfile.open(args.root/'base.tar') as archive:
        assert {p.name:hashlib.sha256(archive.extractfile(p).read()).hexdigest() for p in archive if p.isfile()}==old
    assert sorted(k for k,v in actual.items() if old.get(k)!=v)==sorted(m['owned'])
    assert set(old)<=set(actual)
    r=json.loads((args.proof/'host-checks.json').read_text())
    expected=['test_render_sequence_startup','test_paula_preflight_startup','test_paula_preflight','test_render_sequence','test_render_plan','test_render_invert','test_render_range','test_sampler_paula_readers_boundary']
    assert r['passed'] and [g['module'] for g in r['groups']]==expected
    assert all(g['passed'] and g['tests'] and not g['failures'] and not g['errors'] for g in r['groups'])
    assert r['source_files_before']==r['source_files_after']==len(actual)
    assert r['export_tree_sha256']==hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    canonical={};system={};queries=0;executions=0;latest_products={};latest_objects={}
    generated={}
    for f in r['products']+r['generated_inputs']:
        p=Path(f['archive_path']);assert p.is_file() and digest(p)==f['sha256'] and p.stat().st_size==f['bytes']
        generated.setdefault(f['original_path'],[]).append(f)
    def read_digest(p):
        p=Path(p)
        if p.is_file():return digest(p)
        entries=generated[str(p)]
        values={entry['sha256'] for entry in entries}
        assert len(values)==1
        return next(iter(values))
    for c in r['commands']:
        assert c['stage']=='complete' and c['product_returncode']==0
        assert digest(c['output_log']['path'])==c['output_log']['sha256']
        is_compiler=c['executed_argv'][0]==r['compiler']['path']
        if is_compiler:
            assert c['executed_argv'][0]==r['compiler']['path']
            assert '-fsanitize=address,undefined' in c['executed_argv']
            argv=c['executed_argv']
            assert not any(x.startswith('-DNDEBUG') or (x=='-D' and i+1<len(argv) and argv[i+1].split('=')[0]=='NDEBUG') for i,x in enumerate(argv))
            options,units=cpp_arguments(argv)
            assert len(units)==len(c['dependency_commands'])
            ci=[];gi=[]
            for item in compiler_input_arguments(argv):
                if not item.endswith(('.c','.o')):continue
                p=(Path(c['directory'])/item).resolve()
                try:rel=p.relative_to(source.resolve()).as_posix()
                except ValueError:rel=None
                if rel is not None:ci.append({'path':rel,'sha256':actual[rel]})
                else:
                    matches=[x for x in c['generated_inputs'] if Path(x['original_path']).resolve()==p]
                    assert len(matches)==1;f=matches[0];gi.append(f)
                    assert digest(f['archive_path'])==f['sha256']
                    if p.suffix=='.o':
                        assert str(p) in latest_objects and latest_objects[str(p)]['sha256']==f['sha256']
            assert ci==c['canonical_inputs'] and gi==c['generated_inputs']
            for unit,q in zip(units,c['dependency_commands']):
                assert q['unit']==unit and q['argv']==[r['compiler']['path'],*options,'-M',unit] and q['directory']==c['directory']
        else:
            executions+=1
            assert not c['dependency_commands'] and not c['canonical_inputs'] and not c['generated_inputs']
            assert len(c['executed_argv'])==1 and 'input_binary' in c
            key=str(Path(c['executed_argv'][0]).resolve());f=c['input_binary']
            assert key in latest_products and latest_products[key]['sha256']==f['sha256']
            assert digest(f['archive_path'])==f['sha256']
        cc={};cs={};cg={}
        for q in c['dependency_commands']:
            queries+=1
            assert q['returncode']==0 and '-M' in q['argv'] and '-MM' not in q['argv']
            assert '-fsanitize=address,undefined' in q['argv']
            assert digest(q['output']['path'])==q['output']['sha256']
            joined=Path(q['output']['path']).read_text().replace('\\\n',' ')
            for name in shlex.split(joined.split(':',1)[1]):
                p=(Path(q['directory'])/name).resolve() if not Path(name).is_absolute() else Path(name).resolve()
                try:relative=p.relative_to(source.resolve()).as_posix()
                except ValueError:relative=None
                if relative is not None:
                    assert relative in actual and digest(p)==actual[relative];cc[relative]=actual[relative]
                elif str(p) in generated:cg[str(p)]=read_digest(p)
                else:cs[str(p)]=digest(p)
        assert cc==c['dependencies']['canonical'] and cs==c['dependencies']['external_sdk'] and cg==c['dependencies']['generated']
        canonical.update(cc);system.update(cs)
        for role in ('produced_binary','input_binary','produced_object'):
            if role in c:
                f=c[role];assert digest(f['archive_path'])==f['sha256'] and Path(f['archive_path']).stat().st_size==f['bytes']
        if is_compiler:
            destination=(Path(c['directory'])/c['executed_argv'][c['executed_argv'].index('-o')+1]).resolve()
            if destination.suffix=='.o':
                assert 'produced_object' in c and c['produced_object']['original_path']==str(destination)
                latest_objects[str(destination)]=c['produced_object']
            else:
                assert 'produced_binary' in c and c['produced_binary']['original_path']==str(destination)
                latest_products[str(destination)]=c['produced_binary']
    assert canonical==r['canonical_dependencies'] and system==r['external_sdk_dependencies']
    for role in ('sanitizer_runtime_inputs','pinned_sdk_inputs'):
        for p,h in r[role].items():assert digest(p)==h
    for role in ('compiler','python'):assert digest(r[role]['path'])==r[role]['sha256']
    for f in r['helper_inputs']+r['module_inputs']+[r['source_manifest'],r['pins'],r['log']]:
        assert digest(f['path'])==f['sha256'] and Path(f['path']).stat().st_size==f['bytes']
    assert executions>=len(expected) and queries>0
    for module,fixture in [('test_render_sequence_startup','tests/render_sequence_startup_test.c'),('test_paula_preflight_startup','tests/paula_preflight_startup_test.c')]:
        markers=re.findall(r'puts\("([^"\n]+ STARTUP PASS:[^"\n]+)"\)',(source/fixture).read_text())
        assert len(markers)==1
        calls=[c for c in r['commands'] if c['group']==module and 'input_binary' in c]
        assert len(calls)==1 and Path(calls[0]['output_log']['path']).read_text().count(markers[0])==1
    assert not args.out.exists();shutil.copytree(args.proof,args.out,copy_function=shutil.copy2)
    copies=[]
    for p in sorted(args.proof.rglob('*')):
        if p.is_file():
            copy=args.out/p.relative_to(args.proof)
            assert p.read_bytes()==copy.read_bytes() and (p.stat().st_mode&0o777)==(copy.stat().st_mode&0o777)
            copies.append({'original':str(p),'copy':str(copy),'bytes':p.stat().st_size,'sha256':digest(p)})
    assert actual=={p.relative_to(source).as_posix():digest(p) for p in sorted(source.rglob('*')) if p.is_file()}
    result={'passed':True,'scope':'Root saved-byte source/dependency/product audit only, no compiler/product rerun','source_manifest':record(args.manifest),'report':record(args.out/'host-checks.json'),'source_files':len(actual),'baseline_files':len(old),'owned':m['owned'],'groups':r['groups'],'commands':len(r['commands']),'full_M_queries':queries,'canonical_inputs':len(canonical),'system_inputs':len(system),'products':len(r['products']),'generated':r['generated_inputs'],'durable_copies':copies,'source_before_after_exact':True,'native':'NOT_RUN','physical':'NOT_RUN'}
    target=args.root/'root-host-audit-final-v2.json';target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'receipt':record(target),'commands':len(r['commands']),'full_M':queries,'canonical':len(canonical),'system':len(system),'products':len(r['products']),'generated':len(r['generated_inputs'])}))

if __name__=='__main__':main()
