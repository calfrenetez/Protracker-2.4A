"""Freeze saved candidate and bind exact Git bytes; no build/test/target call."""
import ast, hashlib, json, re, subprocess, tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
def sha(data): return hashlib.sha256(data).hexdigest()
def rec(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def save(name,v):
    p=ROOT/name
    if p.exists(): raise ValueError('Refuse overwriting '+str(p))
    p.write_text(json.dumps(v,indent=2)+'\n');return rec(p)
def git(*args):return subprocess.run(['git',*args],cwd=REPO,check=True,capture_output=True).stdout
def main():
    before=json.loads((ROOT/'before-state.json').read_text());base=json.loads((ROOT/'baseline-manifest.json').read_text())
    assert git('rev-parse','HEAD').decode().strip()==base['base_commit']==before['head']
    assert git('rev-parse','HEAD^{tree}').decode().strip()==base['base_tree']
    assert not git('diff','--cached','--name-only')
    for f in before['preserved_files']:
        p=REPO/f['path'];assert sha(p.read_bytes())==f['sha256'] and p.stat().st_size==f['bytes']
    assert rec(ROOT/'base.tar')['sha256']==before['archive']['sha256']
    tree={}
    for row in git('ls-tree','-rz',base['base_commit']).split(b'\0'):
        if row:
            meta,name=row.split(b'\t',1);mode,kind,h=meta.split();assert kind==b'blob';tree[name.decode()]=(mode.decode(),h.decode())
    blobs={}
    with tarfile.open(ROOT/'base.tar') as tf:
        for f in tf:
            if f.isfile():
                data=tf.extractfile(f).read();assert sha(data)==base['files'][f.name]['sha256'] and len(data)==base['files'][f.name]['bytes']
                blobs[f.name]=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert set(blobs)==set(tree)==set(base['files'])
    assert all(blobs[k]==tree[k][1] for k in blobs)
    candidate=ROOT/'candidate-v2';actual={};sizes={}
    for p in sorted(candidate.rglob('*')):
        assert not p.is_symlink()
        if p.is_file(): actual[p.relative_to(candidate).as_posix()]=sha(p.read_bytes());sizes[p.relative_to(candidate).as_posix()]=p.stat().st_size
    scope=json.loads((ROOT/'scope.json').read_text());owned=scope['production_owned']+scope['fixture_owned']
    assert len(owned)==len(set(owned))==8
    assert sorted(k for k,h in actual.items() if base['files'].get(k,{}).get('sha256')!=h)==sorted(owned)
    assert set(blobs)<=set(actual) and len(actual)==len(blobs)+4==8107
    fingerprint=sha(json.dumps(actual,sort_keys=True,separators=(',',':')).encode())
    h=save('frozen-source-host-v2.json',{'scope':scope['scope'],'base_commit':base['base_commit'],'base_tree':base['base_tree'],'source':actual,'owned':owned,'source_fingerprint':fingerprint})
    n=save('frozen-source-native-v2.json',{'base_commit':base['base_commit'],'base_tree':base['base_tree'],'files':actual,'owned':owned,'source_fingerprint':fingerprint})
    renderer=ast.parse((candidate/'tests/test_render_sequence_startup.py').read_text())
    sources=next(ast.literal_eval(x.value) for x in renderer.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in x.targets))
    assert len(sources)==len(set(sources))==10
    contracts=[]
    for target,fixture,declaration,units,chain in [
        ('PTRenderStartupTest','tests/render_sequence_startup_test.c','tests/test_render_sequence_startup.py',sources,[sources[0]]),
        ('PTPaulaPreflightStartupTest','tests/paula_preflight_startup_test.c','tests/test_paula_preflight_startup.py',['tests/paula_preflight_startup_test.c',*sources[1:],'src/editor/paula_preflight.c','src/core/paula_render_voice.c'],['tests/paula_preflight_startup_test.c',sources[0]])]:
        markers=re.findall(r'puts\("([^"\n]+ STARTUP PASS:[^"\n]+)"\)',(candidate/fixture).read_text());assert len(markers)==1
        assert len(units)==len(set(units)) and all(x in actual for x in units)
        contracts.append(save('native-preparation/'+target+'-contract-v2.json',{'target':target,'fixture':fixture,'host_declaration':declaration,'source_constant':'SOURCES','marker':markers[0],'ordered_sources':units,'include_chain':chain}))
    helpers=[ROOT/'host-tools-v1'/x for x in ('host_provenance.py','provenance_common.py','toolchain-pins.json')]+[ROOT/'native-preparation'/x for x in ('build_preflight_startup_portability.py','toolchain-pins.json')]
    result={'scope':'Saved-byte freeze only; no tests/compiler/target run','passed':True,'base_commit':base['base_commit'],'base_tree':base['base_tree'],'base_tar':rec(ROOT/'base.tar'),'all_baseline_git_blobs':len(blobs),'source_files':len(actual),'source_fingerprint':fingerprint,'host_manifest':h,'native_manifest':n,'manifests_identical_map':True,'owned':[{'path':x,'bytes':sizes[x],'sha256':actual[x]} for x in owned],'helpers':[rec(x) for x in helpers],'fixture_contracts':contracts,'protected16_exact':True,'native':'NOT_RUN','physical':'NOT_RUN'}
    for p in candidate.rglob('*'):
        if p.is_file():p.chmod(p.stat().st_mode&~0o222)
    print(json.dumps(save('root-final-source-freeze-v2.json',result)))
if __name__=='__main__':main()
