#!/usr/bin/env python3
"""Pinned standalone one-fixture readers portability compile/link check; never runs the HUNK.

Prepared derivative of the reviewed V2 startup/genuine readers builder. Accepts
one explicit 22-TU readers or 28/29-TU boundary contract and a root-authorized
frozen source manifest. Preparation does not authorize compilation; the root
must approve the final reviewed source.

Uses the committed core-test 68000/nix20 conventions, suitable for the shared
030 profile. This is portable compilation only, not Exec allocation, Chip/DMA,
song/native output, interrupts or timing qualification. The SDK assertions stay
enabled. A later runtime harness needs its own ownership/identity/cleanup gates
and separately measured sufficient Stack for full master before-image objects.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys
import time
import traceback

ORIGINAL_SOURCES = ['tests/sampler_paula_readers_test.c', 'src/editor/sampler_paula.c', 'src/core/sample_cache.c', 'src/core/playback_pcm.c', 'src/core/scheduled_readers.c', 'src/core/elapsed_clock.c', 'src/editor/sampler.c', 'src/editor/slots.c', 'src/core/pcm_filtered.c', 'src/core/slices.c', 'src/core/pattern.c', 'src/core/document.c', 'src/core/pp20.c', 'src/core/project.c', 'src/core/mod_project.c', 'src/core/mod_inspect.c', 'src/core/channels.c', 'src/core/pcm.c', 'src/core/wav.c', 'src/core/svx.c', 'src/core/raw.c']
READERS_SOURCES = [*ORIGINAL_SOURCES[:6], 'src/core/paula_render_voice.c', *ORIGINAL_SOURCES[6:]]
RENDERER_SOURCES = ['src/core/render.c', 'src/core/pitch.c', 'src/core/timeline.c',
                    'src/core/frame_clock.c', 'src/core/flow.c', 'src/core/voice.c']
BOUNDARY_FIXTURE = 'tests/sampler_paula_readers_boundary_test.c'
BOUNDARY_DECLARATION = 'tests/test_sampler_paula_readers_boundary.py'
READER_IMPLEMENTATION = 'src/editor/sampler_paula_readers.c'
FLAGS = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
         '-Wall', '-Wextra', '-Werror', '-Isrc/core', '-Ibuild/dev', '-fbbb=-']
RUNTIMES = ['ncrt0.o', 'libnix20.a', 'libnixmain.a', 'libnix.a',
            'libstubs.a', 'libamiga.a', 'libgcc.a']
SOURCES = READERS_SOURCES.copy()
TARGET = 'PTPaulaReadersTest'
FIXTURE_CONTRACT = {}
EXPECTED_MARKER = ''
SCOPE = ('Portable pinned 68k compile/link only; no HUNK execution, native/Exec '
         'allocator, Chip/DMA, device, song, IRQ, audio or hardware timing proof')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}


def require_pin(path, expected):
    p = Path(path)
    if not p.is_file() or digest(p) != expected:
        raise ValueError('Pinned input absent or changed: ' + str(p))


def snapshot(source):
    result = {}
    for p in sorted(source.rglob('*')):
        if p.is_symlink():
            raise ValueError('Frozen source contains a symlink: ' + str(p))
        if p.is_file():
            result[p.relative_to(source).as_posix()] = digest(p)
    return result


def require_source(source, expected):
    if snapshot(source) != expected:
        raise ValueError('Complete frozen source inventory changed')


def source_fingerprint(expected):
    return hashlib.sha256(json.dumps(expected, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def below(p, root):
    return p == root or root in p.parents


def write_json(path, value):
    staged = path.with_suffix(path.suffix + '.writing')
    staged.write_text(json.dumps(value, indent=2) + '\n')
    staged.replace(path)


def dependencies(output):
    output = re.sub(r'\\\r?\n', ' ', output)
    names = []
    for line in output.splitlines():
        colon = re.search(r'(?<!\\):', line)
        if colon:
            names.extend(shlex.split(line[colon.end():]))
    return list(dict.fromkeys(names))


def readers_declaration(source, relative, constant, fixture):
    """Accept only seven literal entries and the exact inherited SOURCES[1:]."""
    h = ast.parse((source / relative).read_text())
    parent_host = source / 'tests/test_sampler.py'
    parent = ast.parse(parent_host.read_text())
    parent_units = next(ast.literal_eval(n.value) for n in parent.body if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == 'SOURCES' for t in n.targets))
    declaration = next(n.value for n in h.body if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == constant for t in n.targets))
    imports = [n for n in h.body if isinstance(n, ast.ImportFrom) and n.module == 'test_sampler']
    prefix = [fixture, *READERS_SOURCES[1:7]]
    if (len(imports) != 1 or [(n.name, n.asname) for n in imports[0].names] != [('SOURCES', None)]
            or not isinstance(declaration, ast.List) or len(declaration.elts) != 8
            or [ast.literal_eval(n) for n in declaration.elts[:-1]] != prefix
            or not isinstance(declaration.elts[-1], ast.Starred)
            or ast.unparse(declaration.elts[-1].value) != 'SOURCES[1:]'):
        raise ValueError('Exact 22-TU readers fixture declaration/import changed')
    return prefix + parent_units[1:]


def recipe_contract(source, expected, pins):
    """Read declarations as data, without importing existing build/test code."""
    recipe = source / 'tools/build_core_tests.py'
    require_pin(recipe, pins['canonical_recipe']['sha256'])
    tree = ast.parse(recipe.read_text())
    flags = next(n.value for n in ast.walk(tree) if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == 'flags' for t in n.targets))
    literals = [n.value for n in flags.elts if isinstance(n, ast.Constant)]
    expansions = [ast.unparse(n.value) for n in flags.elts if isinstance(n, ast.Starred)]
    if literals != FLAGS[:-1] or expansions != ['compiler_safety_flags(cc)']:
        raise ValueError('Committed native flag convention changed')
    diagnostic = source / 'tools/build_diagnostic.py'
    require_pin(diagnostic, expected['tools/build_diagnostic.py'])
    d = ast.parse(diagnostic.read_text())
    fn = next(n for n in d.body if isinstance(n, ast.FunctionDef) and n.name == 'runtime_inputs')
    declared = next(ast.literal_eval(n.value) for n in fn.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'names' for t in n.targets))
    if declared != RUNTIMES:
        raise ValueError('Committed seven-runtime convention changed')
    host = source / FIXTURE_CONTRACT['host_declaration']
    parent_host = source / 'tests/test_sampler.py'
    inherited_host = source / 'tests/test_sampler_paula_readers.py'
    boundary = TARGET == 'PTPaulaReadersBoundaryTest'
    if boundary:
        inherited = readers_declaration(source, 'tests/test_sampler_paula_readers.py',
                                        'READERS_SOURCES', ORIGINAL_SOURCES[0])
        if inherited != READERS_SOURCES:
            raise ValueError('Inherited genuine readers source closure changed')
        h = ast.parse(host.read_text())
        declaration = next(n.value for n in h.body if isinstance(n, ast.Assign)
                           and any(isinstance(t, ast.Name) and t.id == FIXTURE_CONTRACT['source_constant'] for t in n.targets))
        imports = [n for n in h.body if isinstance(n, ast.ImportFrom) and n.module == 'test_sampler_paula_readers']
        suffix = SOURCES[len(READERS_SOURCES):]
        if (len(imports) != 1 or [(n.name, n.asname) for n in imports[0].names] != [('READERS_SOURCES', None)]
                or not isinstance(declaration, ast.List) or len(declaration.elts) != 2 + len(suffix)
                or ast.literal_eval(declaration.elts[0]) != BOUNDARY_FIXTURE
                or not isinstance(declaration.elts[1], ast.Starred)
                or ast.unparse(declaration.elts[1].value) != 'READERS_SOURCES[1:]'
                or [ast.literal_eval(n) for n in declaration.elts[2:]] != suffix):
            raise ValueError('Exact boundary fixture declaration/import changed')
        units = [BOUNDARY_FIXTURE, *inherited[1:], *suffix]
    else:
        units = readers_declaration(source, FIXTURE_CONTRACT['host_declaration'],
                                    FIXTURE_CONTRACT['source_constant'], FIXTURE_CONTRACT['fixture'])
    if units != SOURCES or len(units) != len(set(units)):
        raise ValueError('Host ordered source declaration changed')
    chain = FIXTURE_CONTRACT['include_chain']
    for first, second in zip(chain, chain[1:]):
        includes = re.findall(r'^\s*#\s*include\s+"([^"\n]+\.c)"', (source / first).read_text(), re.MULTILINE)
        expected_include = 'sampler_paula_readers_test.c' if second == ORIGINAL_SOURCES[0] else '../src/editor/sampler_paula_readers.c'
        if includes != [expected_include]:
            raise ValueError('Exact direct/transitive adapter inclusion changed')
    if READER_IMPLEMENTATION in SOURCES or (boundary and ORIGINAL_SOURCES[0] in SOURCES):
        raise ValueError('Included fixture/adapter may not be separately compiled')
    return {'committed_flag_recipe': record(recipe), 'committed_runtime_recipe': record(diagnostic),
            'host_declaration': record(host), 'host_parent_declaration': record(parent_host),
            'host_inherited_declaration': record(inherited_host),
            'exact_ordered_translation_units': SOURCES,
            'include_chain': chain,
            'included_sources': [record(source / relative) for relative in chain[1:]],
            'adapter_inclusion': 'Shared C fixture includes sampler_paula_readers.c exactly once through the declared chain; no included C source is separately compiled',
            'flags': FLAGS, 'runtime_names': RUNTIMES,
            'policy': 'Standalone one-target build, reusing the archived readers proof recipe and current committed flags/runtime conventions without executing or editing shared recipes'}


def main():
    global SOURCES, TARGET, FIXTURE_CONTRACT, EXPECTED_MARKER
    sys.dont_write_bytecode = True
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--fixture-contract', type=Path, required=True)
    ap.add_argument('--fixture-contract-sha256', required=True)
    ap.add_argument('--source-manifest', type=Path, required=True)
    ap.add_argument('--source-manifest-sha256', required=True)
    ap.add_argument('--pins', type=Path, required=True)
    ap.add_argument('--pins-sha256', required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    source = args.source.resolve()
    out = args.out.resolve()
    manifest_input, pin_input = args.source_manifest.resolve(), args.pins.resolve()
    if out.exists() or below(out, source) or below(source, out):
        raise ValueError('Output must be fresh and outside source')
    if below(manifest_input, out) or below(pin_input, out):
        raise ValueError('Input controls must be outside output')
    contract_input = args.fixture_contract.resolve()
    if below(contract_input, out):
        raise ValueError('Fixture contract must be outside output')
    require_pin(contract_input, args.fixture_contract_sha256)
    FIXTURE_CONTRACT = json.loads(contract_input.read_text())
    if set(FIXTURE_CONTRACT) != {'fixture', 'host_declaration', 'source_constant', 'target', 'marker', 'ordered_sources', 'include_chain'}:
        raise ValueError('Exactly the declared one-fixture contract fields required')
    for name in ('fixture', 'host_declaration'):
        path = FIXTURE_CONTRACT[name]
        if not isinstance(path, str) or Path(path).is_absolute() or '..' in Path(path).parts or Path(path).as_posix() != path:
            raise ValueError('Noncanonical fixture contract path')
    if (not FIXTURE_CONTRACT['fixture'].startswith('tests/') or not FIXTURE_CONTRACT['fixture'].endswith('.c') or
            not FIXTURE_CONTRACT['host_declaration'].startswith('tests/') or not FIXTURE_CONTRACT['host_declaration'].endswith('.py') or
            not re.fullmatch(r'[A-Z][A-Z0-9_]*', FIXTURE_CONTRACT['source_constant']) or
            FIXTURE_CONTRACT['target'] not in ('PTPaulaReadersTest', 'PTPaulaReadersStartupTest', 'PTPaulaReadersBoundaryTest') or
            not isinstance(FIXTURE_CONTRACT['marker'], str) or not FIXTURE_CONTRACT['marker'] or
            any(c in FIXTURE_CONTRACT['marker'] for c in '\r\n\0')):
        raise ValueError('Explicit readers portability fixture identity required')
    TARGET, EXPECTED_MARKER = FIXTURE_CONTRACT['target'], FIXTURE_CONTRACT['marker']
    if TARGET == 'PTPaulaReadersBoundaryTest':
        if (FIXTURE_CONTRACT['fixture'] != BOUNDARY_FIXTURE or
                FIXTURE_CONTRACT['host_declaration'] != BOUNDARY_DECLARATION):
            raise ValueError('Exact boundary fixture identity required')
        base = [BOUNDARY_FIXTURE, *READERS_SOURCES[1:]]
        allowed = [base + RENDERER_SOURCES, base + ['src/editor/paula_preflight.c', *RENDERER_SOURCES]]
        if FIXTURE_CONTRACT['ordered_sources'] not in allowed:
            raise ValueError('Only exact 28/29-TU boundary closures allowed')
        SOURCES = FIXTURE_CONTRACT['ordered_sources'].copy()
        chain = [BOUNDARY_FIXTURE, ORIGINAL_SOURCES[0], READER_IMPLEMENTATION]
    else:
        SOURCES = [FIXTURE_CONTRACT['fixture'], *READERS_SOURCES[1:]]
        chain = [SOURCES[0], READER_IMPLEMENTATION]
    if (FIXTURE_CONTRACT['ordered_sources'] != SOURCES or len(SOURCES) != len(set(SOURCES)) or
            FIXTURE_CONTRACT['include_chain'] != chain):
        raise ValueError('Exact ordered source closure/inclusion chain required')
    require_pin(manifest_input, args.source_manifest_sha256)
    require_pin(pin_input, args.pins_sha256)
    complete = json.loads(manifest_input.read_text())
    expected = complete['files']
    if not isinstance(expected, dict) or not expected:
        raise ValueError('Full source manifest dictionary required')
    require_source(source, expected)
    all_pins = json.loads(pin_input.read_text())
    pins, python = all_pins['native'], all_pins['host']['python']
    compiler = pins['compiler']['path']
    if Path(sys.executable).resolve() != Path(python['path']).resolve() or sys.version != python['version']:
        raise ValueError('Python executable/version does not match supplied pin')
    require_pin(python['path'], python['sha256'])
    require_pin(compiler, pins['compiler']['sha256'])
    if set(pins['runtime_inputs']) != set(RUNTIMES):
        raise ValueError('Exactly seven runtime pins required')
    sdk_roots = [Path(p).resolve() for p in pins['allowed_sdk_roots']]
    if not sdk_roots:
        raise ValueError('Explicit native SDK roots required')
    convention = recipe_contract(source, expected, all_pins)
    builder = record(Path(__file__).resolve())
    out.mkdir(parents=True)
    started = time.monotonic()
    commands, compile_commands, runtime_paths, sdk_inputs, canonical_inputs = [], [], {}, {}, {}
    result = {'scope': SCOPE, 'passed': False, 'source_export': str(source),
              'source_manifest': record(manifest_input), 'pins': record(pin_input),
              'fixture_contract': record(contract_input), 'native_NOT_RUN': True,
              'base_commit': complete['base_commit'], 'base_tree': complete['base_tree'],
              'source_files_before': len(expected), 'source_fingerprint': source_fingerprint(expected),
              'compiler': pins['compiler'], 'python': python, 'builder': builder,
              'recipe_contract': convention, 'flags': FLAGS, 'runtime_inputs': {},
              'runtime_paths': runtime_paths, 'commands': commands, 'targets': {}}

    def persist():
        command_path = out / 'compile-commands.json'
        write_json(command_path, {'commands': compile_commands})
        result['compile_commands'] = record(command_path)
        result['elapsed_s'] = time.monotonic() - started
        write_json(out / 'manifest.json', result)

    def run(argv, label):
        row = {'label': label, 'argv': argv, 'directory': str(source)}
        commands.append(row)
        persist()
        completed = subprocess.run(argv, cwd=source, capture_output=True, text=True, timeout=180)
        log = out / (label + '.log')
        log.write_text(completed.stdout + completed.stderr)
        row.update(returncode=completed.returncode, log=record(log))
        persist()
        if completed.returncode:
            raise subprocess.CalledProcessError(completed.returncode, argv, completed.stdout, completed.stderr)
        return completed.stdout

    def toolchain_current():
        require_pin(compiler, pins['compiler']['sha256'])
        require_pin(python['path'], python['sha256'])
        for name, path in runtime_paths.items():
            require_pin(path, pins['runtime_inputs'][name])

    try:
        persist()
        if run([compiler, '--version'], 'compiler-version').splitlines()[0] != pins['compiler']['version']:
            raise ValueError('Native compiler version changed')
        if '-fbbb=' not in run([compiler, '--help=target'], 'compiler-target-help'):
            raise ValueError('Required late-optimizer safety flag unavailable')
        for name in RUNTIMES:
            path = Path(run([compiler, '-m68000', '-msoft-float', '-mcrt=nix20', '-print-file-name=' + name],
                            'runtime-' + name.replace('.', '-')).strip()).resolve()
            require_pin(path, pins['runtime_inputs'][name])
            runtime_paths[name] = str(path)
            result['runtime_inputs'][name] = pins['runtime_inputs'][name]
        for index, unit in enumerate(SOURCES):
            toolchain_current()
            text = run([compiler, *FLAGS, '-M', unit], 'dependencies-%02d' % index)
            for name in dependencies(text):
                path = (source / name).resolve()
                if below(path, source):
                    key = path.relative_to(source).as_posix()
                    if key not in expected:
                        raise ValueError('Unknown canonical dependency: ' + key)
                    require_pin(path, expected[key]);canonical_inputs[key] = expected[key]
                elif any(below(path, root) for root in sdk_roots):
                    sdk_inputs[str(path)] = digest(path)
                else:
                    raise ValueError('Dependency outside frozen source and pinned SDK roots: ' + str(path))
        text = run([compiler, *FLAGS, '-E', '-dD', SOURCES[0]], 'preprocessed-fixture')
        assertions = re.findall(r'^#define assert\([^\n]*', text, re.MULTILINE)
        assertion = assertions[-1] if assertions else None
        if not assertion or '__assert_func' not in assertion or text.count('__assert_func (') < 2:
            raise ValueError('Enabled SDK assertion expansion required')
        if text.count(EXPECTED_MARKER) != 1:
            raise ValueError('Shared split-domain sampler fixture marker missing')
        toolchain_current()
        require_source(source, expected)
        binary = out / TARGET
        argv = [compiler, *FLAGS, *SOURCES, '-o', str(binary)]
        compile_commands.append({'name': TARGET, 'directory': str(source), 'argv': argv,
                                 'output': str(binary), 'ordered_translation_units': SOURCES})
        run(argv, TARGET + '.build')
        raw = binary.read_bytes()
        if len(raw) < 4 or struct.unpack('>I', raw[:4])[0] != 0x3f3:
            raise ValueError('Linked native product lacks HUNK_HEADER0x3f3')
        if raw.count(EXPECTED_MARKER.encode()) != 1:
            raise ValueError('Linked product lacks shared assertion-completion marker')
        result['targets'][TARGET] = {'scope': SCOPE, 'source_inputs': SOURCES, 'flags': FLAGS,
                                     'dependencies': dict(sorted(canonical_inputs.items())),
                                     'external_sdk_dependencies': dict(sorted(sdk_inputs.items())),
                                     'binary': record(binary), 'format': 'HUNK_HEADER0x000003f3',
                                     'last_assert_macro': assertion,
                                     'preprocessed_fixture': record(out / 'preprocessed-fixture.log'),
                                     'build_log': record(out / (TARGET + '.build.log'))}
        result['passed'] = True
    except Exception as error:
        result['failure'] = {'kind': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    finally:
        try:
            toolchain_current()
            for path, value in sdk_inputs.items():
                require_pin(path, value)
            require_source(source, expected)
            require_pin(manifest_input, args.source_manifest_sha256)
            require_pin(pin_input, args.pins_sha256)
            require_pin(builder['path'], builder['sha256'])
            require_pin(contract_input, args.fixture_contract_sha256)
            for name in ['tools/build_core_tests.py', 'tools/build_diagnostic.py', FIXTURE_CONTRACT['host_declaration'], 'tests/test_sampler.py', 'tests/test_sampler_paula_readers.py', *FIXTURE_CONTRACT['include_chain']]:
                require_pin(source / name, expected[name])
            result['source_files_after'] = len(expected)
        except Exception as error:
            result['passed'] = False
            result['final_provenance_error'] = {'kind': type(error).__name__, 'message': str(error)}
        persist()
    print(json.dumps({'passed': result['passed'], 'scope': SCOPE, 'manifest': str(out / 'manifest.json')}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
