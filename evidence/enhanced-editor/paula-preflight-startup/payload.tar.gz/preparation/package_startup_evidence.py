"""Archive exact saved source/proofs; no compilation, execution or extraction."""
import ast,gzip,hashlib,io,json,tarfile
from pathlib import Path
assert __debug__
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'candidate-v2';OUT=ROOT/'package'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    assert json.loads((ROOT/'root-host-audit-final-v2.json').read_text())['passed']
    assert json.loads((ROOT/'root-native-audit-final-v2.json').read_text())['passed']
    assert not OUT.exists();OUT.mkdir();members={};inputs=set()
    def put(name,p):
        assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts
        p=Path(p);assert p.is_file() and not p.is_symlink();members[name]=p.read_bytes()
    def tree(prefix,p):
        for f in sorted(p.rglob('*')):
            assert not f.is_symlink()
            if f.is_file():put(prefix+'/'+f.relative_to(p).as_posix(),f)
    for lane in ('host-host-final-v2','native-renderer-final-v2','native-paula-final-v2','host-initial-compile-refusal-v1'):
        tree('proof/'+lane,ROOT/lane)
        report=json.loads((ROOT/lane/('manifest.json' if lane.startswith('native-') else 'host-checks.json')).read_text())
        if lane=='host-initial-compile-refusal-v1':assert not report['passed'] and len(report['commands'])==1
        else:assert report['passed']
        if lane.startswith('native-'):
            assert report['native_NOT_RUN']
            for t in report['targets'].values():inputs.update(t['dependencies'])
        else:inputs.update(report['canonical_dependencies'])
    names=['scope.json','scope-initial-not-tested-preserved.json','startup-package-reader-source-review-v2.json','before-state.json','baseline-manifest.json','root-final-source-freeze-v1.json','root-final-source-freeze-v2.json',
        'frozen-source-host-v1.json','frozen-source-native-v1.json','frozen-source-host-v2.json','frozen-source-native-v2.json',
        'warning-correction-v2.json','initial-compile-refusal-v1.json','host-outer-final-v1.json','host-outer-final-v2.json','renderer-outer-final-v2.json','paula-outer-final-v2.json',
        'host-helper-independent-review-v1.json','startup-host-auditor-independent-source-review-v1.json','startup-host-auditor-independent-source-review-v2.json',
        'independent-production-review-final-v5.json','independent-source-fixture-review-final-v6.json','independent-root-freeze-binding-final-v1.json','independent-warning-correction-review-v2.json',
        'root-host-audit-final-v2.json','root-native-audit-final-v2.json','independent-saved-host-proof-review-v2.json','fresh-peer-status-v2.json']
    for name in names:put('records/'+name,ROOT/name)
    for pattern in ('*-outer-final-v*.stdout','*-outer-final-v*.stderr','warning-correction-v2.patch'):
        for p in sorted(ROOT.glob(pattern)):put('records/'+p.name,p)
    for lane in ('host-tools-v1','native-preparation'):tree('preparation/'+lane,ROOT/lane)
    for name in ('freeze_startup_candidate.py','freeze_startup_candidate_v2.py','run_startup_once.py','run_startup_once_v2.py',
        'audit_startup_host_v1_unexecuted.py','audit_startup_host.py','audit_startup_host_v2.py','audit_startup_native.py','audit_startup_native_v2.py',
        'package_startup_evidence.py','verify_startup_payload.py','verifier-source-initial-v1.py'):
        put('preparation/'+name,ROOT/name)
    source=json.loads((ROOT/'frozen-source-host-v2.json').read_text());inputs.update(source['owned'])
    imports=set('tests/'+n+'.py' for n in json.loads((ROOT/'host-host-final-v2/host-checks.json').read_text())['modules'])
    todo=list(imports)
    while todo:
        name=todo.pop();a=ast.parse((SOURCE/name).read_text())
        for n in ast.walk(a):
            if isinstance(n,ast.ImportFrom) and n.module and n.module.startswith('test_'):
                other='tests/'+n.module+'.py'
                if other not in imports:assert (SOURCE/other).is_file();imports.add(other);todo.append(other)
    inputs.update(imports);inputs.update(['tools/build_core_tests.py','tools/build_diagnostic.py'])
    for name in sorted(inputs):
        assert sha((SOURCE/name).read_bytes())==source['source'][name];put('source/'+name,SOURCE/name)
    for name in source['owned']:put('refused-source/'+name,ROOT/'candidate'/name)
    with tarfile.open(ROOT/'base.tar') as tf:
        for name in json.loads((ROOT/'scope.json').read_text())['production_owned']:
            members['baseline/'+name]=tf.extractfile(name).read()
    payload=OUT/'payload.tar.gz'
    with payload.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tf:
                for name,data in sorted(members.items()):
                    f=tarfile.TarInfo(name);f.size=len(data);f.mode=0o644;f.mtime=0;tf.addfile(f,io.BytesIO(data))
    manifest={'scope':'Optional cancellable renderer/Paula initial setup; saved host and portable compiler evidence only; native/emulator/physical/backend activation/audio/listening NOT_RUN',
        'base_commit':source['base_commit'],'base_tree':source['base_tree'],'payload':{'bytes':payload.stat().st_size,'sha256':sha(payload.read_bytes())},
        'files':[{'path':n,'bytes':len(d),'sha256':sha(d)} for n,d in sorted(members.items())]}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (OUT/'verify_payload.py').write_bytes((ROOT/'verify_startup_payload.py').read_bytes())
    with tarfile.open(payload) as tf:assert {f.name:tf.extractfile(f).read() for f in tf}==members
    print(json.dumps({'members':len(members),'compiled_and_recipe_source_paths':len(inputs),'uncompressed_bytes':sum(map(len,members.values())),'payload':manifest['payload']}))
if __name__=='__main__':main()
