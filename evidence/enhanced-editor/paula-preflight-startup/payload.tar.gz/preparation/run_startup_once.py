"""Exactly one reviewed host or compiler-only invocation; never execute a HUNK."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys, time, traceback
ROOT=Path(__file__).resolve().parent
PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,v):
    stage=p.with_suffix(p.suffix+'.writing');stage.write_text(json.dumps(v,indent=2)+'\n');stage.replace(p)
def main():
    assert __debug__ and len(sys.argv)==2 and sys.argv[1] in ('host','renderer','paula')
    kind=sys.argv[1];freeze=json.loads((ROOT/'root-final-source-freeze-v1.json').read_text());assert freeze['passed']
    for f in freeze['helpers']+[freeze['host_manifest'],freeze['native_manifest']]+freeze['fixture_contracts']:
        assert rec(f['path'])==f
    native=kind!='host'
    if native:
        audit=json.loads((ROOT/'root-host-audit-final-v1.json').read_text());assert audit['passed']
        helper=ROOT/'native-preparation/build_preflight_startup_portability.py';pins=ROOT/'native-preparation/toolchain-pins.json'
        manifest=Path(freeze['native_manifest']['path']);target='PTRenderStartupTest' if kind=='renderer' else 'PTPaulaPreflightStartupTest'
        contract=ROOT/'native-preparation'/(target+'-contract-v1.json')
        argv=[PYTHON,'-B',str(helper),'--source',str(ROOT/'candidate'),'--fixture-contract',str(contract),'--fixture-contract-sha256',sha(contract)]
    else:
        helper=ROOT/'host-tools-v1/host_provenance.py';pins=ROOT/'host-tools-v1/toolchain-pins.json';manifest=Path(freeze['host_manifest']['path'])
        argv=[PYTHON,'-B',str(helper),'--source',str(ROOT/'candidate')]
    private=Path('/private/tmp')/('pt-preflight-startup-fxjdydr8-'+kind+'-v1')
    durable=ROOT/(('native-' if native else 'host-')+kind+'-final-v1')
    prefix=ROOT/(kind+'-outer-final-v1');receipt=prefix.with_suffix('.json');stdout=prefix.with_suffix('.stdout');stderr=prefix.with_suffix('.stderr')
    assert not any(p.exists() for p in (private,durable,receipt,stdout,stderr))
    argv+=['--source-manifest',str(manifest),'--source-manifest-sha256',sha(manifest),'--pins',str(pins),'--pins-sha256',sha(pins),'--out',str(private)]
    controls=[helper,manifest,pins]+([contract] if native else [ROOT/'host-tools-v1/provenance_common.py'])
    r={'scope':'One host sanitizer driver invocation' if not native else 'One portable compiler-only helper invocation; no HUNK execution',
       'kind':kind,'argv':argv,'directory':str(ROOT),'started_utc':datetime.datetime.now(datetime.UTC).isoformat(),'source_freeze':rec(ROOT/'root-final-source-freeze-v1.json'),
       'controls_before':[rec(p) for p in controls],'private_output':str(private),'durable_archive':str(durable),'wrapper':rec(__file__),'helper_invocations':0,'native':'NOT_RUN','physical':'NOT_RUN'}
    with receipt.open('x') as out:json.dump(r,out,indent=2);out.write('\n')
    start=time.monotonic()
    try:
        with stdout.open('x') as out,stderr.open('x') as err:
            r['helper_invocations']=1;save(receipt,r)
            result=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err)
        r['returncode']=result.returncode;r['stdout']=rec(stdout);r['stderr']=rec(stderr)
        r['controls_after']=[rec(p) for p in controls];assert r['controls_after']==r['controls_before']
        if native:
            shutil.copytree(private,durable,copy_function=shutil.copy2);mapping=[]
            for p in sorted(private.rglob('*')):
                if p.is_file():
                    copy=durable/p.relative_to(private);assert p.read_bytes()==copy.read_bytes();mapping.append({'original':rec(p),'durable':rec(copy)})
            r['durable_mapping']=mapping
        r['passed']=result.returncode==0
    except Exception as failure:r['passed']=False;r['failure']={'kind':type(failure).__name__,'message':str(failure),'traceback':traceback.format_exc()}
    r['elapsed_s']=time.monotonic()-start;r['finished_utc']=datetime.datetime.now(datetime.UTC).isoformat();save(receipt,r)
    print(json.dumps({'passed':r['passed'],'kind':kind,'returncode':r.get('returncode'),'receipt':rec(receipt),'private':str(private),'durable':str(durable) if native else 'awaits root saved-byte audit'}))
    if stdout.exists():print(stdout.read_text())
    if stderr.exists():print(stderr.read_text())
    return 0 if r['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
