#include "pcm.h"
unsigned pt_test_pcm_validations;
enum pt_pcm_result pt_pcm_validate_actual(const struct pt_pcm *);
enum pt_pcm_result pt_pcm_validate(const struct pt_pcm *p)
{++pt_test_pcm_validations;return pt_pcm_validate_actual(p);}