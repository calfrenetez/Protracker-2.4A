#ifndef PT_SAMPLER_H
#define PT_SAMPLER_H
#include "pattern.h"
#include "document.h"
#include "slices.h"
#include "svx.h"
#include "raw.h"
struct pt_sample_version;
struct pt_sampler {
    struct pt_sample_version *current[PT_PROJECT_SAMPLES];
    struct pt_sample *table,*table_original;
    size_t table_bytes;
    struct pt_allocator allocator;
    size_t bytes,budget;
    unsigned generation;
    pt_pcm_progress progress;
    void *progress_context;
};
/* Fill a newly allocated PCM buffer without changing the borrowed project.
 * Appending the filled sample is one undo resource. Format.data/capacity are
 * ignored; PCM metadata must stay unchanged during fill. Failure preserves
 * project/history and releases staging; the sampler budget includes all PCM.
 */
typedef enum pt_edit_result (*pt_sample_fill)(void *,struct pt_pcm *);
enum pt_edit_result pt_sampler_append_generated(struct pt_sampler *,struct pt_project *,
    struct pt_pattern_history *,const struct pt_pcm *,const char *,pt_sample_fill,void *);
/* Transfer a unique PCM allocation from exactly the sampler allocator. The
 * caller must own capacity*sizeof(int32_t) bytes at data, with no retained
 * writers or other owners. Success clears pcm; failure leaves it untouched.
 * Full capacity is charged to the sampler budget until final history/current/
 * pin release. Allocator context and sampler must outlive all pins as below. */
enum pt_edit_result pt_sampler_append_owned(struct pt_sampler *,struct pt_project *,
    struct pt_pattern_history *,struct pt_pcm *,const struct pt_allocator *,const char *);
void pt_sampler_init(struct pt_sampler *,const struct pt_allocator *,size_t);
/* Release journal first, then sampler, before destroying/reinitializing editor.
   Versions are immutable and must never be edited through project pointers.
   Release also invalidates an expanded sample table; do not use the project
   afterwards except to release/replace its separately owned document. */
void pt_sampler_release(struct pt_sampler *);
/* Pin current immutable master revision. generation must equal sampler generation.
 * Initial document-backed PCM is promoted once into a budgeted owned version;
 * samples/precision are unchanged and no undo command is added. Failure leaves
 * outputs/project unchanged. Release each successful pin exactly once. Sampler
 * and allocator context must remain alive (not reinitialized) until final unpin,
 * even after history/current ownership is released. */
enum pt_edit_result pt_sampler_pin(struct pt_sampler *,struct pt_project *,unsigned slot,
    unsigned generation,struct pt_pcm *,struct pt_sample_version **);
void pt_sampler_unpin(struct pt_sample_version *);
/* Names (at most 31 characters), volume 0..64 and finetune -8..7 share immutable
   PCM/marker storage with the current version and one chronological undo entry. */
/* Append an empty classic-format slot, up to 255, without moving PCM. */
enum pt_edit_result pt_sampler_add_slot(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *);
enum pt_edit_result pt_sampler_attributes(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,const char *,unsigned,int);
enum pt_edit_result pt_sampler_import(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,const uint8_t *,size_t,const char *);
enum pt_edit_result pt_sampler_edit(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,enum pt_pcm_edit,uint32_t,uint32_t,unsigned);
/* Loop metadata and baked crossfade are each a single shared undo command.
   Baking produces a forward loop with the consumed head skipped. */
enum pt_edit_result pt_sampler_loop(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,enum pt_loop_kind,uint32_t,uint32_t,uint32_t);
/* Replace non-destructive markers. Never silently retarget a referenced ordinal. */
enum pt_edit_result pt_sampler_slices(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,const uint32_t *,size_t);
/* Explicit whole-sample conversion. Linear rate conversion preserves marker
   ordinals by scaling frames; collapsed markers/invalid loop geometry refuse. */
enum pt_edit_result pt_sampler_convert(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,unsigned,uint32_t);
enum pt_edit_result pt_sampler_convert_quality(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,unsigned,uint32_t,unsigned);
/* Explicit IFF export preserves PCM/name/rate/volume/forward loop. Unsupported
   precision, stereo, loop kinds, slices and finetune refuse without conversion. */
/* Scalar/encoded outputs also protect the complete sample header and declared
 * master capacity. ALIAS preserves sample and outputs; no allocation occurs. */
enum pt_svx_result pt_sampler_svx_size(const struct pt_sample *,size_t *);
enum pt_svx_result pt_sampler_svx_encode(const struct pt_sample *,uint8_t *,size_t,size_t *);
enum pt_edit_result pt_sampler_import_raw(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,const uint8_t *,size_t,const char *,const struct pt_raw_format *);
/* Synchronous staged RAW import. Fill must initialize every value and finish
 * input verification/close before returning1. Failure discards staging; source,
 * project and history must remain unchanged by the callback. No reentrancy. */
typedef int (*pt_sampler_raw_fill)(void *,int32_t *,uint32_t,const struct pt_raw_format *);
enum pt_edit_result pt_sampler_import_raw_fill(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,size_t,const char *,const struct pt_raw_format *,pt_sampler_raw_fill,void *);
/* IFF metadata variant of the same staged-fill contract; preserves name,
 * rounded tracker volume and forward-loop endpoints. */
enum pt_edit_result pt_sampler_import_svx_fill(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,const struct pt_svx_info *,const char *,pt_sampler_raw_fill,void *);
/* Deep-copy one validated donor slot into the destination as one undo resource. */
enum pt_edit_result pt_sampler_import_slot(struct pt_sampler *,struct pt_project *,struct pt_pattern_history *,unsigned,const struct pt_project *,unsigned);
#endif
