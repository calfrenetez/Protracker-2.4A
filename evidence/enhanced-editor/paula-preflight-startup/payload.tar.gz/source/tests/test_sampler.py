from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
SOURCES=['tests/sampler_test.c','src/editor/sampler.c','src/editor/slots.c', 'src/core/pcm_filtered.c', 'src/core/slices.c','src/core/pattern.c','src/core/document.c', 'src/core/pp20.c','src/core/project.c','src/core/mod_project.c','src/core/mod_inspect.c','src/core/channels.c','src/core/pcm.c','src/core/wav.c', 'src/core/svx.c', 'src/core/raw.c']
class Sampler(unittest.TestCase):
    def test_owned_versions_and_journal(self):
        with tempfile.TemporaryDirectory() as tmp:
            binary=str(Path(tmp)/'sampler')
            subprocess.run(['cc','-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core',*SOURCES,'-o',binary],cwd=ROOT,check=True)
            subprocess.run([binary],check=True)
