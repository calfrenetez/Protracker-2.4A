#!/usr/bin/env python3
"""Build native diagnostic tools and record compiler/runtime/input digests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compiler_safety_flags(cc):
    """Disable the custom late optimizer with a verified field-address bug."""
    target_help = subprocess.check_output([cc, '--help=target'], text=True)
    return ['-fbbb=-'] if '-fbbb=' in target_help else []


def runtime_inputs(cc):
    """Record the actual startup object and archives selected by this CRT."""
    names = ['ncrt0.o', 'libnix20.a', 'libnixmain.a', 'libnix.a',
             'libstubs.a', 'libamiga.a', 'libgcc.a']
    result = {}
    for name in names:
        path = Path(subprocess.check_output(
            [cc, '-m68000', '-msoft-float', '-mcrt=nix20', '-print-file-name=' + name],
            text=True).strip())
        if not path.is_file():
            raise SystemExit('Cannot resolve runtime input: ' + name)
        result[name] = digest(path)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cc', default=os.environ.get('AMIGA_CC', 'm68k-amigaos-gcc'))
    p.add_argument('--tool', choices=['AmiGUSTest', 'PTModCheck', 'PTDiagOwnershipTest', 'PTDriverWindowTest', 'PTDriverExecTest', 'PTPcmReadTest', 'PTWavetableReadTest'], default='AmiGUSTest')
    args = p.parse_args()
    cc = shutil.which(args.cc)
    if not cc:
        p.error('Set AMIGA_CC to the m68k-amigaos-gcc compiler path')
    flags = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
             '-Wall', '-Wextra', '-Werror', *compiler_safety_flags(cc), '-Ivendor/amigus-sdk']
    inputs = ['src/diagnostic/main.c', 'src/diagnostic/ownership.c', 'src/diagnostic/driver_window.c', 'src/diagnostic/native_driver_window.c']
    headers = ['src/diagnostic/amigus_calls.h', 'src/diagnostic/ownership.h', 'src/diagnostic/driver_window.h', 'src/diagnostic/native_driver_window.h']
    inputs += ['src/diagnostic/wavetable_probe.c', 'src/native/amigus_wavetable_read.c', 'src/diagnostic/register_probe.c', 'src/native/amigus_pcm_read.c',
               'src/native/amigus_reservation.c', 'src/core/amigus_reservation.c']
    headers += ['src/diagnostic/wavetable_probe.h', 'src/native/amigus_wavetable_read.h', 'src/diagnostic/register_probe.h', 'src/native/amigus_pcm_read.h',
                'src/native/amigus_reservation.h', 'src/core/amigus_reservation.h']
    if args.tool == 'PTModCheck':
        flags[-1] = '-Isrc/core'
        inputs = ['tools/modcheck.c', 'src/core/mod_inspect.c']
        headers = ['src/core/mod_inspect.h']
    if args.tool == 'PTDiagOwnershipTest':
        flags[-1] = '-Isrc/diagnostic'
        inputs = ['tests/ownership_test.c', 'src/diagnostic/ownership.c']
        headers = ['src/diagnostic/ownership.h']
    if args.tool == 'PTDriverWindowTest':
        flags[-1] = '-Isrc/diagnostic'
        inputs = ['tests/driver_window_test.c', 'src/diagnostic/driver_window.c']
        headers = ['src/diagnostic/driver_window.h', 'src/diagnostic/ownership.h']
    if args.tool == 'PTDriverExecTest':
        flags[-1] = '-Isrc/diagnostic'
        inputs = ['tests/native_driver_exec_test.c', 'src/diagnostic/driver_window.c',
                  'src/diagnostic/native_driver_window.c']
        headers = ['src/diagnostic/driver_window.h', 'src/diagnostic/ownership.h',
                   'src/diagnostic/native_driver_window.h']
    if args.tool == 'PTPcmReadTest':
        flags += ['-Isrc/native']
        inputs = ['tests/native_pcm_read_test.c', 'src/native/amigus_pcm_read.c']
        headers = ['src/native/amigus_pcm_read.h', 'src/core/amigus_reservation.h']
    if args.tool == 'PTWavetableReadTest':
        flags += ['-Isrc/native']
        inputs = ['tests/native_wavetable_read_test.c', 'src/native/amigus_wavetable_read.c']
        headers = ['src/native/amigus_wavetable_read.h', 'src/core/amigus_reservation.h']
    out = ROOT / 'build/diagnostic'
    out.mkdir(parents=True, exist_ok=True)
    sdk_digest = None
    if args.tool in ('AmiGUSTest', 'PTPcmReadTest', 'PTWavetableReadTest'):
        lock = json.loads((ROOT / 'amigus-sdk.lock.json').read_text())
        for name, expected in lock['files'].items():
            if digest(ROOT / 'vendor/amigus-sdk' / name) != expected:
                raise SystemExit('SDK input changed: ' + name)
        sdk_digest = digest(ROOT / 'amigus-sdk.lock.json')
    result = subprocess.run([cc, *flags, *inputs, '-o', str(out / args.tool)],
                            cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    stem = {'AmiGUSTest': 'build', 'PTDiagOwnershipTest': 'ownership-fixture-build',
            'PTDriverWindowTest': 'driver-window-build', 'PTDriverExecTest': 'driver-exec-build',
            'PTWavetableReadTest': 'wavetable-read-build', 'PTPcmReadTest': 'pcm-read-build', 'PTModCheck': 'modcheck-build'}[args.tool]
    (out / (stem + '.log')).write_text(result.stdout)
    print(result.stdout, end='')
    result.check_returncode()
    report = {
        'compiler': subprocess.check_output([cc, '--version'], text=True).splitlines()[0],
        'compiler_sha256': digest(Path(cc)),
        'builder_sha256': digest(Path(__file__)),
        'runtime_inputs': runtime_inputs(cc),
        'flags': flags,
        'inputs': {name: digest(ROOT / name) for name in inputs + headers},
        'sdk_lock_sha256': sdk_digest,
        'binary_bytes': (out / args.tool).stat().st_size,
        'binary_sha256': digest(out / args.tool),
    }
    (out / (stem + '.json')).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
