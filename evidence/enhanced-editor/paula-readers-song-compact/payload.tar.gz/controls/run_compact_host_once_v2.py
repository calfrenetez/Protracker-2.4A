"""One reviewed frozen compact sanitizer group; no native or target execution."""
import hashlib,json,subprocess,shutil
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent
python='/opt/homebrew/opt/python@3.14/bin/python3.14'
out=Path('/private/tmp/pt-song-compact-8iftv2vr-host-v2')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def record(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
approval=json.loads((root/'approved-host-controls-v2.json').read_bytes())
assert approval['scope']=='Root approved separate compact heap-state caller-workspace host-only fixture source v2'
for row in approval['inputs']:
 p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
assert not out.exists() and not (root/'host-execution-v2.json').exists() and not (root/'host-final-v2').exists()
manifest=root/'frozen-source-v2.json';pins=root/'host-tools-v1/toolchain-pins.json'
argv=[python,'-B',str(root/'host-tools-v1/host_provenance.py'),'--source',str(root/'candidate'),'--source-manifest',str(manifest),'--source-manifest-sha256',digest(manifest),'--pins',str(pins),'--pins-sha256',digest(pins),'--out',str(out)]
r={'scope':approval['scope'],'argv':argv,'state':'dispatched once','native':'NOT_RUN','emulator':'NOT_RUN','physical':'NOT_RUN'}
(root/'host-execution-v2.json').write_text(json.dumps(r,indent=2)+'\n')
with (root/'host-driver-stdout-v2.txt').open('xb') as stdout,(root/'host-driver-stderr-v2.txt').open('xb') as stderr:
 completed=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
r.update({'state':'completed','driver_rc':completed.returncode,'original_out':str(out)})
if out.exists():
 durable=root/'host-final-v2';shutil.copytree(out,durable)
 copies=[]
 for p in sorted(out.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():
   q=durable/p.relative_to(out);assert p.read_bytes()==q.read_bytes() and (p.stat().st_mode&0o777)==(q.stat().st_mode&0o777)
   copies.append({'original':record(p),'durable':record(q),'mode':p.stat().st_mode&0o777})
 r['durable_copies']=copies
(root/'host-execution-v2.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'state':r['state'],'rc':completed.returncode,'durable_files':len(r.get('durable_copies',[]))}))
raise SystemExit(completed.returncode)
