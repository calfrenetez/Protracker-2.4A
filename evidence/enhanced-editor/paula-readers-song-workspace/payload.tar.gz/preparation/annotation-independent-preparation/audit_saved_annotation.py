#!/usr/bin/env python3
"""Independent saved-byte annotation audit. No imports/eval of producer code/tools.

This file only reads JSON, source text/AST and ordinary artifact bytes. It has no
subprocess, compiler/linker/object invocation, network/target or extraction path.
Per-function .su entries do not establish a total 030 stack/WCET/IRQ bound.
"""
import argparse
import ast
import hashlib
import json
import math
from pathlib import Path
import re
import shlex
import stat
import traceback

FLAGS = ['-std=c99','-m68000','-msoft-float','-mcrt=nix20','-Os','-Wall',
         '-Wextra','-Werror','-Isrc/core','-Ibuild/dev','-fbbb=-']
RUNTIMES = ['ncrt0.o','libnix20.a','libnixmain.a','libnix.a','libstubs.a','libamiga.a','libgcc.a']
MARKERS = [
 'PAULA READERS SONG PASS: exact whole-song schedule, independent actual domains and immutable retained masters; host software only',
 'PAULA READERS SONG FAULTS PASS: explicit acceptance, independent fault drain and original deadlines; host software only',
 'PAULA READERS SONG WORKSPACE PASS: guarded caller scratch released before genuine exact scheduling and independent domain ownership; host software only']
FIXTURE = 'tests/paula_readers_song_workspace_test.c'
DECLARATIONS = [
 ('tests/test_sampler.py','SOURCES',None,None),
 ('tests/test_sampler_paula_readers.py','READERS_SOURCES','test_sampler','SOURCES'),
 ('tests/test_sampler_paula_readers_boundary.py','BOUNDARY_SOURCES','test_sampler_paula_readers','READERS_SOURCES'),
 ('tests/test_paula_readers_song.py','SONG_SOURCES','test_sampler_paula_readers_boundary','BOUNDARY_SOURCES'),
 ('tests/test_paula_readers_song_workspace.py','WORKSPACE_SOURCES','test_paula_readers_song','SONG_SOURCES')]
FOCUS = {
 'new_constructor':['song_begin_in_workspace','pt_paula_readers_song_begin_in_workspace','song_source_spans'],
 'legacy_large_begin':['pt_paula_readers_song_begin'],
 'fixture_caller':['main','workspace_exact_reuse_and_legacy','fixture_workspace_begin'],
 'nested_initial_setup':['pt_paula_preflight_setup_begin','pt_render_sequence_setup_begin','pt_flow_begin','pt_project_validation_begin'],
 'later_setup_and_lowering':['pt_render_sequence_setup_take','pt_paula_preflight_setup_transfer','pt_paula_readers_lower_begin','pt_paula_readers_enqueue','pt_readers_enqueue']}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    p = Path(path)
    require(not p.is_symlink() and stat.S_ISREG(p.stat().st_mode), 'Not ordinary nonsymlink file: '+str(p))
    return p.read_bytes()


def record(path, following_tool=False):
    p = Path(path)
    data = p.read_bytes() if following_tool else read_regular(p)
    return {'path':str(p),'bytes':len(data),'sha256':hash_bytes(data),'mode':stat.S_IMODE(p.stat().st_mode)}


def verify_row(row, path=None, following_tool=False):
    actual = record(path or row['path'], following_tool)
    for key in ('bytes','sha256','mode'):
        if key in row:
            require(actual[key] == row[key], 'Changed '+key+': '+str(actual['path']))
    return actual


def below(path, root):
    return path == root or root in path.parents


def snapshot(source):
    result = {}
    for p in sorted(source.rglob('*')):
        require(not p.is_symlink(), 'Source symlink: '+str(p))
        if p.is_file():
            result[p.relative_to(source).as_posix()] = hash_bytes(read_regular(p))
    return result


def make_names(text):
    result = []
    logical = re.sub(r'\\\r?\n', ' ', text)
    for line in logical.splitlines():
        match = re.search(r'(?<!\\):', line)
        if match:
            result.extend(shlex.split(line[match.end():]))
    return list(dict.fromkeys(result))


def assign(tree, name):
    nodes = [node.value for node in tree.body if isinstance(node,ast.Assign)
             and any(isinstance(target,ast.Name) and target.id==name for target in node.targets)]
    require(len(nodes)==1,'Ambiguous declaration: '+name)
    return nodes[0]


def units_from_data(source):
    values = {}
    declaration_rows = []
    for relative, constant, module, parent_constant in DECLARATIONS:
        p = source/relative
        tree = ast.parse(read_regular(p).decode())
        expression = assign(tree,constant)
        require(isinstance(expression,ast.List),'Literal list expected: '+relative)
        current = []
        if module is not None:
            imports = [n for n in tree.body if isinstance(n,ast.ImportFrom) and n.module==module]
            require(len(imports)==1 and [(n.name,n.asname) for n in imports[0].names]==[(parent_constant,None)],'Wrong inherited declaration import')
        for element in expression.elts:
            if isinstance(element,ast.Starred):
                require(parent_constant is not None and ast.unparse(element.value)==parent_constant+'[1:]','Unexpected source expansion')
                current.extend(values[parent_constant][1:])
            else:
                item=ast.literal_eval(element)
                require(isinstance(item,str),'Non-string TU')
                current.append(item)
        values[constant]=current
        declaration_rows.append(record(p))
    result=values['WORKSPACE_SOURCES']
    require(len(result)==29 and len(set(result))==29 and result[0]==FIXTURE,'29 unique actual workspace TUs required')
    require(all(Path(name).as_posix()==name and not Path(name).is_absolute() and '..' not in Path(name).parts for name in result),'Noncanonical TU path')
    return result,declaration_rows


def su_rows(raw, unit):
    require(bool(raw),'Missing/empty SU for '+unit)
    result=[]
    for line in raw.decode('utf-8').splitlines():
        fields=line.rsplit('\t',2)
        require(len(fields)==3 and fields[0] and re.fullmatch(r'\d+',fields[1]),'Malformed saved SU row')
        qualifiers=fields[2].split(',')
        require(len(qualifiers)==len(set(qualifiers)) and set(qualifiers) in ({'static'},{'dynamic'},{'dynamic','bounded'}),'Unknown saved SU qualifier')
        result.append({'compiler_location_and_function':fields[0],'reported_bytes':int(fields[1]),
                       'qualifiers':qualifiers,'numeric_local_bound':'static' in qualifiers or 'bounded' in qualifiers})
    require(bool(result),'No saved SU function rows')
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bindings',type=Path,required=True)
    ap.add_argument('--bindings-sha256',required=True)
    ap.add_argument('--annotation-dir',type=Path,required=True)
    ap.add_argument('--original-output',type=Path,required=True)
    ap.add_argument('--annotation-manifest-sha256',required=True)
    ap.add_argument('--outer',type=Path,required=True)
    ap.add_argument('--outer-sha256',required=True)
    ap.add_argument('--report',type=Path,required=True)
    args=ap.parse_args()
    require(not args.report.exists(),'Own receipt must be fresh')
    report={'status':'READ-ONLY AUDIT INCOMPLETE','integrity_passed':False,
            'stack_qualified':False,'total_030_stack':'UNKNOWN','Stack65536':'NOT_CLEARED',
            'WCET':'UNKNOWN','IRQ_reserve':'UNKNOWN','native_target_NOT_RUN':True,
            'auditor':record(Path(__file__).resolve()),'reader_actions':'Saved bytes/AST/JSON only; no imports of producer, tools, subprocess, object/product/runtime, source mutation or targets'}
    try:
        require(record(args.bindings)['sha256']==args.bindings_sha256,'Binding control changed')
        require(record(args.outer)['sha256']==args.outer_sha256,'Outer control changed')
        bindings=json.loads(read_regular(args.bindings));controls=bindings['controls']
        for row in controls.values():verify_row(row)
        source=Path(bindings['source_export']).resolve()
        files=json.loads(read_regular(controls['source_manifest']['path']))['files']
        require(len(files)==8122 and snapshot(source)==files,'Current complete 8122 source does not match frozen inventory')
        require(files['src/editor/paula_readers_song.c']==bindings['constructor_sha256'],'Wrong constructor revision')
        require(files[FIXTURE]==bindings['fixture_sha256'],'Wrong fixture revision')
        units,declaration_rows=units_from_data(source)
        contract=json.loads(read_regular(controls['functional_contract']['path']))
        require(units==contract['ordered_sources'],'Actual inherited 29-TU declarations differ from functional contract')
        design=json.loads(read_regular(controls['design']['path']))
        require(FLAGS==design['full_production_flags'] and design['separate_annotation_flags']==['-fstack-usage','-c'],'Functional flag design differs')
        functional=ast.parse(read_regular(controls['functional_builder']['path']).decode())
        require(ast.literal_eval(assign(functional,'FLAGS'))==FLAGS and ast.literal_eval(assign(functional,'RUNTIMES'))==RUNTIMES,'Actual functional AST flags/runtime differs')
        recipe=ast.parse(read_regular(source/'tools/build_core_tests.py').decode())
        flag_lists=[n.value for n in ast.walk(recipe) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='flags' for t in n.targets)]
        require(len(flag_lists)==1 and [n.value for n in flag_lists[0].elts if isinstance(n,ast.Constant)]==FLAGS[:-1]
                and [ast.unparse(n.value) for n in flag_lists[0].elts if isinstance(n,ast.Starred)]==['compiler_safety_flags(cc)'],'Committed canonical flags differ')
        pins=json.loads(read_regular(controls['original_native_pins']['path']))
        require(hash_bytes(read_regular(source/'tools/build_core_tests.py'))==pins['canonical_recipe']['sha256'],'Canonical recipe pin differs')
        tools=json.loads(read_regular(controls['stack_pins']['path']))['tools']
        require(tools['compiler']==pins['native']['compiler'] and tools['python']==pins['host']['python'],'Inherited compiler/Python changed')
        for row in tools.values():verify_row(row,following_tool=True)
        annotation=args.annotation_dir.resolve();original=args.original_output.resolve()
        manifest_path=annotation/'manifest.json'
        require(record(manifest_path)['sha256']==args.annotation_manifest_sha256,'Saved annotation manifest changed')
        result=json.loads(read_regular(manifest_path))
        require(result['source_export']==str(source),'Annotation used different source')
        require(result['source_files_before']==8122 and result['source_files_after']==8122 and result['source_after_matches_before'] is True,'Before/after source gate missing')
        require(result['source_inventory_fingerprint']==hash_bytes(json.dumps(files,sort_keys=True,separators=(',',':')).encode()),'Source fingerprint differs')
        for key in ['base_commit','base_tree']:
            require(result[key]==json.loads(read_regular(controls['source_manifest']['path']))[key],'Wrong '+key)
        require(result['helper']['sha256']==controls['helper']['sha256'],'Unreviewed annotation helper')
        verify_row(result['helper'])
        require(result['source_manifest']['sha256']==controls['source_manifest']['sha256'] and result['stack_pins']['sha256']==controls['stack_pins']['sha256'],'Actual input controls differ')
        require(result['tool_pins']==tools,'Actual tool pins differ')
        require(result['recipe_contract']['flags']==FLAGS and result['recipe_contract']['annotation_flags']==['-fstack-usage','-c']
                and result['recipe_contract']['ordered_translation_units']==units,'Actual flags/topology changed')
        require(result['stack_qualified'] is False and result['total_030_stack']=='UNKNOWN' and result['WCET']=='UNKNOWN'
                and result['native_NOT_RUN'] is True and result['link_performed'] is False and result['product_execution_performed'] is False,'Scope was upgraded')

        visited={}
        def artifact(row):
            path=Path(row['path'])
            require(path.parent==original and path.name not in ('','.','..'),'Artifact path outside exact original output')
            actual=verify_row(row,annotation/path.name)
            if original.is_dir():
                verify_row(row,path)
                require(read_regular(path)==read_regular(annotation/path.name),'Durable/original bytes differ')
            visited[path.name]=actual
            return read_regular(annotation/path.name)

        compiler=tools['compiler']['path']
        expected_commands=[('compiler-version',[compiler,'--version']),('compiler-target-help',[compiler,'--help=target']),
            ('selected-cc1',[compiler,'-print-prog-name=cc1']),('selected-as',[compiler,'-print-prog-name=as'])]
        expected_commands += [(name+'-version',[tools[name]['path'],'--version']) for name in ['assembler','objdump','nm']]
        expected_commands += [('runtime-'+name.replace('.','-'),[compiler,'-m68000','-msoft-float','-mcrt=nix20','-print-file-name='+name]) for name in RUNTIMES]
        expected_commands += [('dependencies-%02d'%i,[compiler,*FLAGS,'-M',unit]) for i,unit in enumerate(units)]
        expected_commands.append(('preprocessed-fixture',[compiler,*FLAGS,'-E','-dD',FIXTURE]))
        for i,unit in enumerate(units):
            stem='tu%02d'%i;obj=original/(stem+'.o')
            expected_commands += [(stem+'-annotation',[compiler,*FLAGS,'-fstack-usage','-c',unit,'-o',str(obj)]),
                                  (stem+'-objdump',[tools['objdump']['path'],'-dr',str(obj)]),
                                  (stem+'-nm',[tools['nm']['path'],'-an',str(obj)])]
        require(len(expected_commands)==131,'Independent command sequence calculation differs')
        commands=result['commands'];success=result['annotation_complete'] is True
        require(len(commands)<=131 and (not success or len(commands)==131),'Missing/excess actual commands')
        logs={};prior=None
        for i,row in enumerate(commands):
            label,argv=expected_commands[i]
            require(row['label']==label and row['argv']==argv and row['directory']==str(source),'Wrong actual command at index '+str(i))
            require(isinstance(row['started_monotonic'],(int,float)) and math.isfinite(row['started_monotonic']) and (prior is None or row['started_monotonic']>=prior),'Invalid command timing metadata')
            prior=row['started_monotonic']
            if 'returncode' in row:
                require(math.isfinite(row['elapsed_s']) and row['elapsed_s']>=0,'Invalid command duration')
                require(row['returncode']==0 or (not success and i==len(commands)-1),'Failure followed by another command')
            else:
                require(not success and i==len(commands)-1,'Incomplete command before later execution')
            for stream in ['stdout','stderr']:
                if stream in row:
                    require(Path(row[stream]['path']).name==label+'.'+stream,'Wrong log artifact name')
                    raw=artifact(row[stream])
                    logs[(label,stream)]=raw
        require(success or result.get('first_diagnostic') or result.get('final_provenance_error'),'Failed run lacks original diagnostic')
        if ('compiler-version','stdout') in logs:
            require(logs[('compiler-version','stdout')].decode().splitlines()[0]==tools['compiler']['version'],'Compiler version stdout differs')
        if ('compiler-target-help','stdout') in logs:require(b'-fbbb=' in logs[('compiler-target-help','stdout')],'Functional safety help missing')
        for query,name in [('cc1','cc1'),('as','assembler')]:
            if ('selected-'+query,'stdout') in logs:
                path=Path(logs[('selected-'+query,'stdout')].decode().strip())
                allowed=[tools[name]['path']] if query=='cc1' else [tools['assembler']['path'],tools['assembler_alternate']['path']]
                require(path.is_absolute() and path.resolve() in [Path(x).resolve() for x in allowed],'Actual selected tool differs')
                require(Path(result['selected_'+query]['path']).resolve()==path.resolve(),'Selection record differs from actual query')
                verify_row(result['selected_'+query],following_tool=True)
        runtime_rows={}
        for name in RUNTIMES:
            key=('runtime-'+name.replace('.','-'),'stdout')
            if key in logs:
                path=Path(logs[key].decode().strip()).resolve()
                require(result['runtime_paths'][name]==str(path),'Runtime record differs from actual query')
                require(hash_bytes(path.read_bytes())==pins['native']['runtime_inputs'][name],'Runtime bytes differ')
                runtime_rows[name]=record(path,following_tool=True)

        canonical,system={},{}
        roots=[Path(p).resolve() for p in pins['native']['allowed_sdk_roots']]
        for i,unit in enumerate(units):
            key=('dependencies-%02d'%i,'stdout')
            if key in logs:
                names=make_names(logs[key].decode())
                require(names,'Empty actual full-M')
                for name in names:
                    path=(source/name).resolve()
                    if below(path,source):
                        relative=path.relative_to(source).as_posix()
                        require(relative in files and hash_bytes(read_regular(path))==files[relative],'Changed/unrecognized canonical full-M input')
                        canonical[relative]=files[relative]
                    else:
                        require(any(below(path,root) for root in roots),'Full-M outside allowed SDK')
                        system[str(path)]=hash_bytes(path.read_bytes())
        require(canonical==result['canonical_dependencies'] and system==result['system_dependencies'],'Reconstructed full-M closure differs')
        cpp=logs.get(('preprocessed-fixture','stdout'))
        if cpp is not None:
            text=cpp.decode();macros=re.findall(r'^#define assert\([^\n]*',text,re.MULTILINE)
            require(macros and '__assert_func' in macros[-1] and text.count('__assert_func (')>=2,'Default assert inactive')
            require(result['last_assert_macro']==macros[-1] and all(text.count(marker)==1 for marker in MARKERS),'CPP macro/full markers differ')
        all_rows=[];unit_summary=[]
        require(len(result['translation_units'])<=29 and (not success or len(result['translation_units'])==29),'Wrong annotation count')
        for i,row in enumerate(result['translation_units']):
            require(row['index']==i and row['source']==units[i],'Annotation unit order differs')
            stem='tu%02d'%i
            if 'object' in row:
                require(Path(row['object']['path']).name==stem+'.o','Wrong object stem')
                data=artifact(row['object']);require(len(data)>0,'Empty ordinary object')
            if 'stack_usage' in row:
                require(Path(row['stack_usage']['path']).name==stem+'.su','Wrong SU stem')
                rows=su_rows(artifact(row['stack_usage']),units[i]);require(rows==row['annotations'],'Independent parsed SU rows differ')
                all_rows.extend([dict(item,translation_unit=units[i]) for item in rows])
                disasm=logs.get((stem+'-objdump','stdout'));symbols=logs.get((stem+'-nm','stdout'))
                if disasm is not None:
                    text=disasm.decode();require('file format' in text and 'Disassembly of section' in text,'No saved decoded object assembly')
                    candidates=[line for line in text.splitlines() if re.search(r'\b(?:jsr|bsr|jmp)\b|\bR_[A-Z0-9_]+\b',line)]
                    if 'raw_call_or_relocation_lines' in row:require(candidates==row['raw_call_or_relocation_lines'],'Raw emitted call/relocation lines changed')
                if symbols is not None:require(symbols.strip(),'Empty saved symbol table')
                for key in ['disassembly','symbols']:
                    if key in row:artifact(row[key])
                unit_summary.append({'index':i,'source':units[i],'function_rows':len(rows),'object':row['object'],'su':row['stack_usage']})
            else:
                require(not success,'Missing SU in claimed complete annotation')
        if success:
            require(len(all_rows)==result['function_rows'],'Function row count differs')
            dynamic=[{k:v for k,v in row.items() if k!='translation_unit'} for row in all_rows if not row['numeric_local_bound']]
            require(dynamic==result['dynamic_unbounded_rows'],'Unbounded qualifier summary differs')
        retained=result['retained_output_files']
        require(len({Path(row['path']).name for row in retained})==len(retained),'Duplicate retained artifact')
        for row in retained:artifact(row)
        actual_names={p.name for p in annotation.iterdir() if p.is_file() and p.name!='manifest.json'}
        require(actual_names=={Path(row['path']).name for row in retained},'Retained output inventory incomplete')
        require(not success or len(actual_names)==320,'Successful 29-TU output inventory differs')

        outer=json.loads(read_regular(args.outer))
        require(outer['helper_invocations']==1 and outer['native_runtime']=='NOT_RUN' and outer['target']=='NOT_RUN' and outer['total_stack']=='UNKNOWN','Outer scope/count differs')
        require(outer['completed'] is True and outer['returncode']==(0 if success else 1),'Outer completion differs')
        require(math.isfinite(outer['elapsed_s']) and outer['elapsed_s']>=0,'Invalid outer elapsed')
        actual_argv=outer['argv']
        expected_argv=[tools['python']['path'],'-B',controls['helper']['path'],'--source',str(source),
                       '--source-manifest',controls['source_manifest']['path'],'--source-manifest-sha256',controls['source_manifest']['sha256'],
                       '--stack-pins',controls['stack_pins']['path'],'--stack-pins-sha256',controls['stack_pins']['sha256'],'--out',str(original)]
        require(actual_argv==expected_argv,'Outer exact helper invocation differs')
        require(outer['controls_before']==outer['controls_after'],'Outer control pins changed')
        for row in outer['controls_before']:verify_row(row)
        verify_row(outer['wrapper'])
        for key in ['stdout','stderr']:verify_row(outer[key])
        original_manifest=original/'manifest.json'
        if original_manifest.exists():require(read_regular(original_manifest)==read_regular(manifest_path),'Durable/original manifest differs')
        mapping=outer['durable_mapping']
        require(len(mapping)==len(retained)+1,'Incomplete durable mapping')
        mapped_names=set()
        for pair in mapping:
            left,right=pair['original'],pair['durable']
            old,new=Path(left['path']),Path(right['path'])
            require(old.parent==original and new.parent==annotation and old.name==new.name and old.name not in mapped_names,'Unexpected/duplicate durable mapping')
            mapped_names.add(old.name)
            verify_row(left);verify_row(right)
            require(read_regular(old)==read_regular(new) and stat.S_IMODE(old.stat().st_mode)==stat.S_IMODE(new.stat().st_mode),'Durable mapping bytes/modes differ')
        require(mapped_names==actual_names|{'manifest.json'},'Durable mapping names differ')
        abi_queries={}
        first_disassembly=logs.get(('tu00-objdump','stdout'),b'').decode()
        for name in ['pt_paula_readers_song_begin_workspace_size','pt_paula_readers_song_begin_workspace_alignment']:
            found=re.search(r'^[0-9a-f]+ <_'+re.escape(name)+r'>:\n(.*?)(?=^[0-9a-f]+ <|\Z)',first_disassembly,re.MULTILINE|re.DOTALL)
            body=found.group(1).strip() if found else None
            immediate=re.search(r'\b(?:movel|moveq)\s+#([0-9]+),%?d0\b',body or '')
            abi_queries[name]={'saved_object_instruction_body':body,'direct_immediate_constant':int(immediate.group(1)) if immediate else 'UNKNOWN',
                               'scope':'Static compiled query constant in exact object; no native/runtime call, memory placement or total-stack implication'}
        focus={}
        for group,names in FOCUS.items():
            matched=[row for row in all_rows if any(re.search(r':'+re.escape(name)+r'(?:\.|$)',row['compiler_location_and_function']) for name in names)]
            focus[group]={'requested_functions':names,'observed_per_function_rows':matched,
                          'unlocated_functions':[name for name in names if not any(re.search(r':'+re.escape(name)+r'(?:\.|$)',row['compiler_location_and_function']) for row in matched)],
                          'call_chain_bound':'UNKNOWN; absent standalone rows may be inlined/optimized and are never zero-frame proof'}
        require(snapshot(source)==files,'Source changed during saved-byte audit')
        for row in controls.values():verify_row(row)
        for row in tools.values():verify_row(row,following_tool=True)
        report.update(status='CLEAR SAVED-BYTE INTEGRITY ONLY' if success else 'CLEAR FAILED-ANNOTATION ARCHIVAL INTEGRITY ONLY',integrity_passed=True,
                      annotation_complete=success,annotation_manifest=record(manifest_path),outer=record(args.outer),
                      source_manifest=controls['source_manifest'],source_files=8122,source_current_unchanged=True,
                      commands=len(commands),commands_all_RC0=all(row.get('returncode')==0 for row in commands),
                      ordered_TUs=units,full_M_queries=sum(row['label'].startswith('dependencies-') for row in commands),
                      canonical_dependencies=canonical,system_dependencies=system,canonical_count=len(canonical),system_count=len(system),
                      tool_pins=tools,selected_cc1=result.get('selected_cc1'),selected_as=result.get('selected_as'),runtime_inputs=runtime_rows,
                      declaration_inputs=declaration_rows,recorded_artifacts=len(retained),recorded_artifact_bytes=sum(row['bytes'] for row in retained),
                      artifact_original_and_durable_bytes_modes_match=original.is_dir(),full_function_rows=len(all_rows),
                      durable_mapping_records=len(mapping),compiled_ABI_query_observations=abi_queries,
                      dynamic_unbounded_count=sum(not row['numeric_local_bound'] for row in all_rows),focus_per_function=focus,
                      largest_reported_frames=sorted(all_rows,key=lambda row:row['reported_bytes'],reverse=True)[:15],unit_summary=unit_summary,
                      preserved_first_diagnostic=result.get('first_diagnostic'),final_provenance_error=result.get('final_provenance_error'),
                      limits=['Per-function compiler output only; no frame sums or native total-stack certificate',
                              'Opaque callback/library/compiler-helper/ABI/OS/interrupt and full fixture/legacy call chains remain UNKNOWN',
                              'No 64KiB launcher adequacy, native execution, timing, WCET or hardware placement acceptance'])
    except Exception as error:
        report['status']='READ-ONLY AUDIT REFUSED';report['first_audit_diagnostic']={'kind':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
    args.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'integrity_passed':report['integrity_passed'],'report':record(args.report),'Stack65536':'NOT_CLEARED'}))
    return 0 if report['integrity_passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
