"""Root input binding for the authorized compiler-only workspace build."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
assert __debug__
assert json.loads((ROOT/'root-host-audit-v3.json').read_text())['passed']
names=['root-host-audit-v3.json','frozen-source-native-v3.json',
 'native-preparation/build_song_readers_workspace_portability.py',
 'native-preparation/toolchain-pins.json',
 'native-preparation/PTPaulaReadersSongWorkspaceTest-contract-v1.json',
 'run_native_once_v3.py','audit_workspace_native_v3.py',
 'independent-frozen-workspace-consistency-v3.json',
 'independent-workspace-constructor-source-review-v4.json',
 'independent-workspace-fixture-source-review-v2.json']
inputs={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}
out=ROOT/'approved-native-controls-v3.json'
assert not out.exists()
out.write_text(json.dumps({'scope':'root approved one assertion-enabled workspace v3 compiler-only invocation after actual host PASS',
 'inputs':inputs,'native_runtime':'NOT_RUN','emulator':'NOT_RUN','physical':'NOT_RUN'},indent=2)+'\n')
print(json.dumps({'approval':str(out),'inputs':len(inputs)}))
