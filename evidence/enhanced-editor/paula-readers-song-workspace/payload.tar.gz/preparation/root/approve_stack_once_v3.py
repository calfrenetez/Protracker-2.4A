"""Root input binding for one separately authorized compiler annotation."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
assert __debug__
for n in ['root-host-audit-v3.json','root-native-audit-v3.json']:assert json.loads((ROOT/n).read_text())['passed']
prep='stack-preparation/source-revision-v2/'
names=['root-host-audit-v3.json','root-native-audit-v3.json','frozen-source-native-v3.json',
 'run_stack_once_v3.py','independent-stack-helper-source-review-v2.json',
 'independent-frozen-workspace-consistency-v3.json']
names += [prep+n for n in ['annotate_workspace_stack.py','stack-tool-pins-v1.json','stack-audit-design-v1.json',
 'origin-copies/build_song_readers_workspace_portability.py','origin-copies/PTPaulaReadersSongWorkspaceTest-contract-v1.json',
 'origin-copies/build_song_readers_faults_portability_v2.py','origin-copies/toolchain-pins.json']]
inputs={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}
out=ROOT/'approved-stack-controls-v3.json';assert not out.exists()
out.write_text(json.dumps({'scope':'root approved one separate workspace v3 compiler annotation invocation after host and functional compiler PASS',
 'inputs':inputs,'total_stack':'UNKNOWN','native_runtime':'NOT_RUN','target':'NOT_RUN'},indent=2)+'\n')
print(json.dumps({'approval':str(out),'inputs':len(inputs)}))
