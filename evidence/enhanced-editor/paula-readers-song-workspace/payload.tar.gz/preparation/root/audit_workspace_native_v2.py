"""Reconstruct saved compiler closures only; never run compiler or product."""
import ast,hashlib,json,shlex,struct
from pathlib import Path
assert __debug__
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'candidate-v2'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def main():
    frozen=json.loads((ROOT/'frozen-source-native-v2.json').read_text())
    actual={p.relative_to(SOURCE).as_posix():sha(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
    assert actual==frozen['files'] and len(actual)==8122
    pins_path=ROOT/'native-preparation/toolchain-pins.json';pins=json.loads(pins_path.read_text());rows=[]
    for kind,name,units in [('song','PTPaulaReadersSongWorkspaceTest',29)]:
        folder=ROOT/'native-final-v2';r=json.loads((folder/'manifest.json').read_text())
        contract_path=ROOT/'native-preparation'/(name+'-contract-v1.json');contract=json.loads(contract_path.read_text())
        assert r['passed'] and r['native_NOT_RUN'] and r['base_commit']==frozen['base_commit'] and r['base_tree']==frozen['base_tree']
        assert r['source_files_before']==r['source_files_after']==len(actual) and len(r['commands'])==units+11
        assert r['source_fingerprint']==hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        for role in ('source_manifest','pins','fixture_contract','builder','compile_commands'):
            f=r[role];assert rec(f['path'])==f
        assert r['source_manifest']==rec(ROOT/'frozen-source-native-v2.json') and r['pins']==rec(pins_path) and r['fixture_contract']==rec(contract_path)
        assert r['builder']==rec(ROOT/'native-preparation/build_song_readers_workspace_portability.py')
        declarations=ast.parse(Path(r['builder']['path']).read_text()).body
        flag_nodes=[node.value for node in declarations if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FLAGS' for t in node.targets)]
        assert len(flag_nodes)==1 and r['flags']==ast.literal_eval(flag_nodes[0])
        assert r['compiler']==pins['native']['compiler'] and r['python']==pins['host']['python']
        for role in ('compiler','python'):assert sha(r[role]['path'])==r[role]['sha256']
        assert len(r['runtime_inputs'])==7
        for runtime,h in r['runtime_inputs'].items():assert sha(r['runtime_paths'][runtime])==h==pins['native']['runtime_inputs'][runtime]
        t=r['targets'][name];assert set(r['targets'])=={name} and t['source_inputs']==contract['ordered_sources'] and len(set(t['source_inputs']))==units
        canon={};external={};order=[]
        for c in r['commands']:
            assert c['returncode']==0 and rec(c['log']['path'])==c['log']
            assert (folder/Path(c['log']['path']).name).read_bytes()==Path(c['log']['path']).read_bytes()
            if '-M' not in c['argv']:continue
            assert '-MM' not in c['argv'] and c['argv'][0]==r['compiler']['path'] and c['argv'][1:-2]==r['flags']
            order.append(c['argv'][-1]);text=Path(c['log']['path']).read_text().replace('\\\n',' ')
            for dep in shlex.split(text.split(':',1)[1]):
                p=(Path(c['directory'])/dep).resolve() if not Path(dep).is_absolute() else Path(dep).resolve()
                try:rel=p.relative_to(SOURCE).as_posix()
                except ValueError:rel=None
                if rel is not None:assert sha(p)==actual[rel];canon[rel]=sha(p)
                else:external[str(p)]=sha(p)
        assert order==t['source_inputs'] and canon==t['dependencies'] and external==t['external_sdk_dependencies']
        command_file=json.loads(Path(r['compile_commands']['path']).read_text());assert len(command_file['commands'])==1
        c=command_file['commands'][0];assert c['ordered_translation_units']==order and c['argv'][0]==r['compiler']['path']
        build_rows=[row for row in r['commands'] if row['label']==name+'.build']
        assert len(build_rows)==1 and c['argv']==build_rows[0]['argv']
        assert c['argv'][1+len(r['flags']):-2]==order and c['argv'][-2:]==['-o',t['binary']['path']]
        assert c['argv'][1:1+len(r['flags'])]==r['flags'] and '-m68000' in r['flags'] and '-msoft-float' in r['flags'] and not any(x.startswith('-DNDEBUG') for x in r['flags'])
        for role in ('binary','preprocessed_fixture','build_log'):
            f=t[role];assert rec(f['path'])==f and (folder/Path(f['path']).name).read_bytes()==Path(f['path']).read_bytes()
        b=(folder/name).read_bytes();marker=contract['marker'].encode();assert struct.unpack('>I',b[:4])[0]==0x3f3 and b.count(marker)==1
        pre=Path(t['preprocessed_fixture']['path']).read_bytes();assert pre.count(marker)==1 and pre.count(b'__assert_func (')>=2 and '__assert_func' in t['last_assert_macro']
        fault=b'PAULA READERS SONG FAULTS PASS: explicit acceptance, independent fault drain and original deadlines; host software only'
        assert b.count(fault)==1 and pre.count(fault)==1
        primary=b'PAULA READERS SONG PASS: exact whole-song schedule, independent actual domains and immutable retained masters; host software only'
        assert b.count(primary)==1 and pre.count(primary)==1
        assert len(external)==32
        assert all(any(Path(x).resolve()==Path(root).resolve() or Path(root).resolve() in Path(x).resolve().parents for root in pins['native']['allowed_sdk_roots']) for x in external)
        outer=json.loads((ROOT/'native-outer-final-v2.json').read_text());assert outer['passed'] and outer['helper_invocations']==1 and outer['returncode']==0
        rows.append({'kind':kind,'report':rec(folder/'manifest.json'),'commands_RC0':len(r['commands']),'full_M_queries_RC0':len(order),'canonical_inputs':len(canon),'external_inputs':len(external),'seven_runtimes_exact':True,'binary':t['binary'],'native_NOT_RUN':True})
    assert actual=={p.relative_to(SOURCE).as_posix():sha(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
    out=ROOT/'root-native-audit-v2.json';assert not out.exists();out.write_text(json.dumps({'passed':True,'scope':'Root saved-byte compiler closure/product audit only; no compiler/product/target execution','source_manifest':rec(ROOT/'frozen-source-native-v2.json'),'products':rows,'native':'NOT_RUN','physical':'NOT_RUN'},indent=2)+'\n')
    print(json.dumps({'passed':True,'products':rows,'audit':rec(out)}))
if __name__=='__main__':main()
