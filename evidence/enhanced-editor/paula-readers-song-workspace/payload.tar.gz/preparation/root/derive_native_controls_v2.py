"""Derive current source/target names in reviewed saved-byte audit and one-shot wrapper."""
import hashlib,json
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent;prior=root.parent/'song-readers-s5ii39rm'
def sha(b):return hashlib.sha256(b).hexdigest()
records=[]
for original,dest in [('audit_song_native_final_v5.py','audit_workspace_native_v2.py'),('run_native_once_v5.py','run_native_once_v2.py')]:
 b=(prior/original).read_bytes();s=b.decode()
 replacements={
  'candidate-v5':'candidate-v2',
  'frozen-source-native-v5.json':'frozen-source-native-v2.json',
  'PTPaulaReadersSongTest':'PTPaulaReadersSongWorkspaceTest',
  '-contract-v2.json':'-contract-v1.json',
  'build_song_readers_faults_portability_v2.py':'build_song_readers_workspace_portability.py',
  'native-final-v5':'native-final-v2',
  'native-outer-final-v5':'native-outer-final-v2',
  'root-native-audit-final-v5.json':'root-native-audit-v2.json',
  'root-host-audit-final-v5.json':'root-host-audit-v2.json',
  'approved-native-controls-v5.json':'approved-native-controls-v2.json',
  'root approved one assertion-enabled v5 compiler-only invocation after actual host PASS':'root approved one assertion-enabled workspace v2 compiler-only invocation after actual host PASS',
  '/private/tmp/pt-song-readers-s5ii39rm-native-v5':'/private/tmp/pt-song-workspace-1nyr8qlf-native-v2',
  'len(actual)==8115':'len(actual)==8122'}
 used={}
 for old,new in replacements.items():
  count=s.count(old)
  if count:s=s.replace(old,new);used[old]={'new':new,'count':count}
 if original.startswith('audit_'):
  old="        assert b.count(fault)==1 and pre.count(fault)==1"
  new=old+"\n        primary=b'PAULA READERS SONG PASS: exact whole-song schedule, independent actual domains and immutable retained masters; host software only'\n        assert b.count(primary)==1 and pre.count(primary)==1"
  assert s.count(old)==1;s=s.replace(old,new);used['additional_marker_guard']='complete inherited primary song marker in CPP and HUNK'
 p=root/dest;assert not p.exists();p.write_text(s)
 records.append({'origin':{'path':str(prior/original),'bytes':len(b),'sha256':sha(b)},'derived':{'path':str(p),'bytes':len(s.encode()),'sha256':sha(s.encode())},'replacements':used})
(root/'native-root-controls-derivation-v2.json').write_text(json.dumps({'scope':'Pure wrapper/audit name and full-marker derivation; no helper/compiler/product execution','records':records},indent=2)+'\n')
print(json.dumps(records,indent=2))
