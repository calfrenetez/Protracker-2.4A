"""Bind the scoped commit and prepend current handoff, preserving all prior history."""
import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
CHECKPOINT=ROOT.parent/'ProTracker-2.4G-development-checkpoint.md'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()
def main():
 assert __debug__
 before=json.loads((ROOT/'before-state.json').read_bytes());staged=json.loads((ROOT/'import-staged-workspace-v1.json').read_bytes())
 commit=git('rev-parse','HEAD');assert commit==git('rev-parse','origin/feat/hardware-independent-core') and commit!=before['head']
 assert not git('diff','--cached','--name-only')
 assert subprocess.check_output(['git','status','--short'],cwd=REPO).decode()==before['status']
 assert git('rev-parse','HEAD^')==before['head']
 assert set(git('diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())=={x['path'] for x in staged['staged']}
 for row in staged['staged']:
  b=subprocess.check_output(['git','show','HEAD:'+row['path']],cwd=REPO);assert len(b)==row['bytes'] and sha(b)==row['sha256']
 for row in before['preserved_files']:
  b=(REPO/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 package=json.loads((ROOT/'package/manifest.json').read_bytes());reader=json.loads((ROOT/'package-reader-result-v1.json').read_bytes())
 assert reader['passed']
 tree=git('rev-parse','HEAD^{tree}');now=datetime.datetime.now(datetime.UTC).isoformat()
 binding={'passed':True,'commit':commit,'tree':tree,'parent':before['head'],'owned_paths':10,'index':'EMPTY','protected16':'EXACT_UNSTAGED','package_payload':package['payload'],'reader':reader,'native_runtime':'NOT_RUN','emulator':'NOT_RUN','physical':'NOT_RUN'}
 bp=ROOT/'current-commit-binding-v3.json';assert not bp.exists();bp.write_text(json.dumps(binding,indent=2)+'\n')
 old=CHECKPOINT.read_bytes();history=ROOT/'checkpoint-before-workspace.md';assert not history.exists();history.write_bytes(old)
 prefix=f'''# Current handoff — caller-owned Paula song construction workspace pushed, {now}

Human authorization remains continuous development/testing until a real decision is needed. Exact scheduling remains selected. HEAD/origin {commit}, tree{tree}; parent eed27e97aa40fa92641f92b2e9012a4329a06f40. Exactly10 owned source/test/doc/evidence paths committed and pushed. Index empty; original16 display/editor/harness paths byte-exact and unstaged. Accepted layout, baseline, authoritative8/16/24-bit masters, budgets, independent voice/cache ownership and deferred feature boundary preserved. Existing heartbeat remains PAUSED; no automation changed. Prior full checkpoint preserved byte-exact below.

**Implemented:** optional size/alignment queries and pt_paula_readers_song_begin_in_workspace use caller-owned ordinary storage for the SAME producer constructor snapshot. Full declared scratch capacity and known source/control/output/backend/constructor-local extents are streamed/guarded before any scratch write/callback; original inputs captured before allocation. Parent/child allocations guard scratch and controls, and all transient scratch references clear before actual owner publication. Scratch may be overwritten/freed immediately after begin. Caller budgets it separately from producer control/representation allocations and keeps opaque callbacks/contexts disjoint/alive. Large compatibility begin retained. All subsequent original producer semantics remain byte-exact: actual opaque preflight/full original audit/SAME sequence, current immutable masters,2commands/8readers, positive prospective ACTIVE, original deadlines, explicit submission/terminal STOP, independent detachment/retirement/drain and reentrant close gates. No caller certificate, fake owner, master promotion during borrowing, editor PLAY hookup, timestamp backend or jitter relaxation.

**Host:** first/once final constructorV4/headerV3/fixtureV2 on frozen candidateV3: workspace and unchanged original whole-song groups PASS under ASan/UBSan.4RC0 compile/run commands,58full-M,80canonical105system inputs,2retained products,5complete runtime markers,0generated. Focused null/short/misaligned/wrapped/full spare capacity/source/PCM/output/backend/allocator alias beforeimages, real callback mutations/allocation refusals, exact scratch reuse/free before genuine lifecycle, inherited8/16/24 whole-song oracles/independent domains and separate old compatibility smoke covered. Root and independent actual saved proofs PASS. Exhaustive alias/callback geometries, stereo/rate44100/native/device cases and unused PCM-padding close remain uncovered. Source-onlyV1/V2 refinements UNEXECUTED, not failed runtime runs. Preparation/reviewer schema/path-spelling/JSON-output-print refusals preserved separately; no product retry or relaxed guard.

**Compiler-only:** first/once pinned assertion-enabled68000/soft-float HUNK build PASS40RC0/29ordered full-M/79canonical32SDK/sevenruntimes. PTPaulaReadersSongWorkspaceTest273684B/SHA337a1bdf2e479da75443d06ac83156b995db7acd5b62989849cf520125b344e4. Three full CPP/HUNK markers and425 active assert expansions checked by root/independent actual saved-proof audits. HUNK NEVER EXECUTED; emulator/physical NOT_RUN.

**Separate compiler annotation:** first/once131RC0/29orderedTUs/full-M/79canonical32SDK/sevenruntimes,29ordinary objects/SU/disassembly/symbol records,627function rows/0dynamic-unbounded rows,320artifacts and321durable mappings. No link/product/target run. Saved-byte integrity independently CLEAR. Public workspace16B/static, private constructor124B/dynamic,bounded, source-span128B, nested validator2192/flow2332/renderbegin2876/take2900, legacybegin70352B and fixturemain844B are separate own-frame observations, never an aggregate. Static compiled query object returns70274B/alignment2 for that exact ABI only; callers use actual API queries. Totalcallchains/opaque callbacks/libraries/ABI/IRQ/reserve/high-water/WCET UNKNOWN. **65536 launcher NOT_CLEARED**, including full fixture's actual legacy compatibility smoke; do not launch it with old65536 stack. No native placement/time/audio inference.

**Evidence:** outputs/song-workspace-1nyr8qlf retains full8120base/8122candidate maps/source-onlyV1/V2/finalV3, actual original+durable host/native/annotation proofs, controls, independent source/saved-proof/docs/packet reviews and staged/index binding. evidence/enhanced-editor/paula-readers-song-workspace packet{len(package['files'])} exact safe members/{reader['archived_source_paths']} canonical source+recipe paths, payload{package['payload']['bytes']}B/SHA{package['payload']['sha256']}. One saved-byte reader PASS; archive0644 modes explicit and separate from original proof modes. Post-build docs overlay bound. Original restricted startup receipt remains private/excluded; newly authored current reviews distinct. Older producer packet unchanged/separate scope.

**Targets/current external gate:** fresh two-peer chat snapshots in fresh-peer-status-workspace-v3.json retain Scott090300 Amiberry recovery HOLD and incomplete physical guest cleanup. Finite read-only Bridge release/free locks/Safari48AuthenticatedViewOnly are peer reports, not shared-transport/application clearance. Root owns/reserves no target/window/lock/TAKE/control/transport, queued no guest action, did no target/physical upload/reset/AHI/audio/retry/hold override or stale PID adoption. RealA1200/AmiGUS availability and authorization remain valid, but exact current emulator qualification plus fresh independent ownership/recovery/live cleanup/release are required before later physical scope. Target owner must resolve existing recovery hold/cleanup; no routine user proceed question is needed.

**Next:** retain architecture's unqualified backend/device/timing boundaries. Assess complete actual call chains and a properly bounded launch plan for this exact whole fixture (or separately qualify a smaller caller-workspace native fixture without reclassifying the full fixture); then fresh shared coordination, exact candidate Amiberry RAM-only qualification and subsequent separately guarded realA1200 scope after verified owner release. Remaining native stack/runtime, mixed backend activation, physical sampleRAM capacity/order/completion/voice-stop and human musical listening still require their own evidence. Compiler/host checks are not those acceptances.

---

'''.encode()
 CHECKPOINT.write_bytes(prefix+old);assert CHECKPOINT.read_bytes()[len(prefix):]==history.read_bytes()==old
 receipt=ROOT/'checkpoint-update-v3.json';receipt.write_text(json.dumps({'passed':True,'commit':commit,'checkpoint':str(CHECKPOINT),'prior_bytes':len(old),'prior_sha256':sha(old),'prefix_bytes':len(prefix),'whole_sha256':sha(prefix+old)},indent=2)+'\n')
 print(json.dumps({'passed':True,'commit':commit,'own_paths':10,'protected':16,'history_preserved':True}))
if __name__=='__main__':main()
