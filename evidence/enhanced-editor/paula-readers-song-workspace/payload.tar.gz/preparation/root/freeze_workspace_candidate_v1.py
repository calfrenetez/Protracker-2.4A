"""Freeze four reviewed workspace inputs into an otherwise exact committed export."""
import hashlib,json,subprocess
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent
repo=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
owned=['src/editor/paula_readers_song.c','src/editor/paula_readers_song.h','tests/paula_readers_song_workspace_test.c','tests/test_paula_readers_song_workspace.py']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def inventory(source):
 result={}
 for p in sorted(source.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():result[p.relative_to(source).as_posix()]=sha(p.read_bytes())
 return result
baseline=json.loads((root/'baseline-manifest.json').read_bytes());before=json.loads((root/'before-state.json').read_bytes())
approved=json.loads((root/'approved-drafts-v1.json').read_bytes());assert list(approved['files'])==owned
assert git('rev-parse','HEAD').decode().strip()==before['head']==baseline['base_commit']
assert git('status','--short').decode()==before['status'] and git('diff','--cached','--name-only')==b''
for f in before['preserved_files']:
 b=(repo/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
source=root/'candidate';previous={n:f['sha256'] for n,f in baseline['files'].items()}
assert len(previous)==8120 and inventory(source)==previous
assert not (root/'frozen-source-host-v1.json').exists()
for n in owned:
 f=approved['files'][n];p=Path(f['path']);assert not p.is_symlink()
 b=p.read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
 if n in previous:assert n.startswith('src/editor/')
 else:assert not (source/n).exists()
 (source/n).parent.mkdir(parents=True,exist_ok=True);(source/n).chmod(0o644) if (source/n).exists() else None
 (source/n).write_bytes(b);(source/n).chmod(0o444)
actual=inventory(source);assert len(actual)==8122
assert {n for n in previous if actual[n]!=previous[n]}==set(owned[:2])
assert set(actual)-set(previous)==set(owned[2:])
assert actual['tests/paula_readers_song_test.c']==previous['tests/paula_readers_song_test.c'] and actual['tests/test_paula_readers_song.py']==previous['tests/test_paula_readers_song.py']
common={'scope':'Exact committed baseline plus caller-workspace constructor C/H and separate genuine workspace fixture/recipe','base_commit':baseline['base_commit'],'base_tree':baseline['base_tree'],'owned':owned,'protected16_exact':True}
for lane,key in [('host','source'),('native','files')]:
 p=root/('frozen-source-'+lane+'-v1.json');assert not p.exists();p.write_text(json.dumps({**common,key:actual},indent=2)+'\n');p.chmod(0o444)
record={**common,'source_files':len(actual),'baseline_files':len(previous),'only_replaced':owned[:2],'only_added':owned[2:],'approved_inputs_sha256':sha((root/'approved-drafts-v1.json').read_bytes()),'maps_equal':True,'target_execution':'NONE'}
(root/'candidate-freeze-v1.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
