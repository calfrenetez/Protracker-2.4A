"""Preserve unexecuted V1/V2 and freeze only the reviewed typed-assignment precision."""
import hashlib,json,shutil,subprocess
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent
repo=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(source):
 result={}
 for p in sorted(source.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():result[p.relative_to(source).as_posix()]=sha(p.read_bytes())
 return result
before=json.loads((root/'before-state.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()==before['head']
assert subprocess.check_output(['git','status','--short'],cwd=repo).decode()==before['status']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo)
for f in before['preserved_files']:
 b=(repo/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
old=json.loads((root/'frozen-source-host-v2.json').read_bytes());oldmap=old['source']
assert inventory(root/'candidate-v2')==oldmap and len(oldmap)==8122
approved=json.loads((root/'approved-drafts-v3.json').read_bytes())
assert list(approved['files'])==old['owned'] and not (root/'candidate-v3').exists()
expected=dict(oldmap)
for n,f in approved['files'].items():
 b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];expected[n]=sha(b)
assert {n for n in expected if expected[n]!=oldmap[n]}=={'src/editor/paula_readers_song.c'}
shutil.copytree(root/'candidate-v2',root/'candidate-v3')
for n,f in approved['files'].items():
 p=root/'candidate-v3'/n;p.chmod(0o644);p.write_bytes(Path(f['path']).read_bytes());p.chmod(0o444)
assert inventory(root/'candidate-v3')==expected and inventory(root/'candidate-v2')==oldmap
common={k:v for k,v in old.items() if k!='source'}
common['scope']='Exact committed baseline plus caller-workspace constructor v4 and corrected genuine fixture v2; v1/v2 preserved unexecuted'
for lane,key in [('host','source'),('native','files')]:
 p=root/('frozen-source-'+lane+'-v3.json');assert not p.exists();p.write_text(json.dumps({**common,key:expected},indent=2)+'\n');p.chmod(0o444)
receipt={**common,'source_files':len(expected),'only_delta_from_v2':'src/editor/paula_readers_song.c','previous_source_exact':True,'approved_inputs_sha256':sha((root/'approved-drafts-v3.json').read_bytes()),'target_execution':'NONE'}
(root/'candidate-freeze-v3.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
