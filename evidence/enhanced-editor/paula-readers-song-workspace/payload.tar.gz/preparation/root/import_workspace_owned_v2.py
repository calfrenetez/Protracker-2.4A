"""Import/stage only the reviewed workspace slice, preserving all16 unrelated paths."""
import argparse,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def main():
 assert __debug__
 ap=argparse.ArgumentParser(__doc__);ap.add_argument('--docs',type=Path,required=True);args=ap.parse_args()
 before=json.loads((ROOT/'before-state.json').read_bytes())
 assert git('rev-parse','HEAD').decode().strip()==before['head']
 assert git('branch','--show-current').decode().strip()=='feat/hardware-independent-core'
 assert not git('diff','--cached','--name-only')
 assert git('status','--short').decode()==before['status']
 for row in before['preserved_files']:
  b=(REPO/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 for n in ['root-host-audit-v3.json','root-native-audit-v3.json']:assert json.loads((ROOT/n).read_bytes())['passed']
 packet=json.loads((ROOT/'package-reader-result-v2.json').read_bytes());assert packet['passed']
 baseline=json.loads((ROOT/'baseline-manifest.json').read_bytes())['files']
 frozen=json.loads((ROOT/'frozen-source-host-v3.json').read_bytes());changes={}
 for n in frozen['owned']:
  b=(ROOT/'candidate-v3'/n).read_bytes();assert sha(b)==frozen['source'][n]
  if n in baseline:assert git('show','HEAD:'+n)==(REPO/n).read_bytes() and sha(git('show','HEAD:'+n))==baseline[n]['sha256']
  else:assert not (REPO/n).exists()
  changes[n]=b
 doc='docs/PAULA_READERS_SONG_WORKSPACE.md';assert not (REPO/doc).exists()
 changes[doc]=(args.docs/'PAULA_READERS_SONG_WORKSPACE.md').read_bytes()
 appendix=(args.docs/'PAULA_READERS_SONG.workspace-appendix.txt').read_bytes()
 old=git('show','HEAD:docs/PAULA_READERS_SONG.md')
 assert old==(REPO/'docs/PAULA_READERS_SONG.md').read_bytes()
 changes['docs/PAULA_READERS_SONG.md']=old+appendix
 evidence='evidence/enhanced-editor/paula-readers-song-workspace'
 assert not (REPO/evidence).exists()
 for n in ['README.md','manifest.json','payload.tar.gz','verify_payload.py']:changes[evidence+'/'+n]=(ROOT/'package-final-v2'/n).read_bytes()
 assert len(changes)==10 and not set(changes)&{x['path'] for x in before['preserved_files']}
 receipt=ROOT/'import-staged-workspace-v2.json';assert not receipt.exists()
 for n,b in changes.items():
  p=REPO/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  assert p.read_bytes()==b
 subprocess.run(['git','add','--',*changes],cwd=REPO,check=True)
 staged=set(git('diff','--cached','--name-only').decode().splitlines());assert staged==set(changes)
 for n,b in changes.items():assert git('show',':'+n)==b
 host=json.loads((ROOT/'host-final-v3/host-checks.json').read_bytes())
 native=json.loads((ROOT/'native-final-v3/manifest.json').read_bytes())
 compiled=set(host['canonical_dependencies'])
 for t in native['targets'].values():compiled.update(t['dependencies'])
 protected={x['path'] for x in before['preserved_files']};assert not compiled&protected
 for n in compiled|set(frozen['owned']):assert sha(git('show',':'+n))==frozen['source'][n]
 # A clean archived recipe is referenced, while its dirty working copy is not compiled.
 for n in ['tools/build_core_tests.py','tools/build_diagnostic.py']:assert sha(git('show',':'+n))==frozen['source'][n]
 for row in before['preserved_files']:
  b=(REPO/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 subprocess.run(['git','diff','--cached','--check'],cwd=REPO,check=True)
 receipt.write_text(json.dumps({'passed':True,'scope':'Own10 staged paths and actual compiled/index bytes only; protected16 remain exact/unstaged',
  'base':before['head'],'staged':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(changes.items())],
  'compiled_canonical_index_matches':len(compiled),'clean_recipe_reference_matches':True,
  'preserved16_exact':True,'emulator':'NOT_RUN','physical':'NOT_RUN'},indent=2)+'\n')
 print(json.dumps({'passed':True,'own_staged':len(changes),'compiled':len(compiled),'receipt':str(receipt)}))
if __name__=='__main__':main()
