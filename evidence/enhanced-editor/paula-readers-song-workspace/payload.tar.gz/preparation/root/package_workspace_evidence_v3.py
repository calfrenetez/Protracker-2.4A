"""Package saved workspace source/proof bytes only; no compilation or target action."""
import argparse,ast,gzip,hashlib,io,json,tarfile
from pathlib import Path,PurePosixPath
assert __debug__
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'candidate-v3';OUT=ROOT/'package'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser(__doc__);ap.add_argument('--docs',type=Path,required=True);args=ap.parse_args()
 for n in ['root-host-audit-v3.json','root-native-audit-v3.json']:
  assert json.loads((ROOT/n).read_bytes())['passed']
 annotation=json.loads((ROOT/'stack-final-v3/manifest.json').read_bytes())
 assert annotation['annotation_complete'] and not annotation['link_performed'] and not annotation['product_execution_performed'] and annotation['total_030_stack']=='UNKNOWN'
 assert not OUT.exists();OUT.mkdir();members={};inputs=set()
 def put(n,p):
  name=PurePosixPath(n);assert name.as_posix()==n and not name.is_absolute() and all(x not in ('','.','..') for x in n.split('/')) and n not in members
  p=Path(p);assert p.is_file() and not p.is_symlink();members[n]=p.read_bytes()
 def tree(prefix,p):
  assert p.is_dir()
  for f in sorted(p.rglob('*')):
   assert not f.is_symlink()
   if f.is_file():put(prefix+'/'+f.relative_to(p).as_posix(),f)
 host=json.loads((ROOT/'host-final-v3/host-checks.json').read_bytes());assert host['passed']
 native=json.loads((ROOT/'native-final-v3/manifest.json').read_bytes());assert native['passed'] and native['native_NOT_RUN']
 inputs.update(host['canonical_dependencies'])
 for t in native['targets'].values():inputs.update(t['dependencies'])
 inputs.update(annotation['canonical_dependencies'])
 frozen=json.loads((ROOT/'frozen-source-host-v3.json').read_bytes());assert len(frozen['source'])==8122
 inputs.update(frozen['owned'])
 todo=['tests/'+n+'.py' for n in host['modules']];imports=set(todo)
 while todo:
  n=todo.pop()
  for node in ast.walk(ast.parse((SOURCE/n).read_text())):
   if isinstance(node,ast.ImportFrom) and node.module and node.module.startswith('test_'):
    other='tests/'+node.module+'.py'
    if other not in imports:assert (SOURCE/other).is_file();imports.add(other);todo.append(other)
 inputs.update(imports);inputs.update(['tools/build_core_tests.py','tools/build_diagnostic.py'])
 for n in sorted(inputs):assert sha((SOURCE/n).read_bytes())==frozen['source'][n];put('source/'+n,SOURCE/n)
 for lane in ['host-final-v3','native-final-v3','stack-final-v3']:tree('proof/'+lane,ROOT/lane)
 for v,folder in [(1,'candidate'),(2,'candidate-v2')]:
  fmap=json.loads((ROOT/('frozen-source-host-v%d.json'%v)).read_bytes())['source']
  for n in frozen['owned']:
   assert sha((ROOT/folder/n).read_bytes())==fmap[n];put('unexecuted-source/v%d/'%v+n,ROOT/folder/n)
 # Only root-authored controls and newly authorized scoped reviews. The old
 # restricted private startup receipt is neither read nor copied.
 for p in sorted(ROOT.iterdir()):
  if p.is_file() and p.suffix in ['.json','.txt','.stdout','.stderr']:
   assert p.name not in ['readers-startup-independent-packet-review.json'];put('records/'+p.name,p)
 for lane in ['host-tools-v1','native-preparation','stack-preparation','annotation-independent-preparation']:tree('preparation/'+lane,ROOT/lane)
 for p in sorted(ROOT.glob('*.py')):put('preparation/root/'+p.name,p)
 tree('documentation/final',args.docs.resolve())
 for p in sorted((ROOT/'docs-draft').rglob('*')):
  if p.is_file():put('documentation/history/'+p.relative_to(ROOT/'docs-draft').as_posix(),p)
 payload=OUT/'payload.tar.gz'
 with payload.open('xb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tf:
    for n,b in sorted(members.items()):
     info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(b))
 manifest={'scope':'Caller-owned song constructor workspace. Saved host PASS, compiler-only HUNK, separate per-function annotation. Total native stack/launcher UNKNOWN; emulator/physical/timing/audio/listening NOT_RUN.',
  'base_commit':frozen['base_commit'],'base_tree':frozen['base_tree'],
  'payload':{'bytes':payload.stat().st_size,'sha256':sha(payload.read_bytes())},
  'files':[{'path':n,'bytes':len(b),'sha256':sha(b),'mode':0o644} for n,b in sorted(members.items())]}
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (OUT/'verify_payload.py').write_bytes((ROOT/'verify_workspace_payload_v2.py').read_bytes())
 with tarfile.open(payload) as tf:assert {f.name:tf.extractfile(f).read() for f in tf}==members
 print(json.dumps({'members':len(members),'source_paths':len(inputs),'uncompressed_bytes':sum(map(len,members.values())),'payload':manifest['payload']}))
if __name__=='__main__':main()
