"""Bind root's first host execution approval to exact current source and reviews."""
import hashlib,json
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent;prior=root.parent/'song-readers-s5ii39rm'
def record(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
source=json.loads((root/'frozen-source-host-v3.json').read_bytes())
assert source['source']==json.loads((root/'frozen-source-native-v3.json').read_bytes())['files'] and len(source['source'])==8122
assert json.loads((root/'independent-host-helper-source-review-v1.json').read_bytes())['status'].startswith('CLEAR')
assert json.loads((root/'independent-workspace-fixture-source-review-v2.json').read_bytes())['status'].startswith('CLEAR')
assert json.loads((root/'independent-frozen-workspace-consistency-v3.json').read_bytes())['status'].startswith('CLEAR')
paths=[root/'frozen-source-host-v3.json',root/'frozen-source-native-v3.json',root/'host-tools-v1/host_provenance.py',root/'host-tools-v1/provenance_common.py',root/'host-tools-v1/toolchain-pins.json',root/'run_host_once_v3.py',root/'audit_workspace_host_v3.py',root/'approved-drafts-v3.json',root/'independent-host-helper-source-review-v1.json',root/'independent-workspace-fixture-source-review-v2.json',root/'independent-workspace-constructor-source-review-v4.json']
paths.extend(root/'candidate-v3'/n for n in source['owned'])
paths.append(root/'independent-frozen-workspace-consistency-v3.json')
out=root/'approved-host-controls-v3.json';assert not out.exists()
value={'scope':'Root approved exact workspace constructor v4 / corrected fixture v2 two-group host-only qualification','source_files':8122,'inputs':[record(p) for p in paths],'target_operations':'NOT_AUTHORIZED_BY_THIS_CONTROL; separate shared ownership/recovery/runtime qualification remains required','native_runtime':'NOT_RUN'}
out.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({'control':record(out),'inputs':len(paths),'source_files':8122}))
