"""Derive only host module selection from the previously reviewed helper."""
import hashlib,json,shutil
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent
prior=root.parent/'song-readers-s5ii39rm/host-tools-v1'
out=root/'host-tools-v1';assert not out.exists();out.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
for n in ['provenance_common.py','toolchain-pins.json']:
 b=(prior/n).read_bytes();(out/n).write_bytes(b)
before=(prior/'host_provenance.py').read_bytes()
old=b"MODULES = ['test_paula_readers_song', 'test_sampler_paula_readers_boundary', 'test_paula_preflight_startup']"
new=b"MODULES = ['test_paula_readers_song_workspace', 'test_paula_readers_song']"
assert before.count(old)==1;after=before.replace(old,new)
(out/'host_provenance.py').write_bytes(after)
record={'scope':'Only module selection changed; original helper docstring retained as historical description, actual MODULES two affected constructor groups','prior_helper':{'bytes':len(before),'sha256':sha(before)},'helper':{'bytes':len(after),'sha256':sha(after)},'exact_delta':{'before':old.decode(),'after':new.decode()},'common_and_pins':{n:{'bytes':(out/n).stat().st_size,'sha256':sha((out/n).read_bytes())} for n in ['provenance_common.py','toolchain-pins.json']},'execution':'NONE'}
(root/'host-tools-derivation-v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
