"""Preserve unexecuted V2 controls and bind exact final constructor source revision."""
import hashlib,json
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
rows=[]
for old,new in [('run_host_once_v2.py','run_host_once_v3.py'),('audit_workspace_host_v1.py','audit_workspace_host_v3.py'),('prepare_host_approval_v2.py','prepare_host_approval_v3.py'),('audit_workspace_native_v2.py','audit_workspace_native_v3.py'),('run_native_once_v2.py','run_native_once_v3.py')]:
 p=root/old;b=p.read_bytes();text=b.decode();after=text.replace('-v2','-v3')
 after=after.replace('workspace constructor v3 / corrected fixture v2','workspace constructor v4 / corrected fixture v2')
 after=after.replace('workspace v2 compiler-only','workspace v3 compiler-only')
 # The genuine fixture revision remains V2, while the complete export is V3.
 after=after.replace('independent-workspace-fixture-source-review-v3.json','independent-workspace-fixture-source-review-v2.json')
 after=after.replace('audit_workspace_host_v1.py','audit_workspace_host_v3.py')
 q=root/new;assert not q.exists();q.write_text(after)
 rows.append({'original':{'path':str(p),'bytes':len(b),'sha256':sha(b)},'derived':{'path':str(q),'bytes':len(after.encode()),'sha256':sha(after.encode())}})
(root/'unexecuted-controls-rebinding-v3.json').write_text(json.dumps({'scope':'Only final export/report/control labels and root host review scope rebound. Unchanged fixture V2/source helper/full flags/proof bodies; no compiler/product/target execution','rows':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
