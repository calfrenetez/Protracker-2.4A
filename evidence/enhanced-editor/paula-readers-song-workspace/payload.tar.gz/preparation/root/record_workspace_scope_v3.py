"""Record actual saved qualifications and unresolved targets; no product run."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
assert __debug__
def rec(n):
 p=ROOT/n;return {'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
host=json.loads((ROOT/'host-final-v3/host-checks.json').read_text())
native=json.loads((ROOT/'native-final-v3/manifest.json').read_text())
stack=json.loads((ROOT/'stack-final-v3/manifest.json').read_text())
assert host['passed'] and native['passed'] and stack['annotation_complete']
out=ROOT/'scope-final-v3.json';assert not out.exists()
value={'scope':'Optional caller-owned scratch for the SAME genuine whole-song Paula software producer; preserve architecture/baseline/exact scheduling/master authority/classic layout',
 'source':'candidate-v3 / constructor V4 / header V3 / workspace fixture V2',
 'base_commit':'eed27e97aa40fa92641f92b2e9012a4329a06f40','source_files':8122,
 'host':{'groups':2,'commands_RC0':4,'full_M':58,'canonical_inputs':80,'system_inputs':105,'retained_products':2,'full_runtime_markers':5,'state':'PASS'},
 'native_compiler':{'commands_RC0':40,'ordered_full_M':29,'canonical_inputs':79,'SDK_inputs':32,'runtime_inputs':7,'HUNK':native['targets']['PTPaulaReadersSongWorkspaceTest']['binary'],'state':'COMPILER_ONLY_PASS'},
 'separate_annotation':{'commands_RC0':131,'ordered_full_M':29,'ordinary_objects':29,'compiler_function_rows':627,'public_workspace_own_frame_bytes':16,'private_constructor_own_frame_bytes':124,'legacy_begin_own_frame_bytes':70352,'state':'PER_FUNCTION_ONLY','total_stack':'UNKNOWN','launcher_65536':'NOT_CLEARED','link':False,'product_run':False},
 'runtime':{'Amiga':'NOT_RUN','Amiberry':'NOT_RUN','physical_A1200':'NOT_RUN','placement':'NOT_RUN','DMA_IRQ_backend_activation':'NOT_RUN','device_capacity_order_completion_voice_stop':'NOT_RUN','musical_timing':'NOT_RUN','audio_listening':'NOT_RUN'},
 'preserved':{'unrelated16':'EXACT_UNSTAGED','previous_versions1_2':'UNEXECUTED_SOURCE','old_producer_evidence':'UNCHANGED_SEPARATE_SCOPE','heartbeat':'PAUSED_UNCHANGED'},
 'target_gates':'Fresh peer snapshots retain Scott Amiberry090300 recovery HOLD and incomplete physical guest cleanup. Root owns/reserves no target/control/transport/lock, queued no guest action. Free locks/Safari viewing are not clearance.',
 'records':[rec(n) for n in ['root-host-audit-v3.json','root-native-audit-v3.json','independent-saved-host-proof-review-v3.json','independent-saved-native-proof-review-v3.json','independent-stack-annotation-review-author-v1.json','fresh-peer-status-workspace-v3.json']]}
out.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(rec(out)))
