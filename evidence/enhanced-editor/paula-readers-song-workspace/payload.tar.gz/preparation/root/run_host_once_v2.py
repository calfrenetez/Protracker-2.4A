"""One source-reviewed frozen two-group sanitizer qualification; host software only."""
import hashlib,json,subprocess
from pathlib import Path
assert __debug__
root=Path(__file__).resolve().parent
python='/opt/homebrew/opt/python@3.14/bin/python3.14'
out=Path('/private/tmp/pt-song-workspace-1nyr8qlf-host-v2')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
approval=json.loads((root/'approved-host-controls-v2.json').read_bytes())
assert approval['scope']=='Root approved exact workspace constructor v3 / corrected fixture v2 two-group host-only qualification'
for row in approval['inputs']:
 p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
assert not out.exists() and not (root/'host-execution-v2.json').exists()
manifest=root/'frozen-source-host-v2.json';pins=root/'host-tools-v1/toolchain-pins.json'
argv=[python,'-B',str(root/'host-tools-v1/host_provenance.py'),'--source',str(root/'candidate-v2'),'--source-manifest',str(manifest),'--source-manifest-sha256',sha(manifest),'--pins',str(pins),'--pins-sha256',sha(pins),'--out',str(out)]
record={'scope':approval['scope'],'argv':argv,'state':'dispatched once','native':'NOT_RUN','physical':'NOT_RUN'}
(root/'host-execution-v2.json').write_text(json.dumps(record,indent=2)+'\n')
with (root/'host-driver-stdout-v2.txt').open('xb') as stdout,(root/'host-driver-stderr-v2.txt').open('xb') as stderr:
 completed=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
record.update({'state':'completed','driver_rc':completed.returncode,'original_out':str(out)})
(root/'host-execution-v2.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));raise SystemExit(completed.returncode)
