"""One separate compiler annotation invocation; no link, product or target run."""
import datetime,hashlib,json,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PY='/opt/homebrew/opt/python@3.14/bin/python3.14'
PRIVATE=Path('/private/tmp/pt-song-workspace-1nyr8qlf-stack-v3')
DURABLE=ROOT/'stack-final-v3'
def rec(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def main():
 assert __debug__
 for n in ['root-host-audit-v3.json','root-native-audit-v3.json']:assert json.loads((ROOT/n).read_text())['passed']
 approval=json.loads((ROOT/'approved-stack-controls-v3.json').read_text())
 assert approval['scope']=='root approved one separate workspace v3 compiler annotation invocation after host and functional compiler PASS'
 for n,h in approval['inputs'].items():assert rec(ROOT/n)['sha256']==h,n
 prep=ROOT/'stack-preparation/source-revision-v2'
 helper=prep/'annotate_workspace_stack.py';pins=prep/'stack-tool-pins-v1.json';manifest=ROOT/'frozen-source-native-v3.json'
 argv=[PY,'-B',str(helper),'--source',str(ROOT/'candidate-v3'),'--source-manifest',str(manifest),'--source-manifest-sha256',rec(manifest)['sha256'],'--stack-pins',str(pins),'--stack-pins-sha256',rec(pins)['sha256'],'--out',str(PRIVATE)]
 receipt=ROOT/'stack-outer-final-v3.json';stdout=ROOT/'stack-outer-final-v3.stdout';stderr=ROOT/'stack-outer-final-v3.stderr'
 assert not any(p.exists() for p in [PRIVATE,DURABLE,receipt,stdout,stderr])
 controls=[helper,pins,manifest]
 v={'scope':approval['scope'],'argv':argv,'helper_invocations':1,'wrapper':rec(__file__),'controls_before':[rec(p) for p in controls],'native_runtime':'NOT_RUN','target':'NOT_RUN','total_stack':'UNKNOWN','started_utc':datetime.datetime.now(datetime.UTC).isoformat()}
 receipt.write_text(json.dumps(v,indent=2)+'\n');start=time.monotonic()
 with stdout.open('xb') as out,stderr.open('xb') as err:done=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err)
 v.update({'returncode':done.returncode,'completed':done.returncode==0,'elapsed_s':time.monotonic()-start,'controls_after':[rec(p) for p in controls],'stdout':rec(stdout),'stderr':rec(stderr)})
 assert v['controls_before']==v['controls_after']
 if PRIVATE.exists():
  shutil.copytree(PRIVATE,DURABLE);mapping=[]
  for p in sorted(PRIVATE.rglob('*')):
   if p.is_file():
    copy=DURABLE/p.relative_to(PRIVATE);assert p.read_bytes()==copy.read_bytes();mapping.append({'original':rec(p),'durable':rec(copy)})
  v['durable_mapping']=mapping
 receipt.write_text(json.dumps(v,indent=2)+'\n')
 print(json.dumps({'completed':v['completed'],'returncode':done.returncode,'receipt':rec(receipt),'total_stack':'UNKNOWN','native_runtime':'NOT_RUN'}));raise SystemExit(done.returncode)
if __name__=='__main__':main()
