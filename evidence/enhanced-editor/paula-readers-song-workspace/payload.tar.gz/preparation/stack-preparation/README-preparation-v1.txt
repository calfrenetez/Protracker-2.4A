Prepared compiler-only stack annotation (NOT RUN)

The helper is a separate experiment requiring root and peer source review
before invocation. It will compile the exact current 29 ordered workspace
fixture units, preserving the functional -std=c99/-m68000/-msoft-float/
-mcrt=nix20/-Os/-Wall/-Wextra/-Werror/include/-fbbb=- flags. Only
-fstack-usage and -c are added. It never links or executes a product.

The argument-bound source is root candidate-v2, with the exact 8,122-file
frozen-source-native-v2.json inventory and corrected fixture 72,571 bytes /
f4b0f5fbadc33c8c142efdae31164a55d46805337290f028d1e39e784acaca28.
The unchanged readers and producer implementations retain their actual
single fixture inclusion. The legacy large-stack begin smoke and full
fixture main are present. No branch is skipped for stack convenience.

On a separately authorized invocation, the helper first checks controls,
source bytes, pinned Python/compiler/cc1/two recognized assembler locations/
objdump/nm and the actual selected GCC tool paths. It queries the seven
unchanged runtime paths/hashes. Every unit receives an actual full-M query;
all resulting canonical and SDK inputs are pinned. Default SDK assertions
and all three complete footer literals are checked in preprocessing.

Each object must have its expected nonempty tuNN.su with recognized GCC
qualifiers. Object/.su hashes, bytes and modes plus raw objdump -dr and
nm -an stdout/stderr are retained. Source and pin checks surround the
experiment. The first compiler/report/tool refusal stops without retry,
changed optimization, fallback, link or product execution. Raw/partial
outputs and the first diagnostic survive in manifest.json. Command timeout
is a host-process bound, not an application/native timing claim.

Annotation_complete means only all per-function reports and object tools
completed. It never means total native stack is sufficient. Unbounded
dynamic rows, opaque callbacks, libraries/SDK/OS, emitted compiler helpers,
inlining/clones/tail/recursive effects, ABI caller overhead, whole main,
legacy begin, launcher and interrupt reserve remain separate UNKNOWN
edges. No source-regex graph is summed. Native stack, IRQ residency, WCET,
Fast/Chip placement, hardware scheduling and target execution are unqualified.

Original stack design, excerpt, builder/pins and current functional derivative
are retained as exact origin copies. Initial unexecuted helper history binds
the earlier fixture. A source-only auxiliary AST check falsely counted an
exception constructor as invocation; its refusal record is retained, and the
corrected AST check changed no producer/helper bytes. Only the static audit
script has run; no prepared helper body, compiler/tool, test or product ran.

The exact planned argument vector and external source control fingerprints
are in prepared-handoff-v1.json. It is an invocation recipe, not authorization.
