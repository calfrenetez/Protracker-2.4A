#!/usr/bin/env python3
"""Separate pinned compiler-only stack annotation; preparation never authorizes execution.

Compiles the exact 29-TU workspace fixture topology with its original functional
flags plus -fstack-usage -c. Saves full-M, object, .su, objdump and nm evidence.
Never links or runs a product. Compiler per-function frames are not a total
030 call-chain/launcher stack bound, IRQ reserve, WCET or placement proof.
The large legacy begin smoke, full main, indirect callbacks and libraries
remain part of any later stack assessment; no source/fixture route is skipped.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import time
import traceback

FLAGS = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
         '-Wall', '-Wextra', '-Werror', '-Isrc/core', '-Ibuild/dev', '-fbbb=-']
ANNOTATION_FLAGS = ['-fstack-usage', '-c']
RUNTIMES = ['ncrt0.o', 'libnix20.a', 'libnixmain.a', 'libnix.a',
            'libstubs.a', 'libamiga.a', 'libgcc.a']
SAMPLER_SOURCES = ['tests/sampler_test.c', 'src/editor/sampler.c', 'src/editor/slots.c',
    'src/core/pcm_filtered.c', 'src/core/slices.c', 'src/core/pattern.c',
    'src/core/document.c', 'src/core/pp20.c', 'src/core/project.c',
    'src/core/mod_project.c', 'src/core/mod_inspect.c', 'src/core/channels.c',
    'src/core/pcm.c', 'src/core/wav.c', 'src/core/svx.c', 'src/core/raw.c']
READERS_PREFIX = ['tests/sampler_paula_readers_test.c', 'src/editor/sampler_paula.c',
    'src/core/sample_cache.c', 'src/core/playback_pcm.c', 'src/core/scheduled_readers.c',
    'src/core/elapsed_clock.c', 'src/core/paula_render_voice.c']
RENDERER = ['src/editor/paula_preflight.c', 'src/core/render.c', 'src/core/pitch.c',
    'src/core/timeline.c', 'src/core/frame_clock.c', 'src/core/flow.c', 'src/core/voice.c']
FIXTURE = 'tests/paula_readers_song_workspace_test.c'
FIXTURE_SHA = 'f4b0f5fbadc33c8c142efdae31164a55d46805337290f028d1e39e784acaca28'
FIXTURE_BYTES = 72571
SOURCES = [FIXTURE, *READERS_PREFIX[1:], *SAMPLER_SOURCES[1:], *RENDERER]
MARKERS = [
    'PAULA READERS SONG PASS: exact whole-song schedule, independent actual domains and immutable retained masters; host software only',
    'PAULA READERS SONG FAULTS PASS: explicit acceptance, independent fault drain and original deadlines; host software only',
    'PAULA READERS SONG WORKSPACE PASS: guarded caller scratch released before genuine exact scheduling and independent domain ownership; host software only']
DECLARATIONS = ['tests/test_sampler.py', 'tests/test_sampler_paula_readers.py',
    'tests/test_sampler_paula_readers_boundary.py', 'tests/test_paula_readers_song.py',
    'tests/test_paula_readers_song_workspace.py']
INCLUDE_CHAIN = [FIXTURE, 'tests/sampler_paula_readers_test.c',
    'src/editor/sampler_paula_readers.c', 'src/editor/paula_readers_song.c']
DESIGN_SHA = '5d2da04a3b199d68a50d94c48ccf55888f648e683714ec0c79b4522e8590d4e1'
ORIGIN_SHA = 'a0bd6c350c21c29173daba4f4497be20b7bb06b25b8e46c8d2b093c6d031a01f'
ORIGIN_PINS_SHA = '22ac81cd691e00c5ee75a10b855966eed23a52edf741fcc624a907b37cf0b461'
WORKSPACE_BUILDER_SHA = '51004cae31ac1efb10968598e8661ed5ade4661cae443adb73d6adaa93297740'
WORKSPACE_CONTRACT_SHA = 'f1818232d70c0b028b3466d67bb39d289b895ea649708972a1ba5c2a07f30302'
SCOPE = 'Separate compiler-only per-function annotation and object inspection; no link, runtime, native stack qualification, timing/WCET, IRQ or hardware proof'


class AnnotationUnsupported(ValueError):
    pass


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha_bytes(Path(path).read_bytes())


def record(path):
    p = Path(path)
    metadata = p.stat()
    return {'path': str(p), 'bytes': metadata.st_size, 'sha256': digest(p),
            'mode': stat.S_IMODE(metadata.st_mode)}


def pin(path, expected):
    p = Path(path)
    if not p.is_file() or digest(p) != expected:
        raise ValueError('Pinned input absent/changed: ' + str(p))


def below(path, root):
    return path == root or root in path.parents


def snapshot(source):
    result = {}
    for p in sorted(source.rglob('*')):
        if p.is_symlink():
            raise ValueError('Frozen source symlink: ' + str(p))
        if p.is_file():
            result[p.relative_to(source).as_posix()] = digest(p)
    return result


def checked_files(manifest):
    files = manifest.get('files')
    if not isinstance(files, dict) or len(files) != 8122:
        raise ValueError('Exact frozen 8122-file workspace inventory required')
    for name, value in files.items():
        p = Path(name)
        if (not isinstance(name, str) or p.is_absolute() or '..' in p.parts
                or p.as_posix() != name or not name
                or not isinstance(value, str) or not re.fullmatch(r'[0-9a-f]{64}', value)):
            raise ValueError('Invalid canonical source inventory row')
    return files


def require_source(source, expected):
    if snapshot(source) != expected:
        raise ValueError('Complete frozen source inventory changed')


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.writing')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def dependency_names(text):
    names = []
    for line in re.sub(r'\\\r?\n', ' ', text).splitlines():
        colon = re.search(r'(?<!\\):', line)
        if colon:
            names.extend(shlex.split(line[colon.end():]))
    return list(dict.fromkeys(names))


def assigned(tree, name):
    matches = [n.value for n in tree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    if len(matches) != 1:
        raise ValueError('Exactly one source declaration required: ' + name)
    return matches[0]


def inherited_declaration(source, name, constant, module, imported, prefix, suffix):
    tree = ast.parse((source / name).read_text())
    imports = [n for n in tree.body if isinstance(n, ast.ImportFrom) and n.module == module]
    value = assigned(tree, constant)
    if (len(imports) != 1 or [(n.name, n.asname) for n in imports[0].names] != [(imported, None)]
            or not isinstance(value, ast.List) or len(value.elts) != len(prefix) + len(suffix) + 1
            or [ast.literal_eval(n) for n in value.elts[:len(prefix)]] != prefix
            or not isinstance(value.elts[len(prefix)], ast.Starred)
            or ast.unparse(value.elts[len(prefix)].value) != imported + '[1:]'
            or [ast.literal_eval(n) for n in value.elts[len(prefix)+1:]] != suffix):
        raise ValueError('Exact AST declaration changed: ' + name)


def recipe_contract(source, expected, pins):
    recipe = source / 'tools/build_core_tests.py'
    pin(recipe, pins['canonical_recipe']['sha256'])
    tree = ast.parse(recipe.read_text())
    flags = [n.value for n in ast.walk(tree) if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == 'flags' for t in n.targets)]
    if len(flags) != 1 or not isinstance(flags[0], ast.List):
        raise ValueError('Single committed flags list required')
    if ([n.value for n in flags[0].elts if isinstance(n, ast.Constant)] != FLAGS[:-1]
            or [ast.unparse(n.value) for n in flags[0].elts if isinstance(n, ast.Starred)]
            != ['compiler_safety_flags(cc)']):
        raise ValueError('Functional native flag convention changed')
    diagnostic = source / 'tools/build_diagnostic.py'
    pin(diagnostic, expected['tools/build_diagnostic.py'])
    tree = ast.parse(diagnostic.read_text())
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'runtime_inputs')
    if ast.literal_eval(assigned(fn, 'names')) != RUNTIMES:
        raise ValueError('Committed runtime convention changed')
    tree = ast.parse((source / DECLARATIONS[0]).read_text())
    if ast.literal_eval(assigned(tree, 'SOURCES')) != SAMPLER_SOURCES:
        raise ValueError('Exact inherited sampler sources changed')
    inherited_declaration(source, DECLARATIONS[1], 'READERS_SOURCES', 'test_sampler',
                          'SOURCES', READERS_PREFIX, [])
    inherited_declaration(source, DECLARATIONS[2], 'BOUNDARY_SOURCES', 'test_sampler_paula_readers',
                          'READERS_SOURCES', ['tests/sampler_paula_readers_boundary_test.c'], RENDERER)
    inherited_declaration(source, DECLARATIONS[3], 'SONG_SOURCES', 'test_sampler_paula_readers_boundary',
                          'BOUNDARY_SOURCES', ['tests/paula_readers_song_test.c'], [])
    inherited_declaration(source, DECLARATIONS[4], 'WORKSPACE_SOURCES', 'test_paula_readers_song',
                          'SONG_SOURCES', [FIXTURE], [])
    if len(SOURCES) != 29 or len(set(SOURCES)) != 29:
        raise ValueError('29 unique ordered TUs required')
    fixture = source / FIXTURE
    pin(fixture, FIXTURE_SHA)
    if fixture.stat().st_size != FIXTURE_BYTES:
        raise ValueError('Sealed fixture size changed')
    text = fixture.read_text()
    footers = re.findall(r'^\s*puts\("([^"\n]*)"\);', text, re.MULTILINE)
    if footers != MARKERS or any(text.count(marker) != 1 for marker in MARKERS):
        raise ValueError('Three complete source footer markers required once')
    includes = re.findall(r'^\s*#\s*include\s+"([^"\n]+\.c)"', text, re.MULTILINE)
    if includes != ['sampler_paula_readers_test.c', '../src/editor/paula_readers_song.c']:
        raise ValueError('Workspace fixture exact direct C inclusion changed')
    if not re.search(r'^#define main [A-Za-z_][A-Za-z0-9_]*\n#include "sampler_paula_readers_test\.c"\n#undef main(?:\n|$)', text, re.MULTILINE):
        raise ValueError('Inherited readers main rename required')
    reader_text = (source / INCLUDE_CHAIN[1]).read_text()
    if re.findall(r'^\s*#\s*include\s+"([^"\n]+\.c)"', reader_text, re.MULTILINE) != ['../src/editor/sampler_paula_readers.c']:
        raise ValueError('Exact transitive adapter inclusion changed')
    if any(name in SOURCES for name in INCLUDE_CHAIN[1:]):
        raise ValueError('Included C sources must not be separately compiled')
    if 'pt_paula_readers_song_begin(&' not in text:
        raise ValueError('Do not omit the explicit large-stack legacy begin smoke')
    return {'flags': FLAGS, 'annotation_flags': ANNOTATION_FLAGS,
            'ordered_translation_units': SOURCES, 'include_chain': INCLUDE_CHAIN,
            'markers': MARKERS, 'inputs': [record(source / n) for n in
                ['tools/build_core_tests.py', 'tools/build_diagnostic.py', *DECLARATIONS, *INCLUDE_CHAIN]],
            'policy': 'Declarations read as AST data; no build/test modules imported or executed; fixture topology and -Os inlining retained'}


def functional_contract(builder, contract):
    """Read the actual frozen functional derivative strictly as data."""
    tree = ast.parse(builder.read_text())
    if ast.literal_eval(assigned(tree, 'FLAGS')) != FLAGS or ast.literal_eval(assigned(tree, 'RUNTIMES')) != RUNTIMES:
        raise ValueError('Functional flags/runtime declaration changed')
    expected = {'fixture': FIXTURE, 'host_declaration': DECLARATIONS[-1],
                'source_constant': 'WORKSPACE_SOURCES', 'target': 'PTPaulaReadersSongWorkspaceTest',
                'marker': MARKERS[-1], 'ordered_sources': SOURCES, 'include_chain': INCLUDE_CHAIN[:3]}
    if json.loads(contract.read_text()) != expected:
        raise ValueError('Exact frozen workspace functional contract changed')
    return {'builder': record(builder), 'fixture_contract': record(contract),
            'policy': 'Functional flags/29-TU contract read as AST/JSON only; its compiler/link body is never imported or executed'}


def parse_su(path):
    if not path.is_file() or path.is_symlink() or path.stat().st_size == 0:
        raise AnnotationUnsupported('Required expected .su absent/empty: ' + str(path))
    result = []
    for line in path.read_text().splitlines():
        fields = line.split('\t')
        if len(fields) != 3 or not fields[0] or not re.fullmatch(r'[0-9]+', fields[1]):
            raise AnnotationUnsupported('Unrecognized compiler .su row: ' + line)
        qualifiers = fields[2].split(',')
        if (len(set(qualifiers)) != len(qualifiers)
                or set(qualifiers) not in ({'static'}, {'dynamic'}, {'dynamic', 'bounded'})):
            raise AnnotationUnsupported('Unrecognized .su qualifiers: ' + fields[2])
        result.append({'compiler_location_and_function': fields[0],
                       'reported_bytes': int(fields[1]), 'qualifiers': qualifiers,
                       'numeric_local_bound': 'static' in qualifiers or 'bounded' in qualifiers})
    if not result:
        raise AnnotationUnsupported('No usable .su rows')
    return result


def main():
    sys.dont_write_bytecode = True
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--source-manifest', type=Path, required=True)
    ap.add_argument('--source-manifest-sha256', required=True)
    ap.add_argument('--stack-pins', type=Path, required=True)
    ap.add_argument('--stack-pins-sha256', required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    source, out = args.source.resolve(), args.out.resolve()
    controls = [args.source_manifest.resolve(), args.stack_pins.resolve()]
    if out.exists() or not source.is_dir() or below(out, source) or below(source, out):
        raise ValueError('Output must be fresh and outside existing source')
    if any(below(p, out) for p in controls) or below(Path(__file__).resolve(), out):
        raise ValueError('All controls/helper must be outside output')
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    commands, annotations, canonical, system, runtime_paths = [], [], {}, {}, {}
    expected, pins, stack_pins, input_rows = None, None, None, []
    result = {'scope': SCOPE, 'annotation_complete': False, 'stack_qualified': False,
        'total_030_stack': 'UNKNOWN', 'WCET': 'UNKNOWN', 'native_NOT_RUN': True,
        'link_performed': False, 'product_execution_performed': False,
        'source_export': str(source), 'commands': commands, 'translation_units': annotations,
        'unknown_edges': ['indirect allocator/Chip/backend callbacks', 'library/SDK/Exec and emitted compiler helpers',
                         'optimized/inlined/tail/recursive complete call chains', 'full fixture main and legacy compatibility begin chain',
                         'launcher/ABI/OS/interrupt reserve'],
        'assessment': 'Per-function compiler frames and raw object call/relocation evidence only; no call-chain summation or native Stack clearance'}

    def persist():
        result['elapsed_s'] = time.monotonic() - started
        result['canonical_dependencies'] = dict(sorted(canonical.items()))
        result['system_dependencies'] = dict(sorted(system.items()))
        result['runtime_paths'] = runtime_paths
        write_json(out / 'manifest.json', result)

    def current_pins():
        for row in input_rows:
            pin(row['path'], row['sha256'])
        for name, path in runtime_paths.items():
            pin(path, pins['native']['runtime_inputs'][name])
        for path, value in system.items():
            pin(path, value)
        for relative, value in canonical.items():
            pin(source / relative, value)

    def run(argv, label):
        current_pins()
        row = {'label': label, 'argv': argv, 'directory': str(source), 'started_monotonic': time.monotonic()}
        commands.append(row)
        persist()
        stdout, stderr = out / (label + '.stdout'), out / (label + '.stderr')
        try:
            process = subprocess.run(argv, cwd=source, capture_output=True, timeout=180)
        except subprocess.TimeoutExpired as error:
            stdout.write_bytes(error.stdout or b''); stderr.write_bytes(error.stderr or b'')
            row.update(timed_out=True, returncode=None, elapsed_s=time.monotonic()-row['started_monotonic'],
                       stdout=record(stdout), stderr=record(stderr))
            persist()
            raise
        stdout.write_bytes(process.stdout); stderr.write_bytes(process.stderr)
        row.update(returncode=process.returncode, elapsed_s=time.monotonic()-row['started_monotonic'],
                   stdout=record(stdout), stderr=record(stderr))
        persist()
        if process.returncode:
            raise subprocess.CalledProcessError(process.returncode, argv, process.stdout, process.stderr)
        return process.stdout.decode('utf-8', errors='strict')

    try:
        result['helper'] = record(Path(__file__).resolve())
        input_rows.append(result['helper'])
        pin(controls[0], args.source_manifest_sha256)
        pin(controls[1], args.stack_pins_sha256)
        complete, stack_pins = [json.loads(p.read_text()) for p in controls]
        expected = checked_files(complete)
        result['source_manifest'], result['stack_pins'] = [record(p) for p in controls]
        input_rows.extend([result['source_manifest'], result['stack_pins']])
        require_source(source, expected)
        result['source_files_before'] = len(expected)
        result['source_inventory_fingerprint'] = sha_bytes(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode())
        result['base_commit'], result['base_tree'] = complete['base_commit'], complete['base_tree']
        preparation = Path(__file__).resolve().parent
        design_path = preparation / 'stack-audit-design-v1.json'
        origin_path = preparation / 'origin-copies/build_song_readers_faults_portability_v2.py'
        origin_pins = preparation / 'origin-copies/toolchain-pins.json'
        workspace_builder = preparation / 'origin-copies/build_song_readers_workspace_portability.py'
        workspace_contract = preparation / 'origin-copies/PTPaulaReadersSongWorkspaceTest-contract-v1.json'
        pin(design_path, DESIGN_SHA); pin(origin_path, ORIGIN_SHA); pin(origin_pins, ORIGIN_PINS_SHA)
        pin(workspace_builder, WORKSPACE_BUILDER_SHA); pin(workspace_contract, WORKSPACE_CONTRACT_SHA)
        result['design'], result['functional_builder_origin'], result['original_pins'] = [record(p) for p in [design_path, origin_path, origin_pins]]
        input_rows.extend([result['design'], result['functional_builder_origin'], result['original_pins']])
        result['current_functional_contract'] = functional_contract(workspace_builder, workspace_contract)
        input_rows.extend([record(workspace_builder), record(workspace_contract)])
        pins = json.loads(origin_pins.read_text())
        if stack_pins['original_pins_sha256'] != ORIGIN_PINS_SHA:
            raise ValueError('Wrong inherited native toolchain control identity')
        tools = stack_pins['tools']
        if set(tools) != {'compiler', 'cc1', 'assembler', 'assembler_alternate', 'objdump', 'nm', 'python'}:
            raise ValueError('Exact seven annotation tool pins required')
        if tools['compiler'] != pins['native']['compiler'] or tools['python'] != pins['host']['python']:
            raise ValueError('Inherited compiler/Python pins changed')
        if (Path(sys.executable).resolve() != Path(tools['python']['path']).resolve()
                or sys.version != tools['python']['version']):
            raise ValueError('Pinned Python executable/version required')
        for row in tools.values():
            pin(row['path'], row['sha256']); input_rows.append(row)
        compiler = tools['compiler']['path']
        if set(pins['native']['runtime_inputs']) != set(RUNTIMES):
            raise ValueError('Exactly seven native runtime pins required')
        roots = [Path(p).resolve() for p in pins['native']['allowed_sdk_roots']]
        if not roots:
            raise ValueError('Explicit SDK roots required')
        result['tool_pins'] = tools
        result['recipe_contract'] = recipe_contract(source, expected, pins)
        persist()
        if run([compiler, '--version'], 'compiler-version').splitlines()[0] != tools['compiler']['version']:
            raise ValueError('Compiler version changed')
        if '-fbbb=' not in run([compiler, '--help=target'], 'compiler-target-help'):
            raise ValueError('Required functional safety flag unavailable')
        for selected in ['cc1', 'as']:
            value = run([compiler, '-print-prog-name=' + selected], 'selected-' + selected).strip()
            path = Path(value)
            allowed = [tools['cc1']] if selected == 'cc1' else [tools['assembler'], tools['assembler_alternate']]
            if not path.is_absolute() or path.resolve() not in [Path(t['path']).resolve() for t in allowed]:
                raise ValueError('Unexpected selected compiler tool: ' + value)
            selected_row = next(t for t in allowed if Path(t['path']).resolve() == path.resolve())
            pin(path, selected_row['sha256'])
            result['selected_' + selected] = record(path)
        for name in ['assembler', 'objdump', 'nm']:
            run([tools[name]['path'], '--version'], name + '-version')
        for name in RUNTIMES:
            value = run([compiler, '-m68000', '-msoft-float', '-mcrt=nix20', '-print-file-name=' + name],
                        'runtime-' + name.replace('.', '-')).strip()
            if not Path(value).is_absolute():
                raise ValueError('Runtime must resolve to explicit absolute path: ' + value)
            path = Path(value).resolve()
            pin(path, pins['native']['runtime_inputs'][name]); runtime_paths[name] = str(path)
        for index, unit in enumerate(SOURCES):
            raw = run([compiler, *FLAGS, '-M', unit], 'dependencies-%02d' % index)
            names = dependency_names(raw)
            if not names:
                raise ValueError('Empty full-M dependency result')
            for name in names:
                path = (source / name).resolve()
                if below(path, source):
                    key = path.relative_to(source).as_posix()
                    if key not in expected:
                        raise ValueError('Unknown canonical dependency: ' + key)
                    pin(path, expected[key]); canonical[key] = expected[key]
                elif any(below(path, root) for root in roots):
                    system[str(path)] = digest(path)
                else:
                    raise ValueError('Dependency outside frozen source/SDK: ' + str(path))
        text = run([compiler, *FLAGS, '-E', '-dD', FIXTURE], 'preprocessed-fixture')
        macros = re.findall(r'^#define assert\([^\n]*', text, re.MULTILINE)
        assertion = macros[-1] if macros else None
        if not assertion or '__assert_func' not in assertion or text.count('__assert_func (') < 2:
            raise ValueError('Enabled default SDK assertions required')
        if any(text.count(marker) != 1 for marker in MARKERS):
            raise ValueError('All full fixture markers required once in preprocessing')
        result['last_assert_macro'] = assertion
        require_source(source, expected)
        for index, unit in enumerate(SOURCES):
            row = {'index': index, 'source': unit, 'annotations': []}
            annotations.append(row); persist()
            stem = 'tu%02d' % index
            obj, su = out / (stem + '.o'), out / (stem + '.su')
            run([compiler, *FLAGS, *ANNOTATION_FLAGS, unit, '-o', str(obj)], stem + '-annotation')
            if not obj.is_file() or obj.is_symlink() or not obj.stat().st_size:
                raise AnnotationUnsupported('Compiler produced no ordinary object: ' + str(obj))
            row['object'] = record(obj)
            row['annotations'] = parse_su(su); row['stack_usage'] = record(su)
            persist()
            disassembly = run([tools['objdump']['path'], '-dr', str(obj)], stem + '-objdump')
            if 'file format' not in disassembly or 'Disassembly of section' not in disassembly:
                raise AnnotationUnsupported('No decoded object disassembly for ' + str(obj))
            symbols = run([tools['nm']['path'], '-an', str(obj)], stem + '-nm')
            if not symbols.strip():
                raise AnnotationUnsupported('Empty object symbol table for ' + str(obj))
            row['disassembly'] = record(out / (stem + '-objdump.stdout'))
            row['symbols'] = record(out / (stem + '-nm.stdout'))
            row['raw_call_or_relocation_lines'] = [line for line in disassembly.splitlines()
                if re.search(r'\b(?:jsr|bsr|jmp)\b|\bR_[A-Z0-9_]+\b', line)]
            row['call_edge_assessment'] = 'Raw optimized object evidence; direct/tail/inline/indirect resolution and ABI stack reconciliation NOT performed'
            persist()
        result['annotation_complete'] = True
        result['function_rows'] = sum(len(row['annotations']) for row in annotations)
        result['dynamic_unbounded_rows'] = [item for row in annotations for item in row['annotations'] if not item['numeric_local_bound']]
    except Exception as error:
        result['first_diagnostic'] = {'kind': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(),
            'policy': 'Stopped first failure; no retry, altered flags, link or assembly-only fallback'}
        result['annotation_capability'] = 'UNSUPPORTED/UNKNOWN' if isinstance(error, (AnnotationUnsupported, subprocess.CalledProcessError)) else 'FAILED/UNKNOWN'
    finally:
        result['retained_output_files'] = [record(p) for p in sorted(out.iterdir()) if p.is_file() and p.name != 'manifest.json']
        try:
            current_pins()
            if expected is not None:
                require_source(source, expected)
                result['source_files_after'] = len(expected)
                result['source_after_matches_before'] = True
        except Exception as error:
            result['annotation_complete'] = False
            result['final_provenance_error'] = {'kind': type(error).__name__, 'message': str(error)}
        persist()
    print(json.dumps({'annotation_complete': result['annotation_complete'], 'stack_qualified': False,
                      'native_NOT_RUN': True, 'manifest': str(out / 'manifest.json')}))
    return 0 if result['annotation_complete'] else 1


if __name__ == '__main__':
    sys.exit(main())
