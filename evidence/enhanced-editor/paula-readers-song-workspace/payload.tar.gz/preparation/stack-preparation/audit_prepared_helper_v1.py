"""Read-only AST/data audit of unexecuted preparation; never imports the helper."""
from pathlib import Path
import ast
import hashlib
import json
import difflib
ROOT = Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/song-workspace-1nyr8qlf')
D = ROOT / 'stack-preparation'
P = D / 'annotate_workspace_stack.py'
NAMES = {}
def value(node):
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.Name): return NAMES[node.id]
    if isinstance(node, ast.List):
        result = []
        for item in node.elts:
            if isinstance(item, ast.Starred): result.extend(value(item.value))
            else: result.append(value(item))
        return result
    if isinstance(node, ast.Subscript) and isinstance(node.slice, ast.Slice):
        s = node.slice
        return value(node.value)[value(s.lower) if s.lower else None:value(s.upper) if s.upper else None:value(s.step) if s.step else None]
    raise ValueError(ast.dump(node))
def record(p):
    return {'path':str(p), 'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777,
            'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
tree = ast.parse(P.read_text())
for node in tree.body:
    if isinstance(node, ast.Assign):
        try: computed = value(node.value)
        except (ValueError, KeyError): continue
        for target in node.targets:
            if isinstance(target, ast.Name): NAMES[target.id] = computed
manifest_path = ROOT / 'frozen-source-native-v2.json'
manifest = json.loads(manifest_path.read_text())
source = ROOT / 'candidate-v2'
contract_path = D / 'origin-copies/PTPaulaReadersSongWorkspaceTest-contract-v1.json'
contract = json.loads(contract_path.read_text())
assert len(NAMES['SOURCES']) == 29 and len(set(NAMES['SOURCES'])) == 29
assert NAMES['SOURCES'] == contract['ordered_sources']
assert NAMES['FLAGS'] == json.loads((D/'stack-audit-design-v1.json').read_text())['full_production_flags']
assert NAMES['ANNOTATION_FLAGS'] == ['-fstack-usage', '-c']
assert len(manifest['files']) == 8122
assert manifest['files'][NAMES['FIXTURE']] == NAMES['FIXTURE_SHA']
assert (source/NAMES['FIXTURE']).stat().st_size == NAMES['FIXTURE_BYTES']
assert (source/NAMES['FIXTURE']).read_text().count('pt_paula_readers_song_begin(&') >= 1
for name in NAMES['SOURCES'] + NAMES['DECLARATIONS'] + NAMES['INCLUDE_CHAIN']:
    assert record(source/name)['sha256'] == manifest['files'][name]
invocations = [n for n in ast.walk(tree) if isinstance(n, ast.Call)
    and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
    and n.func.value.id == 'subprocess' and n.func.attr in ('run','Popen','call','check_call','check_output')]
assert len(invocations) == 1 and invocations[0].func.attr == 'run'
compile_calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)
    and isinstance(n.func, ast.Name) and n.func.id == 'run' and n.args
    and isinstance(n.args[0], ast.List) and any(isinstance(v, ast.Starred)
    and isinstance(v.value, ast.Name) and v.value.id == 'ANNOTATION_FLAGS' for v in n.args[0].elts)]
assert len(compile_calls) == 1
assert any(isinstance(x,ast.Constant) and x.value=='-o' for x in compile_calls[0].args[0].elts)
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('exec','eval','compile','__import__') for n in ast.walk(tree))
for node in tree.body:
    if isinstance(node,ast.ImportFrom): assert node.module not in ('build_song_readers_workspace_portability','test_paula_readers_song_workspace','test_paula_readers_song')
assert "'stack_qualified': False" in P.read_text()
review = {
 'status':'SOURCE-ONLY SELF REVIEW CLEAR; ANNOTATION HELPER UNEXECUTED',
 'helper':record(P),'source_manifest':record(manifest_path),'source_export':str(source),
 'source_files':8122,'fixture':record(source/NAMES['FIXTURE']),
 'ordered_translation_units':NAMES['SOURCES'],'flags':NAMES['FLAGS'],'annotation_flags':NAMES['ANNOTATION_FLAGS'],
 'checks':[
 'Python AST parsed as data, no helper import/execution',
 '29 unique ordered TUs match actual workspace functional contract; current fixture/declarations/include-chain hashes match root frozen inventory',
 'Functional -Os/m68000/msoft-float/nix20/fbbb flags preserved; only -fstack-usage -c added, no link/product command',
 'Pins for helper/controls/tools/runtimes/canonical/system inputs rechecked before every tool call; full source snapshot before/after',
 'Fresh output outside source; explicit expected source-manifest SHA; old/current builder origin copies strictly data',
 'Expected nonempty .su with recognized qualifiers per actual object required; first refusal retains objects/reports/stdout/stderr/diagnostic, no retry/fallback',
 'Default SDK assert expansion and three complete footer markers gated during preprocessing; legacy large-stack smoke retained',
 'Object/.su/disassembly/nm bytes/modes saved; no source-call-graph summation or hardware total inferred'],
 'not_run':['compiler/version/runtime/tool queries','full-M/preprocess/object annotation','objdump/nm','link/product/native target'],
 'limits':[
 'Target compiler .su support and HUNK object decoding not yet evaluated',
 'Opaque callbacks/libraries/recursive/optimized/inlined/tail/ABI/launcher and full main/compatibility call-chain frames remain UNKNOWN',
 'Per-function annotation is not total030 stack adequacy, IRQ reserve, WCET or Fast/Chip placement'],
 'history':[
 {'record':record(D/'history-unexecuted-initial-fixture/annotate_workspace_stack.py'),'role':'Initial unexecuted preparation pinned earlier pre-correction fixture, no attempt'},
 {'record':record(D/'preparation-self-check-refusal-v1.json'),'role':'Own source-only AST reader counted exception constructor as invocation, corrected reader predicate; helper unchanged'}],
 'audit_script':record(Path(__file__).resolve())}
(D/'source-only-self-review-v1.json').write_text(json.dumps(review,indent=2)+'\n')
origin=(D/'origin-copies/build_song_readers_faults_portability_v2.py').read_text()
(D/'helper-origin-diff-v1.patch').write_text(''.join(difflib.unified_diff(origin.splitlines(True),P.read_text().splitlines(True),fromfile='original-functional-compile-link-builder.py',tofile='separate-compiler-only-stack-helper.py')))
print(json.dumps({'helper':record(P),'review':record(D/'source-only-self-review-v1.json'),'audit':record(Path(__file__).resolve())}))
