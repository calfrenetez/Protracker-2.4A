"""Import only four approved sealed drafts into the exact clean base export.

This operation never imports a test, compiles a product or mutates the checkout.
"""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
OWNED = ['src/editor/paula_readers_song.c', 'src/editor/paula_readers_song.h',
         'tests/paula_readers_song_test.c', 'tests/test_paula_readers_song.py']

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def inventory(root):
    entries = {}
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file():
            entries[p.relative_to(root).as_posix()] = digest(p)
    return entries

def main():
    assert __debug__ and not (ROOT / 'frozen-source-host-v1.json').exists()
    baseline = json.loads((ROOT / 'baseline-manifest.json').read_bytes())
    before = json.loads((ROOT / 'before-state.json').read_bytes())
    approved = json.loads((ROOT / 'approved-drafts-v1.json').read_bytes())
    assert approved['scope'] == 'root approved exact four draft inputs for first host-only checks'
    assert list(approved['files']) == OWNED
    candidate = ROOT / 'candidate'
    base_hashes = {n: v if isinstance(v, str) else v['sha256'] for n, v in baseline['files'].items()}
    assert inventory(candidate) == base_hashes
    assert len(baseline['files']) == 8111
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=REPO, check=True,
                          capture_output=True, text=True).stdout.strip()
    assert head == before['head'] == baseline['base_commit']
    index = subprocess.run(['git', 'diff', '--cached', '--name-only'], cwd=REPO,
                           check=True, capture_output=True).stdout
    assert not index
    for f in before['preserved_files']:
        path = REPO / f['path']
        assert path.stat().st_size == f['bytes'] and digest(path) == f['sha256']
    for relative in OWNED:
        f = approved['files'][relative]
        source = Path(f['path'])
        assert source.is_file() and not source.is_symlink()
        assert source.stat().st_size == f['bytes'] and digest(source) == f['sha256']
        destination = candidate / relative
        assert not destination.exists() and relative not in baseline['files']
        shutil.copyfile(source, destination)
        assert digest(destination) == f['sha256']
        destination.chmod(0o444)
    actual = inventory(candidate)
    assert len(actual) == 8115
    assert all(actual[n] == h for n, h in base_hashes.items())
    assert set(actual) - set(baseline['files']) == set(OWNED)
    common = {'scope': 'Frozen clean base plus four owned song producer/fixture files; no execution',
              'base_commit': baseline['base_commit'], 'base_tree': baseline['base_tree'],
              'owned': OWNED, 'protected16_exact': True}
    for lane, key in [('host', 'source'), ('native', 'files')]:
        path = ROOT / ('frozen-source-' + lane + '-v1.json')
        assert not path.exists()
        path.write_text(json.dumps({**common, key: actual}, indent=2) + '\n')
        path.chmod(0o444)
    (ROOT / 'candidate-freeze-v1.json').write_text(json.dumps({**common,
        'source_files': len(actual), 'baseline_files': len(baseline['files']),
        'approved_drafts_sha256': digest(ROOT / 'approved-drafts-v1.json'),
        'host_manifest_sha256': digest(ROOT / 'frozen-source-host-v1.json'),
        'native_manifest_sha256': digest(ROOT / 'frozen-source-native-v1.json'),
        'maps_equal': True}, indent=2) + '\n')
    print(json.dumps({'passed': True, 'source_files': len(actual),
                      'baseline_exact': True, 'protected16_exact': True,
                      'native': 'NOT_RUN', 'physical': 'NOT_RUN'}))

if __name__ == '__main__':
    main()
