"""Freeze the separately approved correction/fault expansion, preserving v1."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
OWNED = ['src/editor/paula_readers_song.c', 'src/editor/paula_readers_song.h',
         'tests/paula_readers_song_test.c', 'tests/test_paula_readers_song.py']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def inventory(root):
    result = {}
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():
            result[p.relative_to(root).as_posix()] = sha(p)
    return result

def main():
    assert __debug__
    source, candidate = ROOT / 'candidate', ROOT / 'candidate-v2'
    assert not candidate.exists()
    baseline = json.loads((ROOT / 'baseline-manifest.json').read_bytes())
    before = json.loads((ROOT / 'before-state.json').read_bytes())
    prior = json.loads((ROOT / 'frozen-source-host-v1.json').read_bytes())
    approved = json.loads((ROOT / 'approved-drafts-v2.json').read_bytes())
    assert approved['scope'] == 'root approved exact four revised inputs for corrected host-only checks'
    assert list(approved['files']) == OWNED
    assert inventory(source) == prior['source'] and len(prior['source']) == 8115
    assert subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=REPO, check=True,
                          capture_output=True, text=True).stdout.strip() == before['head'] == baseline['base_commit']
    assert not subprocess.run(['git', 'diff', '--cached', '--name-only'], cwd=REPO,
                              check=True, capture_output=True).stdout
    for f in before['preserved_files']:
        assert sha(REPO / f['path']) == f['sha256']
        assert (REPO / f['path']).stat().st_size == f['bytes']
    shutil.copytree(source, candidate)
    for relative, f in approved['files'].items():
        path = Path(f['path'])
        assert not path.is_symlink() and sha(path) == f['sha256'] and path.stat().st_size == f['bytes']
        destination = candidate / relative
        destination.unlink()
        shutil.copyfile(path, destination)
        destination.chmod(0o444)
    actual = inventory(candidate)
    assert len(actual) == 8115 and set(actual) == set(prior['source'])
    delta = sorted(n for n, h in actual.items() if prior['source'][n] != h)
    assert set(delta) == set(OWNED[:3])
    for n, f in baseline['files'].items():
        assert actual[n] == (f if isinstance(f, str) else f['sha256'])
    assert inventory(source) == prior['source']
    common = {'scope': 'Frozen correction/focused fault expansion; prior failed v1 retained',
              'base_commit': baseline['base_commit'], 'base_tree': baseline['base_tree'],
              'owned': OWNED, 'delta_from_failed_v1': delta, 'protected16_exact': True}
    for lane, key in [('host', 'source'), ('native', 'files')]:
        path = ROOT / ('frozen-source-' + lane + '-v2.json')
        assert not path.exists()
        path.write_text(json.dumps({**common, key: actual}, indent=2) + '\n')
        path.chmod(0o444)
    (ROOT / 'candidate-freeze-v2.json').write_text(json.dumps({**common,
        'source_files': len(actual), 'prior_v1_exact': True,
        'host_manifest_sha256': sha(ROOT / 'frozen-source-host-v2.json'),
        'native_manifest_sha256': sha(ROOT / 'frozen-source-native-v2.json'),
        'maps_equal': True}, indent=2) + '\n')
    print(json.dumps({'passed': True, 'source_files': len(actual),
                      'delta': delta, 'prior_v1_exact': True, 'protected16_exact': True}))

if __name__ == '__main__':
    main()
