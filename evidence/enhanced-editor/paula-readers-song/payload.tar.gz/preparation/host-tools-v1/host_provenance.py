#!/usr/bin/env python3
"""Run the genuine song producer and two affected boundary/startup sanitizer groups against a frozen export.
Does not mutate a checkout or run any native/target/device operation.
"""
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from provenance_common import (arguments, assert_pinned, below, classify, cpp_arguments,
                               compiler_input_arguments, digest, file_record, parse_dependencies, require_snapshot,
                               setup, write_json)

MODULES = ['test_paula_readers_song', 'test_sampler_paula_readers_boundary', 'test_paula_preflight_startup']

def main():
    sys.dont_write_bytecode = True
    args = arguments(__doc__)
    expected, all_pins, record = setup(args, 'Host ASan/UBSan only; no cross-build/native/target/physical/timing/listening acceptance')
    pins = all_pins['host']
    real_run = subprocess.run
    record.update({'modules': MODULES, 'groups': [], 'canonical_dependencies': {},
                   'external_sdk_dependencies': {}, 'generated_inputs': [], 'products': [],
                   'helper_inputs': [file_record(Path(__file__)), file_record(Path(__file__).with_name('provenance_common.py'))]})
    record['module_inputs'] = [file_record(args.source / name) for name in
        tuple('tests/'+name+'.py' for name in MODULES)]
    for entry in [pins['compiler'], pins['python']]:
        assert_pinned(entry['path'], entry['sha256'])
    if Path(sys.executable).resolve() != Path(pins['python']['path']).resolve() or sys.version != pins['python']['version']:
        raise ValueError('Python executable/version does not match supplied pins')
    pinned_files = {**pins['runtime_inputs'], **pins['sdk_inputs']}
    def verify_toolchain():
        assert_pinned(pins['compiler']['path'], pins['compiler']['sha256'])
        for name, sha in pinned_files.items():
            assert_pinned(name, sha)
    verify_toolchain()
    version = real_run([pins['compiler']['path'], '--version'], capture_output=True, text=True, check=True)
    resource = real_run([pins['compiler']['path'], '-print-resource-dir'], capture_output=True, text=True, check=True)
    if version.stdout != pins['compiler']['version'] or resource.stdout.strip() != pins['compiler']['resource_dir']:
        raise ValueError('Host compiler version/resource directory changed')
    record.update({'compiler': pins['compiler'], 'python': pins['python'],
                   'sanitizer_runtime_inputs': pins['runtime_inputs'], 'pinned_sdk_inputs': pins['sdk_inputs']})
    generated_roots, archived, products = {}, {}, {}
    temporary_roots = [Path(tempfile.gettempdir()).resolve(), Path('/private/tmp')]
    group = ''
    ordinal = 0
    result_path = args.out / 'host-checks.json'
    log_path = args.out / 'host-checks.log'
    started = time.monotonic()

    def persist():
        record['elapsed_s'] = time.monotonic() - started
        write_json(result_path, record)

    def archive(path, kind, command_id):
        path = Path(path).resolve()
        sha = digest(path)
        key = (str(path), sha, kind)
        if key not in archived:
            name = '%s-%s-%s-%s' % (command_id, kind, sha[:16], path.name)
            destination = args.out / ('products' if kind == 'executable' else 'generated') / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            if digest(destination) != sha or destination.stat().st_size != path.stat().st_size:
                raise ValueError('Archive copy failed verification: ' + str(path))
            entry = {'original_path': str(path), 'archive_path': str(destination), 'sha256': sha,
                     'bytes': path.stat().st_size, 'kind': kind, 'first_command': command_id, 'group': group}
            archived[key] = entry
            record['products' if kind == 'executable' else 'generated_inputs'].append(entry)
        return archived[key]

    def discover_generated(argv, directory):
        for argument in compiler_input_arguments(argv):
            if argument.endswith(('.c', '.o')):
                path = (Path(directory) / argument).resolve()
                if not below(path, args.source):
                    if not any(below(path, root) for root in temporary_roots) or not path.is_file():
                        raise ValueError('Unexpected generated input location: ' + str(path))
                    generated_roots[str(path)] = str(path.parent)

    with log_path.open('w') as log:
        def logged_run(argv, **kwargs):
            nonlocal ordinal
            if isinstance(argv, str) or kwargs.get('shell'):
                raise ValueError('Unstructured/shell test command refused')
            original = [str(value) for value in argv]
            directory = Path(kwargs.get('cwd', Path.cwd())).resolve()
            ordinal += 1
            command_id = 'c%03d' % ordinal
            command = {'id': command_id, 'group': group, 'argv': original, 'directory': str(directory),
                       'canonical_inputs': [], 'generated_inputs': [], 'dependencies': {'canonical': {}, 'external_sdk': {}, 'generated': {}},
                       'dependency_commands': [], 'stage': 'pre-command-provenance'}
            record['commands'].append(command)
            persist()
            check = kwargs.pop('check', False)
            kwargs.pop('stdout', None)
            kwargs.pop('stderr', None)
            kwargs.pop('capture_output', None)
            kwargs.pop('text', None)
            kwargs.setdefault('timeout', 180)
            try:
                resolved = shutil.which(original[0]) if not Path(original[0]).is_absolute() else original[0]
                is_compiler = resolved and Path(resolved).resolve() == Path(pins['compiler']['path']).resolve()
                executed = original[:]
                if is_compiler:
                    verify_toolchain()
                    executed[0] = pins['compiler']['path']
                    if '-fsanitize=address,undefined' not in original:
                        raise ValueError('Authorized host compiler command lacks both sanitizers')
                    discover_generated(original, directory)
                    options, units = cpp_arguments(original)
                    for argument in compiler_input_arguments(original):
                        if not argument.endswith(('.c', '.o')):
                            continue
                        path = (directory / argument).resolve()
                        category, name = classify(path, args.source, expected, pins['allowed_sdk_roots'], generated_roots)
                        if category == 'canonical':
                            command['canonical_inputs'].append({'path': name, 'sha256': digest(path)})
                        elif category == 'generated':
                            command['generated_inputs'].append(archive(path, 'object' if path.suffix == '.o' else 'source', command_id))
                        else:
                            raise ValueError('Translation unit/object unexpectedly from SDK: ' + str(path))
                    for unit_index, unit in enumerate(units):
                        dep_argv = [pins['compiler']['path'], *options, '-M', unit]
                        dep_result = real_run(dep_argv, cwd=directory, capture_output=True, text=True, check=True, timeout=180)
                        dep_log = args.out / ('%s-dependencies-%02d.txt' % (command_id, unit_index))
                        dep_log.write_text(dep_result.stdout + dep_result.stderr)
                        command['dependency_commands'].append({'argv': dep_argv, 'directory': str(directory), 'returncode': dep_result.returncode,
                                                               'output': file_record(dep_log), 'unit': unit})
                        for dependency in parse_dependencies(dep_result.stdout):
                            path = (directory / dependency).resolve()
                            category, name = classify(path, args.source, expected, pins['allowed_sdk_roots'], generated_roots)
                            sha = digest(path)
                            command['dependencies'][category][name] = sha
                            if category == 'canonical':
                                record['canonical_dependencies'][name] = sha
                            elif category == 'external_sdk':
                                record['external_sdk_dependencies'][name] = sha
                            else:
                                archive(path, 'dependency', command_id)
                else:
                    if len(original) not in (1,2) or str(Path(original[0]).resolve()) not in products:
                        raise ValueError('Unexpected host test subprocess: ' + repr(original))
                    binary = Path(original[0]).resolve()
                    if digest(binary) != products[str(binary)]['sha256']:
                        raise ValueError('Compiled test binary changed before runtime')
                    command['input_binary'] = products[str(binary)]
                    if len(original) == 2:
                        output_argument = Path(original[1]).resolve()
                        if not any(below(output_argument, root) for root in temporary_roots) or below(output_argument, args.source):
                            raise ValueError('Fixture output argument outside private temporary storage')
                        command['fixture_output_argument'] = str(output_argument)
                command['executed_argv'] = executed
                command['stage'] = 'product-execution'
                command_start = time.monotonic()
                result = real_run(executed, **kwargs, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                command['seconds'] = time.monotonic() - command_start
                command['product_returncode'] = result.returncode
                output = args.out / ('%s-product.log' % command_id)
                output.write_text(result.stdout + result.stderr)
                command['output_log'] = file_record(output)
                log.write(result.stdout + result.stderr)
                log.flush()
                command['stage'] = 'post-command-provenance'
                if is_compiler and result.returncode == 0:
                    destination = (directory / original[original.index('-o') + 1]).resolve()
                    if destination.suffix == '.o':
                        generated_roots[str(destination)] = str(destination.parent)
                        command['produced_object'] = archive(destination, 'object', command_id)
                    else:
                        product = archive(destination, 'executable', command_id)
                        products[str(destination)] = product
                        command['produced_binary'] = product
                if not is_compiler and result.returncode == 0 and len(original) == 2 and Path(original[1]).is_file():
                    command['produced_fixture'] = archive(Path(original[1]), 'fixture_output', command_id)
                command['stage'] = 'complete'
                persist()
                if check and result.returncode:
                    raise subprocess.CalledProcessError(result.returncode, executed, result.stdout, result.stderr)
                return result
            except Exception as failure:
                command['error'] = {'kind': type(failure).__name__, 'message': str(failure), 'stage': command['stage']}
                persist()
                raise

        try:
            os.chdir(args.source)
            sys.path.insert(0, str(args.source / 'tests'))
            subprocess.run = logged_run
            all_success = True
            for name in MODULES:
                group = name
                group_start = time.monotonic()
                module = importlib.import_module(name)
                suite = unittest.defaultTestLoader.loadTestsFromModule(module)
                result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
                record['groups'].append({'module': name, 'tests': result.testsRun, 'passed': result.wasSuccessful(),
                                         'failures': len(result.failures), 'errors': len(result.errors),
                                         'seconds': time.monotonic() - group_start})
                all_success &= result.wasSuccessful()
                persist()
                if not result.wasSuccessful():
                    break
            record['passed'] = all_success and len(record['groups']) == len(MODULES)
        except Exception as failure:
            record['harness_error'] = {'kind': type(failure).__name__, 'message': str(failure), 'traceback': traceback.format_exc()}
            record['passed'] = False
        finally:
            subprocess.run = real_run
            try:
                verify_toolchain()
                for name, sha in record['external_sdk_dependencies'].items():
                    assert_pinned(name, sha)
                record['source_files_after'] = len(require_snapshot(args.source, expected))
                assert_pinned(args.source_manifest, args.source_manifest_sha256)
                assert_pinned(args.pins, args.pins_sha256)
                for entry in record['helper_inputs']:
                    assert_pinned(entry['path'], entry['sha256'])
            except Exception as failure:
                record['final_provenance_error'] = {'kind': type(failure).__name__, 'message': str(failure)}
                record['passed'] = False
            log.flush()
            record['log'] = file_record(log_path)
            persist()
    print(json.dumps({'passed': record['passed'], 'groups': record['groups'], 'commands': len(record['commands']),
                      'generated_inputs': len(record['generated_inputs']), 'report': str(result_path)}))
    return 0 if record['passed'] else 1

if __name__ == '__main__':
    sys.exit(main())
