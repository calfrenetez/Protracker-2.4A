"""Package exact saved proof/source bytes; no compiler, test or target operation."""
import ast,gzip,hashlib,io,json,tarfile
from pathlib import Path
assert __debug__
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'candidate-v5';OUT=ROOT/'package'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 for n in ['root-host-audit-final-v5.json','root-native-audit-final-v5.json']:assert json.loads((ROOT/n).read_bytes())['passed']
 assert not OUT.exists();OUT.mkdir();members={};inputs=set()
 def put(n,p):
  assert n not in members and not Path(n).is_absolute() and '..' not in Path(n).parts
  p=Path(p);assert p.is_file() and not p.is_symlink();members[n]=p.read_bytes()
 def tree(prefix,p):
  assert p.is_dir()
  for f in sorted(p.rglob('*')):
   assert not f.is_symlink()
   if f.is_file():put(prefix+'/'+f.relative_to(p).as_posix(),f)
 failed=['host-initial-failed-v1','host-corrected-failed-v2','host-fixture-failed-v3','host-terminal-fixture-failed-v4']
 for i,lane in enumerate(failed,1):
  tree('proof/host-failed-v%d'%i,ROOT/lane)
  report=json.loads((ROOT/lane/'host-checks.json').read_bytes());assert not report['passed']
 for lane in ['host-final-v5','native-final-v5']:
  tree('proof/'+lane,ROOT/lane)
  report=json.loads((ROOT/lane/('host-checks.json' if lane.startswith('host') else 'manifest.json')).read_bytes());assert report['passed']
  if lane.startswith('native'):
   assert report['native_NOT_RUN']
   for t in report['targets'].values():inputs.update(t['dependencies'])
  else:inputs.update(report['canonical_dependencies'])
 frozen=json.loads((ROOT/'frozen-source-host-v5.json').read_bytes());inputs.update(frozen['owned'])
 todo=['tests/'+n+'.py' for n in json.loads((ROOT/'host-final-v5/host-checks.json').read_bytes())['modules']];imports=set(todo)
 while todo:
  n=todo.pop()
  for node in ast.walk(ast.parse((SOURCE/n).read_text())):
   if isinstance(node,ast.ImportFrom) and node.module and node.module.startswith('test_'):
    other='tests/'+node.module+'.py'
    if other not in imports:assert (SOURCE/other).is_file();imports.add(other);todo.append(other)
 inputs.update(imports);inputs.update(['tools/build_core_tests.py','tools/build_diagnostic.py'])
 for n in sorted(inputs):assert sha((SOURCE/n).read_bytes())==frozen['source'][n];put('source/'+n,SOURCE/n)
 for v,folder in [(1,'candidate'),(2,'candidate-v2'),(3,'candidate-v3'),(4,'candidate-v4')]:
  for n in frozen['owned']:put('failed-source/v%d/'%v+n,ROOT/folder/n)
 # New authored reviews and root records only; prior private read-only receipt is excluded.
 patterns=['scope-final-v5.json','fresh-peer-status-song-v5.json','before-state.json','baseline-manifest.json','approved-*.json','candidate-freeze-v*.json','frozen-source-*-v*.json','host-*.json','host-driver-*.txt','native-outer-final-v5.*','independent-*.json','root-host-audit-final-v5.json','root-native-audit-final-v5.json','native-stack-plan-v1.json','freeze-initial-schema-refusal-v1.json']
 records=set()
 for pattern in patterns:records.update(ROOT.glob(pattern))
 for p in sorted(records):put('records/'+p.name,p)
 for lane in ['host-tools-v1','native-preparation']:tree('preparation/'+lane,ROOT/lane)
 for p in sorted(ROOT.glob('*.py')):put('preparation/'+p.name,p)
 for parent in [Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/preflight-startup-fxjdydr8/next-producer-draft'),Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/preflight-startup-fxjdydr8/next-producer-fixture-draft')]:
  for p in sorted(parent.rglob('*')):
   if p.is_file() and (p.suffix in ['.json','.patch']):put('authoring/'+parent.name+'/'+p.relative_to(parent).as_posix(),p)
 payload=OUT/'payload.tar.gz'
 with payload.open('xb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tf:
    for n,b in sorted(members.items()):
     info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(b))
 manifest={'scope':'Optional genuine whole-song readers producer; recorded host and portable compiler proof only. Native/emulator/physical/stack/placement/backendactivation/timing/audio/listening NOT_RUN','base_commit':frozen['base_commit'],'base_tree':frozen['base_tree'],'payload':{'bytes':payload.stat().st_size,'sha256':sha(payload.read_bytes())},'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]}
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(OUT/'verify_payload.py').write_bytes((ROOT/'verify_song_payload_v2.py').read_bytes())
 with tarfile.open(payload) as tf:assert {f.name:tf.extractfile(f).read() for f in tf}==members
 print(json.dumps({'members':len(members),'source_paths':len(inputs),'uncompressed_bytes':sum(map(len,members.values())),'payload':manifest['payload']}))
if __name__=='__main__':main()
