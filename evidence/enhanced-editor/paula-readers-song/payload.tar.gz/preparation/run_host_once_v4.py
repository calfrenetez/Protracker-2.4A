"""Run the reviewed three-group host helper once against the frozen song export."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = '/opt/homebrew/opt/python@3.14/bin/python3.14'
OUT = Path('/private/tmp/pt-song-readers-s5ii39rm-host-v4')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    assert __debug__ and not OUT.exists()
    execution = ROOT / 'host-execution-v4.json'
    assert not execution.exists()
    tools = ROOT / 'host-tools-v1'
    manifest = ROOT / 'frozen-source-host-v4.json'
    pins = tools / 'toolchain-pins.json'
    review = json.loads((ROOT / 'independent-host-helper-source-review-v1.json').read_bytes())
    approval = json.loads((ROOT / 'approved-host-controls-v4.json').read_bytes())
    assert review and approval['scope'] == 'root approved exact original boundary v4 frozen three-group host-only execution'
    for n, expected in approval['inputs'].items():
        assert sha(ROOT / n) == expected, n
    argv = [PYTHON, '-B', str(tools / 'host_provenance.py'),
            '--source', str(ROOT / 'candidate-v4'),
            '--source-manifest', str(manifest), '--source-manifest-sha256', sha(manifest),
            '--pins', str(pins), '--pins-sha256', sha(pins), '--out', str(OUT)]
    execution.write_text(json.dumps({'scope': approval['scope'], 'argv': argv,
        'native': 'NOT_RUN', 'physical': 'NOT_RUN', 'state': 'dispatched once'}, indent=2) + '\n')
    with (ROOT / 'host-driver-stdout-v4.txt').open('xb') as stdout, \
         (ROOT / 'host-driver-stderr-v4.txt').open('xb') as stderr:
        completed = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    value = json.loads(execution.read_bytes())
    value.update({'state': 'completed', 'driver_rc': completed.returncode,
                  'original_out': str(OUT)})
    execution.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'driver_rc': completed.returncode, 'original_out': str(OUT)}))
    raise SystemExit(completed.returncode)

if __name__ == '__main__':
    main()
