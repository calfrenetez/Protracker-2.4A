"""One pinned compiler-only invocation after actual host PASS; never run HUNK."""
import datetime,hashlib,json,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PYTHON='/opt/homebrew/opt/python@3.14/bin/python3.14'
PRIVATE=Path('/private/tmp/pt-song-readers-s5ii39rm-native-v4')
DURABLE=ROOT/'native-final-v4'
def rec(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def main():
 assert __debug__
 audit=json.loads((ROOT/'root-host-audit-final-v4.json').read_bytes());assert audit['passed']
 approval=json.loads((ROOT/'approved-native-controls-v4.json').read_bytes())
 assert approval['scope']=='root approved one assertion-enabled v4 compiler-only invocation after actual host PASS'
 for n,h in approval['inputs'].items():assert rec(ROOT/n)['sha256']==h,n
 helper=ROOT/'native-preparation/build_song_readers_faults_portability_v2.py';pins=ROOT/'native-preparation/toolchain-pins.json'
 manifest=ROOT/'frozen-source-native-v4.json';contract=ROOT/'native-preparation/PTPaulaReadersSongTest-contract-v2.json'
 argv=[PYTHON,'-B',str(helper),'--source',str(ROOT/'candidate-v4'),'--fixture-contract',str(contract),'--fixture-contract-sha256',rec(contract)['sha256'],'--source-manifest',str(manifest),'--source-manifest-sha256',rec(manifest)['sha256'],'--pins',str(pins),'--pins-sha256',rec(pins)['sha256'],'--out',str(PRIVATE)]
 receipt=ROOT/'native-outer-final-v4.json';stdout=ROOT/'native-outer-final-v4.stdout';stderr=ROOT/'native-outer-final-v4.stderr'
 assert not any(p.exists() for p in [PRIVATE,DURABLE,receipt,stdout,stderr])
 controls=[helper,pins,manifest,contract]
 v={'scope':approval['scope'],'argv':argv,'helper_invocations':1,'wrapper':rec(__file__),'host_audit':rec(ROOT/'root-host-audit-final-v4.json'),'controls_before':[rec(p) for p in controls],'native':'NOT_RUN','physical':'NOT_RUN','started_utc':datetime.datetime.now(datetime.UTC).isoformat()}
 receipt.write_text(json.dumps(v,indent=2)+'\n');start=time.monotonic()
 with stdout.open('xb') as out,stderr.open('xb') as err:done=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err)
 v.update({'returncode':done.returncode,'passed':done.returncode==0,'elapsed_s':time.monotonic()-start,'controls_after':[rec(p) for p in controls],'stdout':rec(stdout),'stderr':rec(stderr)})
 assert v['controls_before']==v['controls_after']
 shutil.copytree(PRIVATE,DURABLE);mapping=[]
 for p in sorted(PRIVATE.rglob('*')):
  if p.is_file():
   copy=DURABLE/p.relative_to(PRIVATE);assert p.read_bytes()==copy.read_bytes();mapping.append({'original':rec(p),'durable':rec(copy)})
 v['durable_mapping']=mapping;receipt.write_text(json.dumps(v,indent=2)+'\n')
 print(json.dumps({'passed':v['passed'],'returncode':done.returncode,'receipt':rec(receipt),'native':'NOT_RUN'}));raise SystemExit(done.returncode)
if __name__=='__main__':main()
