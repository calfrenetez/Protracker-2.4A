#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "pcm.h"
struct source {struct pt_pcm pcm;int32_t data[16];};
int main(void)
{
    struct source s,before;unsigned i,failures=0;uint32_t *out;
    for(i=0;i<4;++i) {
        memset(&s,0,sizeof(s));s.pcm=(struct pt_pcm){s.data,16,4,48000,1,16};
        s.data[0]=257;s.data[1]=1;s.data[2]=-1;s.data[3]=32767;s.data[8]=42;
        before=s;out=i==0?(uint32_t *)&s.data[0]:i==1?(uint32_t *)&s.data[8]:i==2?&s.pcm.frames:&s.pcm.rate;
        enum pt_pcm_result result=pt_pcm_resampled_frames(&s.pcm,96000,out);
        unsigned changed=memcmp(&s,&before,sizeof(s))!=0;
        printf("PCM FRAME PROBE case=%u result=%d source_changed=%u\n",i,result,changed);
        if(result!=PT_PCM_ALIAS || changed)++failures;
    }
    printf("PCM FRAME PROBE failures=%u\n",failures);return failures?20:0;
}
