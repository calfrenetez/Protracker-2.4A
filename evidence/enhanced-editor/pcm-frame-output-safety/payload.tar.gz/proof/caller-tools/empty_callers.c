#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sampler.h"
#include "paula_preview.h"
static size_t live,calls;
static void *allocate(void *unused,size_t n)
{void *p;(void)unused;++calls;p=malloc(n);if(p)++live;return p;}
static void release(void *unused,void *p)
{(void)unused;if(p){assert(live);--live;free(p);}}
int main(void)
{
    unsigned bits,ch,k;int32_t data[8]={11,22,33,44,55,66,77,88},before[8],out[8],out_before[8];
    memcpy(before,data,sizeof(data));
    for(bits=8;bits<=24;bits+=8)for(ch=1;ch<=2;++ch) {
        struct pt_pcm p={NULL,0,0,44100,(uint8_t)ch,(uint8_t)bits};
        struct pt_pcm dest={out,8,0,22050,(uint8_t)ch,8};struct pt_pcm descriptor;
        uint32_t n=123;for(k=0;k<8;++k)out[k]=(int32_t)(k+101);memcpy(out_before,out,sizeof(out));
        descriptor=p;assert(pt_paula_preview_frames(&p,22050,&n)==PT_PCM_OK && n==0);
        assert(pt_paula_preview_prepare(&p,&dest)==PT_PCM_OK);
        assert(!memcmp(&p,&descriptor,sizeof(p)) && !memcmp(out,out_before,sizeof(out)));
        p.data=data;p.capacity=8;descriptor=p;n=123;
        assert(pt_paula_preview_frames(&p,22050,&n)==PT_PCM_OK && n==0);
        assert(pt_paula_preview_prepare(&p,&dest)==PT_PCM_OK);
        assert(!memcmp(&p,&descriptor,sizeof(p)) && !memcmp(data,before,sizeof(data)) && !memcmp(out,out_before,sizeof(out)));
        p.data=NULL;descriptor=p;n=123;
        assert(pt_paula_preview_frames(&p,22050,&n)==PT_PCM_ALIAS && n==123);
        assert(!memcmp(&p,&descriptor,sizeof(p)) && !memcmp(data,before,sizeof(data)));
    }
    for(bits=8;bits<=24;bits+=8)for(ch=1;ch<=2;++ch) {
        struct pt_allocator a={NULL,allocate,release};struct pt_document d;
        struct pt_sampler s,snapshot;struct pt_sample saved,header;struct pt_pattern_history h;
        struct pt_pattern_command commands[2];struct pt_event_change changes[2];uint32_t revision;size_t allocations,attempts;
        pt_document_init(&d,&a);assert(pt_document_new(&d,4,SIZE_MAX)==PT_PROJECT_OK);
        memset(&s,0,sizeof(s));pt_sampler_init(&s,&a,1024*1024);
        assert(pt_pattern_history_init(&h,&d.project,commands,2,changes,2)==PT_EDIT_OK);
        saved=d.project.samples[0];
        for(k=0;k<3;++k) {
            d.project.samples[0].pcm=(struct pt_pcm){k==1?data:NULL,k?8:0,0,44100,(uint8_t)ch,(uint8_t)bits};
            header=d.project.samples[0];snapshot=s;revision=h.revision;allocations=live;attempts=calls;
            assert(pt_sampler_convert_quality(&s,&d.project,&h,0,16,22050,0)==PT_EDIT_INVALID);
            assert(pt_sampler_convert_quality(&s,&d.project,&h,0,16,22050,1)==PT_EDIT_INVALID);
            assert(!memcmp(&s,&snapshot,sizeof(s)) && !memcmp(&d.project.samples[0],&header,sizeof(header)));
            assert(live==allocations && calls==attempts && h.revision==revision && !memcmp(data,before,sizeof(data)));
        }
        d.project.samples[0]=saved;pt_pattern_history_release(&h);pt_sampler_release(&s);pt_document_release(&d);assert(!live);
    }
    puts("PCM EMPTY CALLERS PASS: 8/16/24 mono/stereo NULL-zero and reserved preview, unprovable-span refusal, sampler empty early refusal without allocations or publication");return 0;
}
