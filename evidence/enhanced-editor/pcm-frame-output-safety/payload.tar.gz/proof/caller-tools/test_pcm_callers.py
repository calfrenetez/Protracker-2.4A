from pathlib import Path
import subprocess,tempfile,unittest
from test_sampler import ROOT,SOURCES
HERE=Path(__file__).resolve().parent
class EmptyCallers(unittest.TestCase):
 def test_private_frame_counters_empty_policy(self):
  with tempfile.TemporaryDirectory() as tmp:
   binary=str(Path(tmp)/'pcm-empty-callers')
   subprocess.run(['cc','-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core','-Isrc/editor',str(HERE/'empty_callers.c'),*SOURCES[1:],'-o',binary],cwd=ROOT,check=True)
   subprocess.run([binary],check=True)
