#!/usr/bin/env python3
"""Exact host-only PCM frame-count output probe with preserved full-header provenance."""
import argparse,json,shutil,subprocess,sys,time,traceback
from pathlib import Path
from provenance_common import assert_pinned,classify,digest,file_record,parse_dependencies,require_snapshot,write_json
sys.dont_write_bytecode=True
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True)
p.add_argument('--manifest-sha256',required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--expected-rc',type=int,choices=(0,20),required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];pinfile=root/'tools/toolchain-pins.json';probe_original=root/'output-probe.c'
assert_pinned(a.manifest,a.manifest_sha256);expected=json.loads(a.manifest.read_text())['source'];require_snapshot(a.source,expected)
assert_pinned(pinfile,'ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065');pins=json.loads(pinfile.read_text())['host']
assert_pinned(pins['python']['path'],pins['python']['sha256']);assert Path(sys.executable).resolve()==Path(pins['python']['path']).resolve() and sys.version==pins['python']['version']
cc=pins['compiler'];assert_pinned(cc['path'],cc['sha256'])
for path,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(path,sha)
assert not a.out.exists();a.out.mkdir();probe=a.out/'probe.c';shutil.copyfile(probe_original,probe);assert digest(probe)==digest(probe_original)
flags=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core'];units=[str(probe),'src/core/pcm.c'];started=time.monotonic()
r={'scope':'Host ASan/UBSan exact four-case scalar publication probe only; expected baselineRC20 versus candidateRC0; no native/target operation','source_manifest':file_record(a.manifest),'source_files_before':len(expected),'expected_rc':a.expected_rc,'probe':file_record(probe),'probe_origin':file_record(probe_original),'compiler':cc,'python':pins['python'],'runtime_inputs':pins['runtime_inputs'],'sdk_inputs':pins['sdk_inputs'],'helpers':[file_record(__file__),file_record(Path(__file__).with_name('provenance_common.py'))],'commands':[],'canonical_dependencies':{},'external_sdk_dependencies':{},'passed':False}
def run(argv,label):
 z=subprocess.run(argv,cwd=a.source,capture_output=True,text=True,timeout=180);log=a.out/(label+'.log');log.write_text(z.stdout+z.stderr)
 r['commands'].append({'argv':argv,'directory':str(a.source),'returncode':z.returncode,'log':file_record(log)});write_json(a.out/'result.json',r);return z
try:
 z=run([cc['path'],'--version'],'compiler-version');assert z.returncode==0 and z.stdout==cc['version']
 z=run([cc['path'],'-print-resource-dir'],'compiler-resource');assert z.returncode==0 and z.stdout.strip()==cc['resource_dir']
 for i,unit in enumerate(units):
  z=run([cc['path'],*flags,'-M',unit],'dependencies-%02d'%i);assert z.returncode==0
  for dep in parse_dependencies(z.stdout):
   path=(a.source/dep).resolve()
   if path==probe:continue
   kind,key=classify(path,a.source,expected,pins['allowed_sdk_roots']);assert kind in ('canonical','external_sdk')
   r['canonical_dependencies' if kind=='canonical' else 'external_sdk_dependencies'][key]=digest(path)
 z=run([cc['path'],*flags,*units,'-o',str(a.out/'probe')],'compile');assert z.returncode==0;r['binary']=file_record(a.out/'probe')
 z=run([str(a.out/'probe')],'run');r['run_rc']=z.returncode
 pattern='result=0 source_changed=1' if a.expected_rc==20 else 'result=3 source_changed=0'
 r['passed']=z.returncode==a.expected_rc and not z.stderr and z.stdout.count(pattern)==4 and ('PCM FRAME PROBE failures='+str(4 if a.expected_rc==20 else 0)) in z.stdout
except Exception as e:
 r['error']={'kind':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 try:
  require_snapshot(a.source,expected);r['source_files_after']=len(expected)
  assert_pinned(a.manifest,r['source_manifest']['sha256']);assert_pinned(probe_original,r['probe_origin']['sha256']);assert_pinned(cc['path'],cc['sha256'])
  for path,sha in {**pins['runtime_inputs'],**pins['sdk_inputs'],**r['external_sdk_dependencies']}.items():assert_pinned(path,sha)
  for h in r['helpers']:assert_pinned(h['path'],h['sha256'])
 except Exception as e:r['final_guard_error']=str(e);r['passed']=False
 r['elapsed_s']=time.monotonic()-started;write_json(a.out/'result.json',r)
print(json.dumps({'passed':r['passed'],'expected_rc':a.expected_rc,'run_rc':r.get('run_rc'),'canonical_dependencies':len(r['canonical_dependencies']),'external_sdk_dependencies':len(r['external_sdk_dependencies']),'report':str(a.out/'result.json')}))
sys.exit(0 if r['passed'] else 1)
