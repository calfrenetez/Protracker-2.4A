# Playback master-storage boundary — private host proof

Final candidate: `source-final-v3`, manifest `source-manifest-v3.json` and
`final-v3.patch`. The immutable clean archive is committed4c715d1, tree8869e6e.
Exactly four paths differ: `src/core/playback_pcm.c/.h`,
`tests/playback_pcm_test.c`, and `tests/playback_upload_test.c`. No working-tree
or protected display changes were imported. All7,756 source paths are inventoried.

The new metadata-only guards protect the borrowed PCM/format descriptors and
full declared int32_t capacity, including unused storage, without reading padding.
Public scalar size publication refuses missing nonzero-capacity storage and
unrepresentable spans. Packing preserves zero-byte no-write behavior, including
empty NULL data with retained capacity, and existing short-capacity/NULL/invalid
precedence. Conversion arithmetic and emitted8/16-bit channel/endian/pad bytes
are unchanged.

Lease outputs are checked against the known source before cache reservation or
HIT pin mutation. Incremental staging is checked against source storage, source
and job metadata, and its lease output before packing/upload. Ordinary failures
still cancel the unpublished resource. If the lease output lies inside the job,
INVALID preserves the entire job/output; retry with a disjoint output or explicitly
cancel. This exception avoids cancellation itself overwriting the refused output.
Opaque callback/context/resource/cache-object extents are outside this scope.

The byte-identical `output-probe.c` demonstrates three baseline corruptions
(size scalar, pack padding, upload padding plus callback), expectedRC20, versus
finalRC0 with ALIAS3/INVALID4, unchanged master storage, no upload callback and
zero owned resources. Baseline source and receipts remain under
`baseline`, `baseline-manifest.json`, and `baseline-probe-v2`.

Final five ASan/UBSan groups pass in15.3208s: playback PCM/upload, sampler Paula,
sampler wavetable and AmiGUS wavetable cache. Ten compile/runtime commands,
56 full-M dependency queries,56 canonical plus105 system inputs and five product
archives are retained in `host-final-v3`. The probe receipts each retain eight
commands,11 canonical plus102 system dependencies. Full source inventories,
compiler/Python/sanitizer/runtime/header identities and every product/log are
verified by `verify_final.py`; `handoff.json` contains exact records.

Preserved earlier attempts: the original `tools` probe failed isolated-Python
helper import before any compiler/test execution; `tools-v2` explicitly adds its
private helper directory. The original prefix-only failure record is preserved
in `baseline-probe-prelaunch-failure.json`. `source-final-v2`/`host-final-v2`
retain a test-only missing uint8_t cast compile failure before product execution;
final-v3 corrects only that argument type. `candidate-probe-v2` remains a successful
proof of the identical production code, separately superseded by final-v3 proof.

This packet proves host software behavior only. No native build/execution,
emulator, physical Amiga, MMIO, device transfer/completion/voice-stop, audio,
timing or listening acceptance is claimed. The prior Paula native candidate
must be rebuilt from the finalized source before later current-source testing.
