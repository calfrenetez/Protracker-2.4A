#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "playback_pcm.h"
struct device {unsigned writes,live;};
static void *allocate(void *ctx,size_t n) {struct device *d=ctx;void *p=malloc(n);if(p)++d->live;return p;}
static void release(void *ctx,void *p,size_t n) {struct device *d=ctx;(void)n;free(p);--d->live;}
static int write_chunk(void *ctx,void *resource,size_t offset,const uint8_t *bytes,size_t n)
{struct device *d=ctx;memcpy((uint8_t *)resource+offset,bytes,n);++d->writes;return 1;}
int main(void)
{
    union {size_t scalar;int32_t pcm[4];} u;
    int32_t master[4]={65537,0x123456,0x234567,0x345678},before[4];
    unsigned char scalar_before[sizeof(u)];unsigned failures=0,changed;int result;
    struct pt_pcm p={master,4,1,48000,1,24};struct pt_playback_format f={8,0,0,0};
    struct device d={0};struct pt_sample_cache c;struct pt_playback_upload_job job={0};struct pt_cache_lease out={99,123};
    memset(&u,0,sizeof(u));u.pcm[0]=65537;u.pcm[1]=0x123456;
    memcpy(scalar_before,&u,sizeof(u));p.data=u.pcm;
    result=pt_playback_pcm_size(&p,&f,&u.scalar);changed=memcmp(&u,scalar_before,sizeof(u))!=0;
    printf("size result=%d source_changed=%u\n",result,changed);if(result!=PT_PCM_ALIAS || changed)++failures;
    p.data=master;memcpy(before,master,sizeof(master));
    result=pt_playback_pcm_pack(&p,&f,(uint8_t *)(master+1),1);changed=memcmp(master,before,sizeof(master))!=0;
    printf("pack result=%d source_changed=%u\n",result,changed);if(result!=PT_PCM_ALIAS || changed)++failures;
    memcpy(master,before,sizeof(master));pt_cache_init(&c,&d,allocate,release,16);
    if(pt_playback_upload_begin(&job,&c,&p,1,1,&f,&d,write_chunk,&out)!=PT_CACHE_PENDING)return 20;
    result=pt_playback_upload_step(&job,(uint8_t *)(master+1),1,&out);changed=memcmp(master,before,sizeof(master))!=0;
    printf("upload result=%d source_changed=%u writes=%u\n",result,changed,d.writes);
    if(result!=PT_CACHE_INVALID || changed || d.writes || c.bytes || job.cache)++failures;
    if(result==PT_CACHE_LOAD)pt_cache_unpin(&c,out);
    pt_playback_upload_cancel(&job);pt_cache_clear(&c);
    if(d.live || c.bytes)return 20;
    printf("PLAYBACK STORAGE PROBE failures=%u\n",failures);return failures?20:0;
}
