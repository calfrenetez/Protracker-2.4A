from pathlib import Path
import hashlib,json,shutil,difflib,sys
r=Path(__file__).resolve().parent;base=r/'baseline';version=sys.argv[1];final=r/('source-final-'+version);assert not final.exists();shutil.copytree(r/'candidate',final)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={p.relative_to(final).as_posix():sha(p) for p in sorted(final.rglob('*')) if p.is_file()}
bm=json.loads((r/'baseline-manifest.json').read_text());owned=['src/core/playback_pcm.c','src/core/playback_pcm.h','tests/playback_pcm_test.c','tests/playback_upload_test.c']
assert sorted(n for n in files if files[n]!=bm['source'].get(n))==sorted(owned) and set(files)==set(bm['source'])
manifest={'scope':'Final immutable clean4c715d1 archive plus exactly four authorized playback master-storage overlays; no dirty working-tree files','base_commit':bm['base_commit'],'base_tree':bm['base_tree'],'baseline_manifest':{'path':str(r/'baseline-manifest.json'),'bytes':(r/'baseline-manifest.json').stat().st_size,'sha256':sha(r/'baseline-manifest.json')},'overlays':{n:files[n] for n in owned},'source':files,'source_files':len(files)}
m=r/('source-manifest-'+version+'.json');m.write_text(json.dumps(manifest,indent=2)+'\n')
patch=''.join(''.join(difflib.unified_diff((base/n).read_text().splitlines(True),(final/n).read_text().splitlines(True),fromfile='a/'+n,tofile='b/'+n)) for n in owned)
p=r/('final-'+version+'.patch');p.write_text(patch)
for f in final.rglob('*'):
 if f.is_file():f.chmod(0o444)
print(json.dumps({'source_manifest_sha256':sha(m),'source_files':len(files),'overlays':manifest['overlays'],'patch_bytes':p.stat().st_size,'patch_sha256':sha(p)},indent=2))
