from pathlib import Path
import hashlib,json,sys,shlex,re
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rec=lambda p:{'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
load=lambda p:json.loads(Path(p).read_text())
def check_record(x):
 p=Path(x.get('path',x.get('archive_path')))
 assert p.is_file() and sha(p)==x['sha256'] and p.stat().st_size==x['bytes'],p
 return p
base=load(r/'baseline-manifest.json');m=load(r/'source-manifest-v3.json');source=r/'source-final-v3'
def snapshot(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
assert snapshot(r/'baseline')==base['source'] and snapshot(source)==m['source']
assert len(m['source'])==7756 and set(m['source'])==set(base['source'])
assert {n:s for n,s in m['source'].items() if s!=base['source'][n]}==m['overlays']
assert snapshot(r/'candidate')==m['source']
parse=lambda s:list(dict.fromkeys(v for line in re.sub(r'\\\r?\n',' ',s).splitlines() if re.search(r'(?<!\\):',line) for v in shlex.split(line[re.search(r'(?<!\\):',line).end():],posix=True)))
h=load(r/'host-final-v3/host-checks.json');assert h['passed'] and len(h['groups'])==5 and len(h['commands'])==10
canon={};sdk={};deps=0
for c in h['commands']:
 assert c['stage']=='complete' and c['product_returncode']==0
 check_record(c['output_log'])
 for dep in c['dependency_commands']:
  assert dep['returncode']==0 and '-M' in dep['argv'] and '-MM' not in dep['argv']
  p=check_record(dep['output']);actual={}
  for item in parse(p.read_text()):
   f=(Path(dep['directory'])/item).resolve()
   try:n=f.relative_to(source).as_posix();kind='canonical';assert n in m['source'] and sha(f)==m['source'][n]
   except ValueError:n=str(f);kind='external_sdk'
   actual.setdefault(kind,{})[n]=sha(f)
   (canon if kind=='canonical' else sdk)[n]=sha(f)
  for kind,inputs in actual.items():
   for n,s in inputs.items():assert c['dependencies'][kind][n]==s
  deps+=1
 for field in ('produced_binary','input_binary'):
  if field in c:check_record(c[field])
assert canon==h['canonical_dependencies'] and sdk==h['external_sdk_dependencies']
assert not h['generated_inputs'] and len(h['products'])==5
for x in h['products']+h['helper_inputs']+h['module_inputs']:check_record(x)
for group in h['groups']:assert group['passed'] and group['tests']==1 and not group['errors'] and not group['failures']
for path,s in {**h['sanitizer_runtime_inputs'],**h['pinned_sdk_inputs'],**sdk}.items():assert sha(path)==s
check_record(h['source_manifest']);check_record(h['pins']);assert sha(h['compiler']['path'])==h['compiler']['sha256'] and sha(h['python']['path'])==h['python']['sha256']
probes=[]
for label,manifest,expected_rc in [('baseline-probe-v2',base,20),('candidate-probe-v3',m,0)]:
 p=load(r/label/'result.json');assert p['passed'] and p['run_rc']==expected_rc and len(p['commands'])==8
 assert p['source_files_before']==p['source_files_after']==7756
 for c in p['commands']:
  check_record(c['log']);assert c['returncode']==(expected_rc if c['argv']==[p['binary']['path']] else 0)
 for field in ('source_manifest','probe','probe_origin','binary'):check_record(p[field])
 for x in p['helpers']:check_record(x)
 for n,s in p['canonical_dependencies'].items():assert manifest['source'][n]==s
 for n,s in p['external_sdk_dependencies'].items():assert sha(n)==s
 assert p['probe']['sha256']==p['probe_origin']['sha256']==sha(r/'output-probe.c')
 probes.append({'record':rec(r/label/'result.json'),'run_log':rec(r/label/'run.log'),'expected_rc':expected_rc,'binary':p['binary'],'canonical_dependencies':len(p['canonical_dependencies']),'system_dependencies':len(p['external_sdk_dependencies'])})
summary={'scope':'Final private host-only playback master-storage correction; no native/emulator/physical/device/audio/timing/listening acceptance','passed':True,'base_commit':m['base_commit'],'base_tree':m['base_tree'],'source':str(source),'source_manifest':rec(r/'source-manifest-v3.json'),'source_files':7756,'source_fingerprint_sha256':hashlib.sha256(json.dumps(m['source'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'overlays':{n:rec(source/n) for n in m['overlays']},'patch':rec(r/'final-v3.patch'),'host_report':rec(r/'host-final-v3/host-checks.json'),'host_log':rec(r/'host-final-v3/host-checks.log'),'host_groups':h['groups'],'host_elapsed_s':h['elapsed_s'],'host_commands':len(h['commands']),'dependency_commands':deps,'canonical_dependencies':len(canon),'system_dependencies':len(sdk),'products':h['products'],'probes':probes,'preserved_prior_records':[rec(r/'baseline-probe-prelaunch-failure.json'),rec(r/'host-final-v2/host-checks.json'),rec(r/'host-final-v2/host-checks.log'),rec(r/'candidate-probe-v2/result.json')],'limits':['Source span checks read metadata, not PCM padding.','Public scalar size now refuses missing nonzero-capacity storage; zero-byte pack retains no-write behavior.','Step output inside its job returns INVALID without cancellation to keep output/job unchanged; explicit retry/cancel required.','Ordinary stale/source-staging/capacity/transfer failures retain existing unpublished-resource cancellation.','Opaque driver resource/context/cache-object extents are outside this narrow source-boundary guard.']}
(r/'handoff.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed':True,'host_groups':5,'host_commands':10,'dependencies':deps,'canonical':len(canon),'system':len(sdk),'host_elapsed_s':h['elapsed_s'],'handoff':rec(r/'handoff.json'),'source_fingerprint':summary['source_fingerprint_sha256']},indent=2))
