#define main reservation_fixture_main
#include "amigus_reservation_test.c"
#undef main
#include <stdlib.h>
#include "playback_internal.h"
static unsigned prepared_cache_test;
struct fixture {
    struct fake library;
    struct pt_amigus_reservation reservation;
    struct pt_amigus_wavetable_cache cache;
    unsigned writes,fail,lose;
    int healthy,fail_result;
    uint32_t address;
    uint8_t ram[4096];
};
static int bus_owned(void *ctx)
{
    struct fixture *f=ctx;
    if(f->healthy!=1)return f->healthy;
    return f->library.library && f->library.owner==&f->reservation &&
        f->library.acquired==PT_AMIGUS_WAVETABLE && f->reservation.reserved;
}
static int bus_write(void *ctx,unsigned reg,uint32_t value)
{
    struct fixture *f=ctx;unsigned i;
    assert(bus_owned(f) && f->reservation.access);++f->writes;
    assert(!pt_amigus_reservation_close(&f->reservation));
    if(reg==0x14)f->address=value;
    else {
        assert(reg==0x10 && !(f->address&3) && f->address<=sizeof(f->ram)-4);
        for(i=0;i<4;++i)f->ram[f->address+i]=(uint8_t)(value>>(24-8*i));
    }
    if(f->lose && f->lose==f->writes)f->healthy=0;
    return f->fail && f->fail==f->writes?f->fail_result:1;
}
static void init(struct fixture *f,enum pt_amigus_resource resource)
{
    struct pt_amigus_reservation_api api={&f->library,open_library,close_library,find,supported,reserve,release};
    memset(f,0,sizeof(*f));f->healthy=1;
    f->library.available=f->library.supported=f->library.count=1;
    memset(f->ram,0xcc,sizeof(f->ram));
    assert(pt_amigus_reservation_open_resource(&f->reservation,&api,0,resource)==PT_AMIGUS_RESERVED);
}
static enum pt_cache_result load(struct fixture *f,unsigned id,unsigned version,struct pt_cache_lease *lease)
{
    int32_t data[]={8388607,1,-8388608,-1,257,258,65536,-65536,123,-123},original[10];
    uint8_t staging[300];
    struct pt_pcm p={data,10,5,48000,2,24};struct pt_playback_format format={16,0,0,0};
    enum pt_cache_result result;
    memcpy(original,data,sizeof(data));
    assert(pt_pcm_validate(&p)==PT_PCM_OK);
    result=prepared_cache_test?pt_amigus_wavetable_cache_acquire_prepared(&f->cache,&p,id,version,&format,staging,sizeof(staging),lease):
        pt_amigus_wavetable_cache_acquire(&f->cache,&p,id,version,&format,staging,sizeof(staging),lease);
    assert(!memcmp(original,data,sizeof(data)));return result;
}
static void attached(struct fixture *f)
{
    assert(pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,16,32,32,f,bus_owned,bus_write));
    assert(f->reservation.access && !f->writes);
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,16,32,32,f,bus_owned,bus_write));
}
static void refusal(struct fixture *f)
{
    init(f,PT_AMIGUS_PCM);
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,16,32,32,f,bus_owned,bus_write));
    assert(!f->reservation.access && !f->writes);assert(pt_amigus_reservation_close(&f->reservation));
    init(f,PT_AMIGUS_WAVETABLE);
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,17,32,32,f,bus_owned,bus_write));
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,0xfffffffc,8,8,f,bus_owned,bus_write));
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,0x02000000,4,4,f,bus_owned,bus_write));
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,0x01fffffc,8,8,f,bus_owned,bus_write));
    assert(!f->reservation.access && !f->writes && !f->cache.reservation);
    f->healthy=0;assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,16,32,32,f,bus_owned,bus_write));
    assert(!f->reservation.access);f->healthy=1;
    assert(pt_amigus_reservation_begin(&f->reservation));
    assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,16,32,32,f,bus_owned,bus_write));
    assert(f->reservation.access);assert(pt_amigus_reservation_end(&f->reservation));
    assert(pt_amigus_reservation_close(&f->reservation));
}
static void lifetime(struct fixture *f)
{
    struct pt_cache_lease a,b,hit,out={31,999};unsigned writes;uint32_t address,bytes;
    const uint8_t expected[]={0x7f,0xff,0x80,0,0,1,1,0,0,0,0,0};
    init(f,PT_AMIGUS_WAVETABLE);attached(f);
    assert(load(f,1,1,&a)==PT_CACHE_LOAD);assert(!memcmp(f->ram+16,expected,sizeof(expected)));
    assert(pt_amigus_wavetable_cache_location(&f->cache,a,&address,&bytes) && address==16 && bytes==10);
    writes=f->writes;assert(load(f,1,1,&hit)==PT_CACHE_HIT && f->writes==writes);
    assert(pt_amigus_wavetable_cache_unpin(&f->cache,hit));
    pt_amigus_wavetable_cache_invalidate(&f->cache,1);
    assert(load(f,1,2,&b)==PT_CACHE_LOAD);
    assert(pt_amigus_wavetable_cache_location(&f->cache,b,&address,&bytes) && address==28);
    assert(!memcmp(f->ram+16,expected,sizeof(expected))); /* Old voice still pinned. */
    assert(load(f,2,1,&out)==PT_CACHE_CAPACITY && out.serial==999);
    writes=f->writes;
    assert(!pt_amigus_wavetable_cache_detach(&f->cache));
    assert(f->reservation.access && f->library.owner && !f->library.releases);
    assert(!pt_amigus_reservation_close(&f->reservation));
    assert(load(f,1,2,&out)==PT_CACHE_INVALID && out.serial==999);
    assert(!pt_amigus_wavetable_cache_location(&f->cache,b,&address,&bytes));
    assert(pt_amigus_wavetable_cache_unpin(&f->cache,a));
    assert(!pt_amigus_wavetable_cache_detach(&f->cache));
    assert(pt_amigus_wavetable_cache_unpin(&f->cache,b));
    assert(pt_amigus_wavetable_cache_detach(&f->cache));assert(f->writes==writes);
    assert(!f->reservation.access && f->reservation.reserved && !f->library.releases);
    assert(pt_amigus_wavetable_cache_detach(&f->cache));
    assert(!pt_amigus_wavetable_cache_unpin(&f->cache,b));
    assert(pt_amigus_reservation_close(&f->reservation));
    assert(f->library.releases==1 && f->library.closes==1);
}
static void failure(struct fixture *f)
{
    struct pt_cache_lease a,b={31,999};unsigned writes;uint32_t address,bytes;
    init(f,PT_AMIGUS_WAVETABLE);attached(f);f->fail=2;
    assert(load(f,1,1,&b)==PT_CACHE_TRANSFER && b.serial==999);
    assert(!f->cache.cache.bytes && f->reservation.access && !f->library.releases);
    f->fail=0;assert(load(f,1,1,&a)==PT_CACHE_LOAD);writes=f->writes;
    f->healthy=0;
    assert(load(f,1,1,&b)==PT_CACHE_INVALID && b.serial==999); /* HIT must check owner. */
    f->healthy=1;
    assert(load(f,1,1,&b)==PT_CACHE_INVALID); /* Lost ownership is latched. */
    assert(!pt_amigus_wavetable_cache_location(&f->cache,a,&address,&bytes));
    assert(f->writes==writes && !pt_amigus_reservation_close(&f->reservation));
    assert(!pt_amigus_wavetable_cache_detach(&f->cache));
    assert(pt_amigus_wavetable_cache_unpin(&f->cache,a));
    assert(pt_amigus_wavetable_cache_detach(&f->cache));
    assert(pt_amigus_reservation_close(&f->reservation));
    init(f,PT_AMIGUS_WAVETABLE);attached(f);assert(load(f,1,1,&a)==PT_CACHE_LOAD);
    assert(pt_amigus_wavetable_cache_unpin(&f->cache,a));assert(pt_amigus_wavetable_cache_detach(&f->cache));
    assert(pt_amigus_reservation_close(&f->reservation));
}
static void prepared_refusal(struct fixture *f)
{
    int32_t data[4]={-128,-1,0,127};struct pt_pcm p={data,4,4,48000,1,8},bad;
    struct pt_playback_format format={16,0,0,0},bad_format;
    struct pt_cache_lease a,out={31,999};uint8_t staging[8];unsigned mode,writes;
    init(f,PT_AMIGUS_WAVETABLE);attached(f);assert(pt_pcm_validate(&p)==PT_PCM_OK);
    assert(pt_amigus_wavetable_cache_acquire_prepared(&f->cache,&p,1,1,&format,staging,sizeof(staging),&a)==PT_CACHE_LOAD);
    writes=f->writes;
    for(mode=0;mode<7;++mode) {
        bad=p;bad_format=format;
        switch(mode) {
        case 0:bad.capacity=3;break;
        case 1:bad.rate=0;break;
        case 2:bad.channels=3;break;
        case 3:bad.bits=32;break;
        case 4:bad_format.channel=2;break;
        case 5:bad_format.bits=24;break;
        case 6:bad_format.little_endian=2;break;
        }
        assert(pt_amigus_wavetable_cache_acquire_prepared(&f->cache,&bad,1,1,&bad_format,staging,sizeof(staging),&out)==(mode==0?PT_CACHE_CAPACITY:PT_CACHE_INVALID));
        assert(out.slot==31 && out.serial==999 && f->writes==writes && pt_cache_data(&f->cache.cache,a));
    }
    /* Public validation is never disabled, including a populated cache hit. */
    data[0]=-129;
    assert(pt_amigus_wavetable_cache_acquire(&f->cache,&p,1,1,&format,staging,sizeof(staging),&out)==PT_CACHE_INVALID);
    assert(out.serial==999 && f->writes==writes);data[0]=-128;
    assert(pt_amigus_wavetable_cache_unpin(&f->cache,a) && pt_amigus_wavetable_cache_detach(&f->cache));
    assert(pt_amigus_reservation_close(&f->reservation));
}
static void upload_job_fixture(struct fixture *f)
{
    struct pt_amigus_upload_job job={0};struct pt_cache_lease out={31,999},hit;
    struct pt_playback_format format={8,0,0,1};struct pt_amigus_reservation copy;
    int32_t data[5]={-128,-1,0,1,127};struct pt_pcm pcm={data,5,5,48000,1,8};
    uint8_t staging[8];unsigned mode,step,writes;uint32_t address,bytes;enum pt_cache_result result;
    const uint8_t expected[8]={128,255,0,1,127,0,0,0};
    for(mode=0;mode<6;++mode) {
        init(f,PT_AMIGUS_WAVETABLE);attached(f);
        assert(pt_amigus_upload_begin(&job,&f->cache,&pcm,1,1,&format,&out)==PT_CACHE_PENDING && !f->writes);
        for(step=0;step<mode;++step) {
            assert(!pt_amigus_wavetable_cache_location(&f->cache,job.upload.lease,&address,&bytes));
            assert(pt_amigus_upload_step(&job,staging,1,&out)==PT_CACHE_PENDING && out.serial==999);
        }
        pt_amigus_upload_cancel(&job);pt_amigus_upload_cancel(&job);
        assert(!job.backend && !f->cache.cache.bytes && out.serial==999);
        assert(pt_amigus_wavetable_cache_detach(&f->cache) && pt_amigus_reservation_close(&f->reservation));
    }
    for(mode=0;mode<6;++mode) {
        init(f,PT_AMIGUS_WAVETABLE);attached(f);assert(pt_pcm_validate(&pcm)==PT_PCM_OK);
        assert(pt_amigus_upload_begin_prepared(&job,&f->cache,&pcm,1,1,&format,&out)==PT_CACHE_PENDING);
        assert(pt_amigus_upload_step(&job,staging,1,&out)==PT_CACHE_PENDING);writes=f->writes;
        if(mode==1)f->healthy=0;
        if(mode==2)assert(!pt_amigus_wavetable_cache_detach(&f->cache));
        if(mode==3){copy=f->reservation;f->cache.reservation=&copy;}
        if(mode==4)f->fail=2;
        if(mode==5)f->lose=4; /* Ownership disappears on the final bus write. */
        do{result=pt_amigus_upload_step(&job,staging,1,&out);}while(result==PT_CACHE_PENDING);
        assert(!job.backend);
        if(mode) {
            assert(result==(mode>=4?PT_CACHE_TRANSFER:PT_CACHE_INVALID));
            assert(out.serial==999 && !f->cache.cache.bytes);
            if(mode<=3)assert(f->writes==writes);
            f->cache.reservation=&f->reservation;
        }else {
            assert(result==PT_CACHE_LOAD && !memcmp(f->ram+16,expected,sizeof(expected)));
            assert(pt_amigus_wavetable_cache_location(&f->cache,out,&address,&bytes) && bytes==6);
            writes=f->writes;
            assert(pt_amigus_upload_begin(&job,&f->cache,&pcm,1,1,&format,&hit)==PT_CACHE_HIT && !job.backend && f->writes==writes);
            pt_amigus_upload_cancel(&job);assert(pt_amigus_wavetable_cache_unpin(&f->cache,hit));
            assert(pt_amigus_wavetable_cache_unpin(&f->cache,out));out=(struct pt_cache_lease){31,999};
        }
        assert(pt_amigus_wavetable_cache_detach(&f->cache) && pt_amigus_reservation_close(&f->reservation));
    }
    puts("WAVETABLE UPLOAD JOB PASS: bounded steps, cancellation, unpublished leases, partial words, live ownership loss and hit transfer; injected only");
}
static void invalid_callback_results(struct fixture *f)
{
    const int statuses[]={-1,2};unsigned k,fail,writes;
    struct pt_cache_lease a,out;uint32_t address,bytes;
    for(k=0;k<2;++k) {
        init(f,PT_AMIGUS_WAVETABLE);f->healthy=statuses[k];
        assert(!pt_amigus_wavetable_cache_attach(&f->cache,&f->reservation,16,32,32,f,bus_owned,bus_write));
        assert(!f->reservation.access && !f->writes);
        f->healthy=1;attached(f);assert(load(f,1,1,&a)==PT_CACHE_LOAD);writes=f->writes;
        f->healthy=statuses[k];out=(struct pt_cache_lease){31,999};
        assert(load(f,1,1,&out)==PT_CACHE_INVALID && out.serial==999);
        f->healthy=1;assert(!pt_amigus_wavetable_cache_current(&f->cache));
        assert(!pt_amigus_wavetable_cache_location(&f->cache,a,&address,&bytes));
        assert(f->writes==writes && !pt_amigus_wavetable_cache_detach(&f->cache));
        assert(!pt_amigus_reservation_close(&f->reservation));
        assert(pt_amigus_wavetable_cache_unpin(&f->cache,a));
        assert(pt_amigus_wavetable_cache_detach(&f->cache) && pt_amigus_reservation_close(&f->reservation));
        for(fail=1;fail<=2;++fail) {
            init(f,PT_AMIGUS_WAVETABLE);attached(f);f->fail=fail;f->fail_result=statuses[k];out=(struct pt_cache_lease){31,999};
            assert(load(f,1,1,&out)==PT_CACHE_TRANSFER && out.serial==999);
            assert(f->writes==fail && !f->cache.cache.bytes && f->reservation.access);
            assert(pt_amigus_wavetable_cache_detach(&f->cache) && pt_amigus_reservation_close(&f->reservation));
        }
    }
}
static int wavetable_fixture_main(void)
{
    struct fixture *f=malloc(sizeof(*f));assert(f);assert(reservation_fixture_main()==0);
    refusal(f);
    for(prepared_cache_test=0;prepared_cache_test<2;++prepared_cache_test){lifetime(f);failure(f);invalid_callback_results(f);}
    prepared_cache_test=0;prepared_refusal(f);upload_job_fixture(f);free(f);
    puts("AMIGUS WAVETABLE OWNER PASS: explicit resource, pinned cache lifetime, failure cleanup, lost ownership refusal; fake library/bus only");return 0;
}

#ifndef PT_WAVETABLE_NATIVE
int main(void) {return wavetable_fixture_main();}
#endif
