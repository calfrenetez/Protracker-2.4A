#!/usr/bin/env python3
"""Archive exact completed host proof; never build, run tests or access a target."""
import argparse
import gzip
import hashlib
import io
import json
import stat
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path('/private/tmp/protracker-playback-storage-tka8fnd9')
OUT = Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A/evidence/enhanced-editor/playback-master-storage-host')
REVIEW = Path('/private/tmp/protracker-playback-independent-final-v3-review.json')
PINS = {
 'baseline-manifest.json': '35932d027eaa7c47a48eba8550776d8357b360caa7f084f95c8ef14c9013ada9',
 'source-manifest-v2.json': 'b13fc4ddcd163b7965eb6595a5feeb2d10f643ab7a0c1c35f2091dd25564d828',
 'source-manifest-v3.json': '7c2288be138ad0a1bfa4d49619e6a12d1b43ac94586f9ad553cefa676452e49c',
 'handoff.json': 'a25ae05900d4e40c2321402a28e66b0190739aadbc02b41430afb55e95e63bb8',
 'delivery.json': '26edd083b12482367d4a8c6be57962713c10d9260ca99b599d7fdb8dc4e1d484',
 'final-v3.patch': 'a25ef50e00efad8c8fc4d00d9bce5bb8a640fd8238bb98873830d07dfd32e9f3',
 'host-final-v3/host-checks.json': '98b2d387da245de223c33fcd1e82b41a73920559b2c2e29054d6f718fc2f2430',
 'host-final-v2/host-checks.json': '593f9995c935e8efd58b910dec282a43166436a993a5ef1c86db83e7acd3a302',
 'baseline-probe-v2/result.json': 'cbb59b2b33c84d780256e99ef31d64ce1e844c36cae0308f977d3bc6cb342bf3',
 'candidate-probe-v3/result.json': '16bef551211392ba90aa156ad53f5a47c4756ff19634bf74915b7f63d839a31e',
 'candidate-probe-v2/result.json': '7b02ba0d9c66eb366f9887fa7d5c5bde6b46e81b70b5595e4d8f83fcb99d7897',
 'baseline-probe-prelaunch-failure.json': 'cdbb951cc5ad3f1b9cf56e7a05415a95236c4541de576e69cc2b5f49b9343079',
 'root-import-receipt.json': '127f25d2bcf8193e0fc4cbe6b99943bb34b3d6d5d07326ee20a91bea24dff913',
}
REVIEW_SHA = 'f8b8a77586ebc6ad9957f13c6f000860a1d5e4d80fbb4b431c8db80b1587d374'
OWN = ['src/core/playback_pcm.c', 'src/core/playback_pcm.h', 'tests/playback_pcm_test.c', 'tests/playback_upload_test.c']
MODULES = ['test_playback_pcm', 'test_playback_upload', 'test_sampler_paula', 'test_sampler_wavetable', 'test_amigus_wavetable_cache']

def sha(data):
 return hashlib.sha256(data).hexdigest()

def read_regular(path):
 path = Path(path)
 before = path.lstat()
 if not stat.S_ISREG(before.st_mode):
  raise ValueError('Nonregular original: ' + str(path))
 data = path.read_bytes()
 after = path.lstat()
 fields = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns')
 if tuple(getattr(before, x) for x in fields) != tuple(getattr(after, x) for x in fields):
  raise ValueError('Original changed: ' + str(path))
 return data, stat.S_IMODE(before.st_mode)

def document(path, digest=None):
 data, _ = read_regular(path)
 if digest is not None and sha(data) != digest:
  raise ValueError('Original pin differs: ' + str(path))
 return json.loads(data)

def verify_record(rec, external=False):
 path = Path(rec.get('path', rec.get('archive_path', '')))
 if external:
  path = path.resolve(strict=True)
 data, _ = read_regular(path)
 assert sha(data) == rec['sha256'], str(path)
 if 'bytes' in rec:
  assert len(data) == rec['bytes'], str(path)
 return path

def inventory(folder):
 result = {}
 for path in sorted(folder.rglob('*')):
  mode = path.lstat().st_mode
  if stat.S_ISDIR(mode):
   continue
  data, _ = read_regular(path)
  result[path.relative_to(folder).as_posix()] = sha(data)
 return result

def main():
 if not __debug__:
  raise RuntimeError('Optimization disables archival assertions')
 parser = argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--out', type=Path, required=True)
 parser.add_argument('--qa', type=Path, required=True)
 args = parser.parse_args()
 out, qa = args.out.absolute(), args.qa.absolute()
 assert out == OUT and qa.parent == Path('/private/tmp') and not out.exists() and not qa.exists()
 docs = {name: document(ROOT / name, digest) for name, digest in PINS.items() if name.endswith('.json')}
 for name, digest in PINS.items():
  assert sha(read_regular(ROOT / name)[0]) == digest
 baseline, v2, final = (docs[x] for x in ['baseline-manifest.json', 'source-manifest-v2.json', 'source-manifest-v3.json'])
 host, failed = docs['host-final-v3/host-checks.json'], docs['host-final-v2/host-checks.json']
 before, after, previous = (docs[x] for x in ['baseline-probe-v2/result.json', 'candidate-probe-v3/result.json', 'candidate-probe-v2/result.json'])
 handoff = docs['handoff.json']
 review = document(REVIEW, REVIEW_SHA)
 root_import = docs['root-import-receipt.json']
 assert review['passed'] and root_import['review']['sha256'] == REVIEW_SHA and root_import['overlays'] == handoff['overlays']
 assert root_import['protected_paths_unchanged'] == 16
 for source in [baseline, v2, final]:
  assert source['base_commit'] == '4c715d1bcec175860f3ac25849fed5d258b8002c'
  assert source['base_tree'] == '8869e6e261efe2905c820e5fecf228df323df461'
  assert len(source['source']) == 7756 and set(source['source']) == set(baseline['source'])
 assert [p for p in baseline['source'] if baseline['source'][p] != final['source'][p]] == OWN
 assert [p for p in v2['source'] if v2['source'][p] != final['source'][p]] == ['tests/playback_pcm_test.c']
 assert host['passed'] and host['modules'] == MODULES and len(host['commands']) == 10 and len(host['products']) == 5 and not host['generated_inputs']
 assert len(host['canonical_dependencies']) == 56 and len(host['external_sdk_dependencies']) == 105
 assert sum(len(c['dependency_commands']) for c in host['commands']) == 56
 assert all(c['product_returncode'] == 0 for c in host['commands'])
 assert not failed['passed'] and len(failed['commands']) == 1 and failed['commands'][0]['product_returncode'] == 1
 assert len(failed['groups']) == 1 and failed['groups'][0]['errors'] == 1 and failed['groups'][0]['failures'] == 0
 assert not failed['products'] and len(failed['commands'][0]['dependency_commands']) == 4
 assert before['passed'] and before['run_rc'] == 20 and after['passed'] and after['run_rc'] == 0
 assert previous['passed'] and previous['run_rc'] == 0
 assert before['probe']['sha256'] == after['probe']['sha256'] == previous['probe']['sha256'] == sha(read_regular(ROOT / 'output-probe.c')[0])
 for report in [host, failed, before, after, previous]:
  assert report['source_files_before'] == report['source_files_after'] == 7756
 assert read_regular(ROOT / 'baseline-probe-v2/run.log')[0] == b'size result=0 source_changed=1\npack result=0 source_changed=1\nupload result=1 source_changed=1 writes=1\nPLAYBACK STORAGE PROBE failures=3\n'
 assert read_regular(ROOT / 'candidate-probe-v3/run.log')[0] == b'size result=3 source_changed=0\npack result=3 source_changed=0\nupload result=4 source_changed=0 writes=0\nPLAYBACK STORAGE PROBE failures=0\n'
 prefix_failure = docs['baseline-probe-prelaunch-failure.json']
 assert prefix_failure['returncode'] == 1 and not prefix_failure['target_or_product_execution'] and len(prefix_failure['command']) == 3

 members = {}
 def add(path, name, role):
  p = PurePosixPath(name)
  assert not p.is_absolute() and '..' not in p.parts and str(p) == name and name not in members
  data, mode = read_regular(path)
  members[name] = {'data': data, 'origin': str(Path(path).absolute()), 'sha256': sha(data), 'bytes': len(data), 'mode': mode, 'role': role}
 for name in PINS:
  add(ROOT / name, 'records/' + name, 'exact original control or preserved pre-runtime refusal')
 for name in ['README.md', 'prepared-files.json', 'verify_final.py', 'freeze.py', 'output-probe.c']:
  add(ROOT / name, 'records/' + name, 'exact private source/proof/import history')
 add(REVIEW, 'review/independent-final-v3-review.json', 'independent read-only recorded proof review')
 add(Path(__file__), 'tools/package_playback_master_storage.py', 'exact executed archival helper')
 folders = ['host-final-v3', 'host-final-v2', 'baseline-probe-v2', 'candidate-probe-v3', 'candidate-probe-v2', 'tools', 'tools-v2']
 for folder in folders:
  for path in sorted((ROOT / folder).rglob('*')):
   if stat.S_ISDIR(path.lstat().st_mode):
    continue
   name = 'records/' + path.relative_to(ROOT).as_posix()
   if name not in members:
    add(path, name, 'exact original ' + folder + ' member')
 sources = [('baseline', baseline), ('source-final-v2', v2), ('source-final-v3', final)]
 selected = {
  'baseline': set(before['canonical_dependencies']),
  'source-final-v2': set(failed['canonical_dependencies']) | set(previous['canonical_dependencies']) | set(OWN),
  'source-final-v3': set(host['canonical_dependencies']) | set(after['canonical_dependencies']) | set(OWN),
 }
 for module in host['module_inputs']:
  name = Path(module['path']).relative_to(ROOT / 'source-final-v3').as_posix()
  selected['source-final-v3'].add(name)
 for module in failed['module_inputs']:
  name = Path(module['path']).relative_to(ROOT / 'source-final-v2').as_posix()
  selected['source-final-v2'].add(name)
 selected['source-final-v3'].update(['tests/test_sampler.py', 'tools/build_core_tests.py'])
 for folder, source in sources:
  assert inventory(ROOT / folder) == source['source']
  for name in sorted(selected[folder]):
   assert name in source['source'] and sha(read_regular(ROOT / folder / name)[0]) == source['source'][name]
   add(ROOT / folder / name, 'source/' + folder + '/' + name, 'actual scoped compile/dependency/overlay/module input')

 external = {}
 reports = [(host, 'source-final-v3'), (failed, 'source-final-v2'), (before, 'baseline'), (after, 'source-final-v3'), (previous, 'source-final-v2')]
 for report, folder in reports:
  for name, digest in report['canonical_dependencies'].items():
   assert sha(read_regular(ROOT / folder / name)[0]) == digest
  for name, digest in report['external_sdk_dependencies'].items():
   assert sha(read_regular(Path(name).resolve(strict=True))[0]) == digest
   assert name not in external or external[name] == digest
   external[name] = digest
  for key in ['compiler', 'python']:
   verify_record(report[key], external=True)
  for key, digest in report.get('runtime_inputs', report.get('sanitizer_runtime_inputs', {})).items():
   assert sha(read_regular(Path(key).resolve(strict=True))[0]) == digest
  for key, digest in report.get('sdk_inputs', report.get('pinned_sdk_inputs', {})).items():
   assert sha(read_regular(Path(key).resolve(strict=True))[0]) == digest
  for rec in report.get('helpers', report.get('helper_inputs', [])) + report.get('module_inputs', []):
   verify_record(rec)
  for command in report['commands']:
   assert command.get('product_returncode', command.get('returncode')) in (0, 1, 20)
   for key in ['log', 'output_log', 'produced_binary', 'input_binary']:
    if key in command:
     verify_record(command[key])
   for dep in command.get('dependency_commands', []):
    assert dep['returncode'] == 0
    verify_record(dep['output'])
  for key in ['binary', 'probe', 'probe_origin', 'source_manifest', 'log', 'pins']:
   if key in report:
    verify_record(report[key])
  for rec in report.get('products', []):
   verify_record(rec)
 assert len(external) == 105
 for rec in handoff['overlays'].values():
  verify_record(rec)
 for rec in handoff['preserved_prior_records']:
  verify_record(rec)

 def make_archive():
  result = io.BytesIO()
  with gzip.GzipFile(fileobj=result, mode='wb', filename='', mtime=0, compresslevel=9) as zipped:
   with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for name, entry in sorted(members.items()):
     info = tarfile.TarInfo(name)
     info.size, info.mode = entry['bytes'], entry['mode']
     info.uid = info.gid = info.mtime = 0
     info.uname = info.gname = ''
     archive.addfile(info, io.BytesIO(entry['data']))
  return result.getvalue()
 payload = make_archive()
 assert payload == make_archive()
 with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
  seen = set()
  for info in archive:
   assert info.isfile() and info.name not in seen and info.name in members
   seen.add(info.name)
   entry = members[info.name]
   assert info.mode == entry['mode'] and info.uid == info.gid == info.mtime == 0 and info.uname == info.gname == ''
   data = archive.extractfile(info).read()
   assert data == entry['data'] and len(data) == entry['bytes'] and sha(data) == entry['sha256']
  assert seen == set(members)
 for entry in members.values():
  data, mode = read_regular(entry['origin'])
  assert data == entry['data'] and mode == entry['mode']
 for folder, source in sources:
  assert inventory(ROOT / folder) == source['source']
 manifest = {'scope': 'Exact archived original bytes/modes and origin hashes; host-only proof, with no hardware acceptance', 'members': {name: {k: v for k, v in entry.items() if k != 'data'} for name, entry in sorted(members.items())}}
 provenance = {
  'scope': 'Archival integrity of completed playback master-storage host proof; packaging ran no tests/builds/targets',
  'helper': {'path': str(Path(__file__).absolute()), 'sha256': sha(read_regular(Path(__file__))[0])},
  'base_commit': baseline['base_commit'], 'base_tree': baseline['base_tree'], 'source_files_each': 7756,
  'snapshots': [name for name, _ in sources], 'own_paths': OWN,
  'source_fingerprint_sha256': handoff['source_fingerprint_sha256'],
  'host_groups': host['groups'], 'host_elapsed_s': host['elapsed_s'], 'host_completed_commands': 10,
  'host_full_M_commands': 56, 'host_canonical_dependencies': 56, 'external_system_sdk_compiler_fingerprints': external,
  'host_products': 5, 'host_generated_inputs': 0,
  'same_probe_sha256': before['probe']['sha256'], 'baseline_probe_rc': 20, 'candidate_probe_rc': 0,
  'superseded_candidate_v2_probe_rc': 0,
  'history': {'v1': 'Prefix-only import-refusal summary, not a complete invocation or raw log; no compiler/product runtime reached', 'v2': 'One compile RC1 with four full-M queries; no runtime. Final-v3 adds only explicit test pointer cast'},
  'independent_review_sha256': REVIEW_SHA,
  'root_import_receipt_sha256': sha(read_regular(ROOT / 'root-import-receipt.json')[0]),
  'root_preserved_dirty_paths': 16,
  'root_attribution': 'Literal copied root import receipt; this package performs no fresh working-checkout comparison',
  'members': len(members), 'original_member_bytes': sum(e['bytes'] for e in members.values()),
  'payload': {'sha256': sha(payload), 'bytes': len(payload)},
  'reproduction': 'Reconstruct recorded Git baseline, apply archived final-v3 patch or four overlays, verify full inventory; explicitly rebase original historical private paths',
  'native_emulator_physical_audio_timing_listening_acceptance': 'None in this packet; later separate qualifications must bind their exact candidates',
  'limits': handoff['limits'],
 }
 readme = '''This packet preserves the playback conversion/upload master-storage correction and its original host proof. The baseline is committed 4c715d1bcec175860f3ac25849fed5d258b8002c, tree 8869e6e261efe2905c820e5fecf228df323df461. The candidate changes only src/core/playback_pcm.c, src/core/playback_pcm.h, tests/playback_pcm_test.c and tests/playback_upload_test.c. Full inventories of all 7,756 files in the baseline, superseded v2 and final v3 snapshots are retained inside the compressed payload. Only actual scoped dependencies, module declarations, overlays and the canonical recipe are copied; the full source exports and external SDK/compiler trees are omitted.

The identical aligned three-case probe is preserved: baseline RC20 reproduces scalar-size, pack-padding and upload-staging corruption; final candidate RC0 refuses all three, preserves source bytes and makes no upload callback. Superseded v2 probe records remain separate. The final five original ASan/UBSan groups passed: playback PCM, playback upload, sampler Paula, sampler wavetable and AmiGUS wavetable cache. Their ten completed RC0 compile/runtime commands, 56 full-M queries, 56 canonical dependency inputs, 105 system/SDK/compiler fingerprints, five executable archives and complete original logs/helpers are retained. No generated fixture is claimed.

Both earlier pre-runtime refusals remain literal history. The v1 probe helper could not import provenance_common under isolated Python; its retained record is a command-prefix summary, not a complete original invocation or raw output log. No compiler or product execution reached that attempt. The v2 host attempt stopped on a missing explicit uint8_t pointer cast in one test call: one compile RC1 and four dependency queries, without runtime. Final v3 corrects that cast only; production bytes and the assertion result are unchanged. These are host preparation/compile failures, not target or product-runtime failures.

The new checks use metadata to protect borrowed PCM/format descriptors and the full declared master capacity, including unused storage, without reading padding values or allocating. Public scalar size refuses NULL storage with nonzero declared capacity; zero-byte pack retains its no-write behavior. A completion output inside its own upload job returns INVALID without cancellation because cancellation would overwrite the refused output; callers can retry with a disjoint output or explicitly cancel. Ordinary source/stale/capacity/transfer failures keep existing unpublished-resource cleanup. Opaque callback contexts, device resources and cache-object extents remain outside this narrow source guard.

The independent read-only final-v3 review is copied exactly. A separate copied root receipt reports import of the four matching overlays and preservation of 16 unrelated dirty paths; these are root-reported facts, not a new package-time checkout audit. manifest.json binds every regular payload member to its original path, byte count, SHA256, mode and role. Archive ownership/time are normalized, and two in-memory writes plus a full tar-reader verification checked deterministic bytes. SHA256SUMS binds the four other packet files.

Historical helpers and commands retain their original private paths. Reproduction requires the recorded Git baseline plus final overlays, inventory verification and explicit path rebinding. Packaging ran no tests, builds, native binaries, emulator, physical target, locks, network or browser operations. This packet proves host source preservation and archival integrity only; native layout, actual Fast/Chip allocation, hardware cache completion/voice-stop, playback, timing and human listening require separate exact-candidate evidence.
'''
 contents = {
  'payload.tar.gz': payload,
  'manifest.json': (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode(),
  'packet-provenance.json': (json.dumps(provenance, indent=2, sort_keys=True) + '\n').encode(),
  'README.md': readme.encode(),
 }
 contents['SHA256SUMS'] = ''.join(sha(data) + '  ' + name + '\n' for name, data in sorted(contents.items())).encode()
 out.mkdir()
 for name, data in contents.items():
  with (out / name).open('xb') as handle:
   handle.write(data)
 assert {p.name for p in out.iterdir()} == set(contents)
 for name, data in contents.items():
  assert read_regular(out / name)[0] == data
 rows = (out / 'SHA256SUMS').read_text().splitlines()
 assert len(rows) == 4 and len({row.split('  ', 1)[1] for row in rows}) == 4
 for row in rows:
  digest, name = row.split('  ', 1)
  assert sha(read_regular(out / name)[0]) == digest
 qa_record = {
  'scope': 'Packet integrity only; no new product or hardware qualification', 'passed': True,
  'output': str(out), 'files': len(contents), 'bytes': sum(len(x) for x in contents.values()),
  'members': len(members), 'original_member_bytes': sum(e['bytes'] for e in members.values()),
  'deterministic_second_write_equal': True, 'all_original_bytes_modes_preserved': True,
  'all_three_full_source_inventories_before_after_equal': True,
  'controls': {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in contents.items()},
 }
 with qa.open('x') as handle:
  handle.write(json.dumps(qa_record, indent=2, sort_keys=True) + '\n')
 print(json.dumps(qa_record))

if __name__ == '__main__':
 main()
