#!/usr/bin/env python3
"""Reproduce the preserved baseline probe against this frozen host candidate."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from provenance_common import assert_pinned, digest, file_record, parse_dependencies, require_snapshot, write_json

sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[1]
source=root/'source-final';manifest=root/'source-final-manifest.json';out=root/'candidate-probe'
assert_pinned(manifest,'386bd3ffd444745a78998e799d0e84377ff16de393d07deb70f959d3a13767e2')
pinfile=root/'tools/toolchain-pins.json'
assert_pinned(pinfile,'ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065')
pins=json.loads(pinfile.read_text())['host'];expected=json.loads(manifest.read_text())['source']
require_snapshot(source,expected)
assert_pinned(pins['python']['path'],pins['python']['sha256'])
assert Path(sys.executable).resolve()==Path(pins['python']['path']).resolve() and sys.version==pins['python']['version']
cc=pins['compiler'];assert_pinned(cc['path'],cc['sha256'])
for name,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(name,sha)
out.mkdir();probe=out/'probe.c';original=root/'baseline-probe/probe.c'
assert_pinned(original,'379e2cb1f2c832e65e1c8c37dece3c8ab3332a7fb0f505260e22a04bd3f62fb7')
shutil.copyfile(original,probe);assert digest(probe)==digest(original)
flags=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core']
units=[str(probe),'src/core/project.c','src/core/channels.c','src/core/pcm.c']
record={'scope':'Host ASan/UBSan same baseline preservation probe, expected RC0+257 retained; no native/target operation',
        'source_manifest':file_record(manifest),'source_files_before':len(expected),'compiler':cc,
        'runtime_inputs':pins['runtime_inputs'],'helper':file_record(__file__),
        'probe':file_record(probe),'commands':[],'canonical_dependencies':{},'passed':False}
def run(argv,label):
    result=subprocess.run(argv,cwd=source,capture_output=True,text=True,timeout=180)
    log=out/(label+'.log');log.write_text(result.stdout+result.stderr)
    record['commands'].append({'argv':argv,'directory':str(source),'returncode':result.returncode,'log':file_record(log)})
    return result
try:
    version=run([cc['path'],'--version'],'compiler-version');assert version.returncode==0 and version.stdout==cc['version']
    for i,unit in enumerate(units):
        dep=run([cc['path'],*flags,'-MM',unit],'dependencies-%02d'%i);assert dep.returncode==0
        for name in parse_dependencies(dep.stdout):
            path=(source/name).resolve()
            if path==probe:continue
            key=path.relative_to(source).as_posix();assert digest(path)==expected[key]
            record['canonical_dependencies'][key]=expected[key]
    result=run([cc['path'],*flags,*units,'-o',str(out/'probe')],'compile');assert result.returncode==0
    record['binary']=file_record(out/'probe')
    result=run([str(out/'probe')],'run')
    record['passed']=result.returncode==0 and result.stderr=='' and 'result=6 before=257 after=257' in result.stdout
finally:
    require_snapshot(source,expected);record['source_files_after']=len(expected)
    assert_pinned(cc['path'],cc['sha256'])
    for name,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(name,sha)
    assert_pinned(manifest,record['source_manifest']['sha256']);assert_pinned(__file__,record['helper']['sha256'])
    write_json(out/'result.json',record)
print(json.dumps({'passed':record['passed'],'report':str(out/'result.json')}))
sys.exit(0 if record['passed'] else 1)
