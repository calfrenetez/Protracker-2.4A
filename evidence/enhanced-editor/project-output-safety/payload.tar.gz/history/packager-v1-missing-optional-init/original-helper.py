#!/usr/bin/env python3
"""Private exact serializer evidence packager. No build, test, Git, UI or target calls.

Final execution requires actual qualification and copied coordination inputs.
All payload members are original byte copies; original JSON is never reformatted.
"""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import tempfile

INPUT = Path('/private/tmp/protracker-project-output-safety-c_zm9c99')
ROOT = Path('/private/tmp/protracker-project-output-root-76srz_37')
PINS = {
    'source-final-v2-manifest.json': '95577c22f903e3e3799b21130d66f4af14f5cc8bcd094649507b873a4849378e',
    'host-final-v2/host-checks.json': '59ad0ce2bb3a19722d8e31f84a516e3cd9e166af4e0a18d71ca64136583bf22f',
    'native-final-v2/manifest.json': 'abe9d60207ccf9405e081524dd117884bf770777b53ee28ac133a34cb233a39a',
    'candidate-probe-v3/result.json': '94263a80897b2396fc3e5f5c98edf82f39763ba108af562f12c4d8769a34c6f7',
    'baseline-probe/result.json': 'ad390b23eef06498c4f4673665fe93150f0744fe92eecd54e0d4f7a4adc0c098',
    'candidate-probe-harness-failure.json': '4973e0a10d4e6d1d0f366a26d5ba31aa2f2b762b7e568bd1704b2f68bce3ff85',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify_recorded_file(path, digest, size=None):
    observed = fingerprint(path)
    require(observed['sha256'] == digest and (size is None or observed['bytes'] == size),
            'Recorded original file identity changed: ' + str(path))


def safe(name):
    p = PurePosixPath(name)
    require(name and not p.is_absolute() and '\\' not in name and '\n' not in name and '\r' not in name,
            'Unsafe relative member name: ' + repr(name))
    require(p.as_posix() == name and all(x not in ('', '.', '..') for x in p.parts),
            'Noncanonical member name: ' + repr(name))


def files(root):
    require(root.is_dir() and not root.is_symlink(), 'Not a real input directory: ' + str(root))
    result = []
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'Symlink input refused: ' + str(path))
        mode = path.stat().st_mode
        if stat.S_ISDIR(mode):
            continue
        require(stat.S_ISREG(mode), 'Nonregular input refused: ' + str(path))
        result.append(path)
    return result


def source_check(directory, manifest_path):
    manifest = json.loads(manifest_path.read_bytes())
    expected = manifest['source']
    require(len(expected) == 7531, 'Immutable source input count changed')
    observed = {p.relative_to(directory).as_posix(): sha(p.read_bytes()) for p in files(directory)}
    require(observed == expected, 'Immutable source inventory mismatch: ' + str(directory))
    return {'directory': str(directory), 'manifest': fingerprint(manifest_path),
            'files': len(observed), 'all_original_hashes_match': True}


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def write_payload(members, stream):
    with gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for name, record in sorted(members.items()):
                original = Path(record['origin']['path']).read_bytes()
                require(len(original) == record['bytes'] and sha(original) == record['sha256'],
                        'Payload origin changed: ' + name)
                info = tarfile.TarInfo(name)
                info.size = len(original)
                info.mode = record['mode']
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                info.type = tarfile.REGTYPE
                info.pax_headers = {}
                archive.addfile(info, io.BytesIO(original))


def verify_payload(path, members):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for entry in archive:
            safe(entry.name)
            require(entry.name in members and entry.name not in seen, 'Unexpected/duplicate payload member')
            seen.add(entry.name)
            row = members[entry.name]
            require(entry.isfile() and not entry.islnk() and not entry.issym(), 'Nonregular payload member')
            require(entry.uid == entry.gid == entry.mtime == 0 and entry.uname == entry.gname == '',
                    'Payload owner/time is not fixed')
            require(entry.mode == row['mode'] and entry.size == row['bytes'], 'Payload metadata mismatch')
            require(set(entry.pax_headers).issubset({'path'}), 'Unexpected payload PAX metadata')
            reader = archive.extractfile(entry)
            require(reader is not None, 'Missing payload data')
            data = reader.read()
            require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'Payload member hash mismatch')
            require(data == Path(row['origin']['path']).read_bytes(), 'Payload member original byte mismatch')
    require(seen == set(members), 'Payload omitted members')
    return {'members': len(seen), 'original_member_bytes': sum(r['bytes'] for r in members.values()),
            'all_member_bytes_hashes_sizes_modes_verified': True, 'safe_unique_regular_paths': True,
            'uid_gid_mtime_zero': True, 'no_symlinks_hardlinks_or_truncated_members': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=INPUT)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--qualification', type=Path, required=True,
                        help='Actual original top qualification result after the separately authorized run')
    parser.add_argument('--qualification-helper', type=Path, required=True)
    parser.add_argument('--coordination-record', type=Path, required=True,
                        help='Actual original/root-reported coordination; never packaging live verification')
    parser.add_argument('--extra-record', type=Path, action='append', default=[])
    parser.add_argument('--prelaunch', type=Path, action='append', default=[])
    parser.add_argument('--qa-out', type=Path)
    args = parser.parse_args()
    input_root, root, out, qualification, qualifier, coordination = [p.resolve() for p in
        (args.input, args.root, args.out, args.qualification, args.qualification_helper, args.coordination_record)]
    extras = [p.resolve() for p in args.extra_record]
    prelaunches = [p.resolve() for p in args.prelaunch]
    qa_out = (args.qa_out or Path(str(out) + '-qa.json')).resolve()
    origins = [input_root, root, qualification.parent, qualifier, coordination, Path(__file__).resolve(), *extras, *prelaunches]
    for origin in origins:
        require(out != origin and out not in origin.parents and origin not in out.parents,
                'Package output overlaps original: ' + str(origin))
        require(qa_out != origin and origin not in qa_out.parents,
                'External QA output overlaps original: ' + str(origin))
    require(out != qa_out and out not in qa_out.parents and qa_out not in out.parents,
            'Package and QA outputs overlap')
    require(not out.exists() and not qa_out.exists(), 'Fresh private output and QA paths required')
    for name, digest in PINS.items():
        require(fingerprint(input_root / name)['sha256'] == digest, 'Reviewed final/history input changed: ' + name)
    source_scopes = [
        (input_root / 'baseline', input_root / 'baseline-manifest.json'),
        (input_root / 'source-final', input_root / 'source-final-manifest.json'),
        (input_root / 'source-final-v2', input_root / 'source-final-v2-manifest.json'),
    ]
    source_before = [source_check(*pair) for pair in source_scopes]
    final = json.loads((input_root / 'source-final-v2-manifest.json').read_bytes())
    host = json.loads((input_root / 'host-final-v2/host-checks.json').read_bytes())
    native = json.loads((input_root / 'native-final-v2/manifest.json').read_bytes())
    probe = json.loads((input_root / 'candidate-probe-v3/result.json').read_bytes())
    baseline = json.loads((input_root / 'baseline-probe/result.json').read_bytes())
    logger_failure = json.loads((input_root / 'candidate-probe-harness-failure.json').read_bytes())
    top = json.loads(qualification.read_bytes())
    json.loads(coordination.read_bytes())  # Original record is copied; no live acknowledgement is inferred.
    require(host['passed'] is True and len(host['groups']) == 2 and native['passed'] is True and
            set(native['targets']) == {'PTExecProjectStreamTest'} and probe['passed'] is True,
            'Final host/cross-build/probe status changed')
    require(set(final['overlays']) == {'src/core/project.c', 'src/core/project.h',
                                     'tests/project_stream_test.c', 'tests/project_test.c'},
            'Final product overlay scope changed')
    require(baseline['expected_returncode'] == 20 and baseline['expected_failure_observed'] is True,
            'Expected baseline RC20 history changed')
    require(logger_failure['scope'].startswith('Original additional candidate probe harness failure preserved') and
            logger_failure['commands_completed'] == 2,
            'Pre-runtime SDK provenance logger history changed')
    for record in (host, native, probe):
        require(record['source_manifest']['sha256'] == PINS['source-final-v2-manifest.json'],
                'Final proof references another source manifest')
    require((input_root / 'baseline-probe/probe.c').read_bytes() ==
            (input_root / 'candidate-probe-v3/probe.c').read_bytes(), 'Before/after probe source differs')
    for record in (host, native):
        for helper in record['helper_inputs']:
            verify_recorded_file(Path(helper['path']), helper['sha256'], helper['bytes'])
    for item in [*host['products'], *host['generated_inputs']]:
        verify_recorded_file(Path(item['archive_path']), item['sha256'], item['bytes'])
    target = native['targets']['PTExecProjectStreamTest']
    verify_recorded_file(input_root / 'native-final-v2/PTExecProjectStreamTest',
                         target['binary_sha256'], target['binary_bytes'])
    verify_recorded_file(Path(native['compile_commands']), native['compile_commands_sha256'],
                         native['compile_commands_bytes'])
    for command in native['commands']:
        log = command['log']
        verify_recorded_file(Path(log['path']), log['sha256'], log['bytes'])
    require(top.get('verified_manifest') == native, 'Actual top qualification embeds another build manifest')
    root_inputs = json.loads((root / 'root-inputs.json').read_bytes())
    require(fingerprint(root / 'shared_infra_render_files.py')['sha256'] == root_inputs['runner']['after_sha256'],
            'Root runner overlay changed')
    require(fingerprint(qualifier)['sha256'] == root_inputs['qualifier_sha256'], 'Historical qualifier bytes changed')
    baseline_export = fingerprint(input_root / 'a3585d0.tar')
    members = {}
    def add(name, origin, scope, expected=None):
        safe(name)
        require(name not in members, 'Duplicate payload destination: ' + name)
        require(not origin.is_symlink() and stat.S_ISREG(origin.stat().st_mode), 'Nonregular payload origin')
        original = fingerprint(origin)
        if expected is not None:
            require(original['sha256'] == expected, 'Scoped canonical source changed: ' + str(origin))
        members[name] = {'path': name, 'bytes': original['bytes'], 'sha256': original['sha256'],
                         'mode': stat.S_IMODE(origin.stat().st_mode), 'origin': original,
                         'kind': 'exact_original_archive_member', 'scope': scope}
    def tree(prefix, directory, scope, skip=()):
        skip = {p.resolve() for p in skip}
        for path in files(directory):
            if path.resolve() not in skip:
                add(prefix + '/' + path.relative_to(directory).as_posix(), path, scope)
    for prefix, sub, scope in [
        ('host-final-v2', 'host-final-v2', 'Exact final two-group sanitizer commands/logs/products/generated fixture'),
        ('native-final-v2', 'native-final-v2', 'Exact one-target cross-build commands/SDK/runtime pins/binary/preprocessed safe-assert wrapper'),
        ('regression/before', 'baseline-probe', 'Expected before-fix RC20, original binary/source/logs'),
        ('regression/after-final-v2', 'candidate-probe-v3', 'Final-v2 identical probe RC0/master preservation'),
        ('history/probe-sdk-logger-failure', 'candidate-probe', 'Pre-runtime SDK provenance logger failure; not product compile/runtime'),
        ('history/probe-source-v1', 'candidate-probe-v2', 'Earlier source-v1 successful probe, distinct from final-v2'),
        ('history/host-source-v1', 'host-final', 'Earlier source-v1 host checks, distinct from final-v2'),
        ('helpers', 'tools', 'Exact executed source/compiler/runtime/command provenance and probe helpers'),
    ]:
        tree(prefix, input_root / sub, scope)
    for name, destination, scope in [
        ('baseline-manifest.json', 'source/baseline-manifest.json', 'Original full7531 baseline source hash inventory'),
        ('source-final-manifest.json', 'history/source-v1-manifest.json', 'Original full7531 earlier source-v1 hash inventory'),
        ('source-final-v2-manifest.json', 'source/final-v2-manifest.json', 'Original full7531 final-v2 hash inventory/four overlays'),
        ('baseline-provenance.json', 'regression/baseline-provenance.json', 'Original derived baseline provenance with expectedRC20 retained'),
        ('candidate-probe-harness-failure.json', 'history/probe-sdk-logger-failure-description.json', 'Original logger error classification/cause/helper fingerprint'),
        ('draft.patch', 'history/draft.patch', 'Original earlier four-file patch'),
        ('final.patch', 'source/final-four-file.patch', 'Exact reviewed final four-file product/test patch'),
    ]:
        add(destination, input_root / name, scope)
    for source_dir, prefix, host_report, probe_report in [
        ('source-final', 'history/source-v1-scoped', 'host-final/host-checks.json', 'candidate-probe-v2/result.json'),
        ('source-final-v2', 'source/final-v2-scoped', 'host-final-v2/host-checks.json', 'candidate-probe-v3/result.json'),
    ]:
        manifest_name = 'source-final-manifest.json' if source_dir == 'source-final' else 'source-final-v2-manifest.json'
        manifest = json.loads((input_root / manifest_name).read_bytes())
        dependencies = {}
        for item in [json.loads((input_root / host_report).read_bytes())['canonical_dependencies'],
                     json.loads((input_root / probe_report).read_bytes())['canonical_dependencies'],
                     manifest['overlays']]:
            for path, digest in item.items():
                require(path not in dependencies or dependencies[path] == digest, 'Conflicting source closure hash')
                dependencies[path] = digest
        if source_dir == 'source-final-v2':
            for path, digest in native['targets']['PTExecProjectStreamTest']['dependencies'].items():
                require(path not in dependencies or dependencies[path] == digest, 'Conflicting native closure hash')
                dependencies[path] = digest
            for path in native['python_declaration_inputs']:
                dependencies[path] = manifest['source'][path]
            recipe_path = Path(native['canonical_recipe']['path']).relative_to(input_root / source_dir).as_posix()
            dependencies[recipe_path] = manifest['source'][recipe_path]
        for path in ('tests/test_project.py', 'tests/test_project_stream.py', 'tests/__init__.py',
                     'tests/fixtures/project-v1/mixed.ptg'):
            dependencies[path] = manifest['source'][path]
        for path, digest in sorted(dependencies.items()):
            add(prefix + '/' + path, input_root / source_dir / path,
                'Exact canonical execution closure/four source overlays, not full inherited source export', digest)
    for path in sorted(final['overlays']):
        add('history/working-candidate-scoped/' + path, input_root / 'candidate' / path,
            'Working private candidate bytes observed at packaging time; may equal final-v2, never labelled an immutable initial draft')
    baseline_source = json.loads((input_root / 'baseline-manifest.json').read_bytes())['source']
    for origin, digest in baseline['inputs'].items():
        path = Path(origin)
        try:
            relative = path.relative_to(input_root / 'baseline').as_posix()
        except ValueError:
            continue  # Probe source is already copied with the original before record.
        require(baseline_source[relative] == digest, 'Baseline closure differs from original manifest')
        add('source/baseline-scoped/' + relative, path, 'Exact original baseline probe source closure', digest)
    tree('root', root, 'Exact separately prepared runner/qualifier/root review and any root-reported history; no packaging live verification')
    add('qualification/top/qualification-result.json', qualification, 'Exact actual top result; original status/type/fields preserved')
    tree('qualification/records', qualification.parent, 'Exact nested runner/results/identities/logs/independent checks, separate from original top', skip=(qualification,))
    add('qualification/historical-orchestration.py', qualifier, 'Exact helper supplied as historical executed bytes; execution attribution only from original/root report')
    add('qualification/root-reported-coordination.json', coordination, 'Exact historical/root-reported coordination; packaging never claims live release verification')
    for n, path in enumerate(extras, 1):
        add('qualification/extra/%02d-%s' % (n, path.name), path, 'Additional exact root-reported review/history/control')
    for n, path in enumerate(prelaunches, 1):
        tree('history/host-prelaunch-not-run/%02d-%s' % (n, path.name), path,
             'Original separately supplied prelaunch record; no successful rerun substitutes its status')
    add('helpers/packager.py', Path(__file__).resolve(), 'Exact private packaging helper; no target/build/test/Git/UI calls')
    # Check every final native case against its separate original nested record before copying controls.
    case_consistency = []
    for case in top.get('cases', []):
        run = Path(case['run']).resolve()
        require(qualification.parent in run.parents, 'Nested run outside original qualification tree')
        require(json.loads((run / 'result.json').read_bytes()) == case['result'], 'Top/nested result differs')
        independent = run / 'independent-cleanup.json'
        if 'independent_cleanup' in case:
            require(json.loads(independent.read_bytes()) == case['independent_cleanup'], 'Independent cleanup differs')
        candidate = case['candidate']
        require(candidate['binary'] == 'PTExecProjectStreamTest' and
                candidate['sha256'] == native['targets']['PTExecProjectStreamTest']['binary_sha256'],
                'Actual native candidate differs from exact reviewed cross-build')
        case_consistency.append({'label': candidate['label'], 'original_top_equals_distinct_nested_result': True,
                                 'candidate_sha256': candidate['sha256']})
    out.mkdir()
    payload = out / 'payload.tar.gz'
    with payload.open('xb') as writer:
        write_payload(members, writer)
    archive_verification = verify_payload(payload, members)
    with tempfile.TemporaryFile() as second:
        write_payload(members, second)
        second.seek(0)
        with payload.open('rb') as first:
            while True:
                a, b = first.read(1024 * 1024), second.read(1024 * 1024)
                require(a == b, 'Repeated deterministic payload differs')
                if not a:
                    break
    archive_verification['second_archive_write_byte_identical'] = True
    controls = []
    def record(name, kind, scope, origin=None, derivation=None):
        item = fingerprint(out / name)
        item['path'] = name
        item.update(kind=kind, scope=scope)
        if origin is not None:
            item['origin'] = fingerprint(origin)
        if derivation is not None:
            item['derivation'] = derivation
        controls.append(item)
    def copy(name, origin, scope):
        require(not (out / name).exists(), 'Duplicate control destination')
        data = origin.read_bytes()
        (out / name).write_bytes(data)
        require((out / name).read_bytes() == data, 'Exact control copy failed')
        record(name, 'exact_byte_copy', scope, origin)
    def compressed(name, origin, scope):
        require(not (out / name).exists(), 'Duplicate gzip control destination')
        original = origin.read_bytes()
        with (out / name).open('xb') as writer:
            with gzip.GzipFile(fileobj=writer, filename='', mode='wb', mtime=0, compresslevel=9) as gz:
                gz.write(original)
        require(gzip.decompress((out / name).read_bytes()) == original, 'Exact control gzip failed')
        record(name, 'gzip_exact_byte_derivation', scope, origin,
               {'method': 'gzip level9, mtime0, empty filename; original bytes/allfields/order/whitespace unchanged'})
    record('payload.tar.gz', 'lossless_archive_derivation', 'Every selected original byte/control/scoped source/helper/history preserved',
           derivation=archive_verification)
    for name, origin, scope in [
        ('source-manifest.json.gz', input_root / 'source-final-v2-manifest.json', 'Original full7531 source/four-overlay manifest, unmodified'),
        ('baseline-manifest.json.gz', input_root / 'baseline-manifest.json', 'Original full7531 baseline manifest, unmodified'),
        ('source-v1-manifest.json.gz', input_root / 'source-final-manifest.json', 'Original full7531 source-v1 manifest, unmodified'),
        ('host-checks.json.gz', input_root / 'host-final-v2/host-checks.json', 'Exact final two-group host sanitizer report/allcommands/products/generatedfixture/compilerpins'),
        ('native-build.json.gz', input_root / 'native-final-v2/manifest.json', 'Exact one-target cross-build report/orderedTUs/SDKclosures/runtimepins'),
        ('qualification-result.json.gz', qualification, 'Exact actual original top status/fields; distinct nested originals remain in payload'),
    ]:
        compressed(name, origin, scope)
    for name, origin, scope in [
        ('baseline-before.json', input_root / 'baseline-probe/result.json', 'Original expected baseline RC20, not a sanitizer failure'),
        ('probe-after-final-v2.json', input_root / 'candidate-probe-v3/result.json', 'Original final-v2 identical-probeRC0/masterpreservation'),
        ('sdk-logger-failure.json', input_root / 'candidate-probe-harness-failure.json', 'Original pre-runtime SDK logger failure, not rewritten as a product result'),
        ('root-review.json', root / 'root-host-build-review.json', 'Original root provenance review; its original pending/native scope retained'),
        ('root-inputs.json', root / 'root-inputs.json', 'Original separate fifth runner overlay/qualifier fingerprint'),
        ('root-reported-coordination.json', coordination, 'Original/root-reported coordination only; no live packaging verification'),
    ]:
        copy(name, origin, scope)
    for n, path in enumerate(extras, 1):
        copy('extra-%02d-%s' % (n, path.name), path, 'Original supplied extra control/review, explicitly preserved')
    source_after = [source_check(*pair) for pair in source_scopes]
    require(source_before == source_after, 'Original immutable source inputs changed during packaging')
    for item in members.values():
        require(fingerprint(Path(item['origin']['path'])) == item['origin'], 'Original payload input changed after packaging')
    original_history = {
        'source_base_commit': final['base_commit'], 'source_base_tree': final['base_tree'],
        'product_overlay_count': len(final['overlays']), 'separate_runner_overlay': fingerprint(root / 'shared_infra_render_files.py'),
        'baseline_export_fingerprint_only_not_payload': baseline_export,
        'baseline_rc20_is_expected_missing_refusal': True,
        'pre_runtime_sdk_logger_original_failure_preserved': True,
        'earlier_source_v1_host_probe_history_distinct_from_final_v2': True,
        'native_original_top_passed_value': top.get('passed'),
        'native_original_top_scope': top.get('scope'), 'native_case_count': len(top.get('cases', [])),
        'native_top_nested_consistency': case_consistency,
        'coordination_attribution': 'Exact copied original/root-reported records only; no live verification by packaging',
    }
    provenance = {
        'schema': 'protracker-project-output-safety-evidence-v1',
        'scope': 'Private copy/archive/derivation integrity only; no new product/test/build/target/release/device/audio/physical/timing/listening acceptance',
        'source_before': source_before, 'source_after': source_after,
        'source_inventories_before_after_identical': True,
        'history_and_original_result_scope': original_history,
        'archive': fingerprint(payload), 'archive_verification': archive_verification,
        'members': [members[name] for name in sorted(members)],
    }
    raw_provenance = encoded(provenance)
    with (out / 'member-provenance.json.gz').open('xb') as writer:
        with gzip.GzipFile(fileobj=writer, filename='', mode='wb', mtime=0, compresslevel=9) as gz:
            gz.write(raw_provenance)
    require(gzip.decompress((out / 'member-provenance.json.gz').read_bytes()) == raw_provenance, 'Member provenance gzip failed')
    record('member-provenance.json.gz', 'authored_member_provenance_gzip', 'All selected original path/byte/hash/mode identities and source before/after verification',
           derivation={'uncompressed_bytes': len(raw_provenance), 'uncompressed_sha256': sha(raw_provenance),
                       'method': 'authored full original-member index, gzip level9 mtime0 emptyfilename'})
    readme = '''# Project serializer output preservation evidence

`payload.tar.gz` preserves the exact selected original host/build commands, products, generated fixture, compiler/runtime/SDK/helper records, canonical execution source closures and four product overlays, plus the separately recorded fifth runner overlay. Full 7,531-input baseline, earlier-v1 and final-v2 source manifests are preserved without removing, renaming or reformatting any field. The inherited 62MB baseline export tar is fingerprinted only; the full inherited source/evidence trees are not duplicated. `member-provenance.json.gz` lists every selected original member/origin/size/hash/mode. Safe unique regular paths, fixed uid/gid/mtime0 and original modes are retained; every member was byte-verified through a tar reader, and a second archive write matched exactly. Originals were unchanged.

The expected baseline RC20 preservation failure is separate from the identical final-v2 RC0 probe. Earlier source-v1 host/probe proofs remain under `history/`; the first candidate SDKSettings provenance logger failure is preserved as a pre-runtime harness failure with its original commands and helper. It is not a product compilation/runtime failure and is never relabelled PASS. Final host sanitizer and cross-build reports retain their original scopes and all command/definition records.

`qualification-result.json.gz` is the exact supplied actual top result, with its original status and fields unchanged. The same bytes are under `qualification/top/` in the archive; distinct original nested runner/results/logs/identity/independent records remain separately under `qualification/records/`. The supplied root reports and coordination are copied historical/root-reported evidence only. Packaging does not execute a fixture, infer missing cleanup or acknowledgements, or verify live ownership/release. Any prelaunch history supplied later is preserved separately, even when a later run succeeds. `root-review.json` intentionally retains its original preparation/pending wording.

No actual device/card/MMIO, audio, physical hardware, timing or human listening acceptance is claimed. Small readable controls are exact copies or exact-byte gzip encodings, not substitutions for the complete selected payload. `compact-index.json` records control copies/derivations and original identities; `SHA256SUMS` covers every package file except itself. No product, repository, original helper, target or shared lock was changed by this private packager.
'''
    (out / 'README.md').write_text(readme)
    record('README.md', 'authored_scope_note', 'Original history/result tier separation and lossless selected-payload navigation')
    index = {'schema': 'protracker-project-output-safety-compact-controls-v1',
             'scope': 'Copy/derivation integrity only; no new execution/cleanup/coordination acceptance',
             'items': controls, 'control_exclusions': ['compact-index.json', 'SHA256SUMS'],
             'original_native_status_unchanged': top.get('passed'),
             'archive_verification': archive_verification,
             'source_inventories_before_after_identical': True}
    (out / 'compact-index.json').write_bytes(encoded(index))
    package_files = files(out)
    sums = ''.join(sha(p.read_bytes()) + '  ' + p.relative_to(out).as_posix() + '\n' for p in package_files)
    (out / 'SHA256SUMS').write_text(sums)
    final_files = files(out)
    expected_paths = {item['path'] for item in controls} | {'compact-index.json', 'SHA256SUMS'}
    require({p.relative_to(out).as_posix() for p in final_files} == expected_paths, 'Unindexed package member')
    parsed_sums = {}
    for line in (out / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        safe(name)
        require(name not in parsed_sums, 'Duplicate checksum path')
        parsed_sums[name] = digest
    require(set(parsed_sums) == expected_paths - {'SHA256SUMS'}, 'Checksum coverage mismatch')
    for name, digest in parsed_sums.items():
        require(sha((out / name).read_bytes()) == digest, 'Checksum identity mismatch')
    for item in controls:
        data = (out / item['path']).read_bytes()
        require(len(data) == item['bytes'] and sha(data) == item['sha256'], 'Compact indexed bytes changed')
        if 'origin' in item:
            original = Path(item['origin']['path']).read_bytes()
            require(len(original) == item['origin']['bytes'] and sha(original) == item['origin']['sha256'], 'Compact control origin changed')
            observed = gzip.decompress(data) if item['kind'] == 'gzip_exact_byte_derivation' else data
            require(observed == original, 'Original control bytes changed')
    require([source_check(*pair) for pair in source_scopes] == source_before, 'Source changed during final control verification')
    qa = {'scope': 'Private archive/control/source integrity only; no target or new acceptance',
          'package': str(out), 'files': len(final_files), 'bytes': sum(p.stat().st_size for p in final_files),
          'archive_verification': archive_verification,
          'payload': fingerprint(payload), 'compact_index': fingerprint(out / 'compact-index.json'),
          'sha256sums': fingerprint(out / 'SHA256SUMS'), 'checksum_rows': len(parsed_sums),
          'all_original_member_control_bytes_and_gzip_hashes_verified': True,
          'all_source_inventories_before_after_identical': True,
          'original_native_status': top.get('passed'), 'native_top_nested_consistency': case_consistency,
          'historical_coordination_copied_root_report_only': True}
    qa_out.write_bytes(encoded(qa))
    print(json.dumps({'package': str(out), 'qa': fingerprint(qa_out),
                      'files': qa['files'], 'bytes': qa['bytes'], 'payload': qa['payload'],
                      'archive_verification': archive_verification, 'index': qa['compact_index'],
                      'sha256sums': qa['sha256sums']}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('PACKAGING FAILED; original records and any new output preserved: ' + repr(error), file=sys.stderr)
        raise
