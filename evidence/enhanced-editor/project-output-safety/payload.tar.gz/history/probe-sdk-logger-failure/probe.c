#include <stdio.h>
#include <string.h>
#include "project.h"
static struct pt_event events[256];
static uint16_t orders[1];
static uint8_t encoded[8192];
int main(void) {
 struct pt_project p={0};struct pt_sample s={0};
 union {size_t written;int32_t values[8];} master;
 enum pt_project_result result;int32_t before;
 pt_channels_init(&p.channels);p.orders=orders;p.events=events;p.order_count=p.pattern_count=1;p.sample_count=1;p.samples=&s;p.bpm=125;p.speed=6;
 master.values[0]=257;master.values[1]=-513;master.values[2]=1025;master.values[3]=-2049;
 s.pcm=(struct pt_pcm){master.values,8,4,48000,1,24};s.volume=64;before=master.values[0];
 result=pt_project_encode(&p,encoded,sizeof(encoded),&master.written);
 printf("PROJECT OUTPUT PROBE result=%u before=%ld after=%ld\n",(unsigned)result,(long)before,(long)master.values[0]);
 return result==PT_PROJECT_ALIAS && master.values[0]==before?0:20;
}
