#include <stdio.h>
#include <string.h>
#include "raw.h"
static union {size_t scalar;int32_t values[32];} master;
static unsigned char encoded[256], before_encoded[256];
static void reset(void)
{unsigned i;memset(&master,0,sizeof(master));for(i=0;i<4;++i)master.values[i]=257+(int32_t)i;memset(encoded,0x55,sizeof(encoded));memcpy(before_encoded,encoded,sizeof(encoded));}
int main(void)
{
 struct pt_pcm pcm={master.values,32,4,48000,1,24};struct pt_raw_format format={48000,24,1,0,0};
 enum pt_raw_result size_result,written_result,frames_result;int size_ok,written_ok,frames_ok;int32_t first;uint32_t rate;
 reset();first=master.values[0];size_result=pt_raw_size(&pcm,&format,&master.scalar);
 size_ok=size_result==PT_RAW_ALIAS && master.values[0]==first;
 printf("RAW SIZE PROBE result=%d before=%ld after=%ld\n",size_result,(long)first,(long)master.values[0]);
 reset();first=master.values[0];written_result=pt_raw_encode(&pcm,&format,encoded,sizeof(encoded),&master.scalar);
 written_ok=written_result==PT_RAW_ALIAS && master.values[0]==first && !memcmp(encoded,before_encoded,sizeof(encoded));
 printf("RAW WRITTEN PROBE result=%d before=%ld after=%ld\n",written_result,(long)first,(long)master.values[0]);
 rate=format.rate;frames_result=pt_raw_frames(12,&format,&format.rate);
 frames_ok=frames_result==PT_RAW_ALIAS && format.rate==rate;
 printf("RAW FRAMES PROBE result=%d before=%lu after=%lu\n",frames_result,(unsigned long)rate,(unsigned long)format.rate);
 return size_ok && written_ok && frames_ok?0:20;
}
