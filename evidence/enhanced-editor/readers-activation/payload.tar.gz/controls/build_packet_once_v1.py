"""Archive reviewed saved bytes only. Never invoke a producer, verifier or product.

Root must seal packet-inputs-final.json after the four actual proof reviews and
documentation review. This preparation is intentionally unusable while WAITING.
"""
import gzip, hashlib, io, json, stat, tarfile
from pathlib import Path

def require(ok, why):
    if not ok: raise ValueError(why)
def sha(b): return hashlib.sha256(b).hexdigest()
def mode(x): return int(x, 8) if isinstance(x, str) else x
def safe(n): return bool(n) and not n.startswith('/') and '\\' not in n and all(p not in ('', '.', '..') for p in n.split('/'))
def records(x):
    if isinstance(x, dict):
        if {'path', 'bytes', 'sha256'} <= x.keys(): yield x
        else:
            for v in x.values(): yield from records(v)
    elif isinstance(x, list):
        for v in x: yield from records(v)

r = Path(__file__).resolve().parent
i = json.loads((r / 'packet-inputs-final.json').read_bytes())
require(i['state'] == 'READY_ACTUAL_REVIEWED_INPUTS', 'final inputs are not ready')
require(not any(v is None for v in i['counts'].values()), 'unbound actual counts')
selected, aliases, sources, history_sources = {}, {}, {}, {}
def put(p, name=None, expected=None, tool=False):
    p = Path(p); require(p.is_file() and (tool or not p.is_symlink()), 'not a regular file: ' + str(p))
    b = p.read_bytes(); pm = stat.S_IMODE(p.stat().st_mode)
    if expected:
        require(len(b) == expected['bytes'] and sha(b) == expected['sha256'], 'changed saved input: ' + str(p))
        if 'mode' in expected: require(pm == mode(expected['mode']), 'changed mode: ' + str(p))
    name = name or ('blobs/' + sha(b) + '-' + format(pm, '04o'))
    require(safe(name), 'unsafe member')
    if name in selected: require(selected[name][1:] == (b, pm), 'conflicting member')
    else: selected[name] = (str(p), b, pm)
    if str(p) in aliases: require(selected[aliases[str(p)]][1:] == (b, pm), 'path reused with changed bytes')
    aliases[str(p)] = name
    return name
def addrec(x): return put(x['path'], expected=x)
def readrec(x): return json.loads(selected[addrec(x)][1])
def capture_report(x):
    for q in records(x): addrec(q)
    for key in ['compiler', 'python']:
        q = x[key]; member = put(q['path'], tool=True)
        require(sha(selected[member][1]) == q['sha256'], 'pinned executable changed')
def lane(x):
    report, execution = readrec(x['report']), readrec(x['execution'])
    require(execution['state'] == 'completed' and execution['driver_rc'] == x['driver_rc'], 'wrong saved lane outcome')
    require(len(execution['durable_copies']) == x['pairs'], 'wrong original/durable count')
    for pair in execution['durable_copies']:
        a, b = pair['original'], pair['durable']; na, nb = addrec(a), addrec(b)
        require(selected[na][1:] == selected[nb][1:], 'original/durable bytes or mode differ')
        aliases[a['path']] = nb
    capture_report(report)
    for product in report.get('products', []):
        member = put(product['archive_path'], expected=product)
        aliases[product['original_path']] = member  # ended temporary executable; preserved actual archive
    return report, execution

for role, x in i['reviews'].items():
    j = readrec(x['record']); require(j['status'] == x['status'], 'wrong exact review status: ' + role)
    if x.get('require_passed'): require(j.get('passed') is True, 'review did not pass: ' + role)
require(set(i['reviews']) == {'root_host', 'independent_host', 'root_native', 'independent_native', 'documentation'}, 'missing actual review role')
host, he = lane(i['host']); native, ne = lane(i['native'])
require(host['passed'] is True and native['passed'] is True and native['native_NOT_RUN'] is True, 'current proof did not pass within scope')
f = readrec(i['frozen_source']); p = readrec(i['protected_snapshot'])
baseline = readrec(i['baseline_manifest']); bm = baseline.get('source', baseline.get('files'))
require(f['base_commit'] == i['base_commit'] and f['base_tree'] == i['base_tree'], 'wrong baseline')
require(len(f['source']) == i['counts']['source_files'], 'wrong full source inventory')
require(set(f['source']) - set(bm) == set(i['owned_paths']) and all(f['source'][rel] == digest for rel, digest in bm.items()), 'not the exact additive five-path source change')
target = native['targets'][i['target']]
closure = set(host['canonical_dependencies']) | set(target['dependencies']) | set(i['clean_source_references'])
closure |= {rel for rel in i['owned_paths'] if not rel.startswith('docs/')}
require(not (set(host['canonical_dependencies']) | set(target['dependencies'])) & {q['path'] for q in p['preserved_files']}, 'protected file entered compiled closure')
for rel in sorted(closure):
    require(safe(rel) and not rel.startswith('docs/'), 'overlays cannot enter compiled source map')
    member = put(Path(i['source_export']) / rel, 'source/' + rel)
    require(sha(selected[member][1]) == f['source'][rel], 'source differs from frozen snapshot')
    sources[rel] = member
for depmap in [host['external_sdk_dependencies'], host['sanitizer_runtime_inputs'], host['pinned_sdk_inputs'], target['external_sdk_dependencies']]:
    for path, digest in depmap.items():
        member = put(path); require(sha(selected[member][1]) == digest, 'SDK/runtime changed')
for name, digest in native['runtime_inputs'].items():
    member = put(native['runtime_paths'][name]); require(sha(selected[member][1]) == digest, 'native runtime changed')
for x in i['controls']: addrec(x)  # explicit allowlist; no broad private-directory copy

histories = []
for x in i['failed_host_lanes']:
    old, oe = lane(x); sf = readrec(x['frozen_source']); readrec(x['classification'])
    require(old['passed'] is False and [c['product_returncode'] for c in old['commands']] == x['returncodes'], 'wrong retained failure')
    require(len(old['products']) == x['products'], 'wrong retained product count')
    sm = {}
    for rel in sorted(old['canonical_dependencies']):
        member = put(Path(old['source_export']) / rel)
        require(sha(selected[member][1]) == sf['source'][rel], 'historical source changed')
        sm[rel] = member
    histories.append(x); history_sources[x['name']] = sm
for x in i['source_history']:
    seal = readrec(x['seal']); owned = seal.get('owned_files', seal.get('members'))
    require(set(owned) == set(i['owned_paths']), 'wrong authored source history')
    for rel, rec in owned.items(): put(Path(x['directory']) / rel, expected=rec)
    for rec in x['records']: addrec(rec)
    for rel, rec in seal['original_dependency_files'].items():
        member = put(Path(i['source_export']) / rel, expected=rec)
        require(sha(selected[member][1]) == f['source'][rel], 'origin dependency changed')
    for rel, rec in seal['preserved_origin_files'].items(): put(Path(i['origin_directory']) / rel, expected=rec)
refusal = readrec(i['native_pre_dispatch_refusal'])
require(refusal['status'] == 'PRE_DISPATCH_PREPARATION_REFUSAL' and refusal['producer_invocations'] == 0 and refusal['output_exists'] is False, 'pre-dispatch history misclassified')
addrec(refusal['driver'])
overlays = {rel: addrec(rec) for rel, rec in i['post_build_overlays'].items()}
require(set(overlays) == {'docs/READERS_ACTIVATION.md', 'docs/SAMPLE_MEMORY.md'}, 'wrong final overlays')
put(r / 'packet-inputs-final.json', 'controls/packet-inputs-final.json')
put(Path(__file__), 'controls/build_packet_once_v1.py')
out = Path(i['output_directory']); require(not out.exists(), 'output already exists'); out.mkdir()
payload = out / 'payload.tar.gz'
with payload.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, (_, b, pm) in sorted(selected.items()):
                t = tarfile.TarInfo(name); t.size = len(b); t.mode = pm; t.mtime = 0
                t.uid = t.gid = 0; t.uname = t.gname = ''; tar.addfile(t, io.BytesIO(b))
m = {'scope': i['scope'], 'base_commit': i['base_commit'], 'base_tree': i['base_tree'],
     'payload': {'bytes': payload.stat().st_size, 'sha256': sha(payload.read_bytes())},
     'members': {n: {'bytes': len(b), 'sha256': sha(b), 'mode': pm, 'original_path': path} for n, (path, b, pm) in sorted(selected.items())},
     'path_members': dict(sorted(aliases.items())), 'source_members': sources,
     'history_source_members': history_sources, 'post_build_overlays': overlays,
     'inputs': 'controls/packet-inputs-final.json', 'acceptance': i['acceptance']}
(out / 'manifest.json').write_text(json.dumps(m, indent=2) + '\n')
(out / 'verify.py').write_bytes((r / 'verify_packet_v1.py').read_bytes())
(out / 'README.md').write_text(i['readme'])
print(json.dumps({'state': 'BUILT_SAVED_BYTES_ONLY', 'members': len(selected), 'sources': len(sources), 'payload': m['payload']}))
