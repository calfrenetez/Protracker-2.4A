"""Post-build prose overlays only. Keep the frozen compiled candidate unchanged."""
import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
old=r.parent/'song-compact-8iftv2vr/backend-registration-draft-v1/documentation-revision-v2/docs/READERS_BACKEND_REGISTRATION.md'
s=old.read_text().replace('## Evidence to bind after actual validation','## Actual saved validation')
s=s.replace('Host results below are bound to completed actual receipts and saved bytes. The\ncompiler field remains conditional until its actual proof and independent review\nare supplied. A source seal or prepared helper cannot fill a PASS result. Preserve\nprior failed attempts or reader refusals and their classifications separately.','Host and compiler results below bind completed actual receipts and saved bytes.\nNative execution remains separate. Prior saved-reader refusals and classifications\nare retained; neither the passed host run nor the compiler build was repeated.')
s=s.replace('PENDING: root supplies actual final source/ABI2 binding, 31-TU recipe, compiler/runtime/SDK/assertion closure, HUNK identity and independent review. Ordinary malloc entry; no Exec wrapper.','PASS: first/once 42 RC0 commands, 31 ordered full-M queries, 75 canonical and 32 SDK dependencies, seven pinned runtimes, enabled SDK assertions and one complete CPP/HUNK registration marker. HUNK216820 B SHA25672b40262c3c6c54351f7b1fe94042d8672f4a8a4a99e19ed99d60402bfebbf9f. Ordinary malloc entry; no Exec wrapper or execution.')
s=s.replace('All 195 durable\ncopy pairs','All 195 host durable\ncopy pairs')
s=s.replace('These are synthetic software ownership results, not target timing or\nmemory-placement observations.','These are synthetic software ownership results, not target timing or\nmemory-placement observations. The compiler record and its 45 original/durable\ncopy pairs retain the separate portable HUNK; no native product was executed.\nSee [saved evidence](../evidence/enhanced-editor/readers-backend-registration/README.md).')
assert 'PENDING:' not in s
(r/'READERS_BACKEND_REGISTRATION.final.md').write_text(s)
base=(r/'candidate/docs/SAMPLE_MEMORY.md').read_bytes();needle=b'## Scheduled output ownership foundation';assert base.count(needle)==1
insert='''## Public backend registration identities — 5 October 2026

The optional readers descriptor contract now uses version2 and publishes copied
opaque command and persistent-reader context/extent identities. This lets a
separately compiled backend form the exact receipts already required by the core;
it exposes no owner current/release/terminal callbacks or storage-access right.
Version1 backends are refused before allocation/callbacks. The original frame,
private envelope, positive ACTIVE and independent release rules remain unchanged.
Before reporting detachment or retirement the backend drops every corresponding
reference. Core reader storage separately waits for exact retirement and zero
referencing commands; surviving commands cannot revive a retired reader.

Seven affected ASan/UBSan host groups pass once:14 compile/run RC0,172 full-M,
84 canonical/105 SDK dependencies and7 products. The public-header-only fixture
uses genuine current mono8/16/24 masters and public identities only, two commands,
explicit original STOP and independent retirement orders. Old-version refusal,
forged contexts/extents, uncertain accepted submission, unchanged caller outputs
and alias refusal before either backend poll callback run through the final
assertion footer. These are synthetic software results, with no activation driver.

The separate ordinary-malloc public31-TU HUNK builds once:42RC0/75canonical32SDK/
seven pinned runtimes, enabled assertions and one complete CPP/HUNK marker.
PTReadersBackendRegistrationTest216820B/SHA72b40262c3c6c54351f7b1fe94042d8672f4a8a4a99e19ed99d60402bfebbf9f
is native/emulator/physical NOT_RUN. Fast/Chip placement, total stack and65536
launcher remain unqualified. Older compact protocol1 compiler evidence stays in
its exact historical scope; it does not qualify these version2 descriptors.
Mixed AmiGUS formats/card addresses, editor PLAY, native activation/IRQ/device
stop/order/completion/timing/audio/listening remain separate unfinished work.
See [registration contract](READERS_BACKEND_REGISTRATION.md) and
[saved evidence](../evidence/enhanced-editor/readers-backend-registration/README.md).

'''.encode()
final=base.replace(needle,insert+needle,1);(r/'SAMPLE_MEMORY.registration-final.md').write_bytes(final)
def rec(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(r/'documentation-overlays-v1.json').write_text(json.dumps({'scope':'Post-build prose only; compiled candidate unchanged','prior_registration_doc':rec(old),'base_sample_memory':rec(r/'candidate/docs/SAMPLE_MEMORY.md'),'owned':{'docs/READERS_BACKEND_REGISTRATION.md':rec(r/'READERS_BACKEND_REGISTRATION.final.md'),'docs/SAMPLE_MEMORY.md':rec(r/'SAMPLE_MEMORY.registration-final.md')},'host':rec(r/'host-final-v1/host-checks.json'),'native':rec(r/'native-final-v1/manifest.json'),'native_execution':'NOT_RUN','independent_native_review':'PENDING_at_doc_draft'},indent=2)+'\n')
(r/'documentation-script-syntax-refusal-v1.json').write_text(json.dumps({'scope':'Earlier unexecuted inline prose-generation script parsing refusal','error':'SyntaxError bytes can only contain ASCII literal characters at insert byte literal containing em dash','mutation_before_refusal':'NONE: Python parsing failed before execution','correction':'UTF8 text literal then encode, saved as prepare_final_docs.py','product_or_test_rerun':False},indent=2)+'\n')
print('Post-build documentation prepared; candidate unchanged')
