"""Once-only exact reviewed public registration and six affected sanitizer groups."""
import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
inputs=json.loads((root/'inputs.json').read_bytes());prep=Path(inputs['host_preparation'])
python='/opt/homebrew/opt/python@3.14/bin/python3.14'
output=Path('/private/tmp/pt-readers-registration-x0i881jw-host-v1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&0o777}
manifest=root/'frozen-source-v1.json';pins=prep/'toolchain-pins.json';helper=prep/'host_provenance.py'
review=json.loads((root/'final-frozen-source-review-v1.json').read_bytes());assert review['status']=='CLEAR'
assert json.loads((prep/'independent-preparation-review-v1.json').read_bytes())['status'].startswith('CLEAR')
prepared=json.loads((prep/'prepared-files-v1.json').read_bytes())
for r in prepared['members'].values():assert sha(r['path'])==r['sha256'] and Path(r['path']).stat().st_size==r['bytes']
assert not output.exists() and not (root/'host-execution-v1.json').exists() and not (root/'host-final-v1').exists()
controls={'scope':'Root approved first public registration V2 plus six directly affected software ownership groups; host ASan/UBSan only','groups':['test_readers_backend_registration','test_scheduled_readers','test_sampler_paula_readers','test_sampler_paula_readers_boundary','test_paula_readers_song','test_paula_readers_song_workspace','test_paula_readers_song_compact'],'inputs':[rec(p) for p in [manifest,helper,prep/'provenance_common.py',pins,root/'final-frozen-source-review-v1.json',prep/'independent-preparation-review-v1.json']], 'emulator':'NOT_RUN','physical':'NOT_RUN'}
(root/'approved-host-controls-v1.json').write_text(json.dumps(controls,indent=2)+'\n')
argv=[python,'-B',str(helper),'--source',str(root/'candidate'),'--source-manifest',str(manifest),'--source-manifest-sha256',sha(manifest),'--pins',str(pins),'--pins-sha256',sha(pins),'--out',str(output)]
execution={'scope':controls['scope'],'argv':argv,'state':'dispatched once','emulator':'NOT_RUN','physical':'NOT_RUN'}
(root/'host-execution-v1.json').write_text(json.dumps(execution,indent=2)+'\n')
with (root/'host-driver-stdout-v1.txt').open('xb') as stdout,(root/'host-driver-stderr-v1.txt').open('xb') as stderr:
 completed=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
execution.update({'state':'completed','driver_rc':completed.returncode,'original_out':str(output)})
if output.exists():
 durable=root/'host-final-v1';shutil.copytree(output,durable)
 copies=[]
 for p in sorted(output.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():
   q=durable/p.relative_to(output);assert p.read_bytes()==q.read_bytes() and (p.stat().st_mode&0o777)==(q.stat().st_mode&0o777)
   copies.append({'original':rec(p),'durable':rec(q)})
 execution['durable_copies']=copies
(root/'host-execution-v1.json').write_text(json.dumps(execution,indent=2)+'\n')
print(json.dumps({'state':execution['state'],'rc':completed.returncode,'durable_files':len(execution.get('durable_copies',[]))}))
raise SystemExit(completed.returncode)
