# Public readers backend registration bindings

This separate draft changes only the opt-in `scheduled_readers` descriptor ABI
and increments `PT_READERS_VERSION` from 1 to 2. A backend declaring version1 is
refused before queue allocation. Original scheduled flags7 and lineage-v1 are
unchanged. Existing frozen compiler products are not silently eligible for this
new descriptor ABI; future products need matching source/runtime binding.
Five existing fixture copies replace only seven numeric version1 constructors
with `PT_READERS_VERSION`. Existing compact V3 already uses that macro; its frozen
source and proof stay unchanged. The declared reference flags retain their values.

A published `pt_readers_event` carries `binding={context,context_bytes}` for its
complete command holder. Each immutable `pt_readers_domain` separately carries
the exact binding of its independently held persistent-reader control. The core
copies these opaque identity values from its already staged genuine declarations;
there is no retained caller control pointer and no new callback or allocation.
The binding is not a memory access API: backends must not dereference, copy,
mutate, release or invoke an owner through it. No owner current/release/terminal
function is exposed. Full reader resource spans retain their separate meaning.

A backend may copy binding identities into receipts alongside the complete
original queue/session/generation/ticket/token/key and registered descriptor
address. The existing private-holder envelope comparisons remain unchanged:
forged contexts/extents cannot authorize release, even if other identity fields
match. Descriptor addresses and opaque bindings are borrowed until the backend's
independently positive corresponding detachment/retirement proof. Command
reference cessation and reader reference cessation remain separate obligations.
Reader disposal also waits for zero referencing commands. After detachment or
retirement, the backend must drop all corresponding pointers and never inspect a
recycled command descriptor as the old ticket. Numeric historical IDs alone do
not create new ownership or activity permission.

Bindings prove neither source currentness nor ACTIVE, ADOPTED, command detach,
reader retirement, upload completion or voice-stop. Existing core task-side owner
checks and the backend's atomic actual-key/current-device validation at activation
remain required. Activation cannot traverse owners or allocate/convert. The exact
original `ceil(frame*frequency/rate)` admission windows are unchanged; no
immediate-start, predicted timestamp or rebase fallback is introduced.

The proposed public-header-only fixture compiles queue, reader adapter and song
producer as separate translation units. It uses real sampler-owned 8/16/24-bit
masters, full-capacity before-images, caller-sized discarded scratch, the genuine
initial setup/audit/same sequence/lookahead, real selective cache leases and a
synthetic backend. Receipts obtain context/extent solely from public descriptor
bindings; there are no private queue/holder casts or exposed owner callbacks.
It proposes both independent retirement orders, retained reader identity across
command-slot reuse, obsolete-version refusal without allocation, wrong command
and reader contexts/extents, uncertain accepted submission, unchanged refusal
outputs and exact proof-driven cleanup after sticky failure. These are source
claims pending execution, not a PASS result.

Draft/source review only: no host/compiler/product/native/target execution has
occurred. No native backend, IRQ exclusion, DMA, AmiGUS capacity/order/completion,
actual hardware activation/timing, audio or listening is implemented or qualified.
This Paula signed8/four-slot descriptor does not represent AmiGUS card addresses,
16-bit representations or rate/gain controls. A future mixed ABI is separate.
