#!/usr/bin/env python3
"""Pinned public-header-only readers registration compiler/link preparation.

A source-only derivative of the reviewed compact portability builder. Literal
31-TU order, public-header-only fixture and full completion marker are checked
as data before any compiler call. A pinned contract, toolchain pins and root's
complete final frozen source manifest (including base_commit/base_tree) are
required. Root approval after actual host PASS and final source review remains
separate; this preparation does not authorize invocation.

This target uses the shared fixture's ordinary malloc entry, with no native
Exec wrapper and no private implementation C inclusion. All genuine production
implementations are compiled separately. A successful link cannot prove native
malloc/Fast/Chip placement, target execution, activation, reader stop, hardware
timing or listening. Legacy large-stack functions remain compiled/exported.
No stack annotations are added to functional flags; total native stack and
Stack 65,536 remain UNKNOWN/NOT_CLEARED.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys
import time
import traceback

REGISTRATION_FIXTURE = 'tests/readers_backend_registration_test.c'
REGISTRATION_DECLARATION = 'tests/test_readers_backend_registration.py'
SCHEDULED_IMPLEMENTATION = 'src/core/scheduled_readers.c'
READER_IMPLEMENTATION = 'src/editor/sampler_paula_readers.c'
SONG_IMPLEMENTATION = 'src/editor/paula_readers_song.c'
TARGET = 'PTReadersBackendRegistrationTest'
# Exact source bindings are sealed separately; this does not authorize a build.
# Root must first review host PASS and supply its final canonical export.
PREPARATION_READY = True
REGISTRATION_SOURCES = ['tests/readers_backend_registration_test.c', 'src/editor/sampler_paula.c', 'src/core/sample_cache.c', 'src/core/playback_pcm.c', 'src/core/elapsed_clock.c', 'src/core/scheduled_readers.c', 'src/core/paula_render_voice.c', 'src/editor/sampler.c', 'src/editor/slots.c', 'src/core/pcm_filtered.c', 'src/core/slices.c', 'src/core/pattern.c', 'src/core/document.c', 'src/core/pp20.c', 'src/core/project.c', 'src/core/mod_project.c', 'src/core/mod_inspect.c', 'src/core/channels.c', 'src/core/pcm.c', 'src/core/wav.c', 'src/core/svx.c', 'src/core/raw.c', 'src/editor/paula_preflight.c', 'src/core/render.c', 'src/core/pitch.c', 'src/core/timeline.c', 'src/core/frame_clock.c', 'src/core/flow.c', 'src/core/voice.c', 'src/editor/sampler_paula_readers.c', 'src/editor/paula_readers_song.c']
REGISTRATION_MARKER = 'READERS BACKEND REGISTRATION PASS: public opaque bindings; genuine independent software ownership; no activation or hardware timing proof'
REGISTRATION_QUOTED_INCLUDES = ['../src/core/scheduled_readers.h', '../src/editor/paula_readers_song.h']
REGISTRATION_FOOTERS = [REGISTRATION_MARKER]
EXPECTED_REGISTRATION_SOURCE_SET = set(REGISTRATION_SOURCES)
FLAGS = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
         '-Wall', '-Wextra', '-Werror', '-Isrc/core', '-Ibuild/dev', '-fbbb=-']
RUNTIMES = ['ncrt0.o', 'libnix20.a', 'libnixmain.a', 'libnix.a',
            'libstubs.a', 'libamiga.a', 'libgcc.a']
SOURCES = []
FIXTURE_CONTRACT = {}
EXPECTED_MARKER = ''
SCOPE = ('Portable pinned public-registration 68k compile/link only; shared '
         'ordinary-malloc fixture, no Exec wrapper, HUNK execution, native '
         'malloc/Fast/Chip placement, DMA/device, activation, IRQ, audio or '
         'hardware timing/total-stack proof')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}


def require_pin(path, expected):
    p = Path(path)
    if not p.is_file() or digest(p) != expected:
        raise ValueError('Pinned input absent or changed: ' + str(p))


def snapshot(source):
    result = {}
    for p in sorted(source.rglob('*')):
        if p.is_symlink():
            raise ValueError('Frozen source contains a symlink: ' + str(p))
        if p.is_file():
            result[p.relative_to(source).as_posix()] = digest(p)
    return result


def require_source(source, expected):
    if snapshot(source) != expected:
        raise ValueError('Complete frozen source inventory changed')


def source_fingerprint(expected):
    return hashlib.sha256(json.dumps(expected, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def below(p, root):
    return p == root or root in p.parents


def write_json(path, value):
    staged = path.with_suffix(path.suffix + '.writing')
    staged.write_text(json.dumps(value, indent=2) + '\n')
    staged.replace(path)


def dependencies(output):
    output = re.sub(r'\\\r?\n', ' ', output)
    names = []
    for line in output.splitlines():
        colon = re.search(r'(?<!\\):', line)
        if colon:
            names.extend(shlex.split(line[colon.end():]))
    return list(dict.fromkeys(names))


def recipe_contract(source, expected, pins):
    """Read exact sealed declarations and inclusions as data; never import tests."""
    recipe = source / 'tools/build_core_tests.py'
    require_pin(recipe, pins['canonical_recipe']['sha256'])
    tree = ast.parse(recipe.read_text())
    flags = next(n.value for n in ast.walk(tree) if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == 'flags' for t in n.targets))
    literals = [n.value for n in flags.elts if isinstance(n, ast.Constant)]
    expansions = [ast.unparse(n.value) for n in flags.elts if isinstance(n, ast.Starred)]
    if literals != FLAGS[:-1] or expansions != ['compiler_safety_flags(cc)']:
        raise ValueError('Committed native flag convention changed')
    diagnostic = source / 'tools/build_diagnostic.py'
    require_pin(diagnostic, expected['tools/build_diagnostic.py'])
    d = ast.parse(diagnostic.read_text())
    fn = next(n for n in d.body if isinstance(n, ast.FunctionDef) and n.name == 'runtime_inputs')
    declared = next(ast.literal_eval(n.value) for n in fn.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'names' for t in n.targets))
    if declared != RUNTIMES:
        raise ValueError('Committed seven-runtime convention changed')
    host = source / REGISTRATION_DECLARATION
    h = ast.parse(host.read_text())
    declarations = [n for n in h.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'REGISTRATION_SOURCES' for t in n.targets)]
    if (len(declarations) != 1 or len(declarations[0].targets) != 1 or
            not isinstance(declarations[0].value, ast.List) or
            any(not isinstance(n, ast.Constant) or not isinstance(n.value, str)
                for n in declarations[0].value.elts)):
        raise ValueError('Exactly one literal registration source list required')
    units = ast.literal_eval(declarations[0].value)
    if (units != REGISTRATION_SOURCES or len(units) != 31 or
            len(units) != len(set(units)) or set(units) != EXPECTED_REGISTRATION_SOURCE_SET or
            units[0] != REGISTRATION_FIXTURE or SCHEDULED_IMPLEMENTATION not in units or
            READER_IMPLEMENTATION not in units or SONG_IMPLEMENTATION not in units):
        raise ValueError('Exact sealed literal 31-TU public-registration source list required')
    if SOURCES != units:
        raise ValueError('Compile the shared public fixture first, with every implementation separate')
    fixture_text = (source / REGISTRATION_FIXTURE).read_text()
    if re.findall(r'^\s*#\s*include\s+[<"]([^"<>\n]+\.c)[>"]', fixture_text, re.MULTILINE):
        raise ValueError('Public fixture must not include any private implementation/test C')
    includes = re.findall(r'^\s*#\s*include\s+"([^"\n]+)"', fixture_text, re.MULTILINE)
    if includes != REGISTRATION_QUOTED_INCLUDES:
        raise ValueError('Exact public-header-only fixture inclusion shape changed')
    if re.search(r'\b(?:command_entry|reader_entry)\b', fixture_text):
        raise ValueError('Public fixture must not access private registry entry types')
    if re.search(r'\bpt_paula_readers_song_begin\s*\(', fixture_text):
        raise ValueError('Public fixture must not call the legacy large-stack constructor')
    footers = re.findall(r'^\s*puts\("([^"\n]*)"\);', fixture_text, re.MULTILINE)
    if footers != REGISTRATION_FOOTERS or fixture_text.count(REGISTRATION_MARKER) != 1:
        raise ValueError('Exact full public-registration completion marker required once')
    header = source / 'src/core/scheduled_readers.h'
    require_pin(header, expected['src/core/scheduled_readers.h'])
    header_text = header.read_text()
    if (re.findall(r'^#define PT_READERS_VERSION (\d+)U$', header_text, re.MULTILINE) != ['2'] or
            re.findall(r'struct pt_readers_binding\s*\{([^}]*)\};', header_text) !=
                ['void *context;size_t context_bytes;']):
        raise ValueError('Opt-in version2 public opaque identity-binding contract required')
    chain = [REGISTRATION_FIXTURE]
    if FIXTURE_CONTRACT['include_chain'] != chain:
        raise ValueError('Public fixture is the sole C inclusion root; no wrapper/private C chain')
    return {'committed_flag_recipe': record(recipe), 'committed_runtime_recipe': record(diagnostic),
            'host_declaration': record(host), 'exact_ordered_host_translation_units': units,
            'exact_ordered_translation_units': SOURCES, 'include_chain': chain,
            'source_footer_gates': REGISTRATION_FOOTERS,
            'primary_CPP_HUNK_marker': REGISTRATION_MARKER,
            'public_binding_header': record(header), 'public_contract_version': 2,
            'included_sources': [],
            'separately_compiled_genuine_implementations': [record(source / SCHEDULED_IMPLEMENTATION), record(source / READER_IMPLEMENTATION), record(source / SONG_IMPLEMENTATION)],
            'adapter_inclusion': 'Public fixture includes scheduled_readers.h and paula_readers_song.h only; no implementation/test C is included, and core/readers/song are separate translation units',
            'entry_scope': 'Shared ordinary-malloc main; no native Exec wrapper or native memory-class acceptance',
            'legacy_constructor_scope': 'Not called by this fixture; still compiled/exported with genuine production song and may remain in HUNK',
            'flags': FLAGS, 'runtime_names': RUNTIMES,
            'policy': 'Standalone one-target pinned compiler/link only, preserving prior functional proof body and committed flags/runtime checks; no product execution or launch qualification'}

def main():
    global SOURCES, TARGET, FIXTURE_CONTRACT, EXPECTED_MARKER
    if not PREPARATION_READY:
        raise ValueError('Final reviewed source/footer/include bindings are not yet sealed; preparation only')
    sys.dont_write_bytecode = True
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--fixture-contract', type=Path, required=True)
    ap.add_argument('--fixture-contract-sha256', required=True)
    ap.add_argument('--source-manifest', type=Path, required=True)
    ap.add_argument('--source-manifest-sha256', required=True)
    ap.add_argument('--pins', type=Path, required=True)
    ap.add_argument('--pins-sha256', required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    source = args.source.resolve()
    out = args.out.resolve()
    manifest_input, pin_input = args.source_manifest.resolve(), args.pins.resolve()
    if out.exists() or below(out, source) or below(source, out):
        raise ValueError('Output must be fresh and outside source')
    if below(manifest_input, out) or below(pin_input, out):
        raise ValueError('Input controls must be outside output')
    contract_input = args.fixture_contract.resolve()
    if below(contract_input, out):
        raise ValueError('Fixture contract must be outside output')
    require_pin(contract_input, args.fixture_contract_sha256)
    FIXTURE_CONTRACT = json.loads(contract_input.read_text())
    if set(FIXTURE_CONTRACT) != {'fixture', 'host_declaration', 'source_constant', 'target', 'marker', 'ordered_sources', 'include_chain'}:
        raise ValueError('Exactly the declared one-fixture contract fields required')
    for name in ('fixture', 'host_declaration'):
        path = FIXTURE_CONTRACT[name]
        if not isinstance(path, str) or Path(path).is_absolute() or '..' in Path(path).parts or Path(path).as_posix() != path:
            raise ValueError('Noncanonical fixture contract path')
    if (FIXTURE_CONTRACT['fixture'] != REGISTRATION_FIXTURE or
            FIXTURE_CONTRACT['host_declaration'] != REGISTRATION_DECLARATION or
            FIXTURE_CONTRACT['source_constant'] != 'REGISTRATION_SOURCES' or
            FIXTURE_CONTRACT['target'] != 'PTReadersBackendRegistrationTest' or
            FIXTURE_CONTRACT['marker'] != REGISTRATION_MARKER or
            not isinstance(FIXTURE_CONTRACT['marker'], str) or
            any(c in FIXTURE_CONTRACT['marker'] for c in '\r\n\0')):
        raise ValueError('Exact one-target public-registration portability fixture identity required')
    TARGET, EXPECTED_MARKER = FIXTURE_CONTRACT['target'], FIXTURE_CONTRACT['marker']
    SOURCES = list(REGISTRATION_SOURCES)
    chain = [REGISTRATION_FIXTURE]
    if (FIXTURE_CONTRACT['ordered_sources'] != SOURCES or len(SOURCES) != 31 or
            len(SOURCES) != len(set(SOURCES)) or FIXTURE_CONTRACT['include_chain'] != chain):
        raise ValueError('Exact ordered 31-TU public-registration source closure required')
    require_pin(manifest_input, args.source_manifest_sha256)
    require_pin(pin_input, args.pins_sha256)
    complete = json.loads(manifest_input.read_text())
    expected = complete['files']
    if not isinstance(expected, dict) or not expected:
        raise ValueError('Full source manifest dictionary required')
    require_source(source, expected)
    all_pins = json.loads(pin_input.read_text())
    pins, python = all_pins['native'], all_pins['host']['python']
    compiler = pins['compiler']['path']
    if Path(sys.executable).resolve() != Path(python['path']).resolve() or sys.version != python['version']:
        raise ValueError('Python executable/version does not match supplied pin')
    require_pin(python['path'], python['sha256'])
    require_pin(compiler, pins['compiler']['sha256'])
    if set(pins['runtime_inputs']) != set(RUNTIMES):
        raise ValueError('Exactly seven runtime pins required')
    sdk_roots = [Path(p).resolve() for p in pins['allowed_sdk_roots']]
    if not sdk_roots:
        raise ValueError('Explicit native SDK roots required')
    convention = recipe_contract(source, expected, all_pins)
    builder = record(Path(__file__).resolve())
    out.mkdir(parents=True)
    started = time.monotonic()
    commands, compile_commands, runtime_paths, sdk_inputs, canonical_inputs = [], [], {}, {}, {}
    result = {'scope': SCOPE, 'passed': False, 'source_export': str(source),
              'source_manifest': record(manifest_input), 'pins': record(pin_input),
              'fixture_contract': record(contract_input), 'native_NOT_RUN': True,
              'base_commit': complete['base_commit'], 'base_tree': complete['base_tree'],
              'source_files_before': len(expected), 'source_fingerprint': source_fingerprint(expected),
              'compiler': pins['compiler'], 'python': python, 'builder': builder,
              'recipe_contract': convention, 'flags': FLAGS, 'runtime_inputs': {},
              'runtime_paths': runtime_paths, 'commands': commands, 'targets': {}}

    def persist():
        command_path = out / 'compile-commands.json'
        write_json(command_path, {'commands': compile_commands})
        result['compile_commands'] = record(command_path)
        result['elapsed_s'] = time.monotonic() - started
        write_json(out / 'manifest.json', result)

    def run(argv, label):
        row = {'label': label, 'argv': argv, 'directory': str(source)}
        commands.append(row)
        persist()
        completed = subprocess.run(argv, cwd=source, capture_output=True, text=True, timeout=180)
        log = out / (label + '.log')
        log.write_text(completed.stdout + completed.stderr)
        row.update(returncode=completed.returncode, log=record(log))
        persist()
        if completed.returncode:
            raise subprocess.CalledProcessError(completed.returncode, argv, completed.stdout, completed.stderr)
        return completed.stdout

    def toolchain_current():
        require_pin(compiler, pins['compiler']['sha256'])
        require_pin(python['path'], python['sha256'])
        for name, path in runtime_paths.items():
            require_pin(path, pins['runtime_inputs'][name])

    try:
        persist()
        if run([compiler, '--version'], 'compiler-version').splitlines()[0] != pins['compiler']['version']:
            raise ValueError('Native compiler version changed')
        if '-fbbb=' not in run([compiler, '--help=target'], 'compiler-target-help'):
            raise ValueError('Required late-optimizer safety flag unavailable')
        for name in RUNTIMES:
            path = Path(run([compiler, '-m68000', '-msoft-float', '-mcrt=nix20', '-print-file-name=' + name],
                            'runtime-' + name.replace('.', '-')).strip()).resolve()
            require_pin(path, pins['runtime_inputs'][name])
            runtime_paths[name] = str(path)
            result['runtime_inputs'][name] = pins['runtime_inputs'][name]
        for index, unit in enumerate(SOURCES):
            toolchain_current()
            text = run([compiler, *FLAGS, '-M', unit], 'dependencies-%02d' % index)
            for name in dependencies(text):
                path = (source / name).resolve()
                if below(path, source):
                    key = path.relative_to(source).as_posix()
                    if key not in expected:
                        raise ValueError('Unknown canonical dependency: ' + key)
                    require_pin(path, expected[key]);canonical_inputs[key] = expected[key]
                elif any(below(path, root) for root in sdk_roots):
                    sdk_inputs[str(path)] = digest(path)
                else:
                    raise ValueError('Dependency outside frozen source and pinned SDK roots: ' + str(path))
        text = run([compiler, *FLAGS, '-E', '-dD', SOURCES[0]], 'preprocessed-fixture')
        assertions = re.findall(r'^#define assert\([^\n]*', text, re.MULTILINE)
        assertion = assertions[-1] if assertions else None
        if not assertion or '__assert_func' not in assertion or text.count('__assert_func (') < 2:
            raise ValueError('Enabled SDK assertion expansion required')
        if text.count(EXPECTED_MARKER) != 1:
            raise ValueError('Public-registration shared fixture marker missing')
        toolchain_current()
        require_source(source, expected)
        binary = out / TARGET
        argv = [compiler, *FLAGS, *SOURCES, '-o', str(binary)]
        compile_commands.append({'name': TARGET, 'directory': str(source), 'argv': argv,
                                 'output': str(binary), 'ordered_translation_units': SOURCES})
        run(argv, TARGET + '.build')
        raw = binary.read_bytes()
        if len(raw) < 4 or struct.unpack('>I', raw[:4])[0] != 0x3f3:
            raise ValueError('Linked native product lacks HUNK_HEADER0x3f3')
        if raw.count(EXPECTED_MARKER.encode()) != 1:
            raise ValueError('Linked product lacks shared assertion-completion marker')
        result['targets'][TARGET] = {'scope': SCOPE, 'source_inputs': SOURCES, 'flags': FLAGS,
                                     'dependencies': dict(sorted(canonical_inputs.items())),
                                     'external_sdk_dependencies': dict(sorted(sdk_inputs.items())),
                                     'binary': record(binary), 'format': 'HUNK_HEADER0x000003f3',
                                     'last_assert_macro': assertion,
                                     'preprocessed_fixture': record(out / 'preprocessed-fixture.log'),
                                     'build_log': record(out / (TARGET + '.build.log'))}
        result['passed'] = True
    except Exception as error:
        result['failure'] = {'kind': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    finally:
        try:
            toolchain_current()
            for path, value in sdk_inputs.items():
                require_pin(path, value)
            require_source(source, expected)
            require_pin(manifest_input, args.source_manifest_sha256)
            require_pin(pin_input, args.pins_sha256)
            require_pin(builder['path'], builder['sha256'])
            require_pin(contract_input, args.fixture_contract_sha256)
            for name in ['tools/build_core_tests.py', 'tools/build_diagnostic.py', FIXTURE_CONTRACT['host_declaration'], *FIXTURE_CONTRACT['include_chain'], SCHEDULED_IMPLEMENTATION, READER_IMPLEMENTATION, SONG_IMPLEMENTATION]:
                require_pin(source / name, expected[name])
            result['source_files_after'] = len(expected)
        except Exception as error:
            result['passed'] = False
            result['final_provenance_error'] = {'kind': type(error).__name__, 'message': str(error)}
        persist()
    print(json.dumps({'passed': result['passed'], 'scope': SCOPE, 'manifest': str(out / 'manifest.json')}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
