"""Saved-byte review only; never import a helper or invoke a compiler/product."""
import hashlib,json,re,struct
from pathlib import Path
r=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(x):
 p=Path(x['path']);assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
 if 'mode' in x:assert p.stat().st_mode&0o777==x['mode']
def rec(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
e=json.loads((r/'native-execution-v1.json').read_bytes());assert e['driver_rc']==0 and e['native_execution']=='NOT_RUN'
for pair in e['durable_copies']:
 check(pair['original']);check(pair['durable']);assert Path(pair['original']['path']).read_bytes()==Path(pair['durable']['path']).read_bytes()
assert len(e['durable_copies'])==45
m=json.loads((r/'native-final-v1/manifest.json').read_bytes());assert m['passed'] and m['native_NOT_RUN']
assert len(m['commands'])==42 and all(c['returncode']==0 for c in m['commands'])
assert m['source_files_before']==m['source_files_after']==8142
for c in m['commands']:check(c['log'])
for key in ['source_manifest','pins','fixture_contract','builder','compile_commands']:check(m[key])
f=json.loads((r/'frozen-source-v1.json').read_bytes())
actual={p.relative_to(r/'candidate').as_posix():sha(p) for p in (r/'candidate').rglob('*') if p.is_file()}
assert actual==f['files']
contract=json.loads(Path(m['fixture_contract']['path']).read_bytes())
t=m['targets']['PTExecReadersBackendRegistrationTest']
assert t['source_inputs']==contract['ordered_sources'] and len(t['source_inputs'])==31
depcommands=[c for c in m['commands'] if c['label'].startswith('dependencies-')]
assert len(depcommands)==31
assert [c['argv'][-1] for c in depcommands]==t['source_inputs']
for n,h in t['dependencies'].items():assert f['files'][n]==h and sha(r/'candidate'/n)==h
for n,h in t['external_sdk_dependencies'].items():assert sha(n)==h
pin=json.loads(Path(m['pins']['path']).read_bytes())
for group in [pin['native']['compiler'],pin['host']['python']]:assert sha(group['path'])==group['sha256']
for n,h in m['runtime_inputs'].items():assert h==pin['native']['runtime_inputs'][n] and sha(m['runtime_paths'][n])==h
assert len(m['runtime_inputs'])==7
assert all(v==1 for v in m['CPP_required_marker_counts'].values()) and len(m['CPP_required_marker_counts'])==3
assert all(v==1 for v in m['HUNK_required_marker_counts'].values()) and len(m['HUNK_required_marker_counts'])==3
check(t['binary']);check(t['preprocessed_fixture']);check(t['build_log'])
binary=Path(t['binary']['path']).read_bytes();assert struct.unpack('>I',binary[:4])[0]==0x3f3
cpp=Path(t['preprocessed_fixture']['path']).read_text()
assert '__assert_func' in t['last_assert_macro']
for marker in m['CPP_required_marker_counts']:assert cpp.count(marker)==1
for marker in m['HUNK_required_marker_counts']:assert binary.count(marker.encode())==1
tokens=len(re.findall(r'\b__assert_func\s*\(',cpp))
macro_lines=[line for line in cpp.splitlines() if line.startswith('#define assert(')]
decls=len(re.findall(r'void __assert_func\s*\(',cpp))
assert tokens==133 and len(macro_lines)==2 and decls==2
out={'status':'CLEAR','review':'root saved-byte audit only; no helper/compiler/product execution',
 'inputs':[rec(r/'native-execution-v1.json'),rec(r/'native-final-v1/manifest.json'),rec(r/'frozen-source-v1.json')],
 'source_files':len(actual),'commands_RC0':42,'ordered_full_M':31,'canonical_dependencies':len(t['dependencies']),
 'external_SDK_dependencies':len(t['external_sdk_dependencies']),'runtime_inputs':7,'durable_pairs':45,
 'binary':t['binary'],'CPP':t['preprocessed_fixture'],'assert_matching_tokens':tokens,
 'assert_macro_definitions':len(macro_lines),'assert_declarations':decls,'expanded_assert_calls':tokens-len(macro_lines)-decls,
 'three_full_CPP_HUNK_markers':True,'native_execution':'NOT_RUN','emulator':'NOT_RUN','physical':'NOT_RUN',
 'stack':'UNKNOWN; 65536 NOT_CLEARED','memory_placement':'NOT_RUN','activation_DMA_audio_timing_listening':'NOT_RUN'}
(r/'root-saved-native-review-v1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['inputs','CPP']}))
