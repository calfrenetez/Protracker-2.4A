"""First/once exact Exec fixture compile/link; never execute the HUNK."""
import hashlib,json,shutil,subprocess
from pathlib import Path

root=Path(__file__).resolve().parent
inputs=json.loads((root/'inputs.json').read_bytes())
prep=Path(inputs['native_preparation']);prior=Path(inputs['registration_scope'])
python='/opt/homebrew/opt/python@3.14/bin/python3.14'
output=Path('/private/tmp/pt-readers-exec-jg14dwcs-native-v1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&0o777}
manifest=root/'frozen-source-v1.json'
helper=prep/'build_exec_readers_backend_registration_test.py'
contract=prep/'PTExecReadersBackendRegistrationTest-contract-v1.json'
pins=prep/'toolchain-pins.json'
source_review=root/'final-frozen-source-review-v1.json'
helper_review=prep/'independent-helper-review-v1.json'
assert json.loads(source_review.read_bytes())['status']=='CLEAR'
assert json.loads(helper_review.read_bytes())['status']=='CLEAR'
assert json.loads((prior/'independent-saved-host-review-v1.json').read_bytes())['status']=='CLEAR'
assert json.loads((prior/'independent-saved-native-review-v1.json').read_bytes())['status']=='CLEAR'
host=json.loads((prior/'host-final-v1/host-checks.json').read_bytes())
assert host['passed'] and len(host['groups'])==7 and all(r['passed'] for r in host['groups'])
assert json.loads((prior/'native-final-v1/manifest.json').read_bytes())['passed']
review=json.loads(source_review.read_bytes())
assert review['base_binding']['candidate_files']==8142
assert review['prior_proof_source_binding']['all_existing_compiled_dependency_hashes_equal_current_frozen_and_actual_source']
for r in json.loads((prep/'prepared-files-v1.json').read_bytes())['members'].values():
 p=Path(r['path']);assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
assert not output.exists() and not (root/'native-execution-v1.json').exists() and not (root/'native-final-v1').exists()
controls={'scope':'Root approved first/once exact Exec public registration wrapper compiler/link after current complete source and helper independent CLEAR, unchanged seven-group shared host proof and ordinary native proof CLEAR. Compile/link only; no product execution or target operation.',
 'inputs':[rec(p) for p in [manifest,helper,contract,pins,source_review,helper_review,prior/'host-final-v1/host-checks.json',prior/'independent-saved-host-review-v1.json',prior/'independent-saved-native-review-v1.json']],
 'native_execution':'NOT_RUN','emulator':'NOT_RUN','physical':'NOT_RUN','stack':'UNKNOWN_NOT_CLEARED'}
(root/'approved-native-controls-v1.json').write_text(json.dumps(controls,indent=2)+'\n')
argv=[python,'-B',str(helper),'--source',str(root/'candidate'),'--fixture-contract',str(contract),'--fixture-contract-sha256',sha(contract),'--source-manifest',str(manifest),'--source-manifest-sha256',sha(manifest),'--pins',str(pins),'--pins-sha256',sha(pins),'--out',str(output)]
execution={'scope':controls['scope'],'argv':argv,'state':'dispatched once','native_execution':'NOT_RUN','emulator':'NOT_RUN','physical':'NOT_RUN'}
(root/'native-execution-v1.json').write_text(json.dumps(execution,indent=2)+'\n')
with (root/'native-driver-stdout-v1.txt').open('xb') as stdout,(root/'native-driver-stderr-v1.txt').open('xb') as stderr:
 completed=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
execution.update({'state':'completed','driver_rc':completed.returncode,'original_out':str(output)})
if output.exists():
 durable=root/'native-final-v1';shutil.copytree(output,durable)
 copies=[]
 for p in sorted(output.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():
   q=durable/p.relative_to(output);assert p.read_bytes()==q.read_bytes() and (p.stat().st_mode&0o777)==(q.stat().st_mode&0o777)
   copies.append({'original':rec(p),'durable':rec(q)})
 execution['durable_copies']=copies
(root/'native-execution-v1.json').write_text(json.dumps(execution,indent=2)+'\n')
print(json.dumps({'state':execution['state'],'rc':completed.returncode,'durable_files':len(execution.get('durable_copies',[]))}))
raise SystemExit(completed.returncode)
