"""Root-invoked saved-evidence writer, disabled until exact inputs are READY.

Reads an explicit pinned allowlist only. Never imports or invokes a producer,
verifier, compiler, product, target tool or Git. No recursive directory capture.
"""
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile
from pathlib import Path


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def mode(value):
    return int(value, 8) if isinstance(value, str) else value


def safe(name):
    return (isinstance(name, str) and bool(name) and not name.startswith('/')
            and '\\' not in name and all(x not in ('', '.', '..') for x in name.split('/')))


def below(path, roots):
    return any(path == Path(root) or Path(root) in path.parents for root in roots)


def main():
    root = Path(__file__).resolve().parent
    input_path = root / 'packet-inputs-final.json'
    inputs = json.loads(input_path.read_bytes())
    require(inputs['state'] == 'READY_ACTUAL_REVIEWED_INPUTS', 'WAITING: root has not sealed final inputs')
    require(inputs['root_review'] is not None, 'root preparation review unbound')
    require(inputs['counts'] == {
        'source': 225, 'base': 219, 'owned': 8, 'host_groups': 4, 'host_commands': 8,
        'host_full_M': 44, 'host_canonical': 83, 'host_SDK': 105, 'host_products': 4,
        'host_pairs': 58, 'host_runtime_markers': 7, 'native_TUs': 32,
        'native_commands': 43, 'native_canonical': 78, 'native_SDK': 32,
        'native_runtimes': 7, 'native_pairs': 46}, 'actual counts changed')
    out = Path(inputs['output_directory'])
    require(out.is_absolute() and not out.exists(), 'fresh absolute output required')
    require(below(out, inputs['allowed_output_roots']) and not below(out, [inputs['source_export'], str(root)]),
            'output outside dedicated packet scope')
    blobs, aliases, origins = {}, {}, {}
    source_names = {q['path']: 'source/' + rel for rel, q in inputs['source_records'].items()}
    control_names = {q['path']: 'controls/' + key for key, q in inputs['preparation_controls'].items()}

    def alias(path, name):
        if path in aliases:
            require(aliases[path] == name, 'conflicting alias: ' + path)
        aliases[path] = name

    def add(record, role, name=None):
        path = Path(record['path'])
        require(path.is_absolute() and role in inputs['allowed_roles'], 'unapproved input role/path')
        require(below(path, inputs['allowed_source_roots']), 'not an explicitly scoped input root')
        if role not in ('frozen_source', 'clean_beforeimage', 'committed_dependency'):
            require(not any(part in inputs['excluded_path_components'] for part in path.parts),
                    'excluded private scope: ' + str(path))
        resolved = path.resolve(strict=True)
        require(resolved.is_file() and stat.S_ISREG(resolved.stat().st_mode), 'regular input required')
        if path != resolved:
            require(record.get('resolved_path') == str(resolved), 'unbound lexical/resolved input spelling')
        else:
            require(record.get('resolved_path', str(path)) == str(path), 'wrong resolved input spelling')
        data = path.read_bytes()
        pm = stat.S_IMODE(resolved.stat().st_mode)
        require(len(data) == record['bytes'] and sha(data) == record['sha256']
                and pm == mode(record['mode']), 'input hash/size/mode changed: ' + str(path))
        name = (name or source_names.get(str(path)) or control_names.get(str(path))
                or 'blobs/' + sha(data) + '-' + format(pm, '04o'))
        require(safe(name), 'safe member name required')
        if name in blobs:
            require(blobs[name] == (data, pm), 'conflicting member name')
        else:
            blobs[name] = (data, pm)
        alias(str(path), name)
        if record.get('resolved_path'):
            alias(record['resolved_path'], name)
        origin = {'path': str(path), 'bytes': len(data), 'sha256': sha(data), 'mode': pm, 'role': role}
        if record.get('resolved_path'):
            origin['resolved_path'] = record['resolved_path']
        if origin not in origins.setdefault(name, []):
            origins[name].append(origin)
        return name

    require(len(inputs['artifacts']) == len({x['path'] for x in inputs['artifacts']}), 'duplicate artifact paths')
    for record in inputs['artifacts']:
        add(record, record['role'])
    require(inputs['root_review']['path'] in aliases, 'root review must be explicitly allowlisted')

    def loaded(record):
        return json.loads(blobs[aliases[record['path']]][0])

    require(loaded(inputs['root_review'])['status'] == 'CLEAR_PREPARATION_ONLY', 'root preparation gate')
    for role, review in inputs['reviews'].items():
        actual = loaded(review['record'])
        require(actual['status'] == review['status'], 'review status: ' + role)
        if review.get('require_passed'):
            require(actual.get('passed') is True, 'review did not pass')
    frozen, host, native = loaded(inputs['frozen_source']), loaded(inputs['host']['report']), loaded(inputs['native']['report'])
    require(host['passed'] is True and native['passed'] is True and native['native_NOT_RUN'] is True,
            'actual saved proof scope')
    source_members = {}
    for rel, digest in sorted(frozen['source'].items()):
        require(safe(rel), 'unsafe source path')
        record = inputs['source_records'][rel]
        require(record['path'] == str(Path(inputs['source_export'])/rel) and record['sha256'] == digest
                and mode(record['mode']) == mode(frozen['source_modes'][rel]), 'source record binding')
        source_members[rel] = add(record, 'frozen_source', 'source/' + rel)
    require(len(source_members) == 225, 'complete lean source required')
    target = native['targets'][inputs['target']]
    compiled = set(host['canonical_dependencies']) | set(target['dependencies'])
    protected = {q['path'] for q in loaded(inputs['protected_snapshot'])['preserved_files']}
    require(not compiled & protected, 'protected dirty path entered compiled closure')
    for spec in (inputs['host'], inputs['native']):
        execution = loaded(spec['execution'])
        require(execution['state'] == 'completed' and execution['driver_rc'] == 0
                and len(execution['durable_copies']) == spec['pairs'], 'lane outcome/count')
        for pair in execution['durable_copies']:
            a, b = pair['original'], pair['durable']
            require(aliases[a['path']] == aliases[b['path']] and mode(a['mode']) == mode(b['mode']), 'pair mode/bytes')
    for product in host['products']:
        alias(product['original_path'], aliases[product['archive_path']])
    post_build = {rel: aliases[rec['path']] for rel, rec in inputs['post_build_overlays'].items()}
    for key, record in inputs['preparation_controls'].items():
        require(Path(record['path']).parent == root, 'preparation source outside this scope')
        add(record, 'packet_preparation', 'controls/' + key)
    actual_input = {'path': str(input_path), 'bytes': len(input_path.read_bytes()),
                    'sha256': sha(input_path.read_bytes()), 'mode': stat.S_IMODE(input_path.stat().st_mode)}
    input_member = add(actual_input, 'packet_preparation', 'controls/packet-inputs-final.json')

    payload_memory = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=payload_memory, mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, (data, pm) in sorted(blobs.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = pm
                entry.uid = entry.gid = entry.mtime = 0
                entry.uname = entry.gname = ''
                tar.addfile(entry, io.BytesIO(data))
    payload = payload_memory.getvalue()
    manifest = {
        'scope': inputs['scope'], 'base_commit': inputs['base_commit'], 'base_tree': inputs['base_tree'],
        'payload': {'bytes': len(payload), 'sha256': sha(payload)},
        'members': {name: {'bytes': len(data), 'sha256': sha(data), 'mode': pm,
                          'origins': sorted(origins[name], key=lambda q: (q['path'], q['role'])),
                          'roles': sorted({q['role'] for q in origins[name]})}
                    for name, (data, pm) in sorted(blobs.items())},
        'path_members': dict(sorted(aliases.items())), 'source_members': source_members,
        'compiled_sources': {'host': sorted(host['canonical_dependencies']), 'native': sorted(target['dependencies'])},
        'clean_reference_paths': sorted(set(source_members)-compiled),
        'protected_clean_reference_paths': sorted(protected & (set(source_members)-compiled)),
        'protected_compiled_intersection': [], 'post_build_overlays': post_build,
        'inputs': input_member, 'acceptance': inputs['acceptance'],
        'historical_product_aliases': {p['original_path']: {
            'archive_path': p['archive_path'], 'member': aliases[p['archive_path']],
            'bytes': p['bytes'], 'sha256': p['sha256'],
            'mode': blobs[aliases[p['archive_path']]][1],
            'reason': 'Ended temporary executable; exact executed bytes preserved in archive'}
            for p in host['products']}}
    # Fresh output and exclusive controls: a partial writer failure is preserved.
    out.mkdir(mode=0o755)
    values = {'payload.tar.gz': payload, 'manifest.json': (json.dumps(manifest, indent=2)+'\n').encode(),
              'README.md': inputs['readme'].encode(), 'verify_payload.py':
              blobs[aliases[inputs['preparation_controls']['verify_payload.py']['path']]][0]}
    for name, data in values.items():
        with (out/name).open('xb') as stream:
            stream.write(data)
        os.chmod(out/name, 0o644)
    sums = ''.join(sha(values[name])+'  '+name+'\n' for name in sorted(values)).encode()
    with (out/'SHA256SUMS').open('xb') as stream:
        stream.write(sums)
    os.chmod(out/'SHA256SUMS', 0o644)
    print(json.dumps({'state': 'BUILT_SAVED_BYTES_ONLY_NOT_VERIFIED', 'members': len(blobs),
                      'sources': len(source_members), 'origin_bindings': sum(map(len, origins.values())),
                      'payload': manifest['payload']}))


if __name__ == '__main__':
    main()
