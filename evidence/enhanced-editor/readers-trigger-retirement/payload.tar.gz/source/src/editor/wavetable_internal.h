#ifndef PT_WAVETABLE_INTERNAL_H
#define PT_WAVETABLE_INTERNAL_H
#include "wavetable_dispatch.h"
int pt_wavetable_stop_owned(struct pt_wavetable_voices *,unsigned,const void *);
int pt_wavetable_drain_owned(struct pt_wavetable_voices *,const void *);
int pt_wavetable_close_owned(struct pt_wavetable_voices *,const void *);
/* Drain confirms readers/barrier without detaching caches or releasing owner. */
/* Private prepared-song callbacks, never an opt-in for arbitrary providers.
 * The song has validated immutable project/PCM, completed capability analysis,
 * and holds every required exact master pin. Callbacks check its captured
 * revision, identities and live device ownership on each operation; acquire
 * retains the exact validated master through synchronous upload. No callbacks may reenter
 * or mutate the owner. Dispatch stores no callback/trust state. Public dispatch
 * always uses the fully validating bridge. Prepared upload reuses the held master validation.
 * All cache leases, uncertain-stop ownership and rollback rules are unchanged. */
struct pt_wavetable_prepared {
    void *context;
    int (*current)(void *);
    enum pt_cache_result (*acquire)(void *,unsigned,const struct pt_playback_format *,uint8_t *,size_t,struct pt_cache_lease *);
    int (*location)(void *,struct pt_cache_lease,uint32_t *,uint32_t *);
    /* Certifies that every command of this exact private immutable batch was
       converted during preparation. Never supplied by a public caller. */
    int (*batch_ready)(void *,const struct pt_render_plan *,unsigned,const struct pt_playback_format *);
    int (*restore_ready)(void *,const struct pt_render_snapshot *,unsigned,const struct pt_playback_format *);
    int (*restore_plan)(void *,const struct pt_render_snapshot *,unsigned,unsigned,const struct pt_playback_format *,
        uint32_t,uint32_t,struct pt_amigus_restore_plan *);
    int (*control_plan)(void *,const struct pt_render_action *,unsigned,uint32_t *,uint16_t *,uint16_t *);
    /* Exact private action, rate/format and pinned location must still match.
       Geometry is computed during bounded preparation, never on this callback. */
    int (*trigger_plan)(void *,const struct pt_render_action *,unsigned,const struct pt_playback_format *,
        uint32_t,uint32_t,struct pt_amigus_voice_plan *);
};
int pt_wavetable_dispatch_prepared(struct pt_wavetable_voices *,uint64_t,unsigned,
    const struct pt_render_plan *,const struct pt_playback_format *,uint8_t *,size_t,const struct pt_wavetable_prepared *);
int pt_wavetable_restore_prepared(struct pt_wavetable_voices *,uint64_t,unsigned,
    const struct pt_render_snapshot *,const struct pt_playback_format *,uint8_t *,size_t,const struct pt_wavetable_prepared *);
#endif
