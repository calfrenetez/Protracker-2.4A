Private recovery configuration/controller handoff

Exactly three owned source/test overlays against committed 1ab5ed42d85c8b33e656f8673484fb85309f3205. The frozen source-final inventory remains 7,936 files. The patch does not integrate an editor requester or modify environment variables.

One existing host DOS-stub configuration group passed with ASan/UBSan. Exact generated DOS headers are archived before temporary removal. The same valid allocator self-alias probe returns expected RC20 against the original baseline (configuration succeeds but callbacks are erased), and RC0 against this candidate (callbacks preserved). Both probe paths make no allocations. Full canonical/system dependency inputs and toolchain/runtime pins are retained.

The existing canonical tools/build_recovery.py PTExecRecoveryTest cross-build passed with its 16 ordered translation units, required -fbbb=-, complete -M closure, seven runtime libraries, custom RC20 assertion and HUNK header. No native test binary was executed. New typed get/apply assertions run in the host DOS stub only; the native build compiles their production controller ABI as part of the existing recovery-file fixture.

An initial direct isolated Python native-helper invocation failed at import before setup, compiler queries or product generation. Its receipt/log remain under native-invocation-history. Corrected invocation added only the private helper directory through isolated runpy; source, helper and compiler flags were unchanged.

Use final-handoff.json for exact source, patch, logs and build product hashes. No repository source, targets, shared locks, browser/control, network or Git state was mutated.
