/* Same valid allocator-alias probe for clean baseline and candidate. */
#define main legacy_config_main
#include "tests/native_recovery_config_test.c"
#undef main
int main(void)
{
    struct pt_native_recovery r={0};struct pt_allocator a={NULL,allocate,release};
    int configured,preserved;r.allocator=a;
    configured=pt_native_recovery_configure(&r,&r.allocator);
    preserved=configured && r.allocator.allocate==allocate && r.allocator.release==release && r.allocator.context==NULL;
    printf("RECOVERY ALLOCATOR PROBE configured=%d callbacks_preserved=%d locks=%u\n",configured,preserved,locks);
    return preserved?0:20;
}
