#!/usr/bin/env python3
"""Same host-only valid controller allocator-alias probe for baseline/candidate."""
import argparse,ast,json,shutil,subprocess,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from provenance_common import assert_pinned,classify,digest,expected_files,file_record,parse_dependencies,require_snapshot,write_json
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimization disabled for proof guards')
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True)
p.add_argument('--manifest-sha256',required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--expected-rc',type=int,choices=(0,20),required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];pinfile=root/'tools/toolchain-pins.json';origin=root/'allocator-probe.c'
assert_pinned(a.manifest,a.manifest_sha256);expected=expected_files(json.loads(a.manifest.read_text()));require_snapshot(a.source,expected)
assert_pinned(pinfile,'ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065');pins=json.loads(pinfile.read_text())['host']
assert_pinned(pins['python']['path'],pins['python']['sha256']);assert Path(sys.executable).resolve()==Path(pins['python']['path']).resolve() and sys.version==pins['python']['version']
cc=pins['compiler'];assert_pinned(cc['path'],cc['sha256'])
for path,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(path,sha)
assert not a.out.exists();a.out.mkdir();generated=a.out/'generated';generated.mkdir();probe=a.out/'probe.c';shutil.copyfile(origin,probe);assert digest(probe)==digest(origin)
# Reproduce the existing host fixture's exact literal DOS headers, without executing it.
fixture=a.source/'tests/test_native_recovery_config.py';tree=ast.parse(fixture.read_text());headers=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='write_text':
  expr=node.func.value
  assert isinstance(expr,ast.BinOp) and isinstance(expr.op,ast.Div) and isinstance(expr.right,ast.Constant)
  name=expr.right.value;value=ast.literal_eval(node.args[0]);path=generated/name;path.parent.mkdir(exist_ok=True);path.write_text(value);headers.append(file_record(path))
assert {Path(row['path']).relative_to(generated).as_posix() for row in headers}=={'dos/var.h','proto/dos.h'}
decl=a.source/'tests/test_recovery_file.py';tree=ast.parse(decl.read_text());sources=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets))
assert len(sources)==len(set(sources))==15
flags=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(generated),'-I'+str(a.source),'-Isrc/core'];units=[str(probe),*sources];started=time.monotonic()
r={'scope':'Host ASan/UBSan existing DOS-stub same allocator-alias probe only; baseline expectedRC20 versus candidateRC0; no native execution/target operation','source_manifest':file_record(a.manifest),'source_files_before':len(expected),'expected_rc':a.expected_rc,'probe':file_record(probe),'probe_origin':file_record(origin),'compiler':cc,'python':pins['python'],'runtime_inputs':pins['runtime_inputs'],'sdk_inputs':pins['sdk_inputs'],'helpers':[file_record(__file__),file_record(Path(__file__).with_name('provenance_common.py'))],'declaration_inputs':[file_record(fixture),file_record(decl)],'generated_headers':headers,'commands':[],'canonical_dependencies':{},'external_sdk_dependencies':{},'generated_dependencies':{},'passed':False}
def run(argv,label):
 z=subprocess.run(argv,cwd=a.source,capture_output=True,text=True,timeout=180);log=a.out/(label+'.log');log.write_text(z.stdout+z.stderr)
 r['commands'].append({'argv':argv,'directory':str(a.source),'returncode':z.returncode,'log':file_record(log)});write_json(a.out/'result.json',r);return z
try:
 z=run([cc['path'],'--version'],'compiler-version');assert z.returncode==0 and z.stdout==cc['version']
 z=run([cc['path'],'-print-resource-dir'],'compiler-resource');assert z.returncode==0 and z.stdout.strip()==cc['resource_dir']
 for i,unit in enumerate(units):
  z=run([cc['path'],*flags,'-M',unit],'dependencies-%02d'%i);assert z.returncode==0
  for dep in parse_dependencies(z.stdout):
   path=(a.source/dep).resolve()
   if path==probe:continue
   kind,key=classify(path,a.source,expected,pins['allowed_sdk_roots'],{str(generated):str(generated)})
   r[{'canonical':'canonical_dependencies','external_sdk':'external_sdk_dependencies','generated':'generated_dependencies'}[kind]][key]=digest(path)
 z=run([cc['path'],*flags,*units,'-o',str(a.out/'probe')],'compile');assert z.returncode==0;r['binary']=file_record(a.out/'probe')
 z=run([str(a.out/'probe')],'run');r['run_rc']=z.returncode
 line='RECOVERY ALLOCATOR PROBE configured=1 callbacks_preserved=%d locks=1'%(1 if a.expected_rc==0 else 0)
 r['passed']=z.returncode==a.expected_rc and not z.stderr and z.stdout.strip()==line
except Exception as e:r['error']={'kind':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 try:
  require_snapshot(a.source,expected);r['source_files_after']=len(expected)
  assert_pinned(a.manifest,r['source_manifest']['sha256']);assert_pinned(origin,r['probe_origin']['sha256']);assert_pinned(cc['path'],cc['sha256'])
  for path,sha in {**pins['runtime_inputs'],**pins['sdk_inputs'],**r['external_sdk_dependencies'],**r['generated_dependencies']}.items():assert_pinned(path,sha)
  for row in [*r['helpers'],*r['declaration_inputs'],*headers]:assert_pinned(row['path'],row['sha256'])
 except Exception as e:r['final_guard_error']=str(e);r['passed']=False
 r['elapsed_s']=time.monotonic()-started;write_json(a.out/'result.json',r)
print(json.dumps({'passed':r['passed'],'expected_rc':a.expected_rc,'run_rc':r.get('run_rc'),'canonical_dependencies':len(r['canonical_dependencies']),'external_sdk_dependencies':len(r['external_sdk_dependencies']),'report':str(a.out/'result.json')}))
sys.exit(0 if r['passed'] else 1)
