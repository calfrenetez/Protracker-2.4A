Native recovery controller assertion preparation

Two private test overlays extend the reviewed recovery3 controller candidate: tests/native_recovery_cases.h and tests/native_recovery_configuration_cases.h. The original 7,936-file controller proof and 99,380-byte cross-build remain unchanged. This new 7,937-file frozen source inherits the exact three reviewed production/host-test overlays.

The added assertions use the existing owned RAM workspace and source file, with no new entries or cleanup rules. Intended native paths cover real Lock/Examine/NameFromLock canonical success, missing owned-subpath Lock failure, existing file/non-directory refusal, allocator self-alias, transactional settings/no-op/cancel/disable/re-enable, busy/owned-store/input-output overlap refusal and retained document identity. A hook at the real snapshot-open point checks complete owner preservation; the original snapshot restore checks remain afterward. New Lock handles are released before assertions.

A scoped ASan/UBSan host DOS path model executes this exact shared assertion header with synthetic owner flags; it does not prove native DOS behavior or actual snapshot ownership. Existing canonical tools/build_recovery.py PTExecRecoveryTest cross-build passed with 16 unique ordered TUs, real SDK, seven runtime pins, full-M closure, custom RC20 cleanup assertion and HUNK header. New shared assertions and the exact typed-controller PASS marker are present in the candidate. No native test was run.

GetVar/time remain private fixture substitutions; no ENV/time changes occur. NameFromLock failure remains proven by the earlier host injection only; this native fixture does not force long paths, assigns or CurrentDir changes. Use ordinary recovery-file mode (argc3), not --seed, to reach the new assertions. A later qualifier must require the exact new marker once plus all existing recovery/resource markers and fresh exact-candidate/cleanup/idle/coordination records.

Native execution readiness is false/NOT RUN. See final-handoff.json for exact source, marker, product and provenance bindings. This preparation performs no shared checkout, Git, target, browser, process, network or lock operation.
