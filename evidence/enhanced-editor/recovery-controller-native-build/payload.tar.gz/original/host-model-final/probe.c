/* Host DOS path model for the exact new shared native assertion header.
 * This never calls an Amiga, ENV or the native fixture allocator. */
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "src/native/recovery.c"
#include "tests/native_recovery_configuration_cases.h"
static const char *model_root;
static char held_path[1024];static unsigned lock_active,lock_calls,unlock_calls,allocator_calls;
static LONG error;
LONG GetVar(STRPTR name,STRPTR out,LONG capacity,ULONG flags)
{
 const char *value=NULL;size_t n;assert(flags==(GVF_GLOBAL_ONLY|GVF_BINARY_VAR));
 if(!strcmp(name,"PT24G_RECOVERY_DIR"))value=model_root;
 if(!strcmp(name,"PT24G_RECOVERY_MEDIA"))value="fixed";
 if(!strcmp(name,"PT24G_RECOVERY_SECONDS"))value="30";
 if(!strcmp(name,"PT24G_RECOVERY_REMOVABLE"))value="0";
 assert(value && capacity>0);n=strlen(value);assert(n+1<(size_t)capacity);memcpy(out,value,n+1);error=(LONG)n;return (LONG)n;
}
LONG IoErr(void) {return error;}
BPTR Lock(STRPTR path,LONG mode)
{
 struct stat st;assert(mode==ACCESS_READ && !lock_active);++lock_calls;
 if(stat(path,&st)) {assert(errno==ENOENT);error=ERROR_OBJECT_NOT_FOUND;return 0;}
 assert(strlen(path)<sizeof(held_path));strcpy(held_path,path);lock_active=1;return 1;
}
void UnLock(BPTR lock) {assert(lock==1 && lock_active);lock_active=0;++unlock_calls;}
LONG Examine(BPTR lock,struct FileInfoBlock *info)
{struct stat st;assert(lock==1 && lock_active && !stat(held_path,&st));info->fib_DirEntryType=S_ISDIR(st.st_mode)?1:-1;return 1;}
LONG NameFromLock(BPTR lock,STRPTR out,LONG capacity)
{size_t n;assert(lock==1 && lock_active);n=strlen(held_path);if(n+1>(size_t)capacity)return 0;memcpy(out,held_path,n+1);return 1;}
LONG ExNext(BPTR lock,struct FileInfoBlock *info) {(void)lock;(void)info;abort();}
LONG AddPart(STRPTR path,STRPTR name,LONG capacity)
{size_t n=strlen(path),m=strlen(name);if(n+m+2>(size_t)capacity)return 0;path[n]='/';memcpy(path+n+1,name,m+1);return 1;}
static void *model_allocate(void *context,size_t bytes) {(void)context;(void)bytes;++allocator_calls;abort();}
static void model_release(void *context,void *memory) {(void)context;(void)memory;++allocator_calls;abort();}
int main(int argc,char **argv)
{
 struct pt_allocator a={NULL,model_allocate,model_release};struct pt_project project={0};struct pt_native_recovery r={0};
 assert(argc==3);model_root=argv[1];native_recovery_configuration_cases(argv[1],argv[2],&project,&a);
 r.allocator=a;assert(pt_native_recovery_configure(&r,&a) && pt_native_recovery_bind(&r,argv[2]));
 /* Only the host model synthesizes owner flags; native hook uses actual snapshot. */
 r.store.opened=1;r.store.owned=1;native_recovery_configuration_owner_refusal(&r);
 assert(r.store.opened && r.store.owned && !allocator_calls && !lock_active);
 assert(lock_calls==unlock_calls+2); /* absent observation + failed apply; every successful Lock is released */
 puts("HOST NATIVE CONTROLLER HEADER MODEL PASS: exact shared assertions, synthetic owned flags, zero caller allocations and zero remaining DOS model locks");
 return 0;
}
