"""Private shared provenance helpers. Import performs no build/test operation."""
import argparse
import ast
import hashlib
import json
import re
import shlex
import tempfile
from pathlib import Path

RUNTIME_NAMES = ['ncrt0.o', 'libnix20.a', 'libnixmain.a', 'libnix.a',
                 'libstubs.a', 'libamiga.a', 'libgcc.a']
TARGETS = ['PTExecRecoveryTest']
NATIVE_FLAGS = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
                '-Wall', '-Wextra', '-Werror', '-Isrc/core', '-fbbb=-']
VALUE_OPTIONS = {'-I', '-D', '-U', '-include', '-imacros', '-isystem', '-isysroot',
                 '-iquote', '-idirafter', '-target', '--sysroot', '-x', '-arch', '-Xclang'}

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def file_record(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}

def write_json(path, value):
    path = Path(path)
    staging = path.with_suffix(path.suffix + '.writing')
    staging.write_text(json.dumps(value, indent=2) + '\n')
    staging.replace(path)

def below(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False

def expected_files(manifest):
    values = manifest.get('source', manifest.get('files', manifest.get('export_file_hashes')))
    if isinstance(values, dict):
        return {name: row if isinstance(row, str) else row['sha256'] for name, row in values.items()}
    if 'source_inputs' in manifest:
        return {row['path']: row['sha256'] for row in manifest['source_inputs']}
    raise ValueError('Source manifest has no complete recognized file inventory')

def snapshot(source):
    source = Path(source)
    return {path.relative_to(source).as_posix(): digest(path)
            for path in sorted(source.rglob('*')) if path.is_file()}

def require_snapshot(source, expected):
    actual = snapshot(source)
    if actual != expected:
        extra = sorted(set(actual) - set(expected))
        changed = sorted(name for name, sha in expected.items() if actual.get(name) != sha)
        raise ValueError('Immutable source inventory mismatch: extra=%r changed/missing=%r' % (extra, changed))
    return actual

def assert_pinned(path, sha):
    if not Path(path).is_file() or digest(path) != sha:
        raise ValueError('Pinned input changed or absent: ' + str(path))

def parse_dependencies(output):
    """Parse compiler make syntax after joining all escaped continuation lines."""
    joined = re.sub(r'\\\r?\n', ' ', output)
    result = []
    for line in joined.splitlines():
        colon = re.search(r'(?<!\\):', line)
        if colon:
            result.extend(shlex.split(line[colon.end():], posix=True))
    return list(dict.fromkeys(result))

def cpp_arguments(argv):
    """Keep exact preprocessor defines/options; drop link inputs, outputs and -c."""
    result, units = [], []
    position = 1
    while position < len(argv):
        argument = argv[position]
        if argument == '-o':
            position += 2
            continue
        if argument in {'-c', '-shared', '-static'} or argument.startswith(('-Wl,', '-l', '-L')):
            position += 1
            continue
        if argument in VALUE_OPTIONS:
            if position + 1 == len(argv):
                raise ValueError('Compiler option lacks value: ' + argument)
            result.extend(argv[position:position + 2])
            position += 2
            continue
        if argument.endswith(('.c', '.cc', '.cpp', '.s', '.S')):
            units.append(argument)
        elif argument.endswith(('.o', '.a', '.dylib', '.so')):
            pass
        elif argument.startswith('-'):
            result.append(argument)
        else:
            raise ValueError('Unclassified compiler argument: ' + argument)
        position += 1
    if not units:
        raise ValueError('No translation units in compiler call')
    return result, units

def compiler_input_arguments(argv):
    result, position = [], 1
    while position < len(argv):
        argument = argv[position]
        if argument == '-o' or argument in VALUE_OPTIONS:
            position += 2
            continue
        if argument.endswith(('.c', '.cc', '.cpp', '.s', '.S', '.o', '.a')):
            result.append(argument)
        position += 1
    return result

def classify(path, source, expected, sdk_roots, generated=None):
    path = Path(path).resolve()
    if below(path, source):
        relative = path.relative_to(Path(source).resolve()).as_posix()
        if relative not in expected or digest(path) != expected[relative]:
            raise ValueError('Canonical dependency absent/changed: ' + relative)
        return 'canonical', relative
    if generated and (str(path) in generated or any(below(path, root) for root in generated.values())):
        return 'generated', str(path)
    if any(below(path, root) for root in sdk_roots):
        return 'external_sdk', str(path)
    raise ValueError('Unrecognized external dependency: ' + str(path))

def arguments(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--source-manifest-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--pins', type=Path, required=True)
    parser.add_argument('--pins-sha256', required=True)
    args = parser.parse_args()
    args.source = args.source.resolve()
    args.source_manifest = args.source_manifest.resolve()
    args.out = args.out.resolve()
    args.pins = args.pins.resolve()
    if not args.source.is_dir() or below(args.out, args.source) or not any(
            below(args.out, root) for root in [Path('/private/tmp'), Path(tempfile.gettempdir())]):
        parser.error('Output must be outside a valid immutable source directory')
    assert_pinned(args.source_manifest, args.source_manifest_sha256)
    assert_pinned(args.pins, args.pins_sha256)
    args.out.mkdir(parents=True, exist_ok=True)
    if any(args.out.iterdir()):
        parser.error('Output directory must be new/empty to preserve prior evidence')
    return args

def setup(args, scope):
    manifest = json.loads(args.source_manifest.read_text())
    expected = expected_files(manifest)
    pins = json.loads(args.pins.read_text())
    inputs = require_snapshot(args.source, expected)
    record = {'scope': scope, 'source_export': str(args.source),
              'source_manifest': file_record(args.source_manifest), 'pins': file_record(args.pins),
              'base_commit': manifest.get('base_commit', manifest.get('baseline_commit')),
              'base_tree': manifest.get('base_tree', manifest.get('baseline_tree')),
              'source_files_before': len(inputs),
              'export_tree_sha256': hashlib.sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
              'commands': [], 'passed': False}
    return expected, pins, record

def read_canonical_recipe(source, expected_sha):
    """Read the existing standalone recovery recipe; never import/run builder."""
    recipe=Path(source)/'tools/build_recovery.py';assert_pinned(recipe,expected_sha)
    tree=ast.parse(recipe.read_text(),filename=str(recipe))
    main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    flags=next(n.value for n in main.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='flags' for t in n.targets))
    if not isinstance(flags,ast.List) or len(flags.elts)!=len(NATIVE_FLAGS):raise ValueError('Recovery recipe flags shape changed')
    if [ast.literal_eval(n) for n in flags.elts[:-1]]!=NATIVE_FLAGS[:-1] or ast.unparse(flags.elts[-1])!='*compiler_safety_flags(args.cc)':raise ValueError('Recovery recipe flags/order changed')
    source_nodes=[n.value for n in main.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='sources' for t in n.targets)]
    if len(source_nodes)!=2 or ast.unparse(source_nodes[1])!="['tests/native_exec_recovery_test.c', *sources]":raise ValueError('Recovery recipe source composition changed')
    fixture=Path(source)/'tests/test_recovery_file.py';decl=ast.parse(fixture.read_text())
    sources=next(ast.literal_eval(n.value) for n in decl.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets))
    units=['tests/native_exec_recovery_test.c',*sources]
    if len(units)!=16 or len(units)!=len(set(units)) or any(not (Path(source)/unit).is_file() for unit in units):raise ValueError('Recovery canonical ordered16 source list changed/invalid')
    return {'PTExecRecoveryTest':units},file_record(recipe)
