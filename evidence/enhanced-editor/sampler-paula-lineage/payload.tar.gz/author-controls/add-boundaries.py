from pathlib import Path
p=Path('/private/tmp/protracker-paula-lineage-ixzzdr35/candidate/tests/sampler_paula_lineage_test.c');t=p.read_text()
t=t.replace('r->receipt.action[j].reader=PT_LINEAGE_RETIRED;}return 0;','''r->receipt.action[j].reader=b->active[r->event.key[j].slot] && equal(r->event.key+j,b->slot+r->event.key[j].slot)?PT_LINEAGE_ACTIVE:PT_LINEAGE_RETIRED;}return 0;''')
t=t.replace('assert(pt_paula_lineage_step(o,&f->sampler.generation)==PT_PAULA_LINEAGE_INVALID);','''assert(pt_paula_lineage_step(o,&f->sampler.generation)==PT_PAULA_LINEAGE_INVALID);
 assert(pt_paula_lineage_step(o,(unsigned *)(UINTPTR_MAX-1))==PT_PAULA_LINEAGE_INVALID);
 assert(pt_paula_lineage_step(o,(unsigned *)f->sampler.current[0])==PT_PAULA_LINEAGE_INVALID);''')
insert='''static void two_targets_and_actual_replacement(void)
{
 struct fixture f;struct pt_paula_lineage_owner *a[2],*command_owner;struct pt_paula_lineage_view v[2],cv;
 struct pt_lineage_key key[2];struct pt_lineage_receipt receipt;struct pt_paula_lineage_request requests[2];
 struct pt_scheduled_batch e;uint64_t t[2],command_ticket;unsigned i,ready=77,fastcalls,chipcalls,effects;
 init(&f,24,2,3,16388);
 for(i=0;i<2;++i){a[i]=begin(&f,10+i,i,i,1);prepare(&f,a[i]);assert(pt_paula_lineage_view(a[i],0,v+i)==PT_PAULA_LINEAGE_OK);
  t[i]=enqueue(&f,a[i],v[i],10+i,PT_SCHEDULED_TRIGGER);f.backend.now=record(&f.backend,t[i])->event.scheduled.first;
  assert(fire(&f.backend,t[i]) && pt_lineage_poll(f.queue,t[i],&receipt)==PT_SCHEDULED_PENDING);
  assert(pt_paula_lineage_reader_key(a[i],0,key+i)==PT_SCHEDULED_OK);
  requests[i]=(struct pt_paula_lineage_request){i?PT_SCHEDULED_STOP:PT_SCHEDULED_CONTROL,i,i,1,a[i],v[i].token,0,{0}};
  requests[i].key=key[i];}
 assert(pt_paula_lineage_begin(f.pool,f.queue,20,requests,2,&command_owner)==PT_PAULA_LINEAGE_OK);
 for(i=0;i<4;++i)assert(pt_paula_lineage_step(command_owner,&ready)==(i==3?PT_PAULA_LINEAGE_OK:PT_PAULA_LINEAGE_PENDING));
 assert(pt_paula_lineage_view(command_owner,0,&cv)==PT_PAULA_LINEAGE_OK && cv.data==v[0].data);
 memset(&e,0,sizeof(e));e.generation=7;e.frame=20;e.count=2;
 /* Action order deliberately differs from preparation order; mapping is stable slot plus captured source. */
 e.action[0]=(struct pt_scheduled_action){PT_SCHEDULED_STOP,1,NULL,0,0,0};
 e.action[1]=(struct pt_scheduled_action){PT_SCHEDULED_CONTROL,0,NULL,0,428,32};
 assert(pt_paula_lineage_enqueue(command_owner,&e,&command_ticket)==PT_SCHEDULED_OK);
 assert(pt_lineage_publish(f.queue,command_ticket)==PT_SCHEDULED_OK);
 effects=f.backend.effects;fastcalls=f.fast.calls;chipcalls=f.chip.calls;
 /* Simulate an independently replaced exact reader after task snapshots. Same
  * PCM/cache addresses remain; only backend actual identity changed. */
 ++f.backend.slot[1].serial;f.backend.now=record(&f.backend,command_ticket)->event.scheduled.first;
 assert(!fire(&f.backend,command_ticket) && f.backend.effects==effects && f.fast.calls==fastcalls && f.chip.calls==chipcalls);
 drain(&f.backend);collected(&f,command_owner,command_ticket);
 assert(f.chip.live==2);collected(&f,a[1],t[1]);collected(&f,a[0],t[0]);finish(&f);
}
static void stale_headers_and_reentry(void)
{
 unsigned mode;for(mode=0;mode<4;++mode){struct fixture f;struct pt_paula_lineage_owner *o;struct pt_sample *samples;unsigned ready=77;
  init(&f,16,1,2,8194);o=begin(&f,10,0,0,0);
  if(mode==0){samples=f.document.project.samples;f.document.project.samples=NULL;
   assert(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_STALE && ready==77);f.document.project.samples=samples;}
  else if(mode==1){++f.sampler.generation;assert(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_STALE && ready==77);}
  else if(mode==2){f.document.project.channels.track[0].route=PT_ROUTE_MIDI;
   assert(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_STALE && ready==77);}
  else {reenter_owner=o;assert(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_STALE && ready==77);reenter_owner=NULL;assert(reenter_calls);}
  assert(pt_paula_lineage_cancel(o)==PT_PAULA_LINEAGE_OK && pt_paula_lineage_owner_close(o));finish(&f);
 }
}
'''
assert t.count('int main(void)')==1;t=t.replace('int main(void)',insert+'int main(void)')
t=t.replace('forged_targets();failure_and_cancellation();finite_pressure_and_uncertainty();','forged_targets();failure_and_cancellation();finite_pressure_and_uncertainty();two_targets_and_actual_replacement();stale_headers_and_reentry();')
p.write_text(t)
