from pathlib import Path
p=Path('/private/tmp/protracker-paula-lineage-ixzzdr35/candidate/tests/sampler_paula_lineage_test.c');t=p.read_text()
a='''assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_PENDING && pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_OK);
 c=command'''
b='''assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_PENDING && pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_OK);
 {struct backend before=f.backend;struct image holder=image(&f.fast,a),pool=image(&f.fast,f.pool),queue=image(&f.fast,f.queue);
  assert(pt_paula_lineage_reader_key(a,0,f.backend.slot)==PT_SCHEDULED_INVALID && !memcmp(&before,&f.backend,sizeof(before)));
  unchanged(&holder);unchanged(&pool);unchanged(&queue);}
 c=command'''
assert a in t;t=t.replace(a,b,1)
a='''for(mode=0;mode<11;++mode) {''';b='''{struct image pool=image(&f.fast,f.pool);unsigned calls=f.fast.calls;
  assert(pt_paula_lineage_begin(f.pool,f.queue,20,(const struct pt_paula_lineage_request *)(UINTPTR_MAX-1),1,&sentinel)==PT_PAULA_LINEAGE_INVALID && sentinel==(void *)1 && f.fast.calls==calls);
  unchanged(&pool);}
 for(mode=0;mode<11;++mode) {''';assert t.count(a)==1;t=t.replace(a,b)
t=t.replace('while(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_PENDING)assert(ready==0);','{unsigned steps=0;while(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_PENDING){assert(ready==0 && ++steps<=52);}}')
insert='''static void concurrent_same_source_and_terminal_failure(void)
{
 struct fixture f;struct pt_paula_lineage_owner *a,*b,*sentinel=(void *)1;struct pt_paula_lineage_view av,bv;
 struct pt_scheduled_batch e;struct pt_lineage_receipt receipt,saved;struct pt_paula_lineage_request request={0};
 uint64_t ta;int32_t before[VALUES];unsigned calls;
 init(&f,24,2,3,8194);memcpy(before,f.master.values,sizeof(before));
 a=begin(&f,10,0,0,1);b=begin(&f,11,1,0,1);prepare(&f,a);assert(prepare(&f,b)==3);
 assert(pt_paula_lineage_view(a,0,&av)==PT_PAULA_LINEAGE_OK && pt_paula_lineage_view(b,0,&bv)==PT_PAULA_LINEAGE_OK && av.data==bv.data && av.token!=bv.token);
 assert(pt_paula_lineage_cancel(b)==PT_PAULA_LINEAGE_OK && pt_paula_lineage_owner_close(b));
 assert(f.chip.live==1 && !memcmp(before,f.master.values,sizeof(before)));
 e=batch(av,10,PT_SCHEDULED_TRIGGER);assert(pt_paula_lineage_enqueue(a,&e,&ta)==PT_SCHEDULED_OK);
 assert(pt_lineage_publish(f.queue,ta)==PT_SCHEDULED_OK);f.backend.now=record(&f.backend,ta)->event.scheduled.first;assert(fire(&f.backend,ta));
 assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_PENDING);drain(&f.backend);retire(&f.backend,ta);
 /* Exact independently valid retirement envelope, invalid timing classification:
  * wrapper latches its own failure, yet releases this exact ticket only once. */
 record(&f.backend,ta)->receipt.action[0].issued=record(&f.backend,ta)->event.scheduled.last;
 memset(&receipt,0x5a,sizeof(receipt));saved=receipt;calls=f.fast.calls;
 assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_BACKEND && !memcmp(&receipt,&saved,sizeof(receipt)));
 assert(!f.chip.live && !pt_lineage_held(f.queue) && pt_paula_lineage_owner_close(a));
 assert(pt_paula_lineage_begin(f.pool,f.queue,20,&request,1,&sentinel)==PT_PAULA_LINEAGE_STALE && sentinel==(void *)1 && f.fast.calls==calls);
 assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_INVALID);
 assert(!memcmp(before,f.master.values,sizeof(before)));finish(&f);
}
'''
assert t.count('int main(void)')==1;t=t.replace('int main(void)',insert+'int main(void)')
t=t.replace('two_targets_and_actual_replacement();stale_headers_and_reentry();','two_targets_and_actual_replacement();stale_headers_and_reentry();concurrent_same_source_and_terminal_failure();')
p.write_text(t)
