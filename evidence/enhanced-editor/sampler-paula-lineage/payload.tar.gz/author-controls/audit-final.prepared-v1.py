from pathlib import Path
import ast,hashlib,json,re,shlex,subprocess,tarfile,io
r=Path('/private/tmp/protracker-paula-lineage-ixzzdr35');source=r/'source-final';base=r/'baseline'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=lambda p:{'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
snapshot=lambda p:{x.relative_to(p).as_posix():sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
manifest=json.loads((r/'source-manifest.json').read_text());bm=json.loads((r/'baseline-manifest.json').read_text());h=json.loads((r/'host-final/host-checks.json').read_text());pins=json.loads((r/'tools/toolchain-pins.json').read_text())['host']
def check_file(row):
 p=Path(row['path']);assert p.is_file() and sha(p)==row['sha256'],str(p)
 if 'bytes' in row:assert p.stat().st_size==row['bytes'],str(p)
def check_tree(p,expected):
 actual=snapshot(p);assert actual==expected;return hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()
bfinger=check_tree(base,bm['files']);finger=check_tree(source,manifest['files']);assert finger==h['export_tree_sha256']
new=set(manifest['files'])-set(bm['files']);assert new=={row['path'] for row in manifest['overlays']} and len(new)==5
assert all(manifest['files'][n]==v for n,v in bm['files'].items())
# Original baseline source is read from Git archive only; no checkout/index mutation.
repo=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
raw=subprocess.run(['git','-C',str(repo),'archive',bm['base_commit']],check=True,capture_output=True).stdout
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
 committed={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive.getmembers() if m.isfile()}
inherited={row['path']:row['sha256'] for row in bm['inherited_overlays']};expected={**committed,**inherited};assert expected==bm['files']
for row in inherited.items():assert manifest['files'][row[0]]==row[1]
for row in [h['source_manifest'],h['pins'],h['log'],*h['module_inputs'],*h['helper_inputs'],pins['compiler'],pins['python']]:check_file(row)
for k in ['runtime_inputs','sdk_inputs']:
 for p,v in pins[k].items():assert sha(p)==v
for p,v in h['external_sdk_dependencies'].items():assert sha(p)==v
for p,v in h['canonical_dependencies'].items():assert manifest['files'][p]==v and sha(source/p)==v
assert h['source_files_before']==h['source_files_after']==7994 and h['passed'] is True
assert len(h['groups'])==3 and all(g['passed'] and g['tests']==1 for g in h['groups'])
assert len(h['commands'])==6 and len(h['products'])==3 and not h['generated_inputs']
# Reconstruct declarative Python source lists without importing tests/helpers.
def decl(n,symbol,previous=None):
 node=next(x.value for x in ast.parse((source/n).read_text()).body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id==symbol for t in x.targets));assert isinstance(node,ast.List)
 units=[]
 for x in node.elts:
  if isinstance(x,ast.Constant):assert isinstance(x.value,str);units.append(x.value)
  else:
   assert isinstance(x,ast.Starred) and isinstance(x.value,ast.Subscript) and x.value.value.id=='SOURCES'
   assert isinstance(x.value.slice,ast.Slice) and x.value.slice.lower.value==1 and x.value.slice.upper is None and x.value.slice.step is None
   units.extend(previous[1:])
 assert len(units)==len(set(units));return units
parent=decl('tests/test_sampler.py','SOURCES');declarations={
 'test_sampler_paula_lineage':decl('tests/test_sampler_paula_lineage.py','LINEAGE_SOURCES',parent),
 'test_sampler_paula_future':decl('tests/test_sampler_paula_future.py','FUTURE_SOURCES',parent),
 'test_scheduled_lineage':decl('tests/test_scheduled_lineage.py','SOURCES')}
assert declarations==h['translation_unit_declarations']
canonical={};system={};query_count=0
for c in h['commands']:
 assert c['stage']=='complete' and c['product_returncode']==0
 check_file(c['output_log']);argv=c['executed_argv']
 if c['dependency_commands']:
  units=[x for x in argv if x.endswith('.c')];assert units==declarations[c['group']] and len(c['dependency_commands'])==len(units)
  assert '-fsanitize=address,undefined' in argv and argv[0]==pins['compiler']['path'] and '-Werror' in argv
  assert [x['path'] for x in c['canonical_inputs']]==units
  for d in c['dependency_commands']:
   query_count+=1;assert d['returncode']==0 and '-M' in d['argv'] and d['argv'][-1]==d['unit'];check_file(d['output'])
   text=Path(d['output']['path']).read_text();text=re.sub(r'\\\r?\n',' ',text)
   dependencies=[]
   for line in text.splitlines():
    match=re.search(r'(?<!\\):',line)
    if match:dependencies.extend(shlex.split(line[match.end():]))
   for n in dict.fromkeys(dependencies):
    p=(Path(d['directory'])/n).resolve()
    try:relative=p.relative_to(source).as_posix()
    except ValueError:system[str(p)]=sha(p)
    else:canonical[relative]=sha(p)
  check_file({'path':c['produced_binary']['archive_path'],**{k:c['produced_binary'][k] for k in ['sha256','bytes']}})
 else:
  product=c['input_binary'];check_file({'path':product['archive_path'],**{k:product[k] for k in ['sha256','bytes']}})
  assert argv==[product['original_path']]
assert query_count==47 and canonical==h['canonical_dependencies'] and system==h['external_sdk_dependencies']
assert len(canonical)==56 and len(system)==105
productlogs=[Path(c['output_log']['path']).read_text() for c in h['commands'] if not c['dependency_commands']]
markers=['SAMPLER PAULA LINEAGE PASS: independent master/cache command ownership, genuine typed original reader and per-ticket retirement; software contract only, no DMA or timing proof',
 'PAULA FUTURE TRIGGER OWNER PASS:', 'SCHEDULED LINEAGE PASS:']
for text,marker in zip(productlogs,markers):assert marker in text and not any(x in text for x in ['ERROR: AddressSanitizer','runtime error:','Assertion failed'])
# Unchanged producer input inventories are checked again after this read-only audit.
assert check_tree(source,manifest['files'])==finger and check_tree(base,bm['files'])==bfinger
status={'scope':'Own host-source/declaration/toolchain/dependency/log/product integrity audit; no native/target acceptance',
 'passed':True,'source_manifest':record(r/'source-manifest.json'),'baseline_manifest':record(r/'baseline-manifest.json'),
 'patch':record(r/'final.patch'),'host_report':record(r/'host-final/host-checks.json'),'host_log':record(r/'host-final/host-checks.log'),
 'base_commit':bm['base_commit'],'original_committed_files':len(committed),'inherited_core_files':len(inherited),
 'source_counts':{'baseline':len(bm['files']),'final':len(manifest['files']),'new':len(new)},
 'before_after_fingerprints':{'baseline':bfinger,'final':finger},'host':{'groups':h['groups'],'elapsed_s':h['elapsed_s'],'commands':6,'full_M_queries':47,'canonical':56,'system':105,'products':3,'generated':0},
 'declarations':declarations,'module_inputs':h['module_inputs'],'helper_inputs':h['helper_inputs'],
 'native':'NOT RUN','physical':'NOT RUN','devices_IRQ_DMA_timing':'NOT IMPLEMENTED OR QUALIFIED',
 'histories':{'development-1':'Import failure before compiler; PYTHONPATH corrected',
 'development-2':'Generated draft include referenced old header; compile-only failure, include corrected',
 'development-3':'Fixture beforeimage taken before deliberate origin close; assertion failed, snapshot boundary corrected',
 'development-4':'Draft new suite PASS; development-only source, not immutable final proof',
 'development-5':'Draft wrong PT_ROUTE_MIDI enum; compile-only failure; exact five source files and log preserved in history',
 'development-6':'Draft new suite PASS; development-only',
 'development-7':'Draft three suites PASS; development-only',
 'development-8':'Fixture expected cache allocation freed at last unpin; assertion failed; full tested five files/log preserved separately; eviction remains allowed until pool close',
 'development-9':'Corrected narrow draft suite PASS; final frozen proof supersedes as exact validation'}}
(r/'own-final-review.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps({'passed':True,'audit':record(r/'own-final-review.json')}))
