from pathlib import Path
r=Path('/private/tmp/protracker-paula-lineage-ixzzdr35');s=r/'candidate';base=r/'baseline'
c=(base/'src/editor/sampler_paula_future.c').read_text().replace('pt_paula_future','pt_paula_lineage').replace('PT_PAULA_FUTURE','PT_PAULA_LINEAGE').replace('PT_FUTURE_','PT_PAULA_LINEAGE_').replace('struct pt_scheduled_output','struct pt_lineage_output')
c=c.replace('unsigned generation,busy,closing;','unsigned generation,busy,closing,failed,queue_call;')
c=c.replace('unsigned count,index,phase,state,borrowers,released;','unsigned count,index,phase,state,borrowers,released;\n    struct pt_lineage_receipt terminal;unsigned terminal_seen,terminal_valid;')
c=c.replace('if(p->closing || p->sampler->generation','if(p->closing || p->failed || p->sampler->generation')
c=c.replace('s->previous=NULL;--previous->borrowers;','s->previous=NULL;s->request.previous=NULL;--previous->borrowers;')
c=c.replace('if((p->busy && p->callback!=o)', 'if((p->busy && !p->queue_call)')
c=c.replace('p->callback==o?p->callback_batch:&o->batch','p->callback==o && p->callback_batch?p->callback_batch:&o->batch')
start=c.index('static int batch_valid(');end=c.index('static void resources(',start)
c=c[:start]+'''static int batch_valid(struct pt_paula_lineage_owner *o,const struct pt_scheduled_batch *b)
{
    unsigned i,j,seen=0;struct pt_paula_lineage_pool *p=o->pool;
    if(!b || b->generation!=p->config.generation || b->frame!=o->frame || b->count!=o->count)return 0;
    for(i=0;i<b->count;++i) {
        const struct pt_scheduled_action *a=b->action+i;struct source *s;
        if(a->slot>=4 || (seen&(1U<<a->slot)) || a->volume>64)return 0;
        seen|=1U<<a->slot;
        for(j=0;j<o->count;++j)if(p->map[o->source[j].request.track]==(int)a->slot)break;
        if(j==o->count)return 0;
        s=o->source+j;if(a->kind!=s->request.kind)return 0;
        if(a->kind==PT_SCHEDULED_TRIGGER) {
            uintptr_t x=(uintptr_t)a->data,y=(uintptr_t)s->data;size_t n=(size_t)a->words*2;
            if(!a->words || !a->period || (x&1) || x<y || x-y>s->bytes || n>s->bytes-(x-y))return 0;
        }else if(a->kind==PT_SCHEDULED_CONTROL) {
            if(a->data || a->words || !a->period)return 0;
        }else if(a->kind==PT_SCHEDULED_STOP) {
            if(a->data || a->words || a->period || a->volume)return 0;
        }else return 0;
    }
    return 1;
}
''' + c[end:]
start=c.index('static int request_valid(');end=c.index('enum pt_paula_lineage_result pt_paula_lineage_begin',start)
c=c[:start]+'''static int same_key(const struct pt_lineage_key *a,const struct pt_lineage_key *b)
{
    return a->queue==b->queue && a->session==b->session && a->generation==b->generation &&
        a->ticket==b->ticket && a->owner==b->owner && a->serial==b->serial && a->action==b->action && a->slot==b->slot;
}
static int zero_key(const struct pt_lineage_key *k)
{return !k->queue && !k->session && !k->generation && !k->ticket && !k->owner && !k->serial && !k->action && !k->slot;}
/* Serialized task-side key lookup. Its original-owner current callback only
 * validates held resources; callbacks never recursively query the core queue. */
static int key_current(struct pt_paula_lineage_pool *p,struct pt_lineage_output *q,const struct pt_lineage_key *key)
{
    struct pt_lineage_key actual;enum pt_scheduled_result result;
    p->queue_call=1;result=pt_lineage_reader_key(q,key->ticket,key->action,&actual);p->queue_call=0;
    return result==PT_SCHEDULED_OK && !p->failed && same_key(&actual,key);
}
static int request_valid(struct pt_paula_lineage_pool *p,struct pt_lineage_output *q,uint64_t frame,
    const struct pt_paula_lineage_request *r,unsigned n)
{
    unsigned i,seen=0;
    if(!q || frame==UINT64_MAX || !r || !n || n>PT_PAULA_LINEAGE_SOURCES)return 0;
    for(i=0;i<n;++i) {
        const struct pt_paula_lineage_request *x=r+i;struct pt_paula_lineage_owner *v=x->previous;struct source *from;
        if(x->track>=p->header.channels.count || p->map[x->track]<0 || x->sample>=p->header.sample_count ||
           x->channel>=p->project->samples[x->sample].pcm.channels || (seen&(1U<<p->map[x->track])))return 0;
        seen|=1U<<p->map[x->track];
        if(x->kind==PT_SCHEDULED_TRIGGER) {
            if(v || x->token || x->source || !zero_key(&x->key))return 0;
            continue;
        }
        if((x->kind!=PT_SCHEDULED_CONTROL && x->kind!=PT_SCHEDULED_STOP) || !v || !registered(p,v) ||
           v->state!=LIVE || v->token!=x->token || v->queue!=q || v->frame>=frame || x->source>=v->count ||
           v->borrowers==UINT_MAX || x->key.queue!=q || x->key.ticket!=v->ticket || x->key.owner!=v->token ||
           x->key.action>=v->batch.count || v->batch.action[x->key.action].kind!=PT_SCHEDULED_TRIGGER ||
           x->key.slot!=(unsigned)p->map[x->track] || v->batch.action[x->key.action].slot!=x->key.slot)return 0;
        from=v->source+x->source;
        if(from->request.kind!=PT_SCHEDULED_TRIGGER || from->request.track!=x->track || from->request.sample!=x->sample ||
           from->request.channel!=x->channel || !source_current(v,x->source) || !key_current(p,q,&x->key))return 0;
    }
    return 1;
}
''' + c[end:]
# While a lower callback is serialized, reject and latch wrapper reentry.
c=c.replace('static int current_pool(', 'static int reentry(struct pt_paula_lineage_pool *p)\n{if(p->busy){p->failed=1;return 1;}return 0;}\nstatic int current_pool(')
c=c.replace('p->busy || p->closing','reentry(p) || p->closing')
c=c.replace('p->busy || !registered(p,o)','reentry(p) || !registered(p,o)')
c=c.replace('if(!p || p->busy)return 0;','if(!p || reentry(p))return 0;')
# Begin full validation can invoke current callbacks, serialized under its own queue-call mode.
c=c.replace('if(!request_valid(p,q,frame,r,n))return PT_PAULA_LINEAGE_INVALID;', 'p->busy=1;\n    if(!request_valid(p,q,frame,r,n)){p->busy=0;return PT_PAULA_LINEAGE_INVALID;}\n    p->busy=0;')
# Check all captured target keys at each preparation step, including READY before output.
c=c.replace('if(o->state==READY) {','for(i=0;i<o->count;++i)if(o->source[i].request.kind!=PT_SCHEDULED_TRIGGER &&\n       !key_current(p,o->queue,&o->source[i].request.key)){result=fail(o,PT_PAULA_LINEAGE_STALE);goto end;}\n    if(o->state==READY) {',1)
# Retain classification before exactly-once release, without inferring activation.
pos=c.index('static int add_span(')
c=c[:pos]+'''static void owner_terminal(void *context,uint64_t token,const struct pt_lineage_receipt *receipt,int valid)
{
    struct pt_paula_lineage_owner *o=context;struct pt_paula_lineage_pool *p=o->pool;
    if(!registered(p,o) || token!=o->token || o->state!=LIVE)return;
    o->terminal=*receipt;o->terminal_seen=1;o->terminal_valid=valid!=0;
    if(!valid)p->failed=1;
}
''' + c[pos:]
start=c.index('enum pt_scheduled_result pt_paula_lineage_enqueue(');end=c.index('enum pt_paula_lineage_result pt_paula_lineage_cancel',start)
c=c[:start]+'''enum pt_scheduled_result pt_paula_lineage_enqueue(struct pt_paula_lineage_owner *o,
    const struct pt_scheduled_batch *b,uint64_t *out)
{
    struct pt_paula_lineage_pool *p;struct pt_lineage_owner owner;struct pt_scheduled_batch candidate;
    struct pt_lineage_key targets[PT_PAULA_LINEAGE_SOURCES];enum pt_scheduled_result result;unsigned i,j;
    if(!o || !(p=o->pool) || reentry(p) || !registered(p,o) || o->state!=READY || !b || !out ||
       !output_disjoint(p,out,sizeof(*out)) || !output_disjoint(p,b,sizeof(*b)) ||
       !disjoint(out,sizeof(*out),b,sizeof(*b)))return PT_SCHEDULED_INVALID;
    if(!current_pool(p))return PT_SCHEDULED_STALE;
    for(i=0;i<o->count;++i)if(!source_current(o,i))return PT_SCHEDULED_STALE;
    if(!batch_valid(o,b))return PT_SCHEDULED_INVALID;
    memset(targets,0,sizeof(targets));candidate=*b;p->busy=1;
    for(i=0;i<b->count;++i) {
        for(j=0;j<o->count;++j)if((unsigned)p->map[o->source[j].request.track]==b->action[i].slot)break;
        if(b->action[i].kind!=PT_SCHEDULED_TRIGGER) {
            targets[i]=o->source[j].request.key;
            if(!key_current(p,o->queue,targets+i)){p->busy=0;return PT_SCHEDULED_STALE;}
        }
    }
    owner.held=(struct pt_scheduled_owner){o,o->token,owner_current,owner_retired,o->spans,o->span_count};
    owner.terminal=owner_terminal;p->callback=o;p->callback_batch=&candidate;p->queue_call=1;
    result=pt_lineage_enqueue(o->queue,b,targets,&owner,out);
    p->queue_call=0;p->callback=NULL;p->callback_batch=NULL;p->busy=0;
    if(result==PT_SCHEDULED_OK){o->batch=candidate;o->state=LIVE;o->ticket=*out;}
    return result;
}
enum pt_scheduled_result pt_paula_lineage_reader_key(struct pt_paula_lineage_owner *o,unsigned action,
    struct pt_lineage_key *out)
{
    struct pt_paula_lineage_pool *p;struct pt_lineage_key key;enum pt_scheduled_result result;
    if(!o || !(p=o->pool) || reentry(p) || !registered(p,o) || o->state!=LIVE || action>=o->batch.count ||
       o->batch.action[action].kind!=PT_SCHEDULED_TRIGGER || !out || !output_disjoint(p,out,sizeof(*out)))return PT_SCHEDULED_INVALID;
    if(!current_pool(p))return PT_SCHEDULED_STALE;
    p->busy=1;p->queue_call=1;result=pt_lineage_reader_key(o->queue,o->ticket,action,&key);p->queue_call=0;p->busy=0;
    if(result==PT_SCHEDULED_OK)*out=key;
    return result;
}
''' + c[end:]
(s/'src/editor/sampler_paula_lineage.c').write_text(c)
(s/'src/editor/sampler_paula_lineage.h').write_text('''#ifndef PT_SAMPLER_PAULA_LINEAGE_H
#define PT_SAMPLER_PAULA_LINEAGE_H
#include "sampler.h"
#include "../core/scheduled_lineage.h"
#define PT_PAULA_LINEAGE_OWNERS 8
#define PT_PAULA_LINEAGE_SOURCES 4
struct pt_paula_lineage_pool;
struct pt_paula_lineage_owner;
enum pt_paula_lineage_result {PT_PAULA_LINEAGE_OK,PT_PAULA_LINEAGE_PENDING,PT_PAULA_LINEAGE_INVALID,
    PT_PAULA_LINEAGE_CAPACITY,PT_PAULA_LINEAGE_STALE,PT_PAULA_LINEAGE_BUSY};
struct pt_paula_lineage_config {
    unsigned maximum_owners;size_t control_budget,chip_budget;uint64_t generation;
    void *chip_context;void *(*chip_allocate)(void *,size_t);
    void (*chip_release)(void *,void *,size_t);
};
/* TRIGGER has zero key/no previous. CONTROL/STOP requires an actual positively
 * ACTIVE original TRIGGER from this pool and exact same lineage queue/session.
 * previous/token/source borrow only preparation metadata; never active proof.
 * Its original source must match track/sample/channel and stable routed slot. */
struct pt_paula_lineage_request {
    enum pt_scheduled_kind kind;unsigned track,sample,channel;
    struct pt_paula_lineage_owner *previous;uint64_t token;unsigned source;
    struct pt_lineage_key key;
};
struct pt_paula_lineage_view {
    const uint8_t *data;size_t bytes;uint32_t frames;
    unsigned track,sample,channel,slot;uint64_t token;
};
/* Separate bounded pool/cache. No legacy future/prepared owner sharing/casts.
 * Borrowed project/sampler/allocator/queue stay alive and immutable through close.
 * No copied handles, in-place source edits, reentry, IRQ/DMA/output integration.
 * Outputs/control inputs also remain disjoint from opaque queue and allocator/
 * Chip callback contexts whose complete extents this API cannot discover. */
enum pt_paula_lineage_result pt_paula_lineage_open(const struct pt_allocator *,
    struct pt_sampler *,struct pt_project *,const struct pt_paula_lineage_config *,
    struct pt_paula_lineage_pool **);
enum pt_paula_lineage_result pt_paula_lineage_begin(struct pt_paula_lineage_pool *,
    struct pt_lineage_output *,uint64_t,const struct pt_paula_lineage_request *,unsigned,
    struct pt_paula_lineage_owner **);
/* One transition OR <=4096 master bytes OR <=256 Chip bytes. No partial cache or
 * view. CONTROL/STOP obtains independent exact-current master and identical
 * serial cache refs, then severs raw predecessor borrow before READY. Target key
 * is rechecked each step and before enqueue; same-cache identity is not activation.
 * Invalid aliases preserve state/output; valid stale/errors cancel partial refs. */
enum pt_paula_lineage_result pt_paula_lineage_step(struct pt_paula_lineage_owner *,unsigned *ready);
enum pt_paula_lineage_result pt_paula_lineage_view(struct pt_paula_lineage_owner *,unsigned,
    struct pt_paula_lineage_view *);
/* One action per request/stable slot, exact frame/generation/kind. TRIGGER only
 * addresses actual retained signed8 geometry; CONTROL/STOP has no data/words.
 * Whole-batch refusal preserves caller ownership/input/output. Transfer only OK.
 * Current callbacks validate resources only; core/backend revalidate full target
 * set at publication and actual activation. No recursive queue key callback. */
enum pt_scheduled_result pt_paula_lineage_enqueue(struct pt_paula_lineage_owner *,
    const struct pt_scheduled_batch *,uint64_t *);
enum pt_scheduled_result pt_paula_lineage_reader_key(struct pt_paula_lineage_owner *,unsigned,
    struct pt_lineage_key *);
/* LIVE cancel/close refuses. Core per-ticket positive all-reader retirement alone
 * releases refs; unsubmitted local core retirement is explicitly local provenance.
 * Preparation borrowers defer original disposal until independently pinned/cancelled.
 * Handles remain registered until explicit close, tokens never reused. Finite<=8
 * pressure is intentional: command issue/cancel-before is not reader retirement. */
enum pt_paula_lineage_result pt_paula_lineage_cancel(struct pt_paula_lineage_owner *);
int pt_paula_lineage_owner_close(struct pt_paula_lineage_owner *);
int pt_paula_lineage_close(struct pt_paula_lineage_pool *);
#endif
''')
(s/'docs/SAMPLER_PAULA_LINEAGE.md').write_text('''# Typed sampler reader-lineage adapter (private draft)

Separate opt-in sampler pool and typed lineage core queue. Existing future
TRIGGER/legacy queue/prepared paths remain unchanged. Reuses current master/cache
jobs; each command independently retains exact master and identical cache lease.
CONTROL/STOP requires a positively observed original TRIGGER key from this pool;
acceptance or same-cache identity cannot prove activation. Preparation borrows
prevent use-after-free until independent pins/HIT acquired, then raw predecessor
pointers are severed before READY. Keys recheck each step/enqueue and core publish;
backend must compare whole target set again at actual original frame window.

Full held spans protect master/version/backing/markers/project/table/Chip/control
capacities without padding scans. No ghost spans for released private originals.
Bound<=8 owners and separately bounded control/Chip budgets. <=4096 master or256
Chip bytes per task step. No partial cache publication, deadline allocation,
conversion, editor calls, device/IRQ/DMA/native scheduling or timing claim.

Each transferred ticket retains full refs until its own positive all-reader
retirement. Cancelled-before CONTROL does not stop its source; STOPpending/issued/
draining is not retirement. Unknown or mismatched receipts retain refs. Finite8
pressure deliberately refuses; a scalable persistent reader-domain transfer
contract and song integration remain unfinished. Host synthetic timestamp tests
are software ownership/conditional-target proofs only, not hardware capability.
''')
print('draft source/header/docs written')
