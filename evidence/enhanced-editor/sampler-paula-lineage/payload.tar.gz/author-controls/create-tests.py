from pathlib import Path
r=Path('/private/tmp/protracker-paula-lineage-ixzzdr35');base=r/'baseline';s=r/'candidate'
old=(base/'tests/sampler_paula_future_test.c').read_text();prefix=old[:old.index('struct backend {')].replace('pt_paula_future','pt_paula_lineage').replace('PT_FUTURE_','PT_PAULA_LINEAGE_')
fixture=old[old.index('struct fixture {'):old.index('static struct pt_paula_future_owner *begin(')].replace('pt_paula_future','pt_paula_lineage').replace('PT_FUTURE_','PT_PAULA_LINEAGE_').replace('struct pt_scheduled_output','struct pt_lineage_output').replace('struct pt_scheduled_backend','struct pt_lineage_backend').replace('pt_scheduled_output_held','pt_lineage_held').replace('pt_scheduled_output_close','pt_lineage_close')
fixture=fixture.replace('f->backend.now=100;f->backend.submit=1;','f->backend.now=100;')
fixture=fixture.replace('b=(struct pt_lineage_backend){&f->backend,sizeof(f->backend),{7,8,4},clock_read,submit,poll,cancel};','b=(struct pt_lineage_backend){&f->backend,sizeof(f->backend),{7,8,4},1,1,clock_read,submit,poll,cancel};')
fixture=fixture.replace('pt_scheduled_output_open(&f->allocator,&grid,&b,owners,&f->queue)','pt_lineage_open(&f->allocator,&grid,1001,&b,owners,&f->queue)')
backend='''struct record {struct pt_lineage_event event;struct pt_lineage_receipt receipt;int retired;};
struct backend {struct record record[8];unsigned n,effects;uint64_t now;struct pt_lineage_key slot[4];unsigned active[4];int uncertain;};
static int equal(const struct pt_lineage_key *a,const struct pt_lineage_key *b)
{return a->queue==b->queue && a->session==b->session && a->generation==b->generation && a->ticket==b->ticket &&
 a->owner==b->owner && a->serial==b->serial && a->action==b->action && a->slot==b->slot;}
static struct record *record(struct backend *b,uint64_t ticket)
{unsigned i;for(i=0;i<b->n;++i)if(b->record[i].event.scheduled.ticket==ticket)return b->record+i;assert(0);return NULL;}
static int clock_read(void *c,uint64_t *ticks,uint32_t *frequency)
{struct backend *b=c;*ticks=b->now;*frequency=1000;return 1;}
static int submit(void *c,const struct pt_lineage_event *e)
{
 struct backend *b=c;struct record *r;unsigned i;assert(b->n<8);r=b->record+b->n++;memset(r,0,sizeof(*r));r->event=*e;
 r->receipt.queue=e->queue;r->receipt.session=e->session;r->receipt.generation=e->scheduled.batch.generation;
 r->receipt.ticket=e->scheduled.ticket;r->receipt.owner=e->owner;r->receipt.count=e->scheduled.batch.count;
 for(i=0;i<r->receipt.count;++i)if(e->scheduled.batch.action[i].kind!=PT_SCHEDULED_TRIGGER) {
   r->receipt.action[i].key=e->key[i];r->receipt.action[i].reader=e->scheduled.batch.action[i].kind==PT_SCHEDULED_STOP?PT_LINEAGE_STOP_PENDING:PT_LINEAGE_ACTIVE;
 }
 return b->uncertain?-1:1;
}
static enum pt_lineage_reply poll(void *c,uint64_t ticket,struct pt_lineage_receipt *out)
{struct backend *b=c;struct record *r=record(b,ticket);if(b->uncertain)return PT_LINEAGE_UNCERTAIN;*out=r->receipt;return r->retired?PT_LINEAGE_ALL_RETIRED:PT_LINEAGE_OBSERVATION;}
static enum pt_lineage_reply cancel(void *c,uint64_t ticket,struct pt_lineage_receipt *out)
{
 struct backend *b=c;struct record *r=record(b,ticket);unsigned i;if(b->uncertain)return PT_LINEAGE_UNCERTAIN;
 for(i=0;i<r->receipt.count;++i)if(r->receipt.action[i].command==PT_LINEAGE_WAITING)r->receipt.action[i].command=PT_LINEAGE_CANCELLED_BEFORE;
 *out=r->receipt;return r->retired?PT_LINEAGE_ALL_RETIRED:PT_LINEAGE_OBSERVATION;
}
static int fire(struct backend *b,uint64_t ticket)
{
 struct record *r=record(b,ticket);unsigned i;assert(b->now>=r->event.scheduled.first && b->now<r->event.scheduled.last);
 for(i=0;i<r->receipt.count;++i)if(r->event.scheduled.batch.action[i].kind!=PT_SCHEDULED_TRIGGER &&
    (!b->active[r->event.key[i].slot] || !equal(r->event.key+i,b->slot+r->event.key[i].slot))) {
   unsigned j;for(j=0;j<r->receipt.count;++j){r->receipt.action[j].command=PT_LINEAGE_CANCELLED_BEFORE;
     r->receipt.action[j].reader=PT_LINEAGE_RETIRED;}return 0;
 }
 for(i=0;i<r->receipt.count;++i) {
   struct pt_lineage_action_receipt *a=r->receipt.action+i;unsigned slot=r->event.scheduled.batch.action[i].slot;
   a->command=PT_LINEAGE_ISSUED;a->observed=a->issued=b->now;a->key=r->event.key[i];
   if(r->event.scheduled.batch.action[i].kind==PT_SCHEDULED_TRIGGER){b->slot[slot]=a->key;b->active[slot]=1;}
   if(r->event.scheduled.batch.action[i].kind==PT_SCHEDULED_STOP){b->active[slot]=0;a->reader=PT_LINEAGE_DRAINING;}
   else a->reader=PT_LINEAGE_ACTIVE;
 }
 b->effects+=r->receipt.count;return 1;
}
static void drain(struct backend *b){unsigned i;for(i=0;i<4;++i)b->active[i]=0;}
static void retire(struct backend *b,uint64_t ticket)
{
 struct record *r=record(b,ticket);unsigned i;for(i=0;i<r->receipt.count;++i){struct pt_lineage_action_receipt *a=r->receipt.action+i;
   if(a->command==PT_LINEAGE_WAITING)a->command=PT_LINEAGE_CANCELLED_BEFORE;
   if(a->reader!=PT_LINEAGE_NONE){assert(!b->active[a->key.slot]);a->reader=PT_LINEAGE_RETIRED;}}
 r->retired=1;
}
'''
body='''static struct pt_paula_lineage_owner *begin(struct fixture *f,uint64_t frame,unsigned track,unsigned sample,unsigned channel)
{
 struct pt_paula_lineage_request r;struct pt_paula_lineage_owner *o=NULL;memset(&r,0,sizeof(r));
 r.track=track;r.sample=sample;r.channel=channel;
 assert(pt_paula_lineage_begin(f->pool,f->queue,frame,&r,1,&o)==PT_PAULA_LINEAGE_OK && o);return o;
}
static unsigned prepare(struct fixture *f,struct pt_paula_lineage_owner *o)
{
 unsigned ready=77,n=0;enum pt_paula_lineage_result result;void *master=NULL;size_t masterbytes=0,headerbytes=0;
 uint8_t before[VALUES*sizeof(int32_t)];
 do {
  unsigned i,changed=0,calls=f->fast.calls;void *chip=NULL;size_t chipbytes=0;uint8_t chipbefore[8194];
  struct pt_paula_lineage_view hidden={0},saved;hidden.token=77;saved=hidden;
  assert(pt_paula_lineage_view(o,0,&hidden)==PT_PAULA_LINEAGE_INVALID && !memcmp(&hidden,&saved,sizeof(hidden)));
  for(i=0;i<128;++i)if(f->chip.block[i].data){chip=f->chip.block[i].data;chipbytes=f->chip.block[i].bytes;break;}
  if(chip){assert(chipbytes<=sizeof(chipbefore));memcpy(chipbefore,chip,chipbytes);}
  if(master)memcpy(before,(uint8_t *)master+headerbytes,masterbytes);
  result=pt_paula_lineage_step(o,&ready);assert(++n<=52);
  if(chip){for(i=0;i<chipbytes;++i)changed+=chipbefore[i]!=((uint8_t *)chip)[i];assert(changed<=256);}
  if(master){changed=0;for(i=0;i<masterbytes;++i)changed+=before[i]!=((uint8_t *)master)[headerbytes+i];assert(changed<=4096);}
  else if(f->fast.calls!=calls){assert(f->fast.calls==calls+1);master=f->fast.last;
   masterbytes=(size_t)f->document.project.samples[0].pcm.frames*f->document.project.samples[0].pcm.channels*sizeof(int32_t);
   headerbytes=allocated(&f->fast,master)-masterbytes;}
  assert(result==PT_PAULA_LINEAGE_PENDING || result==PT_PAULA_LINEAGE_OK);assert(ready==(result==PT_PAULA_LINEAGE_OK));
 }while(result==PT_PAULA_LINEAGE_PENDING);
 return n;
}
static struct pt_scheduled_batch batch(struct pt_paula_lineage_view v,uint64_t frame,enum pt_scheduled_kind kind)
{
 struct pt_scheduled_batch b;memset(&b,0,sizeof(b));b.generation=7;b.frame=frame;b.count=1;
 b.action[0]=(struct pt_scheduled_action){kind,v.slot,kind==PT_SCHEDULED_TRIGGER?v.data:NULL,
     kind==PT_SCHEDULED_TRIGGER?(uint16_t)(v.bytes/2):0,kind==PT_SCHEDULED_STOP?0:428,kind==PT_SCHEDULED_STOP?0:64};return b;
}
static struct pt_paula_lineage_owner *command(struct fixture *f,struct pt_paula_lineage_owner *original,
 struct pt_paula_lineage_view view,struct pt_lineage_key key,uint64_t frame,enum pt_scheduled_kind kind)
{
 struct pt_paula_lineage_request request={kind,view.track,view.sample,view.channel,original,view.token,0,{0}};
 struct pt_paula_lineage_owner *o=NULL;request.key=key;
 assert(pt_paula_lineage_begin(f->pool,f->queue,frame,&request,1,&o)==PT_PAULA_LINEAGE_OK && o);return o;
}
static uint64_t enqueue(struct fixture *f,struct pt_paula_lineage_owner *o,struct pt_paula_lineage_view v,uint64_t frame,enum pt_scheduled_kind kind)
{
 struct pt_scheduled_batch e=batch(v,frame,kind);uint64_t ticket=99;
 assert(pt_paula_lineage_enqueue(o,&e,&ticket)==PT_SCHEDULED_OK && ticket!=99);
 assert(pt_paula_lineage_cancel(o)==PT_PAULA_LINEAGE_BUSY && !pt_paula_lineage_owner_close(o));
 assert(pt_lineage_publish(f->queue,ticket)==PT_SCHEDULED_OK);return ticket;
}
static void collected(struct fixture *f,struct pt_paula_lineage_owner *o,uint64_t ticket)
{
 struct pt_lineage_receipt receipt;retire(&f->backend,ticket);assert(pt_lineage_poll(f->queue,ticket,&receipt)==PT_SCHEDULED_OK);
 assert(pt_paula_lineage_owner_close(o));
}
static void aliases(struct fixture *f,struct pt_paula_lineage_owner *o,struct pt_paula_lineage_view v,uint64_t frame,enum pt_scheduled_kind kind)
{
 struct image holder=image(&f->fast,o),pool=image(&f->fast,f->pool),queue=image(&f->fast,f->queue);
 struct pt_scheduled_batch e=batch(v,frame,kind),saved=e;unsigned ready=77;
 assert(pt_paula_lineage_step(o,(unsigned *)&f->master.member.ticket)==PT_PAULA_LINEAGE_INVALID);
 assert(pt_paula_lineage_step(o,(unsigned *)o)==PT_PAULA_LINEAGE_INVALID);
 assert(pt_paula_lineage_step(o,&f->sampler.generation)==PT_PAULA_LINEAGE_INVALID);
 assert(pt_paula_lineage_view(o,0,(struct pt_paula_lineage_view *)v.data)==PT_PAULA_LINEAGE_INVALID);
 assert(pt_paula_lineage_enqueue(o,&e,(uint64_t *)v.data)==PT_SCHEDULED_INVALID);
 assert(pt_paula_lineage_enqueue(o,&e,&f->master.member.ticket)==PT_SCHEDULED_INVALID);
 assert(pt_paula_lineage_enqueue(o,&e,(uint64_t *)o)==PT_SCHEDULED_INVALID);
 assert(pt_paula_lineage_enqueue(o,&e,(uint64_t *)(UINTPTR_MAX-1))==PT_SCHEDULED_INVALID);
 assert(ready==77 && !memcmp(&e,&saved,sizeof(e)));unchanged(&holder);unchanged(&pool);unchanged(&queue);
}
static void precision_and_commands(unsigned bits,unsigned channels)
{
 struct fixture f;struct pt_paula_lineage_owner *a,*c,*stop;struct pt_paula_lineage_view av,cv,sv;
 struct pt_lineage_key key,sentinel;struct pt_lineage_receipt receipt;struct pt_playback_format format={8,channels-1,0,1};
 uint8_t gold[8194];int32_t saved[VALUES];uint64_t ta,tc,ts;unsigned fastcalls,chipcalls;
 init(&f,bits,channels,4,8194);memcpy(saved,f.master.values,sizeof(saved));
 a=begin(&f,10,0,0,channels-1);assert(prepare(&f,a)==(channels==1?44U:52U));
 assert(pt_paula_lineage_view(a,0,&av)==PT_PAULA_LINEAGE_OK);
 assert(pt_playback_pcm_pack(&f.document.project.samples[0].pcm,&format,gold,sizeof(gold))==PT_PCM_OK && !memcmp(av.data,gold,sizeof(gold)));
 if(channels==1){const uint8_t expected[6]={128,127,18,238,1,255};assert(!memcmp(av.data,expected,6));}
 else {const uint8_t expected[3]={127,238,255};assert(!memcmp(av.data,expected,3));}
 aliases(&f,a,av,10,PT_SCHEDULED_TRIGGER);ta=enqueue(&f,a,av,10,PT_SCHEDULED_TRIGGER);
 memset(&sentinel,0x5a,sizeof(sentinel));key=sentinel;
 assert(pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_STALE && !memcmp(&key,&sentinel,sizeof(key)));
 f.backend.now=record(&f.backend,ta)->event.scheduled.first;fastcalls=f.fast.calls;chipcalls=f.chip.calls;
 assert(fire(&f.backend,ta) && f.fast.calls==fastcalls && f.chip.calls==chipcalls);
 assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_PENDING && pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_OK);
 c=command(&f,a,av,key,20,PT_SCHEDULED_CONTROL);assert(prepare(&f,c)==2 && f.chip.calls==chipcalls);
 assert(pt_paula_lineage_view(c,0,&cv)==PT_PAULA_LINEAGE_OK && cv.data==av.data && cv.token!=av.token);
 aliases(&f,c,cv,20,PT_SCHEDULED_CONTROL);tc=enqueue(&f,c,cv,20,PT_SCHEDULED_CONTROL);
 assert(pt_paula_lineage_reader_key(c,0,&sentinel)==PT_SCHEDULED_INVALID);
 assert(pt_lineage_cancel(f.queue,tc,&receipt)==PT_SCHEDULED_PENDING && receipt.action[0].command==PT_LINEAGE_CANCELLED_BEFORE);
 assert(pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_OK && f.chip.live==1);
 stop=command(&f,a,av,key,30,PT_SCHEDULED_STOP);assert(prepare(&f,stop)==2);
 assert(pt_paula_lineage_view(stop,0,&sv)==PT_PAULA_LINEAGE_OK && sv.data==av.data);ts=enqueue(&f,stop,sv,30,PT_SCHEDULED_STOP);
 assert(pt_lineage_poll(f.queue,ts,&receipt)==PT_SCHEDULED_PENDING && receipt.action[0].reader==PT_LINEAGE_STOP_PENDING);
 assert(pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_STALE);
 f.backend.now=record(&f.backend,ts)->event.scheduled.first;assert(fire(&f.backend,ts));
 assert(pt_lineage_poll(f.queue,ts,&receipt)==PT_SCHEDULED_PENDING && receipt.action[0].reader==PT_LINEAGE_DRAINING);
 assert(!pt_paula_lineage_owner_close(a) && !pt_paula_lineage_owner_close(c) && !pt_paula_lineage_owner_close(stop));
 drain(&f.backend);collected(&f,stop,ts);assert(f.chip.live==1);collected(&f,a,ta);assert(f.chip.live==1);collected(&f,c,tc);
 assert(!memcmp(saved,f.master.values,sizeof(saved)));finish(&f);
}
static void origin_retirement(unsigned when)
{
 struct fixture f;struct pt_paula_lineage_owner *a,*c;struct pt_paula_lineage_view av,cv;struct pt_lineage_key key;
 struct pt_lineage_receipt receipt;uint64_t ta,ticket=99;unsigned ready=77,i;
 init(&f,24,2,3,8194);a=begin(&f,10,0,0,1);prepare(&f,a);assert(pt_paula_lineage_view(a,0,&av)==PT_PAULA_LINEAGE_OK);
 ta=enqueue(&f,a,av,10,PT_SCHEDULED_TRIGGER);f.backend.now=record(&f.backend,ta)->event.scheduled.first;assert(fire(&f.backend,ta));
 assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_PENDING && pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_OK);
 c=command(&f,a,av,key,20,PT_SCHEDULED_CONTROL);
 for(i=0;i<when;++i)assert(pt_paula_lineage_step(c,&ready)==(i==1?PT_PAULA_LINEAGE_OK:PT_PAULA_LINEAGE_PENDING));
 drain(&f.backend);retire(&f.backend,ta);assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_OK);
 if(when<2){assert(!pt_paula_lineage_owner_close(a));ready=77;assert(pt_paula_lineage_step(c,&ready)==PT_PAULA_LINEAGE_STALE && ready==77);}
 else {
  struct image holder=image(&f.fast,c),pool=image(&f.fast,f.pool);struct pt_scheduled_batch e;
  assert(pt_paula_lineage_owner_close(a));assert(pt_paula_lineage_view(c,0,&cv)==PT_PAULA_LINEAGE_OK);e=batch(cv,20,PT_SCHEDULED_CONTROL);
  assert(pt_paula_lineage_enqueue(c,&e,&ticket)==PT_SCHEDULED_STALE && ticket==99);unchanged(&holder);unchanged(&pool);
 }
 assert(pt_paula_lineage_cancel(c)==PT_PAULA_LINEAGE_OK && pt_paula_lineage_owner_close(c));
 if(when<2)assert(pt_paula_lineage_owner_close(a));finish(&f);
}
static void forged_targets(void)
{
 struct fixture f;struct pt_paula_lineage_owner *a,*sentinel=(void *)1;struct pt_paula_lineage_view av;
 struct pt_lineage_key key;struct pt_lineage_receipt receipt;struct pt_paula_lineage_request r;uint64_t ta;unsigned mode;
 init(&f,16,1,3,8194);a=begin(&f,10,0,0,0);prepare(&f,a);assert(pt_paula_lineage_view(a,0,&av)==PT_PAULA_LINEAGE_OK);
 ta=enqueue(&f,a,av,10,PT_SCHEDULED_TRIGGER);f.backend.now=record(&f.backend,ta)->event.scheduled.first;assert(fire(&f.backend,ta));
 assert(pt_lineage_poll(f.queue,ta,&receipt)==PT_SCHEDULED_PENDING && pt_paula_lineage_reader_key(a,0,&key)==PT_SCHEDULED_OK);
 for(mode=0;mode<11;++mode) {
  struct image pool=image(&f.fast,f.pool),holder=image(&f.fast,a),queue=image(&f.fast,f.queue);unsigned calls=f.fast.calls;
  r=(struct pt_paula_lineage_request){PT_SCHEDULED_CONTROL,0,0,0,a,av.token,0,{0}};r.key=key;
  switch(mode){case 0:r.key.queue=(void *)1;break;case 1:++r.key.session;break;case 2:++r.key.generation;break;
   case 3:++r.key.ticket;break;case 4:++r.key.action;break;case 5:++r.key.owner;break;case 6:++r.key.serial;break;
   case 7:++r.key.slot;break;case 8:r.previous=(void *)1;break;case 9:++r.token;break;default:r.track=1;}
  assert(pt_paula_lineage_begin(f.pool,f.queue,20,&r,1,&sentinel)==PT_PAULA_LINEAGE_INVALID && sentinel==(void *)1 && f.fast.calls==calls);
  unchanged(&pool);unchanged(&holder);unchanged(&queue);
 }
 drain(&f.backend);collected(&f,a,ta);finish(&f);
}
static void failure_and_cancellation(void)
{
 unsigned mode;for(mode=0;mode<3;++mode){struct fixture f;struct pt_paula_lineage_owner *o,*sentinel=(void *)1;unsigned ready=77;
  struct pt_paula_lineage_request r={0};init(&f,24,2,2,8194);
  if(mode==0){f.fast.fail=f.fast.calls+1;assert(pt_paula_lineage_begin(f.pool,f.queue,10,&r,1,&sentinel)==PT_PAULA_LINEAGE_CAPACITY && sentinel==(void *)1);}
  else {
   o=begin(&f,10,0,0,1);if(mode==1)f.fast.fail=f.fast.calls+1;else f.chip.fail=f.chip.calls+1;
   while(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_PENDING)assert(ready==0);
   assert(ready!=1);assert(pt_paula_lineage_cancel(o)==PT_PAULA_LINEAGE_OK && pt_paula_lineage_owner_close(o));
  }
  finish(&f);
 }
 for(mode=0;mode<52;++mode){struct fixture f;struct pt_paula_lineage_owner *o;unsigned i,ready=77;
  init(&f,24,2,2,8194);o=begin(&f,10,0,0,1);
  for(i=0;i<mode;++i)assert(pt_paula_lineage_step(o,&ready)==PT_PAULA_LINEAGE_PENDING);
  assert(pt_paula_lineage_cancel(o)==PT_PAULA_LINEAGE_OK && pt_paula_lineage_owner_close(o));finish(&f);
 }
}
static void finite_pressure_and_uncertainty(void)
{
 struct fixture f;struct pt_paula_lineage_owner *o[8],*sentinel=(void *)1;struct pt_paula_lineage_view v;
 struct pt_lineage_key key;struct pt_lineage_receipt receipt;uint64_t t[8];unsigned i;
 init(&f,8,1,8,8194);o[0]=begin(&f,10,0,0,0);prepare(&f,o[0]);assert(pt_paula_lineage_view(o[0],0,&v)==PT_PAULA_LINEAGE_OK);
 t[0]=enqueue(&f,o[0],v,10,PT_SCHEDULED_TRIGGER);f.backend.now=record(&f.backend,t[0])->event.scheduled.first;assert(fire(&f.backend,t[0]));
 assert(pt_lineage_poll(f.queue,t[0],&receipt)==PT_SCHEDULED_PENDING && pt_paula_lineage_reader_key(o[0],0,&key)==PT_SCHEDULED_OK);
 for(i=1;i<8;++i){struct pt_paula_lineage_view cv;o[i]=command(&f,o[0],v,key,10+i,PT_SCHEDULED_CONTROL);prepare(&f,o[i]);
  assert(pt_paula_lineage_view(o[i],0,&cv)==PT_PAULA_LINEAGE_OK);t[i]=enqueue(&f,o[i],cv,10+i,PT_SCHEDULED_CONTROL);
  assert(pt_lineage_cancel(f.queue,t[i],&receipt)==PT_SCHEDULED_PENDING && !pt_paula_lineage_owner_close(o[i]));}
 {struct pt_paula_lineage_request r={0};struct image pool=image(&f.fast,f.pool);unsigned calls=f.fast.calls;
  assert(pt_paula_lineage_begin(f.pool,f.queue,30,&r,1,&sentinel)==PT_PAULA_LINEAGE_CAPACITY && sentinel==(void *)1 && f.fast.calls==calls);unchanged(&pool);}
 f.backend.uncertain=1;assert(pt_lineage_poll(f.queue,t[0],&receipt)==PT_SCHEDULED_BACKEND && f.chip.live==1);
 f.backend.uncertain=0;drain(&f.backend);
 for(i=8;i>0;--i){retire(&f.backend,t[i-1]);assert(pt_lineage_poll(f.queue,t[i-1],&receipt)==PT_SCHEDULED_BACKEND);assert(pt_paula_lineage_owner_close(o[i-1]));}
 finish(&f);
}
int main(void)
{
 unsigned bits,channels,when;for(bits=8;bits<=24;bits+=8)for(channels=1;channels<=2;++channels)precision_and_commands(bits,channels);
 for(when=0;when<3;++when)origin_retirement(when);
 forged_targets();failure_and_cancellation();finite_pressure_and_uncertainty();
 puts("SAMPLER PAULA LINEAGE PASS: independent master/cache command ownership, genuine typed original reader and per-ticket retirement; software contract only, no DMA or timing proof");return 0;
}
'''
(s/'tests/sampler_paula_lineage_test.c').write_text(prefix+backend+fixture+body)
(s/'tests/test_sampler_paula_lineage.py').write_text('''from pathlib import Path
import subprocess,tempfile,unittest
from test_sampler import SOURCES
ROOT=Path(__file__).resolve().parents[1]
LINEAGE_SOURCES=['tests/sampler_paula_lineage_test.c','src/editor/sampler_paula_lineage.c',
                 'src/editor/sampler_paula.c','src/core/sample_cache.c','src/core/playback_pcm.c',
                 'src/core/scheduled_lineage.c','src/core/elapsed_clock.c',*SOURCES[1:]]
class PaulaLineage(unittest.TestCase):
    def test_typed_original_and_independent_command_retirement(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe=Path(tmp)/'test'
            subprocess.run(['cc','-std=c99','-O1','-g','-Wall','-Wextra','-Werror',
                            '-fsanitize=address,undefined','-Isrc/core',*LINEAGE_SOURCES,'-o',str(exe)],cwd=ROOT,check=True)
            subprocess.run([str(exe)],check=True)
''')
print('tests written')
