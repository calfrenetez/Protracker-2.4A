from pathlib import Path
import hashlib,json,shutil,difflib,stat,ast
r=Path('/private/tmp/protracker-paula-lineage-ixzzdr35')
files=['src/editor/sampler_paula_lineage.c','src/editor/sampler_paula_lineage.h','tests/sampler_paula_lineage_test.c','tests/test_sampler_paula_lineage.py','docs/SAMPLER_PAULA_LINEAGE.md']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
snapshot=lambda p:{x.relative_to(p).as_posix():sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
b=json.loads((r/'baseline-manifest.json').read_text());before=snapshot(r/'baseline');assert before==b['files']
out=r/'source-final';assert not out.exists();shutil.copytree(r/'baseline',out)
for n in files:
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'candidate'/n,p)
after=snapshot(out);assert len(after)==len(before)+5 and {n for n in after if before.get(n)!=after[n]}==set(files)
manifest={'base_commit':b['base_commit'],'base_tree':b['base_tree'],'source_path':str(out),
 'scope':'Five new typed sampler lineage adapter files; host-only software ownership. Legacy and all baseline inputs unchanged.',
 'inherited_overlays':b['inherited_overlays'],'baseline_manifest':{'path':str(r/'baseline-manifest.json'),'sha256':sha(r/'baseline-manifest.json')},
 'overlays':[{'path':n,'sha256':after[n],'bytes':(out/n).stat().st_size} for n in files],'files':after}
(r/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
patch=''.join('diff --git a/'+n+' b/'+n+'\nnew file mode 100644\n'+''.join(difflib.unified_diff([], (out/n).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+n)) for n in files)
(r/'final.patch').write_text(patch)
tools=r/'tools';tools.mkdir(exist_ok=True)
origin=Path('/private/tmp/protracker-paula-future-owner-vpbs9_ci/tools')
for n in ['provenance_common.py','toolchain-pins.json']:
 shutil.copyfile(origin/n,tools/n)
s=(origin/'host_provenance.py').read_text()
s=s.replace('Run three focused future-trigger-owner/dependent host sanitizer groups','Run three focused typed-sampler-lineage/legacy/core host sanitizer groups')
s=s.replace('import importlib\n','import importlib\nimport ast\n')
s=s.replace("MODULES = ['test_sampler_paula_future', 'test_sampler_paula', 'test_scheduled_output']", "MODULES = ['test_sampler_paula_lineage', 'test_sampler_paula_future', 'test_scheduled_lineage']")
anchor='\ndef main():\n'
func='''
def source_declaration(path, name, inherited=None):
    tree = ast.parse(path.read_text(), filename=str(path))
    values = [node.value for node in tree.body if isinstance(node, ast.Assign) and
              any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
    if len(values) != 1 or not isinstance(values[0], ast.List):
        raise ValueError('Missing exact source declaration: '+str(path))
    result = []
    for node in values[0].elts:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            result.append(node.value)
        elif inherited is not None and isinstance(node, ast.Starred) and isinstance(node.value, ast.Subscript) and (
                isinstance(node.value.value, ast.Name) and node.value.value.id == 'SOURCES' and
                isinstance(node.value.slice, ast.Slice) and isinstance(node.value.slice.lower, ast.Constant) and
                node.value.slice.lower.value == 1 and node.value.slice.upper is None and node.value.slice.step is None):
            result.extend(inherited[1:])
        else:
            raise ValueError('Unexpected executable source declaration: '+str(path))
    if len(result) != len(set(result)) or any(not value.endswith('.c') for value in result):
        raise ValueError('Duplicate or non-C unit in source declaration')
    return result
'''
assert anchor in s;s=s.replace(anchor,'\n'+func+anchor)
anchor="    for entry in [pins['compiler'], pins['python']]:\n"
setup="""    sampler_inputs = source_declaration(args.source/'tests/test_sampler.py', 'SOURCES')
    declarations = {
        'test_sampler_paula_lineage': source_declaration(args.source/'tests/test_sampler_paula_lineage.py', 'LINEAGE_SOURCES', sampler_inputs),
        'test_sampler_paula_future': source_declaration(args.source/'tests/test_sampler_paula_future.py', 'FUTURE_SOURCES', sampler_inputs),
        'test_scheduled_lineage': source_declaration(args.source/'tests/test_scheduled_lineage.py', 'SOURCES')}
    record['translation_unit_declarations'] = declarations
"""
assert anchor in s;s=s.replace(anchor,setup+anchor)
anchor='                    options, units = cpp_arguments(original)\n'
assert anchor in s;s=s.replace(anchor,anchor+"                    if units != declarations[group]:\n                        raise ValueError('Actual compile order differs from pinned source declaration: '+group)\n")
(tools/'host_provenance.py').write_text(s);ast.parse(s)
pre={'scope':'Preparation and source freeze only, no target operations',
 'source_manifest':{'path':str(r/'source-manifest.json'),'sha256':sha(r/'source-manifest.json')},
 'final_patch':{'path':str(r/'final.patch'),'sha256':sha(r/'final.patch')},
 'origins':{'host_provenance.py':{'path':str(origin/'host_provenance.py'),'sha256':sha(origin/'host_provenance.py'),'delta':'three module names/description, declarative AST source list verification before ordered compile'}},
 'helpers':{n:{'path':str(tools/n),'sha256':sha(tools/n),'bytes':(tools/n).stat().st_size} for n in ['host_provenance.py','provenance_common.py','toolchain-pins.json']},
 'source_counts':{'baseline':len(before),'final':len(after),'new':5},'physical':'NOT RUN','native':'NOT RUN'}
(r/'prepared-files.json').write_text(json.dumps(pre,indent=2)+'\n')
# Bytecode-free frozen source. Read-only modes document intent, not security proof.
for x in out.rglob('*'):
 if x.is_file():x.chmod(stat.S_IMODE(x.stat().st_mode)&~0o222)
print(json.dumps(pre))
