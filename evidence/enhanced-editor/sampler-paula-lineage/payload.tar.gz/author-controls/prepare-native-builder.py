from pathlib import Path
import ast,difflib,hashlib,json,subprocess,tempfile
r=Path('/private/tmp/protracker-paula-lineage-ixzzdr35');repo=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
root=Path(tempfile.mkdtemp(prefix='protracker-paula-lineage-native-builder-',dir='/private/tmp'))
commit='0077fd0c3276cd295361637a56330b8de05048c2'
name='tools/build_paula_future_test.py'
s=subprocess.run(['git','-C',str(repo),'show',commit+':'+name],capture_output=True,check=True).stdout.decode()
(root/'build_paula_future_test.original.py').write_text(s)
new=s.replace('future-Paula-trigger-owner','typed-sampler-Paula-lineage')
new=new.replace("'tests/sampler_paula_future_test.c'", "'tests/sampler_paula_lineage_test.c'")
new=new.replace("'src/editor/sampler_paula_future.c'", "'src/editor/sampler_paula_lineage.c'")
new=new.replace("'src/core/scheduled_output.c'", "'src/core/scheduled_lineage.c'")
new=new.replace("'test_sampler_paula_future.py'", "'test_sampler_paula_lineage.py'")
new=new.replace("'tests/test_sampler_paula_future.py'", "'tests/test_sampler_paula_lineage.py'")
new=new.replace("'FUTURE_SOURCES'", "'LINEAGE_SOURCES'")
new=new.replace('Exact future source declaration/import changed','Exact sampler lineage source declaration/import changed')
new=new.replace("TARGET = 'PTPaulaFutureTriggerTest'", "TARGET = 'PTPaulaLineageTest'")
marker='SAMPLER PAULA LINEAGE PASS: independent master/cache command ownership, genuine typed original reader and per-ticket retirement; software contract only, no DMA or timing proof'
new=new.replace('PAULA FUTURE TRIGGER OWNER PASS:',marker)
new=new.replace('Shared scheduled fixture marker missing','Shared typed-sampler lineage fixture marker missing')
assert new!=s
p=root/'build_paula_lineage_test.py';p.write_text(new);a=ast.parse(new)
def assigned(n):return next(ast.literal_eval(x.value) for x in a.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id==n for t in x.targets))
units=assigned('SOURCES');h=json.loads((r/'host-final/host-checks.json').read_text());assert units==h['translation_unit_declarations']['test_sampler_paula_lineage'] and len(units)==22
origin=ast.parse(s)
for n in ['FLAGS','RUNTIMES']:
 other=next(ast.literal_eval(x.value) for x in origin.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id==n for t in x.targets));assert assigned(n)==other
assert assigned('TARGET')=='PTPaulaLineageTest' and marker in new and 'future.py' not in new
(root/'builder.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile='committed/'+name,tofile='tools/build_paula_lineage_test.py')))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rec=lambda p:{'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
out={'scope':'Static AST/preparation only; no builder import/compiler/HUNK/target operation', 'origin_commit':commit,'origin':rec(root/'build_paula_future_test.original.py'),'builder':rec(p),'diff':rec(root/'builder.patch'),
 'new_repository_path':'tools/build_paula_lineage_test.py','own_adapter_source_manifest':rec(r/'source-manifest.json'),'host_declared_exact_order':units,'translation_unit_count':22,
 'flags':assigned('FLAGS'),'runtime_names':assigned('RUNTIMES'),'marker':marker,'target':assigned('TARGET'),
 'preserved_guards':['complete source before/after','compiler/Python/SHA/version','seven runtime query/SHA pins','full-M canonical and SDK closure','enabled SDK __assert_func expansion','full linked marker','HUNK_HEADER0x3f3','fresh outside-source output','canonical recipe AST only; never executes shared dirty recipe'],
 'native_build':'NOT RUN','native_runtime':'NOT RUN','future_provisional_stack':2097152,'stack_adequacy':'UNQUALIFIED; any later runner needs separate measurement and ownership gates'}
(root/'prepared-files.json').write_text(json.dumps(out,indent=2)+'\n')
(root/'README.md').write_text('''# Typed sampler lineage standalone builder preparation

The new standalone builder is derived byte-for-byte except the target, fixture,
new module/core TU and declaration/full marker substitutions from the committed
0077fd0 future-owner builder. Its flags and seven runtimes remain identical. The
22 ordered translation units match the exact frozen new Python host declaration.
It validates the shared recipe as AST data without importing or running it.

This directory is preparation only. No compiler, HUNK or target was run. The root
must first create its own clean current committed export plus the reviewed five
adapter files and this separate sixth portability-only overlay, then independently
check all source/manifests/pins before one crossbuild. Host proof stays unchanged.
A future test Stack2097152 is provisional, not evidence of adequacy. No native
allocation, Chip, DMA, backend, interrupt, exact output or listening claim applies.
''')
print(json.dumps({'directory':str(root),'prepared':rec(root/'prepared-files.json'),'builder':rec(p)}))
