# Typed sampler reader-lineage adapter (private draft)

Separate opt-in sampler pool and typed lineage core queue. Existing future
TRIGGER/legacy queue/prepared paths remain unchanged. Reuses current master/cache
jobs; each command independently retains exact master and identical cache lease.
CONTROL/STOP requires a positively observed original TRIGGER key from this pool;
acceptance or same-cache identity cannot prove activation. Preparation borrows
prevent use-after-free until independent pins/HIT acquired, then raw predecessor
pointers are severed before READY. Keys recheck each step/enqueue and core publish;
backend must compare whole target set again at actual original frame window.

Full held spans protect master/version/backing/markers/project/table/Chip/control
capacities without padding scans. No ghost spans for released private originals.
Bound<=8 owners and separately bounded control/Chip budgets. <=4096 master or256
Chip bytes per task step. No partial cache publication, deadline allocation,
conversion, editor calls, device/IRQ/DMA/native scheduling or timing claim.

Each transferred ticket retains full refs until its own positive all-reader
retirement. Cancelled-before CONTROL does not stop its source; STOPpending/issued/
draining is not retirement. Unknown or mismatched receipts retain refs. Finite8
pressure deliberately refuses; a scalable persistent reader-domain transfer
contract and song integration remain unfinished. Host synthetic timestamp tests
are software ownership/conditional-target proofs only, not hardware capability.
