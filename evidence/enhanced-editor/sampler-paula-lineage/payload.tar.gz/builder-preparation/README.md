# Typed sampler lineage standalone builder preparation

The new standalone builder is derived byte-for-byte except the target, fixture,
new module/core TU and declaration/full marker substitutions from the committed
0077fd0 future-owner builder. Its flags and seven runtimes remain identical. The
22 ordered translation units match the exact frozen new Python host declaration.
It validates the shared recipe as AST data without importing or running it.

This directory is preparation only. No compiler, HUNK or target was run. The root
must first create its own clean current committed export plus the reviewed five
adapter files and this separate sixth portability-only overlay, then independently
check all source/manifests/pins before one crossbuild. Host proof stays unchanged.
A future test Stack2097152 is provisional, not evidence of adequacy. No native
allocation, Chip, DMA, backend, interrupt, exact output or listening claim applies.
