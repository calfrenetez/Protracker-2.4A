from pathlib import Path
import ast,hashlib,json,re,shlex,struct
r=Path('/private/tmp/protracker-sampler-lineage-current-native-lu1i49zc');source=r/'source-final-native';out=r/'native-final-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=lambda p:{'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
a=json.loads((out/'manifest.json').read_text());m=json.loads((r/'source-manifest-native.json').read_text());p=json.loads((r/'toolchain-pins.json').read_text());h=json.loads(Path('/private/tmp/protracker-paula-lineage-ixzzdr35/host-final/host-checks.json').read_text());t=a['targets']['PTPaulaLineageTest']
actual={x.relative_to(source).as_posix():sha(x) for x in sorted(source.rglob('*')) if x.is_file()};assert actual==m['files'] and len(actual)==8001
finger=hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert finger==a['source_fingerprint']
def check(row):
 q=Path(row['path']);assert q.is_file() and sha(q)==row['sha256'] and ('bytes' not in row or q.stat().st_size==row['bytes']),q
for row in [a['source_manifest'],a['pins'],a['builder'],a['compile_commands'],a['compiler'],a['python'],t['binary'],t['preprocessed_fixture'],t['build_log']]:check(row)
assert a['passed'] is True and len(a['commands'])==33 and a['source_files_before']==a['source_files_after']==8001
assert len(t['source_inputs'])==22 and t['source_inputs']==h['translation_unit_declarations']['test_sampler_paula_lineage']
assert all(x['returncode']==0 for x in a['commands'])
for x in a['commands']:check(x['log'])
for n,q in a['runtime_paths'].items():assert sha(q)==p['native']['runtime_inputs'][n]==a['runtime_inputs'][n]
assert set(a['runtime_paths'])==set(['ncrt0.o','libnix20.a','libnixmain.a','libnix.a','libstubs.a','libamiga.a','libgcc.a'])
canonical={};sdk={}
for x in a['commands']:
 if not x['label'].startswith('dependencies-'):continue
 assert '-M' in x['argv']
 text=re.sub(r'\\\r?\n',' ',Path(x['log']['path']).read_text())
 for line in text.splitlines():
  match=re.search(r'(?<!\\):',line)
  if not match:continue
  for value in shlex.split(line[match.end():]):
   q=(Path(x['directory'])/value).resolve()
   try:n=q.relative_to(source).as_posix()
   except ValueError:sdk[str(q)]=sha(q)
   else:canonical[n]=sha(q)
assert canonical==t['dependencies'] and sdk==t['external_sdk_dependencies'] and len(canonical)==51 and len(sdk)==32
assert all(h['canonical_dependencies'].get(n)==v for n,v in canonical.items())
assert len([x for x in a['commands'] if x['label'].startswith('dependencies-')])==22
flags=['-std=c99','-m68000','-msoft-float','-mcrt=nix20','-Os','-Wall','-Wextra','-Werror','-Isrc/core','-Ibuild/dev','-fbbb=-'];assert flags==a['flags']==t['flags']
cc=json.loads((out/'compile-commands.json').read_text())['commands'];assert len(cc)==1 and cc[0]['ordered_translation_units']==t['source_inputs']
assert cc[0]['argv']==a['commands'][-1]['argv']==[a['compiler']['path'],*flags,*t['source_inputs'],'-o',t['binary']['path']]
text=Path(t['preprocessed_fixture']['path']).read_text();raw=Path(t['binary']['path']).read_bytes()
marker=b'SAMPLER PAULA LINEAGE PASS: independent master/cache command ownership, genuine typed original reader and per-ticket retirement; software contract only, no DMA or timing proof'
assert raw.count(marker)==1 and text.count(marker.decode())==1 and struct.unpack('>I',raw[:4])[0]==0x3f3
assert '__assert_func' in t['last_assert_macro'] and text.count('__assert_func (')>=2
for n,row in a['recipe_contract'].items():
 if isinstance(row,dict) and 'path' in row:check(row)
status={'passed':True,'scope':'Own read-only complete compiler-build integrity audit only; no HUNK/target execution',
 'manifest':rec(out/'manifest.json'),'compile_commands':rec(out/'compile-commands.json'),'source_manifest':rec(r/'source-manifest-native.json'),'pins':rec(r/'toolchain-pins.json'),
 'builder':a['builder'],'target':t['binary'],'base_commit':a['base_commit'],'base_tree':a['base_tree'],
 'source_files_before_after':8001,'fingerprint':finger,'commands':33,'commands_RC0':33,'ordered_TUs':t['source_inputs'],
 'full_M_queries':22,'canonical':51,'SDK':32,'runtime_pins':7,'assert':t['last_assert_macro'],'marker_count_in_preprocess_HUNK':1,'HUNK':'0x3f3',
 'host_equivalence':'All51 compiled canonical inputs match frozen host closure; full current export independently provided by root',
 'host_source_proof_independent':rec(Path('/private/tmp/protracker-sampler-lineage-final-independent-review-1791066278673219000.json')),
 'stack':{'provisional':2097152,'adequacy':'NOT QUALIFIED'},'native_runtime':'NOT RUN','target':'NOT RUN','Exec_Chip_DMA_backend_IRQ_hardware_timing':'NOT QUALIFIED'}
(r/'paula-preflight-agent-native-build-review.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(rec(r/'paula-preflight-agent-native-build-review.json')))
