#!/usr/bin/env python3
"""Copy a lossless host/compiler packet; no producer imports/test/compiler/target operations."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,io,json,stat,tarfile
AUTHOR=Path('/private/tmp/protracker-paula-lineage-ixzzdr35')
CURRENT=Path('/private/tmp/protracker-sampler-lineage-current-native-lu1i49zc')
BUILDER=Path('/private/tmp/protracker-paula-lineage-native-builder-www6ahsh')
REVIEWS={
 'source-host-final':(Path('/private/tmp/protracker-sampler-lineage-final-independent-review-1791066278673219000.json'),'3d590fca5e29e051e8b0bfed0e8a28180cbb16ac37c5e394f951a215e6a7caf3'),
 'builder-export':(Path('/private/tmp/protracker-sampler-lineage-builder-export-independent-review-1791066692137432000.json'),'f126bc9c7a13b49c05a56b18286ab0c887061fe81163fe7b29b41f355f8d4903'),
 'actual-native-build':(Path('/private/tmp/protracker-sampler-lineage-native-actual-independent-review-1791066832121789000.json'),'9798c8efcc37f08499317e21fa6971f4fbd7dff8a9ea55b42fff7dec85d789ca')}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(path):return json.loads(path.read_bytes())
def rec(path):return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
def exact(path,value):assert path.is_file() and not path.is_symlink() and sha(path.read_bytes())==value,(path,value)
def snapshot(root):
 found={}
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink(),path
  if path.is_file():found[path.relative_to(root).as_posix()]=sha(path.read_bytes())
 return found
# Reader only; no archived producer code import or eval. It checks member types,
# exact bytes/modes, all origins when asked, and reconstructs the whole payload.
VERIFY='''#!/usr/bin/env python3
"""Verify this packet without extracting or executing archived software."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,io,json,stat,tarfile

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--origins',action='store_true');a=ap.parse_args();root=Path(__file__).resolve().parent
 d=json.loads((root/'manifest.json').read_bytes());members=d['members'];payload=(root/'payload.tar.gz').read_bytes();assert sha(payload)==d['payload']['sha256'] and len(payload)==d['payload']['bytes']
 rows={}
 for line in (root/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert n not in rows and n in {'README.md','manifest.json','payload.tar.gz','verify_payload.py'};assert sha((root/n).read_bytes())==h;rows[n]=h
 assert len(rows)==4 and d['member_count']==len(members)
 raws={}
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  seen=set()
  for t in tf:
   n=t.name;p=PurePosixPath(n);assert t.isfile() and n not in seen and n in members and str(p)==n and not p.is_absolute() and '..' not in p.parts and len(n.encode())<=100;seen.add(n)
   r=members[n];raw=tf.extractfile(t).read();assert t.size==r['bytes']==len(raw) and sha(raw)==r['sha256'] and t.mode==r['mode'] and t.uid==t.gid==t.mtime==0 and t.uname==t.gname=='';raws[n]=raw
   if a.origins:
    origin=Path(r['original_path']);assert not origin.is_symlink() and origin.is_file() and origin.read_bytes()==raw and stat.S_IMODE(origin.stat().st_mode)==r['mode']
  assert seen==set(members)
 assert sum(len(raw) for raw in raws.values())==d['original_bytes']
 buf=io.BytesIO()
 with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tf:
   for n in sorted(members):
    r=members[n];t=tarfile.TarInfo(n);t.size=r['bytes'];t.mode=r['mode'];t.mtime=0;t.uid=t.gid=0;t.uname=t.gname='';tf.addfile(t,io.BytesIO(raws[n]))
 assert buf.getvalue()==payload
 print(json.dumps({'passed':True,'members':len(members),'original_bytes':d['original_bytes'],'payload_sha256':sha(payload),'all_modes_and_bytes':True,'deterministic_reconstruction':True,'origins_checked':a.origins}))
if __name__=='__main__':main()
'''
README='''This packet preserves the separate bounded sampler typed-lineage adapter, its exact host proof and a distinct compiler-only current export. The five new adapter files use actual sampler master pins and selective cache jobs to retain independent TRIGGER/CONTROL/STOP ownership. CONTROL/STOP requires a genuine positively observed original TRIGGER key; accepted work, identical cache bytes, a pending event or lack of retirement cannot prove activation. Original preparation borrows are severed before READY. Complete target sets are rechecked task-side, by the core at publication and contractually by the backend at actual activation. Legacy future TRIGGER, prepared-owner and original flags7 paths remain unchanged.

Each ticket retains its full master/cache reader domain until its own positive all-reader retirement. Cancelled-before CONTROL leaves its original reader ACTIVE; STOP pending/issued/draining is not retirement. Unknown or mismatched retirement envelopes retain resources. An exact independently valid all-reader retirement with invalid command/timing classification releases only that ticket once and latches pool failure. Unpinned cached allocations may remain evictable until eviction/pool close. Full source precision and spare capacity stay protected. Public guards cover actual held storage and borrowed metadata; opaque queue/backend/allocator/Chip callback extents remain explicit caller-disjointness contracts, with actual reader_key output forwarded to core guards.

Final host ASan/UBSan proof ran the new sampler-lineage, unchanged future-owner and core-lineage groups: three tests, six RC0 compile/runtime commands, 47 full-M queries, 56 canonical inputs, 105 external system/SDK fingerprints and three archived executable products in 14.014151750 seconds. No generated compiler inputs occurred. The author's 7,989-file dbededed13cd596683867c3f39a5127651f86d74 baseline includes five exact previously reviewed core-lineage inputs; the final author export adds only five files and has 7,994. Both complete original inventories and all compiled/declaration closures are retained. Those executions use ordinary host allocations and a simulated timestamp backend: they prove software ownership and conditional-target behavior, not Chip memory class or physical output.

The separate native compile export is clean committed 0077fd0c3276cd295361637a56330b8de05048c2 plus those exact five files and one standalone builder: 7,995 current committed files plus six overlays equals 8,001. Root's preflight and independent export review bind that original source. All 51 compiler canonical dependencies are byte-identical to the frozen host closure. The only host aggregate/current mismatch is the already reviewed literal newline in tests/scheduled_lineage_test.c, an unchanged core regression fixture outside this new native22-TU closure; no sanitizer rerun or new formatting fix was needed.

One portable 68k compile/link attempt passed in 4.8793702499970095 seconds with 33 RC0 commands, 22 ordered translation units, 22 full-M queries, 51 canonical dependencies, 32 external SDK fingerprints and seven pinned runtimes. Committed flags, -fbbb=- and default SDK __assert_func assertions remain enabled. The complete SAMPLER PAULA LINEAGE PASS marker occurs exactly once in preprocessing and the HUNK. PTPaulaLineageTest is 151,592 bytes, SHA256 5607e94a8417e8476d4bade6b92bcbf832e835b61c340ac174bb2278f5e32d78, HUNK_HEADER0x3f3. This HUNK has NOT RUN. Stack2097152 is provisional and adequacy is NOT QUALIFIED. No native/Exec allocation, Chip/DMA, output backend, IRQ, audio, hardware timing, physical or listening acceptance is supplied.

Original development logs and the separately retained tested compile/assertion-failure source snapshots remain historical. Their corrections include draft includes/enum and fixture snapshot/evictable-cache expectations; they are not silently converted to PASS and do not claim immutable source identity where none was retained. The final source/test/docs review and final saved host-proof review are independently CLEAR. Both handoffs and the prepared-v1 builder/receipt relocation are preserved: the initial builder had presence-only full-marker checks, then the root-approved revision required exact count==1 before the one compiler attempt. Own initial compiler-audit metadata accidentally reused its target key and omitted the binary field; its exact bytes and corrective v2 record remain distinct, with all compiler/product originals unchanged. Root protected16 statements are captured root-reported checks, not a live state observation by this packager.

Exact source inventories, five adapter files, standalone builder, actual C/header and Python declaration closures, AST-only build/runtime recipes, all producer preparation/provenance helpers, full-M logs, ordered commands, products, pins and independent/root reviews are losslessly archived. Full source exports and SDK/toolchain trees are omitted; full inventories and all external fingerprints remain. The fixed eight-owner/event domain deliberately refuses pressure. Scalable persistent reader ownership, a song scheduler and native activation/output capability remain unfinished.

manifest.json maps every ordinary regular archive member to its exact original path, SHA256, bytes, mode and role. USTAR ownership/timestamps and gzip metadata are deterministic; duplicate generation and complete tar-reader byte/mode/origin checks were performed. verify_payload.py verifies all controls and reconstructs the archive without extracting or running producer software; --origins additionally checks retained private originals. SHA256SUMS binds the other four controls. Packaging itself does not rerun tests/compiler/HUNK or touch a target.
'''
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--qa',type=Path,required=True);a=ap.parse_args();out=a.out.resolve();qa=a.qa.resolve()
 assert out.parent==qa.parent==Path('/private/tmp') and not out.exists() and not qa.exists()
 for origin in (AUTHOR,CURRENT,BUILDER):assert out!=origin and out not in origin.parents and origin not in out.parents
 for role,(path,pin) in REVIEWS.items():exact(path,pin);assert parse(path)['passed'] is True
 exact(CURRENT/'root-preflight-review.json','43b09aa01cbdeac14b4ca02379a859fb582e658b83098a6458396bbbb60788a6')
 exact(AUTHOR/'source-manifest.json','50acaf95c24acd818529d218b21c24468ae57ccb653cd24c74acdcbe9389a8ee')
 exact(CURRENT/'source-manifest-native.json','757498b9dd2d73145df6ebf909e6ec50b360d8c0a9d6429c1ccf51c4a362131d')
 exact(CURRENT/'native-final-v1/manifest.json','9731f31f7e5f6d16e3dca54980f7f99a7f4328978e68f85b9e1b9b86fb9d4d90')
 inventories={}
 for role,root,manifest in [('author-baseline',AUTHOR/'baseline',AUTHOR/'baseline-manifest.json'),('author-final',AUTHOR/'source-final',AUTHOR/'source-manifest.json'),('native-current',CURRENT/'source-final-native',CURRENT/'source-manifest-native.json')]:
  expected=parse(manifest)['files'];assert snapshot(root)==expected;inventories[role]={'source_root':str(root),'manifest':rec(manifest),'file_count':len(expected),'all_hashes_match':True}
 host=parse(AUTHOR/'host-final/host-checks.json');native=parse(CURRENT/'native-final-v1/manifest.json');target=native['targets']['PTPaulaLineageTest']
 assert host['passed'] and native['passed'] and len(host['commands'])==6 and len(native['commands'])==33
 assert all(x['product_returncode']==0 for x in host['commands']) and all(x['returncode']==0 for x in native['commands'])
 assert len(host['canonical_dependencies'])==56 and len(host['external_sdk_dependencies'])==105 and len(host['products'])==3 and not host['generated_inputs']
 assert sum(len(x['dependency_commands']) for x in host['commands'])==47
 assert len(target['dependencies'])==51 and len(target['external_sdk_dependencies'])==32 and len(target['source_inputs'])==22 and len(native['runtime_paths'])==7
 assert target['binary']['bytes']==151592 and target['binary']['sha256']=='5607e94a8417e8476d4bade6b92bcbf832e835b61c340ac174bb2278f5e32d78'
 # Current fingerprints are checked, not SDK/compiler trees copied into the archive.
 for row in [host['compiler'],host['python'],native['compiler'],native['python']]:assert sha(Path(row['path']).read_bytes())==row['sha256']
 for mapping in [host['external_sdk_dependencies'],host['sanitizer_runtime_inputs'],host['pinned_sdk_inputs'],target['external_sdk_dependencies']]:
  for path,value in mapping.items():assert sha(Path(path).read_bytes())==value,path
 for name,path in native['runtime_paths'].items():assert sha(Path(path).read_bytes())==native['runtime_inputs'][name]
 members={};raws={}
 def add(name,path,role):
  path=Path(path);p=PurePosixPath(name);assert str(p)==name and not p.is_absolute() and '..' not in p.parts and len(name.encode())<=100 and name not in members
  assert path.is_file() and not path.is_symlink(),path;raw=path.read_bytes();members[name]={'original_path':str(path),'sha256':sha(raw),'bytes':len(raw),'mode':stat.S_IMODE(path.stat().st_mode),'role':role};raws[name]=raw
 def tree(prefix,root,role):
  assert root.is_dir()
  for path in sorted(root.rglob('*')):
   assert not path.is_symlink()
   if path.is_file() and '__pycache__' not in path.parts:add(prefix+'/'+path.relative_to(root).as_posix(),path,role)
 for path in sorted(AUTHOR.iterdir()):
  if path.is_file():add('author-controls/'+path.name,path,'Exact author control/history/helper; development logs qualify only their literal outcomes and retained source snapshots')
 for folder in ['tools','host-final','history']:tree('author/'+folder,AUTHOR/folder,'Exact host helper/pins/47-M logs/six command logs/three products and original retained tested draft snapshots; no execution by packager')
 for path in sorted(CURRENT.iterdir()):
  if path.is_file():add('native-controls/'+path.name,path,'Exact current source/root export review/compiler invocation/own audit metadata histories and handoff')
 tree('native-build',CURRENT/'native-final-v1','Exact one-attempt compiler/runtime/full-M/preprocessing/link records and NOT RUN HUNK')
 tree('builder-preparation',BUILDER,'Exact committed origin, prepared-v1 builder/control, count==1 revision and diffs; no producer execution by packager')
 module_names={Path(row['path']).relative_to(AUTHOR/'source-final').as_posix() for row in host['module_inputs']}
 own={row['path'] for row in parse(AUTHOR/'source-manifest.json')['overlays']}
 for stage,source in [('baseline',AUTHOR/'baseline'),('final',AUTHOR/'source-final')]:
  names=set(host['canonical_dependencies'])|module_names|own
  for name in sorted(names):
   if (source/name).is_file():add('host-inputs/'+stage+'/'+name,source/name,'Exact compiled canonical/Python declaration bytes for this stage; five new files exist only in final')
 source=CURRENT/'source-final-native';native_names=set(target['dependencies'])|own|{'tools/build_paula_lineage_test.py','tools/build_core_tests.py','tools/build_diagnostic.py','tests/test_sampler_paula_lineage.py','tests/test_sampler.py'}
 for name in sorted(native_names):add('native-inputs/'+name,source/name,'Exact current51 compiled inputs or five-file/builder overlay and AST-only committed build/runtime/Python declaration controls')
 for role,(path,pin) in REVIEWS.items():add('independent/'+role+'.json',path,'Exact independent '+role+' receipt; scope and historical timing preserved')
 prior=parse(REVIEWS['source-host-final'][0])['previous_independent_record'];exact(Path(prior['path']),prior['sha256']);add('independent/source-host-prior.json',Path(prior['path']),'Exact earlier independent read-only source/host audit prior to final append-only builder binding')
 add('preparation/packager.py',Path(__file__).resolve(),'Exact host-only lossless copier, standard-library reader and deterministic archive creation; no producer imports')
 def generate():
  buf=io.BytesIO()
  with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tf:
    for name in sorted(members):
     row=members[name];item=tarfile.TarInfo(name);item.size=row['bytes'];item.mode=row['mode'];item.uid=item.gid=item.mtime=0;item.uname=item.gname='';tf.addfile(item,io.BytesIO(raws[name]))
  return buf.getvalue()
 payload=generate();assert payload==generate()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  seen=set()
  for item in tf:
   assert item.isfile() and item.name in members and item.name not in seen;seen.add(item.name);row=members[item.name]
   assert tf.extractfile(item).read()==raws[item.name] and item.mode==row['mode'] and item.size==row['bytes'] and item.uid==item.gid==item.mtime==0 and item.uname==item.gname==''
  assert seen==set(members)
 for name,row in members.items():path=Path(row['original_path']);assert path.read_bytes()==raws[name] and stat.S_IMODE(path.stat().st_mode)==row['mode']
 for row in inventories.values():assert snapshot(Path(row['source_root']))==parse(Path(row['manifest']['path']))['files']
 out.mkdir();(out/'payload.tar.gz').write_bytes(payload);(out/'verify_payload.py').write_text(VERIFY);(out/'verify_payload.py').chmod(0o644);(out/'README.md').write_text(README)
 document={'scope':'Lossless host/compiler origins and ordinary deterministic regular USTAR members; no software/target execution',
 'member_count':len(members),'original_bytes':sum(x['bytes'] for x in members.values()),'payload':{'bytes':len(payload),'sha256':sha(payload)},'members':members,'source_inventories':inventories,
 'five_adapter_paths':parse(AUTHOR/'source-manifest.json')['overlays'],'six_native_overlays':parse(CURRENT/'source-manifest-native.json')['overlays'],
 'independent_reviews':{role:rec(path) for role,(path,_) in REVIEWS.items()},'root_preflight':rec(CURRENT/'root-preflight-review.json'),
 'compiled_source_equivalence':'All51 compiler canonical inputs match actual frozen host dependencies; different full trees are explicitly preserved',
 'complete_source_exports_and_SDK_toolchain_trees_archived':False,'external_fingerprints':'All host105system/native32SDK/compiler/Python/runtime inputs retained in original controls and rehashed at packaging',
 'host_PASS':'three groups/sixRC0/47-M/56canonical105system/three archived executables','native_build_PASS':'one attempt33RC0/22TUs/22-M/51canonical32SDK/seven runtime pins',
 'native_binary':target['binary'],'HUNK_NOT_RUN':True,'Stack2097152':'PROVISIONAL/NOT QUALIFIED','native_Exec_Chip_DMA_backend_IRQ_song_hardware_timing':'NOT QUALIFIED OR IMPLEMENTED',
 'protected16':'Only original captured root-reported check, not packager live verification','reader':'verify_payload.py checks controls/all bytes and modes and recreates deterministic payload without extracting/evaluating producer code; optional --origins checks retained exact private originals'}
 (out/'manifest.json').write_text(json.dumps(document,indent=2)+'\n');controls=['README.md','manifest.json','payload.tar.gz','verify_payload.py']
 (out/'SHA256SUMS').write_text(''.join(sha((out/name).read_bytes())+'  '+name+'\n' for name in controls))
 rows={}
 for line in (out/'SHA256SUMS').read_text().splitlines():
  value,name=line.split('  ',1);assert name not in rows and name in controls and sha((out/name).read_bytes())==value;rows[name]=value
 assert set(rows)==set(controls) and len(list(out.iterdir()))==5
 for name,row in members.items():assert Path(row['original_path']).read_bytes()==raws[name]
 qa.write_text(json.dumps({'passed':True,'scope':'Lossless archival/copy/reader/determinism checks only, no tests/compiler/HUNK/targets',
 'packet':str(out),'members':len(members),'original_bytes':document['original_bytes'],'five_controls':[rec(out/name) for name in [*controls,'SHA256SUMS']],
 'all_origins_bytes_modes_verified':True,'safe_unique_regular_tar':True,'duplicate_payload_generation_equal':True,'source_inventories_unchanged':inventories,'packager':rec(Path(__file__).resolve())},indent=2)+'\n')
 print(json.dumps({'packet':str(out),'files':5,'total_bytes':sum(p.stat().st_size for p in out.iterdir()),'members':len(members),'original_bytes':document['original_bytes'],'payload':rec(out/'payload.tar.gz'),'manifest':rec(out/'manifest.json'),'sums':rec(out/'SHA256SUMS'),'qa':rec(qa)},indent=2))
if __name__=='__main__':main()
