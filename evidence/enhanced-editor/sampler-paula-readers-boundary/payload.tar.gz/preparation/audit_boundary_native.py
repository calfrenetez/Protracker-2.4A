#!/usr/bin/env python3
"""Independently reconstruct saved compiler closures; never invoke the compiler or products."""
import hashlib, json, shlex, struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'candidate'
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def record(p):
    return {'path': str(p), 'bytes': Path(p).stat().st_size, 'sha256': sha(p)}
def main():
    frozen = json.loads((ROOT / 'boundary-native-source-manifest-final-v1.json').read_text())
    actual = {p.relative_to(SOURCE).as_posix(): sha(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
    assert actual == frozen['files'] and len(actual) == 8099
    pins = json.loads((ROOT / 'native-preparation/toolchain-pins.json').read_text())
    rows = []
    for lane, name, contract_name, units in (
            ('native-genuine-final-v1', 'PTPaulaReadersTest', 'genuine', 22),
            ('native-startup-final-v1', 'PTPaulaReadersStartupTest', 'startup', 22),
            ('native-boundary-final-v1', 'PTPaulaReadersBoundaryTest', 'boundary', 29)):
        folder = ROOT / lane
        report = json.loads((folder / 'manifest.json').read_text())
        contract = json.loads((ROOT / 'native-preparation' / (contract_name + '-fixture-contract.json')).read_text())
        assert report['passed'] and report['native_NOT_RUN']
        assert report['base_commit'] == frozen['base_commit'] and report['base_tree'] == frozen['base_tree']
        assert report['source_files_before'] == report['source_files_after'] == 8099
        assert len(report['commands']) == units + 11
        for role in ('source_manifest', 'pins', 'fixture_contract', 'builder', 'compile_commands'):
            r = report[role]
            assert sha(r['path']) == r['sha256'] and Path(r['path']).stat().st_size == r['bytes']
        assert report['builder']['sha256'] == 'c76506544fb11072436f7894c2425d83cd05ec8f02929df66072ca9e730c542e'
        assert report['source_manifest']['sha256'] == sha(ROOT / 'boundary-native-source-manifest-final-v1.json')
        assert report['pins']['sha256'] == '22ac81cd691e00c5ee75a10b855966eed23a52edf741fcc624a907b37cf0b461'
        assert sha(report['compiler']['path']) == report['compiler']['sha256']
        assert sha(report['python']['path']) == report['python']['sha256']
        assert len(report['runtime_inputs']) == 7
        for runtime, value in report['runtime_inputs'].items():
            assert sha(report['runtime_paths'][runtime]) == value == pins['native']['runtime_inputs'][runtime]
        target = report['targets'][name]
        assert set(report['targets']) == {name}
        assert target['source_inputs'] == contract['ordered_sources'] and len(set(target['source_inputs'])) == units
        canon, external, order = {}, {}, []
        for c in report['commands']:
            assert c['returncode'] == 0
            log = c['log']
            assert sha(log['path']) == log['sha256'] and Path(log['path']).stat().st_size == log['bytes']
            assert (folder / Path(log['path']).name).read_bytes() == Path(log['path']).read_bytes()
            if '-M' not in c['argv']:
                continue
            assert '-MM' not in c['argv']
            order.append(c['argv'][-1])
            text = Path(log['path']).read_text().replace('\\\n', ' ')
            for dep in shlex.split(text.split(':', 1)[1]):
                p = (Path(c['directory']) / dep).resolve() if not Path(dep).is_absolute() else Path(dep).resolve()
                try:
                    rel = p.relative_to(SOURCE).as_posix()
                    assert sha(p) == actual[rel]
                    canon[rel] = sha(p)
                except ValueError:
                    external[str(p)] = sha(p)
        assert order == target['source_inputs']
        assert canon == target['dependencies'] and external == target['external_sdk_dependencies']
        command_file = json.loads(Path(report['compile_commands']['path']).read_text())
        assert len(command_file['commands']) == 1
        command = command_file['commands'][0]
        assert command['ordered_translation_units'] == order and command['argv'][0] == report['compiler']['path']
        assert '-m68000' in report['flags'] and '-msoft-float' in report['flags'] and '-DNDEBUG' not in report['flags']
        for role in ('binary', 'preprocessed_fixture', 'build_log'):
            r = target[role]
            assert sha(r['path']) == r['sha256'] and Path(r['path']).stat().st_size == r['bytes']
            assert (folder / Path(r['path']).name).read_bytes() == Path(r['path']).read_bytes()
        binary = (folder / name).read_bytes()
        marker = contract['marker'].encode()
        assert struct.unpack('>I', binary[:4])[0] == 0x3f3 and binary.count(marker) == 1
        preprocessed = Path(target['preprocessed_fixture']['path']).read_bytes()
        assert preprocessed.count(marker) == 1 and preprocessed.count(b'__assert_func (') >= 2
        assert '__assert_func' in target['last_assert_macro']
        rows.append({'lane': lane, 'report': record(folder / 'manifest.json'), 'commands_RC0': len(report['commands']),
                     'full_M_queries_RC0': len(order), 'canonical_inputs': len(canon), 'external_inputs': len(external),
                     'seven_runtimes_exact': True, 'binary': target['binary'], 'native_NOT_RUN': True})
    assert {p.relative_to(SOURCE).as_posix(): sha(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()} == actual
    out = ROOT / 'root-native-audit-final-v1.json'
    out.write_text(json.dumps({'passed': True, 'scope': 'Root independent saved-byte proof audit only; no compiler/product/target execution',
                               'source_manifest': record(ROOT / 'boundary-native-source-manifest-final-v1.json'),
                               'products': rows, 'native': 'NOT_RUN', 'physical': 'NOT_RUN'}, indent=2) + '\n')
    print(json.dumps({'passed': True, 'products': rows, 'audit': record(out)}))

if __name__ == '__main__':
    main()
