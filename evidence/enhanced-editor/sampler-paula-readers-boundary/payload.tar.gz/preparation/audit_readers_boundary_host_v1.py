from pathlib import Path
import json,hashlib,shutil,shlex,ast,tarfile
root=Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/readers-boundary-w5pj8drq');source=root/'candidate';proof=Path('/private/tmp/pt-readers-boundary-host-v1');dest=root/'boundary-host-final-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=lambda p:{'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
r=json.loads((proof/'host-checks.json').read_text());m=json.loads((root/'boundary-source-manifest-final-v1.json').read_text());base=json.loads((root/'baseline-manifest.json').read_text())
actual={p.relative_to(source).as_posix():sha(p) for p in sorted(source.rglob('*')) if p.is_file()}
assert actual==m['source'] and len(actual)==8099
old={k:v['sha256'] for k,v in base['files'].items()};assert len(old)==8097 and sorted(k for k,h in actual.items() if old.get(k)!=h)==sorted(m['owned'])
with tarfile.open(root/'base.tar') as tar:
 assert {x.name:hashlib.sha256(tar.extractfile(x).read()).hexdigest() for x in tar if x.isfile()}==old
assert r['passed'] and len(r['groups'])==3 and all(g['passed'] for g in r['groups'])
assert r['source_files_before']==r['source_files_after']==8099
assert r['export_tree_sha256']==hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(r['commands'])==6 and len(r['products'])==3 and not r['generated_inputs']
for name,h in r['canonical_dependencies'].items():assert actual[name]==h
for name,h in r['external_sdk_dependencies'].items():assert sha(name)==h
for role in ['sanitizer_runtime_inputs','pinned_sdk_inputs']:
 for name,h in r[role].items():assert sha(name)==h
for role in ['compiler','python']:
 assert sha(r[role]['path'])==r[role]['sha256']
for f in r['helper_inputs']+r['module_inputs']+[r['source_manifest'],r['pins'],r['log']]:assert sha(f['path'])==f['sha256'] and Path(f['path']).stat().st_size==f['bytes']
all_canon={};all_system={};queries=0
for c in r['commands']:
 assert c['stage']=='complete' and c['product_returncode']==0
 assert sha(c['output_log']['path'])==c['output_log']['sha256']
 ccanon={};csystem={}
 for q in c['dependency_commands']:
  queries+=1;assert q['returncode']==0 and '-M' in q['argv'] and '-MM' not in q['argv'] and '-fsanitize=address,undefined' in q['argv']
  assert sha(q['output']['path'])==q['output']['sha256']
  contents=Path(q['output']['path']).read_text().replace('\\\n',' ')
  deps=shlex.split(contents.split(':',1)[1])
  for d in deps:
   path=(Path(q['directory'])/d).resolve() if not Path(d).is_absolute() else Path(d).resolve()
   try: name=path.relative_to(source.resolve()).as_posix();assert name in actual;ccanon[name]=sha(path)
   except ValueError: csystem[str(path)]=sha(path)
 assert ccanon==c['dependencies']['canonical']
 assert csystem==c['dependencies']['external_sdk']
 all_canon.update(ccanon);all_system.update(csystem)
 if c['dependency_commands']:
  assert '-fsanitize=address,undefined' in c['executed_argv'] and c['executed_argv'][0]==r['compiler']['path']
 for key in ['produced_binary','input_binary']:
  if key in c: f=c[key];assert sha(f['archive_path'])==f['sha256'] and Path(f['archive_path']).stat().st_size==f['bytes']
assert queries==73 and all_canon==r['canonical_dependencies'] and all_system==r['external_sdk_dependencies']
for f in r['products']:assert sha(f['archive_path'])==f['sha256'] and Path(f['archive_path']).stat().st_size==f['bytes']
marker='PAULA READERS BOUNDARY PASS: exact renderer plans, folded triggers and independently retained readers; software ownership only'
assert Path(r['commands'][1]['output_log']['path']).read_text().count(marker)==1
# Resolve only literal/starred declarations, never import production test modules.
sampler=ast.parse((source/'tests/test_sampler.py').read_text());initial=next(n.value for n in sampler.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets));SOURCES=ast.literal_eval(initial)
readers=ast.parse((source/'tests/test_sampler_paula_readers.py').read_text());decl=next(n.value for n in readers.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='READERS_SOURCES' for t in n.targets));READERS_SOURCES=[n.value for n in decl.elts[:-1]]+SOURCES[1:]
boundary=ast.parse((source/'tests/test_sampler_paula_readers_boundary.py').read_text());decl=next(n.value for n in boundary.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BOUNDARY_SOURCES' for t in n.targets));BOUNDARY_SOURCES=[decl.elts[0].value]+READERS_SOURCES[1:]+[n.value for n in decl.elts[2:]]
assert len(READERS_SOURCES)==22 and len(BOUNDARY_SOURCES)==29 and len(set(BOUNDARY_SOURCES))==29
assert BOUNDARY_SOURCES==[x['path'] for x in r['commands'][0]['canonical_inputs']]
assert READERS_SOURCES==[x['path'] for x in r['commands'][2]['canonical_inputs']]
assert ['tests/sampler_paula_readers_prepare_test.c',*READERS_SOURCES[1:]]==[x['path'] for x in r['commands'][4]['canonical_inputs']]
assert not dest.exists();shutil.copytree(proof,dest,copy_function=shutil.copy2)
copies=[]
for origin in sorted(proof.rglob('*')):
 if origin.is_file():
  copied=dest/origin.relative_to(proof);assert origin.read_bytes()==copied.read_bytes() and (origin.stat().st_mode&0o777)==(copied.stat().st_mode&0o777)
  copies.append({'original':str(origin),'copy':str(copied),'sha256':sha(copied),'bytes':copied.stat().st_size,'mode':copied.stat().st_mode&0o777})
closure=root/'boundary-compiled-closure-final-v1';closure.mkdir();declarations=['tests/test_sampler.py','tests/test_sampler_paula_readers.py','tests/test_sampler_paula_readers_prepare.py','tests/test_sampler_paula_readers_boundary.py']
for name in sorted(set(all_canon)|set(declarations)):
 target=closure/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,target);assert sha(target)==actual[name]
source_after={p.relative_to(source).as_posix():sha(p) for p in sorted(source.rglob('*')) if p.is_file()};assert source_after==actual
receipt={'passed':True,'scope':'Author pure saved-byte/source/dependency audit; no product/compiler reruns/native/target action','source_manifest':record(root/'boundary-source-manifest-final-v1.json'),'source_files':len(actual),'baseline_files':len(old),'exact_owned':m['owned'],'groups':r['groups'],'commands':6,'full_M_queries':queries,'canonical':len(all_canon),'system':len(all_system),'products':r['products'],'generated_inputs':0,'ast_ordered_units':{'boundary':29,'genuine':22,'startup':22},'declarations':{n:actual[n] for n in declarations},'source_before_after_exact':True,'original_report':record(proof/'host-checks.json'),'durable_report':record(dest/'host-checks.json'),'durable_copies':copies,'native':'NOT RUN','physical':'NOT RUN','hardware_timing':'UNQUALIFIED'}
q=root/'boundary-host-own-audit-final-v1.json';q.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'audit':record(q),'report':record(proof/'host-checks.json'),'durable_files':len(copies),'closure_files':len(set(all_canon)|set(declarations)),'queries':queries,'canonical':len(all_canon),'system':len(all_system)}))
