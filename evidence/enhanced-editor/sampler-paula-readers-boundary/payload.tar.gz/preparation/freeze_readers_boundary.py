from pathlib import Path
import json,hashlib,tarfile,difflib,shutil,sys
root=Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/readers-boundary-w5pj8drq');src=root/'candidate';stage=sys.argv[1]
owned=['src/editor/sampler_paula_readers.c','src/editor/sampler_paula_readers.h','tests/test_sampler_paula_readers.py','tests/test_sampler_paula_readers_prepare.py','tests/sampler_paula_readers_boundary_test.c','tests/test_sampler_paula_readers_boundary.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
base=json.loads((root/'baseline-manifest.json').read_text());old={k:v['sha256'] for k,v in base['files'].items()}
actual={p.relative_to(src).as_posix():sha(p.read_bytes()) for p in sorted(src.rglob('*')) if p.is_file()}
delta=sorted(p for p,h in actual.items() if old.get(p)!=h)
assert delta==sorted(owned),(delta,owned)
assert not(set(old)-set(actual))
saved=root/('boundary-overlays-'+stage);saved.mkdir()
patch=[]
with tarfile.open(root/'base.tar') as tar:
 for name in owned:
  b=(src/name).read_bytes();dest=saved/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  origin=tar.extractfile(name).read() if name in old else b''
  patch.extend(difflib.unified_diff(origin.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
(root/('boundary-'+stage+'.patch')).write_text(''.join(patch))
manifest={'scope':'Private complete frozen host source; exact renderer boundary adapter plus genuine fixture, native NOT RUN', 'source_export':str(src),'base_commit':base['head'],'base_archive':{'path':str(root/'base.tar'),'sha256':sha((root/'base.tar').read_bytes())},'source':actual,'owned':{name:{'sha256':actual[name],'bytes':(src/name).stat().st_size} for name in owned}}
p=root/('boundary-source-manifest-'+stage+'.json');p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':str(p),'sha256':sha(p.read_bytes()),'source_files':len(actual),'owned':manifest['owned']}))
