#!/usr/bin/env python3
"""Read/hash-only independent audit of saved compiler proofs; no product run."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import shlex
import struct

ROOT = Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/readers-boundary-w5pj8drq')
PREP = ROOT / 'native-preparation'
SOURCE = ROOT / 'candidate'
FLAGS = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
         '-Wall', '-Wextra', '-Werror', '-Isrc/core', '-Ibuild/dev', '-fbbb=-']
KINDS = ['genuine', 'startup', 'boundary']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}


def read(path):
    return json.loads(Path(path).read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def verify_record(value):
    check(record(value['path']) == value, 'Recorded bytes changed: ' + value['path'])


def dependencies(output):
    names = []
    for line in re.sub(r'\\\r?\n', ' ', output).splitlines():
        colon = re.search(r'(?<!\\):', line)
        if colon:
            names.extend(shlex.split(line[colon.end():]))
    return list(dict.fromkeys(names))


def audit_kind(kind, expected, pins, native_manifest, fingerprint):
    durable = ROOT / ('native-' + kind + '-final-v1')
    outer_path = PREP / (kind + '-compiler-outer-final-v1.json')
    outer, mapping = read(outer_path), read(durable / 'outer-archive-mapping.json')
    check(outer['passed'] and outer['returncode'] == 0 and outer['helper_invocations'] == 1,
          kind + ': outer success/once gate')
    check(outer['native_execution'] == mapping['native_execution'] == 'NOT_RUN', kind + ': execution scope')
    check(outer['controls_before'] == outer['controls_after'], kind + ': outer controls changed')
    check(mapping['mappings'] == outer['durable_mapping'], kind + ': mapping differs')
    verify_record(mapping['outer_invocation'])
    for value in outer['controls_before'] + [outer['wrapper'], outer['stdout'], outer['stderr']]:
        verify_record(value)
    check(Path(outer['stderr']['path']).read_bytes() == b'', kind + ': nonempty outer stderr')
    for row in mapping['mappings']:
        verify_record(row['original']); verify_record(row['durable'])
        check(row['original']['sha256'] == row['durable']['sha256'] and
              row['original']['bytes'] == row['durable']['bytes'], kind + ': archive copy differs')
    contract = read(PREP / (kind + '-fixture-contract.json'))
    sources, target, marker = contract['ordered_sources'], contract['target'], contract['marker']
    m = read(durable / 'manifest.json')
    check(m['passed'] and 'failure' not in m and 'final_provenance_error' not in m, kind + ': helper failure')
    check(m['native_NOT_RUN'] is True, kind + ': native execution scope')
    check(m['source_files_before'] == m['source_files_after'] == len(expected) == 8099, kind + ': source count')
    check(m['source_fingerprint'] == fingerprint, kind + ': source fingerprint')
    check(m['base_commit'] == native_manifest['base_commit'] and m['base_tree'] == native_manifest['base_tree'], kind + ': base identity')
    check(m['flags'] == FLAGS and m['compiler'] == pins['native']['compiler'] and m['python'] == pins['host']['python'], kind + ': toolchain/flags')
    for value in [m['source_manifest'], m['pins'], m['fixture_contract'], m['builder'], m['compile_commands']]:
        verify_record(value)
    check(set(m['targets']) == {target}, kind + ': target set')
    t = m['targets'][target]
    check(t['source_inputs'] == sources and t['flags'] == FLAGS, kind + ': target source order')
    compiler = pins['native']['compiler']['path']
    commands = m['commands']
    runtimes = list(pins['native']['runtime_inputs'])
    labels = ['compiler-version', 'compiler-target-help'] + ['runtime-' + x.replace('.', '-') for x in runtimes]
    labels += ['dependencies-%02d' % n for n in range(len(sources))] + ['preprocessed-fixture', target + '.build']
    check([x['label'] for x in commands] == labels, kind + ': exact command order/count')
    check(all(x['returncode'] == 0 and x['directory'] == str(SOURCE) for x in commands), kind + ': command status/directory')
    for command in commands:
        verify_record(command['log'])
    check(Path(commands[0]['log']['path']).read_text().splitlines()[0] == m['compiler']['version'], kind + ': compiler version')
    check('-fbbb=' in Path(commands[1]['log']['path']).read_text(), kind + ': optimizer guard help')
    check(m['runtime_inputs'] == pins['native']['runtime_inputs'] and set(m['runtime_paths']) == set(runtimes), kind + ': seven runtimes')
    for n, name in enumerate(runtimes):
        row = commands[2+n]
        check(row['argv'] == [compiler, '-m68000', '-msoft-float', '-mcrt=nix20', '-print-file-name=' + name], kind + ': runtime resolution argv')
        check(str(Path(Path(row['log']['path']).read_text().strip()).resolve()) == m['runtime_paths'][name], kind + ': runtime path')
        check(digest(m['runtime_paths'][name]) == pins['native']['runtime_inputs'][name], kind + ': runtime pin')
    canonical, sdk = {}, {}
    for n, unit in enumerate(sources):
        row = commands[9+n]
        check(row['argv'] == [compiler, *FLAGS, '-M', unit], kind + ': full-M argv')
        for name in dependencies(Path(row['log']['path']).read_text()):
            p = (SOURCE / name).resolve()
            if p.is_relative_to(SOURCE):
                relative = p.relative_to(SOURCE).as_posix()
                check(relative in expected and digest(p) == expected[relative], kind + ': canonical dependency')
                canonical[relative] = expected[relative]
            else:
                check(any(p.is_relative_to(Path(root)) for root in pins['native']['allowed_sdk_roots']), kind + ': unexpected dependency root')
                sdk[str(p)] = digest(p)
    check(canonical == t['dependencies'] and sdk == t['external_sdk_dependencies'], kind + ': saved source/SDK closure')
    check(all(x in canonical for x in contract['include_chain']), kind + ': transitive reader include chain')
    check(all(x not in sources[1:] for x in contract['include_chain']), kind + ': duplicate fixture/adapter TU')
    cpp = Path(t['preprocessed_fixture']['path']).read_text()
    assertions = re.findall(r'^#define assert\([^\n]*', cpp, re.MULTILINE)
    check(assertions and t['last_assert_macro'] == assertions[-1] and '__assert_func' in assertions[-1] and cpp.count('__assert_func (') >= 2, kind + ': active SDK assertions')
    check(cpp.count(marker) == 1, kind + ': full marker in preprocessing')
    verify_record(t['preprocessed_fixture']); verify_record(t['build_log']); verify_record(t['binary'])
    check(Path(t['build_log']['path']).read_bytes() == b'', kind + ': compile/link warning/error output')
    raw = Path(t['binary']['path']).read_bytes()
    check(struct.unpack('>I', raw[:4])[0] == 0x3f3 and t['format'] == 'HUNK_HEADER0x000003f3', kind + ': HUNK header')
    check(raw.count(marker.encode()) == 1, kind + ': complete marker in HUNK')
    compile_rows = read(m['compile_commands']['path'])['commands']
    expected_argv = [compiler, *FLAGS, *sources, '-o', t['binary']['path']]
    check(len(compile_rows) == 1 and compile_rows[0]['argv'] == commands[-1]['argv'] == expected_argv and
          compile_rows[0]['ordered_translation_units'] == sources and compile_rows[0]['name'] == target, kind + ': once-only exact compile/link')
    return {'kind': kind, 'passed': True, 'helper_invocations': 1, 'compile_link_invocations': 1,
            'compiler_commands': len(commands), 'ordered_full_M_translation_units': len(sources),
            'canonical_dependency_count': len(canonical), 'sdk_dependency_count': len(sdk),
            'runtime_count': len(runtimes), 'native_execution': 'NOT_RUN', 'assertions_active': True,
            'no_FPU_scope': 'Pinned -m68000 -msoft-float seven-runtime recipe only; no instruction-level or target execution claim',
            'marker': marker, 'format': t['format'], 'product': record(durable / target),
            'original_product': t['binary'], 'original_proof': record(Path(outer['private_output']) / 'manifest.json'),
            'durable_proof': record(durable / 'manifest.json'), 'outer_invocation': record(outer_path),
            'archive_mapping': record(durable / 'outer-archive-mapping.json'), 'archive_copy_count': len(mapping['mappings'])}


def main():
    manifest_path = ROOT / 'boundary-native-source-manifest-final-v1.json'
    manifest = read(manifest_path)
    host = read(ROOT / 'boundary-source-manifest-final-v1.json')
    expected = manifest['files']
    check(expected == host['source'], 'Native manifest derivation changed source map')
    actual = {}
    for p in sorted(SOURCE.rglob('*')):
        check(not p.is_symlink(), 'Symlink in candidate: ' + str(p))
        if p.is_file():
            actual[p.relative_to(SOURCE).as_posix()] = digest(p)
    check(actual == expected, 'Actual complete source map changed')
    fingerprint = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    pins = read(PREP / 'toolchain-pins.json')
    check(digest(pins['native']['compiler']['path']) == pins['native']['compiler']['sha256'], 'Compiler pin')
    check(digest(pins['host']['python']['path']) == pins['host']['python']['sha256'], 'Python pin')
    report = {'scope': 'Read/hash-only audit of three once-only compiler proofs; no product execution',
              'audited_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'passed': True,
              'audit_script': record(__file__), 'source_manifest': record(manifest_path),
              'source_files_after': len(actual), 'source_fingerprint': fingerprint,
              'products': [audit_kind(k, expected, pins, manifest, fingerprint) for k in KINDS],
              'native_execution': 'NOT_RUN', 'emulator': 'NOT_RUN', 'physical': 'NOT_RUN'}
    out = PREP / 'compiler-only-audit-final-v1.json'
    with out.open('x') as f:
        json.dump(report, f, indent=2); f.write('\n')
    print(json.dumps({'audit': record(out), 'products': report['products']}))


if __name__ == '__main__':
    main()
