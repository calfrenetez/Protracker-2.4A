#!/usr/bin/env python3
"""Run one root-authorized helper invocation, archive bytes, never run its HUNK."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time
import traceback

ROOT = Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/readers-boundary-w5pj8drq')
PREP = ROOT / 'native-preparation'
PYTHON = '/opt/homebrew/opt/python@3.14/bin/python3.14'
MANIFEST_SHA = 'f541a748bea7c7801d7ef3ecf76303292de38f188c022793decde67fc3a8b439'
HELPER_SHA = 'c76506544fb11072436f7894c2425d83cd05ec8f02929df66072ca9e730c542e'
PINS_SHA = '22ac81cd691e00c5ee75a10b855966eed23a52edf741fcc624a907b37cf0b461'
CONTRACTS = {
    'genuine': 'c83834b7ff16cc08bc2ff0d89282d3a24191507ae16aa542e3183663134104b1',
    'startup': '5e63ca433d021a7aec515516b1641d3eadf61cccf25631b765f2bd5a23d2aa1b',
    'boundary': '6a6fc176505abc7943890b82105921a23ec9e8b84c214afb0abeb18c0b44631a',
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require_pin(path, expected):
    p = Path(path)
    if not p.is_file() or p.is_symlink() or digest(p) != expected:
        raise ValueError('Pinned regular control changed: ' + str(p))


def record(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}


def write_json(path, value):
    staged = path.with_suffix(path.suffix + '.writing')
    staged.write_text(json.dumps(value, indent=2) + '\n')
    staged.replace(path)


def archive(private, archive):
    archive.mkdir()
    mappings = []
    if private.exists():
        for original in sorted(private.rglob('*')):
            if original.is_symlink() or not original.is_file():
                raise ValueError('Unexpected non-file proof member: ' + str(original))
            relative = original.relative_to(private)
            destination = archive / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            before = record(original)
            data = original.read_bytes()
            destination.write_bytes(data)
            after, saved = record(original), record(destination)
            if before != after or before['sha256'] != saved['sha256'] or before['bytes'] != saved['bytes']:
                raise ValueError('Proof copy changed: ' + str(original))
            mappings.append({'relative_path': relative.as_posix(), 'original': before, 'durable': saved})
    return mappings


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CONTRACTS:
        raise ValueError('Exactly one authorized genuine/startup/boundary product required')
    kind = sys.argv[1]
    layout = json.loads((PREP / 'compiler-only-run-layout-final-v1.json').read_text())
    private = Path(layout['products'][kind]['private_output'])
    durable = Path(layout['products'][kind]['durable_archive'])
    helper = PREP / 'build_readers_boundary_portability.py'
    manifest = ROOT / 'boundary-native-source-manifest-final-v1.json'
    pins = PREP / 'toolchain-pins.json'
    contract = PREP / (kind + '-fixture-contract.json')
    for path, expected in ((helper, HELPER_SHA), (manifest, MANIFEST_SHA),
                           (pins, PINS_SHA), (contract, CONTRACTS[kind])):
        require_pin(path, expected)
    if private.exists() or durable.exists():
        raise ValueError('Private/durable product output already exists; no retry')
    prefix = kind + '-compiler-outer-final-v1'
    receipt_path = PREP / (prefix + '.json')
    stdout_path, stderr_path = PREP / (prefix + '.stdout'), PREP / (prefix + '.stderr')
    argv = [PYTHON, '-B', str(helper), '--source', str(ROOT / 'candidate'),
            '--fixture-contract', str(contract), '--fixture-contract-sha256', CONTRACTS[kind],
            '--source-manifest', str(manifest), '--source-manifest-sha256', MANIFEST_SHA,
            '--pins', str(pins), '--pins-sha256', PINS_SHA, '--out', str(private)]
    receipt = {
        'kind': kind, 'scope': 'Exactly one authorized compiler-only helper invocation; no product execution',
        'argv': argv, 'cwd': str(PREP), 'private_output': str(private), 'durable_archive': str(durable),
        'started_utc': datetime.datetime.now(datetime.UTC).isoformat(),
        'controls_before': [record(path) for path in (helper, manifest, pins, contract)],
        'wrapper': record(__file__), 'helper_invocations': 0, 'native_execution': 'NOT_RUN',
    }
    with receipt_path.open('x') as f:
        json.dump(receipt, f, indent=2); f.write('\n')
    started = time.monotonic()
    try:
        with stdout_path.open('x') as stdout, stderr_path.open('x') as stderr:
            receipt['helper_invocations'] = 1
            write_json(receipt_path, receipt)
            completed = subprocess.run(argv, cwd=PREP, stdout=stdout, stderr=stderr)
        receipt['returncode'] = completed.returncode
        receipt['elapsed_seconds'] = time.monotonic() - started
        receipt['stdout'], receipt['stderr'] = record(stdout_path), record(stderr_path)
        receipt['durable_mapping'] = archive(private, durable)
        receipt['controls_after'] = [record(path) for path in (helper, manifest, pins, contract)]
        if receipt['controls_after'] != receipt['controls_before']:
            raise ValueError('Outer control inventory changed during invocation')
        receipt['finished_utc'] = datetime.datetime.now(datetime.UTC).isoformat()
        receipt['passed'] = completed.returncode == 0
    except Exception as error:
        receipt['passed'] = False
        receipt['failure'] = {'kind': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
        receipt['finished_utc'] = datetime.datetime.now(datetime.UTC).isoformat()
    write_json(receipt_path, receipt)
    durable.mkdir(exist_ok=True)
    write_json(durable / 'outer-archive-mapping.json', {
        'scope': 'Exact unchanged helper proof bytes; separate original-to-durable mapping',
        'outer_invocation': record(receipt_path), 'mappings': receipt.get('durable_mapping', []),
        'native_execution': 'NOT_RUN',
    })
    print(json.dumps({'kind': kind, 'passed': receipt['passed'], 'receipt': record(receipt_path),
                      'durable_archive': str(durable), 'returncode': receipt.get('returncode')}))
    print(stdout_path.read_text() if stdout_path.exists() else '')
    print(stderr_path.read_text() if stderr_path.exists() else '')
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
