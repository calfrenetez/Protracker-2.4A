#!/usr/bin/env python3
"""Archive exact completed saved proofs; never compile, run or extract targets."""
import gzip, hashlib, io, json, tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'candidate'
OUT = BASE / 'package'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    OUT.mkdir(exist_ok=False)
    members = {}
    def put(name, path):
        assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts
        members[name] = Path(path).read_bytes()
    def tree(prefix, path):
        for p in sorted(Path(path).rglob('*')):
            assert not p.is_symlink()
            if p.is_file():
                put(prefix + '/' + p.relative_to(path).as_posix(), p)
    lanes = ('boundary-host-final-v1', 'root-host-final-v1', 'native-genuine-final-v1',
             'native-startup-final-v1', 'native-boundary-final-v1')
    inputs = set()
    for lane in lanes:
        tree('proof/' + lane, BASE / lane)
        native = lane.startswith('native-')
        report = json.loads((BASE / lane / ('manifest.json' if native else 'host-checks.json')).read_text())
        assert report['passed']
        if native:
            assert report['native_NOT_RUN']
            for target in report['targets'].values():
                inputs.update(target['dependencies'])
        else:
            inputs.update(report['canonical_dependencies'])
    for lane in ('native-preparation', 'boundary-tools-v1', 'root-tools'):
        tree('preparation/' + lane, BASE / lane)
    for path in sorted(BASE.glob('*.json')):
        # The previous task's rejected publication receipt is never included.
        assert 'startup-independent-packet-review' not in path.name
        put('records/' + path.name, path)
    for pattern in ('*.patch', '*.stdout', '*.stderr'):
        for path in sorted(BASE.glob(pattern)):
            put('records/' + path.name, path)
    put('preparation/package_boundary_evidence.py', Path(__file__))
    for name in ('audit_boundary_native.py', 'verify_boundary_payload.py',
                 'audit_readers_boundary_host_v1.py', 'freeze_readers_boundary.py',
                 'run_readers_boundary_host_v1.py'):
        put('preparation/' + name, BASE / name)
    manifest = json.loads((BASE / 'boundary-source-manifest-final-v1.json').read_text())
    inputs.update(manifest['owned'])
    inputs.update(('tests/test_sampler.py', 'tests/test_sampler_paula_readers.py',
                   'tests/test_sampler_paula_readers_prepare.py', 'tests/test_sampler_paula_readers_boundary.py',
                   'tests/test_paula_preflight.py', 'tests/test_render_sequence.py',
                   'tests/test_render_plan.py', 'tests/test_scheduled_readers.py',
                   'tools/build_core_tests.py', 'tools/build_diagnostic.py'))
    for name in sorted(inputs):
        assert sha((SOURCE / name).read_bytes()) == manifest['source'][name]
        put('source/' + name, SOURCE / name)
    with tarfile.open(BASE / 'base.tar') as tar:
        for name in ('src/editor/sampler_paula_readers.c', 'src/editor/sampler_paula_readers.h',
                     'tests/test_sampler_paula_readers.py', 'tests/test_sampler_paula_readers_prepare.py'):
            members['baseline/' + name] = tar.extractfile(name).read()
    payload = OUT / 'payload.tar.gz'
    with payload.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for name, value in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(value), 0o644, 0
                    tar.addfile(info, io.BytesIO(value))
    result = {'scope': 'Optional exact renderer-boundary Paula lowering: saved host and compiler proofs only; native/target/physical/activation/timing/audio/listening NOT_RUN.',
              'base_commit': manifest['base_commit'],
              'payload': {'bytes': payload.stat().st_size, 'sha256': sha(payload.read_bytes())},
              'files': [{'path': name, 'bytes': len(value), 'sha256': sha(value)} for name, value in sorted(members.items())]}
    (OUT / 'manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    with tarfile.open(payload) as tar:
        assert {m.name: tar.extractfile(m).read() for m in tar.getmembers()} == members
    print(json.dumps({'members': len(members), 'uncompressed_bytes': sum(map(len, members.values())), 'payload': result['payload']}))

if __name__ == '__main__':
    main()
