from pathlib import Path
import json,subprocess,time,hashlib
root=Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/readers-boundary-w5pj8drq')
python='/opt/homebrew/opt/python@3.14/bin/python3.14'
argv=[python,'-B',str(root/'boundary-tools-v1/host_provenance.py'),'--source',str(root/'candidate'),'--source-manifest',str(root/'boundary-source-manifest-final-v1.json'),'--source-manifest-sha256','8bf7829da92f80ac1ce5d9a81b6296f84c511926b5a26e1b3b8324568efe0a5b','--pins',str(root/'boundary-tools-v1/toolchain-pins.json'),'--pins-sha256','ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065','--out','/private/tmp/pt-readers-boundary-host-v1']
t=time.monotonic();r=subprocess.run(argv,capture_output=True,text=True,timeout=180)
stdout=root/'boundary-host-v1.stdout';stderr=root/'boundary-host-v1.stderr';stdout.write_text(r.stdout);stderr.write_text(r.stderr)
rec={'argv':argv,'returncode':r.returncode,'elapsed_s':time.monotonic()-t,'stdout':str(stdout),'stderr':str(stderr),'scope':'Host-only three sanitizer groups; no native product execution'}
(root/'boundary-host-v1-invocation.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec));print(r.stdout[-3000:]);print(r.stderr[-1200:]);raise SystemExit(r.returncode)
