#!/usr/bin/env python3
"""One-run Mac CPU comparison; never runs target code or touches target locks."""
import hashlib,json,platform,re,shlex,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
FLAGS=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core','-Isrc/editor']
SOURCES=['src/editor/sampler_paula_readers.c','src/editor/sampler_paula.c','src/core/sample_cache.c',
    'src/core/playback_pcm.c','src/core/scheduled_readers.c','src/core/elapsed_clock.c','src/editor/sampler.c',
    'src/editor/slots.c','src/core/pcm_filtered.c','src/core/slices.c','src/core/pattern.c','src/core/document.c',
    'src/core/pp20.c','src/core/project.c','src/core/mod_project.c','src/core/mod_inspect.c','src/core/channels.c',
    'src/core/pcm.c','src/core/wav.c','src/core/svx.c','src/core/raw.c']
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run_case(name,root,extra):
    out=HERE/name;out.mkdir(exist_ok=False)
    command=['/usr/bin/cc',*FLAGS,*extra,str(HERE/'startup.c'),*SOURCES,'-o',str(out/'startup')]
    dependency_rows=[];inputs=set()
    for source in [str(HERE/'startup.c'),*SOURCES]:
        cmd=['/usr/bin/cc',*FLAGS,*extra,'-M',source]
        result=subprocess.run(cmd,cwd=root,capture_output=True,text=True,check=True)
        dependency_rows.append(dict(command=cmd,stdout=result.stdout,stderr=result.stderr,returncode=result.returncode))
        names=shlex.split(re.sub(r'\\\r?\n',' ',result.stdout).split(':',1)[1])
        inputs.update(str((root/Path(p)).resolve()) if not Path(p).is_absolute() else p for p in names)
    before={p:sha(p) for p in sorted(inputs)}
    started=time.monotonic()
    compile_run=subprocess.run(command,cwd=root,capture_output=True,text=True)
    (out/'compile.stdout').write_text(compile_run.stdout);(out/'compile.stderr').write_text(compile_run.stderr)
    assert compile_run.returncode==0,compile_run.stderr
    execution=subprocess.run([str(out/'startup')],capture_output=True,text=True,timeout=60)
    (out/'run.stdout').write_text(execution.stdout);(out/'run.stderr').write_text(execution.stderr)
    after={p:sha(p) for p in sorted(inputs)}
    result=dict(scope='Single-run Mac CPU and requested payload only; not 030 wall-clock, WCET, RSS, Fast/Chip placement, audio or listening',
        source=str(root),command=command,dependency_commands=dependency_rows,source_before=before,source_after=after,
        source_unchanged=before==after,compile_returncode=compile_run.returncode,returncode=execution.returncode,
        binary=dict(bytes=(out/'startup').stat().st_size,sha256=sha(out/'startup')),
        host=platform.platform(),compiler=dict(path='/usr/bin/cc',sha256=sha('/usr/bin/cc'),
        version=subprocess.check_output(['/usr/bin/cc','--version'],text=True)),outer_seconds=time.monotonic()-started)
    if execution.returncode==0:result['observations']=json.loads(execution.stdout)
    (out/'record.json').write_text(json.dumps(result,indent=2)+'\n')
    assert execution.returncode==0 and before==after,execution.stderr
    return result['observations']
if __name__=='__main__':
    before=run_case('before',HERE/'baseline',[])
    after=run_case('after',PARENT/'candidate',['-DASYNC_STARTUP'])
    result=dict(scope='Same 8 MiB stereo24 payload and public APIs; one serialized host observation each',before=before,after=after)
    (HERE/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
