#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sampler_paula_readers.h"
#define VALUES (2U * 1048576U)
struct memory {size_t live, bytes, peak;unsigned calls;};
struct block {size_t bytes;};
static void *alloc(void *context,size_t bytes)
{
    struct memory *m=context;struct block *p=malloc(sizeof(*p)+bytes);
    if(!p)return NULL;
    p->bytes=bytes;++m->live;++m->calls;m->bytes+=bytes;
    if(m->bytes>m->peak)m->peak=m->bytes;
    return p+1;
}
static void release(void *context,void *data)
{
    struct memory *m=context;struct block *p;
    if(!data)return;
    p=(struct block *)data-1;assert(m->live&&m->bytes>=p->bytes);
    --m->live;m->bytes-=p->bytes;free(p);
}
static void *chip_alloc(void *context,size_t bytes){return alloc(context,bytes);}
static void chip_release(void *context,void *data,size_t bytes)
{assert(((struct block *)data-1)->bytes==bytes);release(context,data);}
static uint64_t fingerprint(const int32_t *pcm,size_t count)
{uint64_t v=1469598103934665603ULL;size_t i;for(i=0;i<count;++i){v^=(uint32_t)pcm[i];v*=1099511628211ULL;}return v;}
int main(void)
{
    struct memory fast={0},chip={0};struct pt_allocator a={&fast,alloc,release};
    struct pt_sampler sampler;struct pt_project p;struct pt_sample sample;
    struct pt_event events[PT_PROJECT_ROWS*4];uint16_t order=0;
    struct pt_paula_readers_config c={2,2,1048576,65536,7,&chip,chip_alloc,chip_release};
    struct pt_paula_readers_pool *pool=NULL;int32_t *pcm;uint64_t before;size_t i;
    clock_t start,end,maximum=0,total=0;unsigned calls=0;size_t workspace=0;
    pcm=malloc((VALUES+64)*sizeof(*pcm));assert(pcm);
    for(i=0;i<VALUES+64;++i)pcm[i]=(int32_t)(i%1000)-500;
    memset(&p,0,sizeof(p));memset(&sample,0,sizeof(sample));memset(events,0,sizeof(events));
    pt_channels_init(&p.channels);p.orders=&order;p.order_count=1;p.events=events;p.pattern_count=1;
    p.samples=&sample;p.sample_count=1;p.speed=6;p.bpm=125;p.mode=PT_MODE_WAVETABLE;
    sample.volume=64;sample.pcm=(struct pt_pcm){pcm,VALUES+64,VALUES/2,48000,2,24};
    pt_sampler_init(&sampler,&a,1048576);before=fingerprint(pcm,VALUES+64);
#ifdef ASYNC_STARTUP
    {
        struct pt_paula_readers_preparation preparation={0};enum pt_paula_readers_result r;
        workspace=sizeof(preparation);
        start=clock();
        r=pt_paula_readers_prepare_begin(&preparation,&a,&sampler,&p,&c,1);
        end=clock();assert(r==PT_PAULA_READERS_OK);total+=end-start;maximum=end-start;++calls;
        assert(!fast.calls&&!chip.calls);
        do {
            start=clock();r=pt_paula_readers_prepare_step(&preparation,1,4096);end=clock();
            assert(r==PT_PAULA_READERS_PENDING||r==PT_PAULA_READERS_OK);
            total+=end-start;if(end-start>maximum)maximum=end-start;++calls;
            assert(!fast.calls&&!chip.calls);
        }while(r==PT_PAULA_READERS_PENDING);
        start=clock();r=pt_paula_readers_prepare_transfer(&preparation,1,&pool);end=clock();
        assert(r==PT_PAULA_READERS_OK&&pool);
        total+=end-start;if(end-start>maximum)maximum=end-start;++calls;
        pt_paula_readers_prepare_cancel(&preparation);
    }
#else
    start=clock();assert(pt_paula_readers_open(&a,&sampler,&p,&c,&pool)==PT_PAULA_READERS_OK);end=clock();
    maximum=total=end-start;calls=1;
#endif
    assert(fingerprint(pcm,VALUES+64)==before&&!chip.calls);
    assert(pt_paula_readers_close(pool));pt_sampler_release(&sampler);
    assert(!fast.live&&!fast.bytes&&!chip.live&&!chip.bytes);free(pcm);
    printf("{\"calls\":%u,\"max_call_cpu_us\":%.3f,\"total_cpu_us\":%.3f,\"master_bytes\":%lu,"
           "\"caller_workspace_bytes\":%lu,\"peak_aux_requested_bytes\":%lu,\"allocations\":%u,"
           "\"chip_allocations\":%u,\"final_owned_bytes\":%lu}\n",calls,
           1000000.0*(double)maximum/CLOCKS_PER_SEC,1000000.0*(double)total/CLOCKS_PER_SEC,
           (unsigned long)((VALUES+64)*sizeof(int32_t)),(unsigned long)workspace,
           (unsigned long)fast.peak,fast.calls,chip.calls,(unsigned long)fast.bytes);
    return 0;
}
