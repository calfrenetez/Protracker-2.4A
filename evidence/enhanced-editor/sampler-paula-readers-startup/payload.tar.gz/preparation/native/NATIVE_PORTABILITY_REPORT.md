# Frozen V2 readers compiler portability qualification

Both approved contracts passed their only compiler invocation. The saved proofs contain 32 RC0 commands per contract: compiler identification, target help, seven pinned runtime resolutions, 21 full `-M` dependency queries, SDK assertion preprocessing, and one compile/link. Both compile logs are empty. No compiled product was executed and no target, browser, shared lock, reservation, control or recovery operation occurred.

| Contract | Product | Bytes | SHA256 |
| --- | --- | ---: | --- |
| genuine | PTPaulaReadersTest | 168,816 | 9dcff2d4eec448ec09c2642ab2ecd43c2512227d0c75dc0d0c38d1a441e73407 |
| startup | PTPaulaReadersStartupTest | 155,792 | d32b442ad5e980c7acb91a243c4c5a009d88e3484b331ff4cf520e7a461319b1 |

The exact reviewed helper is `build_readers_portability.py`, SHA256 `5a750e5275a25d16c0f8907c54e42e46e3b8142e3b86358f2a8a2e3f91f92f6c`; root approval is preserved in `../root-build-review.json`. Control and contract hashes remained as approved. The immutable source manifest is `../native-source-manifest.json`, SHA256 `142cfd731b1b412595b04ff901710f12e7f5e770a14e68f2c053079254bd6725`, with base commit `c8550f0b55a7058d92cd81f452309d49cdfd12ea` and base tree `c27cf925d5f02bbd5cf3c06c706d5ebe4c81cdbc`.

Both proofs retain the complete source before/after guards for 8,093 files, fingerprint `842bbcace4e042d9749396aa6e4bdc0375f352abb77c1c53cc7a565050f96412`. A separate read/hash audit rechecked the full current candidate inventory against that manifest after both builds and found it unchanged. The audit also reparsed all actual saved dependency outputs, compared their unions to the recorded closures and rehashed all closure files and saved compiler logs. Each product has 53 frozen-source dependencies, 32 external SDK dependencies and seven pinned runtime inputs. The fixture includes `sampler_paula_readers.c` once; it is not separately linked.

The compiler is pinned GCC 6.5.0b 20260807212032. Both exact compile argument lists use `-std=c99 -m68000 -msoft-float -mcrt=nix20 -Os -Wall -Wextra -Werror -Isrc/core -Ibuild/dev -fbbb=-`. This qualifies the inherited 68000/software-float compiler and runtime recipe; no instruction-level binary scan or hardware CPU execution is claimed. The SDK assertion macro expands to `__assert_func` and assertions are active: the saved genuine/startup preprocessor outputs contain 165/77 occurrences of `__assert_func (` respectively, including the macro/declaration text. Neither command defines `NDEBUG`.

Each product starts with `HUNK_HEADER0x000003f3`, and each full literal contract completion marker occurs once in its preprocessing output and once in its linked HUNK. Marker presence proves link preservation, not execution of the asserted behavior.

The genuine outer invocation completed RC0 in 91.777 seconds; startup completed RC0 in 6.230 seconds. These are host compiler/provenance times, not target preparation or musical timing measurements. Outer invocation arguments/results and outputs are preserved alongside this report. Original preparation records remain unchanged.

Full durable machine audit: `native-products-audit.json`, SHA256 `9b8a9a0659a3666038889c32b282e9c4822cbae0a7ca3b407a20f578a8c78c16`. The independent audit source is `audit_native_products.py`, SHA256 `47b1859c5df2db7e71b788ece300dc32c0e764d15bbdce9100a5fe25c593c6f9`. Genuine proof manifest SHA256 `f06fbe0726be93499160b07d24a2c5475dde4fbc77983c8509a3781738f90d64`; startup proof manifest SHA256 `00af3d9fb8bac379ff65bdba63d6572e288646d28f56d616cfe855b6e3c0a8b0`. The audit inventory retains hashes and sizes of every saved native-proof file.

Native/emulator/physical execution: **NOT_RUN**. This compiler-only result does not qualify native Exec/Fast allocation, actual Chip memory, Paula DMA or voice stop, card sample RAM, register access, IRQ/audio, musical timing, or listening. Target execution remains a later separately coordinated scope owned by the root task.
