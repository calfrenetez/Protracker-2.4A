#!/usr/bin/env python3
"""Read and hash saved compiler evidence only; never execute its products."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import shlex
import struct
import traceback

ROOT = Path('/Users/james1/Documents/Codex/2026-09-18/rev/outputs/readers-startup-3qab5dsf')
PREP = ROOT / 'native-preparation'
SOURCE = ROOT / 'candidate'
FLAGS = ['-std=c99', '-m68000', '-msoft-float', '-mcrt=nix20', '-Os',
         '-Wall', '-Wextra', '-Werror', '-Isrc/core', '-Ibuild/dev', '-fbbb=-']
CONTROL_PINS = {
    'native-source-manifest.json': '142cfd731b1b412595b04ff901710f12e7f5e770a14e68f2c053079254bd6725',
    'root-build-review.json': '8b5ba55e29d016a0047dc135e179fcf632c616e16fd75ea37674422302e48292',
    'native-preparation/build_readers_portability.py': '5a750e5275a25d16c0f8907c54e42e46e3b8142e3b86358f2a8a2e3f91f92f6c',
    'native-preparation/toolchain-pins.json': '22ac81cd691e00c5ee75a10b855966eed23a52edf741fcc624a907b37cf0b461',
    'native-preparation/genuine-fixture-contract.json': 'f8167f8b035f2f5058a09655c16058a23b013b81e0b81295a99b67d7167acc28',
    'native-preparation/startup-fixture-contract.json': '319f75ecccc851ca1efe8211982a88eb0c60e8fbb6c7bf0591cdcc3ea0985105',
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    p = Path(path)
    if not p.is_file() or p.is_symlink():
        raise ValueError('Expected regular evidence/input file: ' + str(p))
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_record(value):
    require(record(value['path']) == value, 'Saved evidence hash/size mismatch: ' + value['path'])


def dependency_names(text):
    text = re.sub(r'\\\r?\n', ' ', text)
    names = []
    for line in text.splitlines():
        colon = re.search(r'(?<!\\):', line)
        if colon:
            names.extend(shlex.split(line[colon.end():]))
    return list(dict.fromkeys(names))


def main():
    report = {
        'scope': 'Independent audit of two saved pinned 68k compiler-only proofs; no product execution',
        'started_utc': datetime.datetime.now(datetime.UTC).isoformat(),
        'passed': False,
        'native_execution': 'NOT_RUN',
        'emulator_execution': 'NOT_RUN',
        'physical_execution': 'NOT_RUN',
        'software_ownership_only': True,
        'controls': {},
        'products': {},
        'excluded_acceptance': ['Native/Exec allocation', 'Chip DMA', 'Paula voice stop',
                                'card sample RAM', 'device registers', 'IRQ/audio',
                                'musical timing', 'human listening'],
    }
    report_path = PREP / 'native-products-audit.json'
    require(not report_path.exists(), 'Audit output already exists; preserve prior evidence')
    try:
        for relative, expected in CONTROL_PINS.items():
            item = record(ROOT / relative)
            require(item['sha256'] == expected, 'Approved control changed: ' + relative)
            report['controls'][relative] = item
        frozen = json.loads((ROOT / 'native-source-manifest.json').read_text())
        expected = frozen['files']
        fingerprint = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        actual = {}
        for path in sorted(SOURCE.rglob('*')):
            require(not path.is_symlink(), 'Source symlink found: ' + str(path))
            if path.is_file():
                actual[path.relative_to(SOURCE).as_posix()] = digest(path)
        require(actual == expected, 'Complete source inventory changed after builds')
        report['complete_source_after_audit'] = {
            'files': len(actual), 'fingerprint': fingerprint,
            'base_commit': frozen['base_commit'], 'base_tree': frozen['base_tree'],
            'status': 'Exact complete frozen inventory unchanged',
        }
        pins_document = json.loads((PREP / 'toolchain-pins.json').read_text())
        pins = dict(pins_document['native'])
        pins['python'] = pins_document['host']['python']
        for kind in ('genuine', 'startup'):
            out = ROOT / ('native-' + kind)
            contract = json.loads((PREP / (kind + '-fixture-contract.json')).read_text())
            manifest_path = out / 'manifest.json'
            manifest = json.loads(manifest_path.read_text())
            outer = json.loads((PREP / (kind + '-outer-invocation.json')).read_text())
            require(manifest['passed'] is True and manifest['native_NOT_RUN'] is True, kind + ' proof not passed/unrun')
            require(outer['returncode'] == 0, kind + ' outer invocation failed')
            require(manifest['source_fingerprint'] == fingerprint and
                    manifest['source_files_before'] == len(expected) and
                    manifest['source_files_after'] == len(expected) and
                    manifest['base_commit'] == frozen['base_commit'] and
                    manifest['base_tree'] == frozen['base_tree'], kind + ' source provenance mismatch')
            require(set(manifest['targets']) == {contract['target']}, kind + ' contains unexpected product')
            require(manifest['flags'] == FLAGS, kind + ' flags changed')
            require(manifest['runtime_inputs'] == pins['runtime_inputs'], kind + ' runtime set changed')
            for key in ('source_manifest', 'pins', 'fixture_contract', 'builder', 'compile_commands'):
                validate_record(manifest[key])
            for value in manifest['recipe_contract'].values():
                if isinstance(value, dict) and set(value) == {'path', 'bytes', 'sha256'}:
                    validate_record(value)
            for tool in ('compiler', 'python'):
                require(digest(manifest[tool]['path']) == manifest[tool]['sha256'] == pins[tool]['sha256'], kind + ' toolchain hash changed')
            for name, path in manifest['runtime_paths'].items():
                require(digest(path) == pins['runtime_inputs'][name], kind + ' runtime changed: ' + name)
            target = manifest['targets'][contract['target']]
            require(target['source_inputs'] == contract['ordered_sources'] and target['flags'] == FLAGS,
                    kind + ' target input/flag mismatch')
            require(len(set(target['source_inputs'])) == 21 and
                    'src/editor/sampler_paula_readers.c' not in target['source_inputs'], kind + ' duplicate adapter linking')
            require((SOURCE / contract['fixture']).read_text().count('#include "../src/editor/sampler_paula_readers.c"') == 1,
                    kind + ' adapter not included exactly once')
            require(manifest['recipe_contract']['exact_ordered_translation_units'] == contract['ordered_sources'],
                    kind + ' recipe order changed')
            commands = manifest['commands']
            expected_labels = ['compiler-version', 'compiler-target-help'] + [
                'runtime-' + name.replace('.', '-') for name in pins['runtime_inputs']
            ] + ['dependencies-%02d' % i for i in range(21)] + ['preprocessed-fixture', contract['target'] + '.build']
            require([c['label'] for c in commands] == expected_labels and len(commands) == 32,
                    kind + ' command sequence/count changed')
            for command in commands:
                require(command['returncode'] == 0 and command['directory'] == str(SOURCE), kind + ' command failed/retargeted')
                validate_record(command['log'])
                require(command['argv'][0] == pins['compiler']['path'], kind + ' unpinned command executable')
            source_dependencies, sdk_dependencies = {}, {}
            for index, unit in enumerate(contract['ordered_sources']):
                command = commands[9 + index]
                require(command['argv'] == [pins['compiler']['path'], *FLAGS, '-M', unit], kind + ' full -M query changed')
                for name in dependency_names(Path(command['log']['path']).read_text()):
                    path = (SOURCE / name).resolve()
                    if path == SOURCE or SOURCE in path.parents:
                        relative = path.relative_to(SOURCE).as_posix()
                        require(relative in expected and digest(path) == expected[relative], kind + ' source dependency changed')
                        source_dependencies[relative] = expected[relative]
                    else:
                        require(str(path) in target['external_sdk_dependencies'], kind + ' unsaved external dependency')
                        sdk_dependencies[str(path)] = digest(path)
            require(source_dependencies == target['dependencies'] and sdk_dependencies == target['external_sdk_dependencies'],
                    kind + ' saved actual closure mismatch')
            require('src/editor/sampler_paula_readers.c' in source_dependencies and contract['fixture'] in source_dependencies,
                    kind + ' fixture/reader source missing from closure')
            compile_commands = json.loads((out / 'compile-commands.json').read_text())['commands']
            expected_build = [pins['compiler']['path'], *FLAGS, *contract['ordered_sources'], '-o', str(out / contract['target'])]
            require(len(compile_commands) == 1 and compile_commands[0]['argv'] == expected_build and
                    commands[-1]['argv'] == expected_build, kind + ' not exactly one expected compile/link')
            require(commands[-2]['argv'] == [pins['compiler']['path'], *FLAGS, '-E', '-dD', contract['fixture']],
                    kind + ' assertion preprocessing command changed')
            for key in ('binary', 'preprocessed_fixture', 'build_log'):
                validate_record(target[key])
            cpp = Path(target['preprocessed_fixture']['path']).read_text()
            macros = re.findall(r'^#define assert\([^\n]*', cpp, re.MULTILINE)
            require(macros and macros[-1] == target['last_assert_macro'] and '__assert_func' in macros[-1], kind + ' assertions disabled')
            expansion_count = cpp.count('__assert_func (')
            require(expansion_count >= 2 and cpp.count(contract['marker']) == 1, kind + ' assertion/marker preprocessing mismatch')
            raw = Path(target['binary']['path']).read_bytes()
            require(struct.unpack('>I', raw[:4])[0] == 0x3f3 and raw.count(contract['marker'].encode()) == 1,
                    kind + ' HUNK/marker product mismatch')
            require(target['build_log']['bytes'] == 0, kind + ' compile/link diagnostic output present')
            report['products'][kind] = {
                'binary': target['binary'], 'manifest': record(manifest_path),
                'outer_invocation': record(PREP / (kind + '-outer-invocation.json')),
                'outer_output': record(PREP / (kind + '-outer-output.txt')),
                'commands_rc0': len(commands), 'full_M_queries': 21,
                'source_dependencies': len(source_dependencies), 'SDK_dependencies': len(sdk_dependencies),
                'runtime_inputs': len(manifest['runtime_inputs']),
                'source_before_after_files': len(expected), 'source_fingerprint': fingerprint,
                'sdk_assert_macro': macros[-1], 'assert_func_occurrences_in_cpp': expansion_count,
                'completion_marker': contract['marker'], 'CPP_marker_count': 1, 'HUNK_marker_count': 1,
                'format': 'HUNK_HEADER0x000003f3',
                'no_FPU_scope': 'Exact compiler argv uses -m68000 -msoft-float with pinned runtimes; no instruction-level binary scan or hardware execution claimed',
                'elapsed_outer_seconds': outer['elapsed_seconds'],
                'saved_evidence_inventory': [record(p) for p in sorted(out.iterdir()) if p.is_file()],
            }
        report['passed'] = True
    except Exception as error:
        report['failure'] = {'kind': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    report['finished_utc'] = datetime.datetime.now(datetime.UTC).isoformat()
    report['auditor'] = record(__file__)
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'report': record(report_path),
                      'products': {key: value['binary'] for key, value in report['products'].items()}}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
