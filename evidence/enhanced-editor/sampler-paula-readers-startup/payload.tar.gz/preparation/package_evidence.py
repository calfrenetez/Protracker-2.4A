#!/usr/bin/env python3
"""Archive exact completed host/compiler proof bytes; no tests or target calls."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
SOURCE=BASE/'candidate'
OUT=BASE/'package'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);members={}
    def put(name,path):
        assert name not in members,name
        members[name]=Path(path).read_bytes()
    def tree(prefix,path):
        for p in sorted(Path(path).rglob('*')):
            assert not p.is_symlink(),p
            if p.is_file():put(prefix+'/'+p.relative_to(path).as_posix(),p)
    for name in ('startup-host-v1','startup-host-v2','root-regression-proof','native-genuine','native-startup'):
        tree('proof/'+name,BASE/name)
    for name in ('startup-host-v1','startup-host-v2','root-regression-proof'):
        assert json.loads((BASE/name/'host-checks.json').read_text())['passed']
    native=[]
    for name in ('native-genuine','native-startup'):
        d=json.loads((BASE/name/'manifest.json').read_text());assert d['passed'] and d['native_NOT_RUN']
        native.append(d)
    tree('compiled-overlay',BASE/'compiled-overlay')
    owned=json.loads((BASE/'startup-source-manifest-v2.json').read_text())['owned_overlays']
    for version in ('v1','v2'):
        for name in owned:
            put('source-overlays/startup-final-'+version+'/'+name,BASE/('startup-source-final-'+version)/name)
    tree('preparation/native',BASE/'native-preparation')
    tree('preparation/startup-host-tools-v1',BASE/'startup-tools-v1')
    tree('preparation/startup-host-tools-v2',BASE/'startup-tools-v2')
    tree('preparation/root-host-tools',BASE/'root-tools')
    tree('benchmark/before',BASE/'benchmark/before');tree('benchmark/after',BASE/'benchmark/after')
    for name in ('startup.c','run_comparison.py','comparison.json','baseline-source.json'):
        put('benchmark/'+name,BASE/'benchmark'/name)
    for p in sorted(BASE.glob('*.json')):put('records/'+p.name,p)
    for p in sorted(BASE.glob('*.log')):put('records/'+p.name,p)
    for p in sorted(BASE.glob('*.patch')):put('records/'+p.name,p)
    put('preparation/package_evidence.py',Path(__file__))
    inputs=set()
    for name in ('startup-host-v1','startup-host-v2','root-regression-proof'):
        d=json.loads((BASE/name/'host-checks.json').read_text());inputs.update(d['canonical_dependencies'])
    for d in native:
        for target in d['targets'].values():inputs.update(target['dependencies'])
    for name in sorted(inputs):
        assert not Path(name).is_absolute() and '..' not in Path(name).parts,name
        put('source/'+name,SOURCE/name)
    for name in ('tests/test_sampler.py','tests/test_sampler_paula_readers.py','tests/test_sampler_paula_readers_prepare.py',
                 'tests/test_sampler_paula.py','tests/test_project_validation.py','tests/test_scheduled_readers.py',
                 'tools/build_core_tests.py','tools/build_diagnostic.py'):
        if 'source/'+name not in members:put('source/'+name,SOURCE/name)
    with tarfile.open(BASE/'base.tar') as tar:
        for name in ('src/editor/sampler_paula_readers.c','src/editor/sampler_paula_readers.h'):
            members['baseline/'+name]=tar.extractfile(name).read()
    payload=OUT/'payload.tar.gz'
    with payload.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                for name,data in sorted(members.items()):
                    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                    tar.addfile(info,io.BytesIO(data))
    manifest={'scope':'Cancellable initial readers preparation; exact saved host and compiler evidence. Native/target/device/timing/audio/listening NOT RUN.',
        'base_commit':'c8550f0b55a7058d92cd81f452309d49cdfd12ea',
        'payload':{'bytes':payload.stat().st_size,'sha256':sha(payload.read_bytes())},
        'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())]}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with tarfile.open(payload) as tar:
        actual={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
    assert actual==members
    print(json.dumps({'members':len(members),'uncompressed_bytes':sum(map(len,members.values())),'payload':manifest['payload']}))
if __name__=='__main__':main()
