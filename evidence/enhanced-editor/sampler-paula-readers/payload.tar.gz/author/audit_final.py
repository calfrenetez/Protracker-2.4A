from pathlib import Path
import ast, hashlib, json, shlex, re
R=Path('/private/tmp/protracker-sampler-readers-gtljl35f');S=R/'source-final';B=R/'baseline'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(row,key='path'):
 p=Path(row[key]);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];return rec(p)
def inventory(p):return {q.relative_to(p).as_posix():sha(q) for q in sorted(p.rglob('*')) if q.is_file()}
def deps(txt):
 joined=re.sub(r'\\\r?\n',' ',txt);names=[]
 for line in joined.splitlines():
  colon=re.search(r'(?<!\\):',line)
  if colon:names+=shlex.split(line[colon.end():])
 return list(dict.fromkeys(names))
m=json.loads((R/'source-manifest.json').read_text());base=json.loads((R/'baseline-binding.json').read_text());h=json.loads((R/'host-final/host-checks.json').read_text())
assert inventory(B)==base['files'] and inventory(S)==m['files']==h['source_files_before']==h['source_files_after']
assert len(base['files'])==8012 and len(m['files'])==8017 and set(m['files'])-set(base['files'])==set(m['new_inputs'])
assert all(m['files'][name]==v for name,v in base['files'].items())
assert h['passed'] and h['modules']==['test_sampler_paula_readers'] and len(h['commands'])==2 and len(h['groups'])==1 and not h['generated_inputs']
records=[]
for row in h['helper_inputs']+h['module_inputs']:[records.append(check(row))]
for name,v in h['canonical_dependencies'].items():assert sha(S/name)==v
for name,v in h['external_sdk_dependencies'].items():assert sha(name)==v
for name,v in {**h['sanitizer_runtime_inputs'],**h['pinned_sdk_inputs']}.items():assert sha(name)==v
assert sha(h['compiler']['path'])==h['compiler']['sha256'] and sha(h['python']['path'])==h['python']['sha256']
rows=h['commands'][0]['dependency_commands'];assert len(rows)==21
unions={}
for c in h['commands']:
 assert c['stage']=='complete' and c['product_returncode']==0
 records.append(check(c['output_log']))
 for d in c['dependency_commands']:
  assert d['returncode']==0 and d['argv'][-2]=='-M';records.append(check(d['output']))
  for name in deps(Path(d['output']['path']).read_text()):
   q=Path(name);q=q if q.is_absolute() else S/q
   q=q.resolve();v=sha(q)
   try:n=q.relative_to(S).as_posix();assert h['canonical_dependencies'][n]==v
   except ValueError:assert h['external_sdk_dependencies'][str(q)]==v
   unions[str(q)]=v
assert len(unions)==156 and len(h['canonical_dependencies'])==51 and len(h['external_sdk_dependencies'])==105
for p in h['products']:records.append(check(p,'archive_path'))
assert len(h['products'])==1 and h['commands'][1]['input_binary']==h['products'][0]==h['commands'][0]['produced_binary']
assert h['commands'][1]['argv'][0]==h['products'][0]['original_path'].replace('/private/var/','/var/')
module=ast.parse((S/'tests/test_sampler.py').read_text());sampler=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets))
expected=['tests/sampler_paula_readers_test.c','src/editor/sampler_paula.c','src/core/sample_cache.c','src/core/playback_pcm.c','src/core/scheduled_readers.c','src/core/elapsed_clock.c',*sampler[1:]]
actual=[v for v in h['commands'][0]['argv'][1:] if v.endswith('.c')]
assert actual==expected and len(actual)==len(set(actual))==21
fixture=(S/actual[0]).read_text();assert fixture.count('#include "../src/editor/sampler_paula_readers.c"')==1 and 'src/editor/sampler_paula_readers.c' not in actual
marker='SAMPLER PAULA READERS PASS: genuine master and selective Chip cache retained through 20 controls with command capacity2'
assert Path(h['commands'][1]['output_log']['path']).read_text().strip()==marker
assert (S/'src/core/scheduled_readers.c').read_bytes()==(B/'src/core/scheduled_readers.c').read_bytes()
# Reference helper adaptation is exactly a docstring/module-label change.
ref=Path('/private/tmp/protracker-scheduled-readers-dmuzps6v/tools')
assert (R/'tools/provenance_common.py').read_bytes()==(ref/'provenance_common.py').read_bytes()
assert (R/'tools/toolchain-pins.json').read_bytes()==(ref/'toolchain-pins.json').read_bytes()
assert (R/'tools/host_provenance.py').read_text()==(ref/'host_provenance.py').read_text().replace('Run one focused split-domain reader/command host sanitizer group','Run one focused genuine sampler split-domain reader host sanitizer group').replace("MODULES = ['test_scheduled_readers']","MODULES = ['test_sampler_paula_readers']")
result={'scope':'Author byte/provenance audit only; no product rerun/native/target','passed':True,'baseline_count':8012,'final_count':8017,'source_manifest':rec(R/'source-manifest.json'),'baseline_binding':rec(R/'baseline-binding.json'),'final_patch':rec(R/'final.patch'),'new_inputs':m['new_inputs'],'host_report':rec(R/'host-final/host-checks.json'),'host_log':rec(R/'host-final/host-checks.log'),'host_invocation':rec(R/'host-final-invocation.log'),'groups':h['groups'],'elapsed_s':h['elapsed_s'],'commands_RC0':2,'full_M':21,'canonical':51,'system':105,'products':h['products'],'generated':0,'source_declarations':expected,'compiled_adapter_included_exactly_once':True,'checked_records':records,'compiler':h['compiler'],'python':h['python'],'sanitizer_runtime_inputs':h['sanitizer_runtime_inputs'],'pinned_sdk_inputs':h['pinned_sdk_inputs'],'history':{'development1':'preserved compile-refusal summary and fixture; original console tool output was not separately redirected','development2':'preserved product model assertion (STOP observation did not reflect retired reader)','development4_5':'preserved wrong test history-init argument compile refusals','development6':'preserved test count bytes incorrectly multiplied by sizeof(int32_t)','development3_7_8_9':'PASS development logs retained; development fixture snapshots where recorded are historical, not a claim of every transient header/source version'},'unqualified':['No installed native backend/ref-domain transfer/atomic activation','No native execution/Fast/Chip TypeOfMem/DMA/IRQ/audio/physical/listening/timing proof','Serialized backend model while actual sampler pins/cache ownership are genuine'],'repository':'No shared repository/Git/target action'}
(R/'own-final-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'review':rec(R/'own-final-review.json')},indent=2))
