import ast,hashlib,json,shlex
from pathlib import Path
r=Path('/private/tmp/protracker-scheduled-lineage-fyrcg2b7')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=lambda p:{str(x.relative_to(p)):sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
rec=lambda p:{'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
load=lambda p:json.loads(Path(p).read_text())
base=load(r/'baseline-manifest.json');old=load(r/'source-manifest.json');new=load(r/'source-manifest-v2.json');h=load(r/'host-final-v2/host-checks.json');freeze=load(r/'freeze-v2.json');pins=load(r/'tools/toolchain-pins.json')['host'];s=Path(new['source_path'])
assert sha(r/'baseline-manifest.json')=='81840112ee35328c2bf91cfb230dfe7bf52410f184bcddf33acdd0a4ab5dd103'
assert files(r/'baseline')==base['files'] and files(r/'source-final')==old['files'] and files(s)==new['files']
assert len(base['files'])==7973 and len(new['files'])==7978
assert all(new['files'][n]==v for n,v in base['files'].items())
assert set(new['files'])-set(base['files'])==set(x['path'] for x in new['overlays'])
for p,v in freeze['old_controls'].items():assert sha(p)==v
assert h['passed'] and h['source_files_before']==h['source_files_after']==7978
assert h['export_tree_sha256']==hashlib.sha256(json.dumps(new['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(h['commands'])==4 and len(h['products'])==2 and h['generated_inputs']==[]
assert len(h['canonical_dependencies'])==16 and len(h['external_sdk_dependencies'])==105
verified={}
def verify(p,v,n=None):
 assert sha(p)==v,(p,'sha')
 if n is not None:assert Path(p).stat().st_size==n
 verified[str(p)]=v
def record(x):verify(x['path'],x['sha256'],x['bytes'])
for name in ['source_manifest','pins','log','compiler','python']:record(h[name]) if 'bytes' in h[name] else verify(h[name]['path'],h[name]['sha256'])
assert h['compiler']==pins['compiler'] and h['python']==pins['python']
assert h['sanitizer_runtime_inputs']==pins['runtime_inputs'] and h['pinned_sdk_inputs']==pins['sdk_inputs']
for name,value in {**h['sanitizer_runtime_inputs'],**h['pinned_sdk_inputs'],**h['external_sdk_dependencies']}.items():verify(name,value)
for x in h['helper_inputs']+h['module_inputs']:record(x)
for name,value in h['canonical_dependencies'].items():assert new['files'][name]==value;verify(s/name,value)
query_count=0
for c in h['commands']:
 assert c['stage']=='complete' and c['product_returncode']==0
 record(c['output_log'])
 if c.get('canonical_inputs'):
  module=s/'tests'/('test_scheduled_lineage.py' if c['group']=='test_scheduled_lineage' else 'test_scheduled_output.py')
  tree=ast.parse(module.read_text());decl=None
  for n in ast.walk(tree):
   if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets):decl=ast.literal_eval(n.value)
  assert decl==[x['path'] for x in c['canonical_inputs']]
  assert c['executed_argv'][0]==pins['compiler']['path']
  assert '-fsanitize=address,undefined' in c['executed_argv'] and '-Werror' in c['executed_argv']
  for d in c['dependency_commands']:
   query_count+=1;assert d['returncode']==0 and '-M' in d['argv'];record(d['output'])
   raw=Path(d['output']['path']).read_text().replace('\\\n',' ');dep=shlex.split(raw.split(':',1)[1]);assert dep
   for name in dep:
    path=(s/name).resolve() if not Path(name).is_absolute() else Path(name).resolve()
    if path.is_relative_to(s):assert str(path.relative_to(s)) in c['dependencies']['canonical'];verify(path,c['dependencies']['canonical'][str(path.relative_to(s))])
    else:assert str(path) in c['dependencies']['external_sdk'];verify(path,c['dependencies']['external_sdk'][str(path)])
 for n,v in c.get('dependencies',{}).get('canonical',{}).items():assert h['canonical_dependencies'][n]==v
 for n,v in c.get('dependencies',{}).get('external_sdk',{}).items():assert h['external_sdk_dependencies'][n]==v
assert query_count==7
for p in h['products']:verify(p['archive_path'],p['sha256'],p['bytes'])
for name in ['source-manifest-v2.json','final-v2.patch','host-final-v2/host-checks.json','freeze-v2.json','baseline-manifest.json']:record(rec(r/name))
audit={'passed':True,'scope':'Read-only author byte/dependency/provenance audit; no product rerun','base_commit':new['base_commit'],'source_checks':[{'path':str(r/'baseline'),'files':7973,'compared_to_manifest':rec(r/'baseline-manifest.json')},{'path':str(r/'source-final'),'files':7978,'compared_to_manifest':rec(r/'source-manifest.json')},{'path':str(s),'files':7978,'compared_to_manifest':rec(r/'source-manifest-v2.json')}],'exact_five_new':new['overlays'],'changed_from_prior_freeze':freeze['changed_from_v1'],'old_controls_unchanged':freeze['old_controls'],'groups':h['groups'],'commands':4,'all_commands_rc0':True,'dependency_queries':7,'canonical_count':16,'system_count':105,'generated_inputs':0,'products':h['products'],'verified_files':verified,'elapsed_s':h['elapsed_s'],'source_before_after':7978,'fingerprint':h['export_tree_sha256'],'toolchain_and_declaration_order_checked':True,'tier':'Host ASan/UBSan contract/regression only; native compile/link/runtime, sampler integration, IRQ, DMA/hardware timing/listening NOT RUN'}
(r/'own-final-v2-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
controls=[r/'source-manifest-v2.json',r/'final-v2.patch',r/'host-final-v2/host-checks.json',r/'host-final-v2/host-checks.log',r/'own-final-v2-audit.json',r/'freeze-v2.json',r/'baseline-manifest.json',r/'tools/host_provenance.py',r/'tools/provenance_common.py',r/'tools/toolchain-pins.json']
handoff={'passed':True,'revision':'v2 monotone positively issued replacement supersession','source':str(s),'baseline':str(r/'baseline'),'base_commit':new['base_commit'],'files':7978,'overlays':new['overlays'],'controls':[rec(p) for p in controls],'prior_frozen_source_proof':'source-final/source-manifest.json/final.patch/host-final/own-final-audit.json remain exact; obsolete positive-replacement gap preserved, not current final acceptance','development_history':['development-1-platform-refusal.json','development-2.log','development-3.log','development-4.log','development-5.log','development-6.log','history/development-6-tested'],'host':{'groups':h['groups'],'commands':4,'dependency_queries':7,'canonical':16,'system':105,'products':2,'generated':0,'elapsed_s':h['elapsed_s']},'finished':'Separate opt-in core lineage software contract; legacy unchanged','unfinished':['Sampler future CONTROL/STOP integration','native compile/link/runtime','scheduled activation backend','IRQ/device/song integration','hardware timing/listening','scalable persistent reader domain'],'no_target_or_shared_changes':True}
(r/'handoff-v2.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'audit':rec(r/'own-final-v2-audit.json'),'handoff':rec(r/'handoff-v2.json'),'elapsed_s':h['elapsed_s'],'report':rec(r/'host-final-v2/host-checks.json'),'log':rec(r/'host-final-v2/host-checks.log')}))
