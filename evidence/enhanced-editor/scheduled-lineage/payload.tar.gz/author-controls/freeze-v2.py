import difflib,hashlib,json,shutil
from pathlib import Path
root=Path('/private/tmp/protracker-scheduled-lineage-fyrcg2b7')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=lambda p:{str(x.relative_to(p)):sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
paths=['src/core/scheduled_lineage.c','src/core/scheduled_lineage.h','tests/scheduled_lineage_test.c','tests/test_scheduled_lineage.py','docs/SCHEDULED_LINEAGE.md']
base=json.loads((root/'baseline-manifest.json').read_text())
assert sha(root/'baseline-manifest.json')=='81840112ee35328c2bf91cfb230dfe7bf52410f184bcddf33acdd0a4ab5dd103'
assert files(root/'baseline')==base['files']
old=json.loads((root/'source-manifest.json').read_text())
assert files(root/'source-final')==old['files']
history=root/'history'/'development-6-tested';history.mkdir(parents=True,exist_ok=False)
for name in paths:
    dest=history/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'candidate'/name,dest)
shutil.copyfile(root/'development-6.log',history/'development-6.log')
# Separate statements for the same portable -Werror convention; no behavior change.
test=root/'candidate/tests/scheduled_lineage_test.c';text=test.read_text()
a='if(mode==2)assert(pt_lineage_poll(q,replacement,&out)==PT_SCHEDULED_PENDING);drain(&b);}'
b='if(mode==2)assert(pt_lineage_poll(q,replacement,&out)==PT_SCHEDULED_PENDING);\n                drain(&b);}'
assert text.count(a)==1;test.write_text(text.replace(a,b))
source=root/'source-final-v2';assert not source.exists();shutil.copytree(root/'baseline',source)
for name in paths:
    assert name not in base['files'];dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'candidate'/name,dest)
actual=files(source);assert len(actual)==7978 and set(actual)-set(base['files'])==set(paths)
assert all(actual[name]==value for name,value in base['files'].items())
manifest={k:v for k,v in old.items() if k not in ('files','source_path','overlays')}
manifest.update(source_path=str(source),revision='v2: positively issued replacements permanently supersede original permission without reader retirement',previous_manifest={'path':str(root/'source-manifest.json'),'sha256':sha(root/'source-manifest.json')},baseline_manifest={'path':str(root/'baseline-manifest.json'),'sha256':sha(root/'baseline-manifest.json')},overlays=[{'path':n,'base_sha256':None,'sha256':actual[n]} for n in paths],files=actual)
write(root/'source-manifest-v2.json',manifest)
patch=''.join(''.join(difflib.unified_diff([], (source/n).read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+n)) for n in paths)
(root/'final-v2.patch').write_text(patch)
changed=[n for n in paths if actual[n]!=old['files'][n]]
assert set(changed)=={'src/core/scheduled_lineage.c','tests/scheduled_lineage_test.c','docs/SCHEDULED_LINEAGE.md'}
write(root/'freeze-v2.json',{'passed':True,'files':len(actual),'baseline_files':len(base['files']),'own_paths':paths,'changed_from_v1':changed,'source_manifest':{'path':str(root/'source-manifest-v2.json'),'sha256':sha(root/'source-manifest-v2.json')},'patch':{'path':str(root/'final-v2.patch'),'sha256':sha(root/'final-v2.patch')},'old_source_verified_unchanged':True,'old_controls':{str(x):sha(x) for x in [root/'source-manifest.json',root/'final.patch',root/'host-final/host-checks.json',root/'own-final-audit.json']},'development_6_tested_source':files(history),'format_delta':'one newline separating unconditional drain from the conditional assertion; final pinned proof follows'})
print(json.dumps({'manifest_sha256':sha(root/'source-manifest-v2.json'),'patch_sha256':sha(root/'final-v2.patch'),'files':len(actual),'changed':changed}))
