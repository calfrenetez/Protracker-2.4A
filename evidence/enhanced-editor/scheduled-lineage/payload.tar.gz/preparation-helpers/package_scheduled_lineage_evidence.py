#!/usr/bin/env python3
"""Private lossless lineage host/compiler evidence packaging; no product/helper import or target operation."""
import argparse,gzip,hashlib,io,json,stat,tarfile
from pathlib import Path,PurePosixPath
AUTHOR=Path('/private/tmp/protracker-scheduled-lineage-fyrcg2b7')
CURRENT=Path('/private/tmp/protracker-lineage-current-source-l2sqyvbp')
BUILDER=Path('/private/tmp/protracker-lineage-native-builder-hed1g75m')
ROOT_SOURCE_REVIEW=Path('/private/tmp/protracker-scheduled-lineage-v2-independent-review.json')
VERIFY_SCRIPT='''#!/usr/bin/env python3
"""Verify this packet without extracting or executing its archived software."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,io,json,stat,tarfile

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--origins',action='store_true');a=ap.parse_args();root=Path(__file__).resolve().parent
 d=json.loads((root/'manifest.json').read_bytes());members=d['members'];payload=(root/'payload.tar.gz').read_bytes();assert sha(payload)==d['payload']['sha256'] and len(payload)==d['payload']['bytes']
 rows={}
 for line in (root/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert n not in rows and '/' not in n and n in {'README.md','manifest.json','payload.tar.gz','verify_payload.py'};assert sha((root/n).read_bytes())==h;rows[n]=h
 assert len(rows)==4
 raws={}
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  seen=set()
  for t in tf:
   n=t.name;p=PurePosixPath(n);assert t.isfile() and n not in seen and n in members and not p.is_absolute() and '..' not in p.parts;seen.add(n)
   r=members[n];raw=tf.extractfile(t).read();assert t.size==r['bytes']==len(raw) and sha(raw)==r['sha256'] and t.mode==r['mode'] and t.uid==t.gid==t.mtime==0 and t.uname==t.gname=='';raws[n]=raw
   if a.origins:
    origin=Path(r['original_path']);assert not origin.is_symlink() and origin.is_file() and origin.read_bytes()==raw and stat.S_IMODE(origin.stat().st_mode)==r['mode']
  assert seen==set(members)
 buf=io.BytesIO()
 with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for n in sorted(members):
    r=members[n];t=tarfile.TarInfo(n);t.size=r['bytes'];t.mode=r['mode'];t.mtime=0;t.uid=t.gid=0;t.uname=t.gname='';tf.addfile(t,io.BytesIO(raws[n]))
 assert buf.getvalue()==payload
 print(json.dumps({'passed':True,'members':len(members),'original_bytes':sum(r['bytes'] for r in members.values()),'payload_sha256':sha(payload),'all_modes_and_bytes':True,'deterministic_reconstruction':True,'origins_checked':a.origins}))
if __name__=='__main__':main()
'''
def sha(b):return hashlib.sha256(b).hexdigest()
def parse(p):return json.loads(p.read_bytes())
def rec(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def exact(p,h):assert not p.is_symlink() and p.is_file() and sha(p.read_bytes())==h,(p,h)
def snapshot(root):
 out={}
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p.read_bytes())
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--native-review',type=Path,required=True);ap.add_argument('--native-review-sha256',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--qa',type=Path,required=True);a=ap.parse_args()
 out=a.out.resolve();qa=a.qa.resolve();review=a.native_review.resolve()
 assert out.parent==Path('/private/tmp') and qa.parent==Path('/private/tmp') and not out.exists() and not qa.exists()
 for origin in (AUTHOR,CURRENT,BUILDER,review):assert out!=origin and out not in origin.parents and origin not in out.parents
 exact(review,a.native_review_sha256);assert parse(review)['passed'] is True
 exact(ROOT_SOURCE_REVIEW,'50f197caa623a7a8922a19e051efd5c1ca4ace81dc939c5059a70a3f5307beb7')
 exact(CURRENT/'native-final-v2/manifest.json','1c92f93e4a952fa25af82e15e518c8bb43ffd5138de9e0a3376d35a92bc05739')
 exact(CURRENT/'native-final/manifest.json','c6663fae409b2566b202f0637c51f5535b301b19d39bf1a6a1917ab665435ade')
 exact(CURRENT/'source-manifest-native-v2.json','f21e6bb8a253c8e2e005f00674a5192e55122a020ba4d141469000260d43c46e')
 exact(CURRENT/'formatting-native-v2.json','82c745d384b69e0100931f02325f9f3805ec33b51c7a87f67a2127885e5238d3')
 exact(CURRENT/'origin-protracker-lineage-native-builder-independent-review.json','1d5b914f584c41ae4a67b33c0a5da7739d91fb7e9cdf7f9b53a5493838b82acb')
 exact(CURRENT/'builder-independent-author-review.json','7e4f946cafb6d36e09c928e55c549787432c2f9a7d385a2b5cd737b4f40be1f0')
 inventories={}
 for name,root,manifest in [('author-baseline',AUTHOR/'baseline',AUTHOR/'baseline-manifest.json'),('author-obsolete-v1',AUTHOR/'source-final',AUTHOR/'source-manifest.json'),('author-final-v2',AUTHOR/'source-final-v2',AUTHOR/'source-manifest-v2.json'),('current-baseline',CURRENT/'baseline',CURRENT/'baseline-before.json'),('current-first-compile',CURRENT/'source-final',CURRENT/'source-manifest.json'),('current-formatting-v2',CURRENT/'source-final-native-v2',CURRENT/'source-manifest-native-v2.json')]:
  d=parse(manifest);found=snapshot(root);assert found==d['files'];inventories[name]={'source_root':str(root),'manifest':rec(manifest),'file_count':len(found),'all_file_hashes_match':True}
 host=parse(AUTHOR/'host-final-v2/host-checks.json');native=parse(CURRENT/'native-final-v2/manifest.json');t=native['targets']['PTScheduledLineageTest'];assert native['passed'] and host['passed']
 assert t['binary']['bytes']==60292 and t['binary']['sha256']=='59c0cfe3d2dc2ceecf645c3fce0651f0022503c0d6ceb9b66c3cc6b5b68e5a8e'
 assert len(native['commands'])==14 and all(c['returncode']==0 for c in native['commands'])
 assert len(t['dependencies'])==12 and len(t['external_sdk_dependencies'])==30 and len(native['runtime_paths'])==7
 assert len(host['commands'])==4 and all(c['product_returncode']==0 for c in host['commands']) and len(host['canonical_dependencies'])==16
 raws={};members={}
 def add(name,p,role):
  name=str(PurePosixPath(name));parts=PurePosixPath(name).parts;assert name not in members and not name.startswith('/') and '..' not in parts
  assert not p.is_symlink() and p.is_file(),p;raw=p.read_bytes();r=rec(p);members[name]={'original_path':str(p),'bytes':len(raw),'sha256':r['sha256'],'mode':stat.S_IMODE(p.stat().st_mode),'role':role};raws[name]=raw
 def tree(prefix,root,role):
  assert root.is_dir()
  for p in sorted(root.rglob('*')):
   assert not p.is_symlink(),p
   if p.is_file():add(prefix+'/'+p.relative_to(root).as_posix(),p,role)
 # Only original control/history files, not huge full source directories, are archived.
 for p in sorted(AUTHOR.iterdir()):
  if p.is_file():add('author-controls/'+p.name,p,'Original author lineage history/control; development logs do not imply a reproducible frozen source unless explicitly bound')
 for folder in ('tools','host-final','host-final-v2','history'):
  tree('author/'+folder,AUTHOR/folder,'Exact author helper, old obsolete or final-v2 host commands/dependency logs/product and retained development-tested source history')
 for p in sorted(CURRENT.iterdir()):
  if p.is_file() and p.name!='baseline-export.tar':add('current-controls/'+p.name,p,'Exact current committed baseline/current source inventories, formatting proof, invocation, original strict compiler failure and retained reviews')
 for folder in ('native-final','native-final-v2'):tree('current/'+folder,CURRENT/folder,'Original distinct first failed or corrected PASS compile/dependency/preprocessor/runtime commands/logs/products')
 tree('builder-draft',BUILDER,'Exact unchanged standalone builder, canonical origin copy, adaptation diff and initial draft handoff')
 for stage,source,report in [('obsolete-v1',AUTHOR/'source-final',parse(AUTHOR/'host-final/host-checks.json')),('final-v2',AUTHOR/'source-final-v2',host)]:
  names=set(report['canonical_dependencies'])|{Path(r['path']).relative_to(source).as_posix() for r in report['module_inputs']}|{r['path'] for r in parse(AUTHOR/('source-manifest.json' if stage=='obsolete-v1' else 'source-manifest-v2.json'))['overlays']}
  for name in sorted(names):add('host-inputs/'+stage+'/'+name,source/name,'Exact host compiled canonical closure, executed Python declaration or original five-path overlay for this frozen stage')
 source=CURRENT/'source-final-native-v2'
 names=set(t['dependencies'])|{'tools/build_core_tests.py','tools/build_diagnostic.py','tests/test_scheduled_lineage.py','tests/test_scheduled_output.py','tools/build_scheduled_lineage_test.py','docs/SCHEDULED_LINEAGE.md'}
 for name in sorted(names):add('native-inputs/'+name,source/name,'Exact current formatted compiler closure, standalone builder, committed AST-only recipes and actual Python declaration bytes')
 add('independent/source-final-v2-review.json',ROOT_SOURCE_REVIEW,'Independent final author source and host-proof audit; superseded v1 positive-replacement gap remains history')
 add('independent/native-corrected-v2-review.json',review,'Independent exact corrected build and current-source audit; HUNK has not run')
 for p in (Path('/private/tmp/prepare_lineage_current_source.py'),Path('/private/tmp/prepare_lineage_formatting_v2.py'),Path(__file__).resolve()):add('preparation-helpers/'+p.name,p,'Exact host source/export/formatting/packaging helper; no target action')
 def make():
  buf=io.BytesIO()
  with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
    for name in sorted(members):
     r=members[name];item=tarfile.TarInfo(name);item.size=r['bytes'];item.mode=r['mode'];item.uid=item.gid=item.mtime=0;item.uname=item.gname='';tf.addfile(item,io.BytesIO(raws[name]))
  return buf.getvalue()
 payload=make();assert payload==make()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  seen=set()
  for item in tf:
   assert item.isfile() and item.name not in seen and item.name in members;seen.add(item.name);assert tf.extractfile(item).read()==raws[item.name] and item.mode==members[item.name]['mode'] and item.uid==item.gid==item.mtime==0
  assert seen==set(members)
 for name,r in members.items():assert Path(r['original_path']).read_bytes()==raws[name] and stat.S_IMODE(Path(r['original_path']).stat().st_mode)==r['mode']
 for record in inventories.values():assert snapshot(Path(record['source_root']))==parse(Path(record['manifest']['path']))['files']
 out.mkdir();(out/'payload.tar.gz').write_bytes(payload);(out/'verify_payload.py').write_text(VERIFY_SCRIPT);(out/'verify_payload.py').chmod(0o644)
 document={'scope':'Exact original regular member bytes/modes; deterministic tar ownership and timestamps normalized, no truncation or software execution','member_count':len(members),'original_bytes':sum(r['bytes'] for r in members.values()),'payload':{'bytes':len(payload),'sha256':sha(payload)},'members':members,'source_inventories':inventories,'complete_source_exports_and_sdk_trees_archived':False,'source_only_current_base':'dbededed13cd596683867c3f39a5127651f86d74','overlay_paths':parse(CURRENT/'source-manifest-native-v2.json')['overlays'],'independent_source_review':rec(ROOT_SOURCE_REVIEW),'independent_actual_native_build_review':rec(review),'native_NOT_RUN':True,'reproduction':'verify_payload.py verifies all member bytes/modes and reconstructs the deterministic archive without extraction; --origins additionally verifies retained private paths'}
 (out/'manifest.json').write_text(json.dumps(document,indent=2)+'\n')
 (out/'README.md').write_text('''This packet preserves the optional scheduled-lineage software contract, its final host proof and a distinct corrected compiler-only candidate. The legacy scheduled_output flags7 implementation remains unchanged. Five new lineage files introduce exact trigger identities, typed actual observations, copied CONTROL/STOP targets and independent positive reader-retirement ownership. Fixed capacity remains at most eight retained events and four actions per event; this is not a scalable song scheduler or an installed activation backend. No future-owner CONTROL/STOP integration, IRQ, DMA, device, audio, memory-class, hardware timing, physical or listening acceptance is supplied.

Final author-v2 host ASan/UBSan proof ran two groups with four RC0 commands, seven full-M queries, 16 canonical inputs, 105 external system/SDK fingerprints and two archived products. The earlier host-v1 proof is preserved separately as obsolete: it lacked permanent positive replacement history after the replacement entry retired. Final v2 permanently supersedes the original reader permission on validated actual ISSUED/CANCELLED_AFTER replacement without retiring that original holder. Cancelled-before/unsubmitted replacement leaves no such permanent fact. Matching four-mode regressions are in the shared fixture. Local cancellation does not fabricate ACTIVE state; CONTROL/STOP draining/retired observations close the exact source key without releasing another ticket.

The compiler source is an exact clean committed dbededed13cd596683867c3f39a5127651f86d74 export of 7,984 files plus the five reviewed new files and one standalone builder, totaling 7,990. It is distinct from the author's c055 full tree. All 16 host canonical inputs and actual test declarations are equivalent; only the shared fixture's line392 received a separately authorized token/directive-equivalent newline split after the first strict GCC compile refused misleading indentation. The original 7,990-file first export, RC1 log and 13 preceding RC0 records are unchanged. All 7,989 other files are identical in the corrected export; no sanitizer rerun or semantic change occurred.

The corrected standalone PTScheduledLineageTest is 60,292 bytes, SHA256 59c0cfe3d2dc2ceecf645c3fce0651f0022503c0d6ceb9b66c3cc6b5b68e5a8e. Fourteen compiler/dependency/runtime commands completed RC0 using three ordered translation units, 12 canonical dependencies, 30 external SDK inputs, seven pinned runtimes and the committed optimizer-safety flags. Default SDK assertions remain enabled and the complete SCHEDULED LINEAGE PASS marker occurs exactly once in preprocessing and in the HUNK. The HUNK has NOT RUN. Native runtime and adequate stack remain unqualified and require separate exact-candidate preparation/ownership/cleanup/release work. Compilation proves no timing or hardware capability.

All prior/final source inventories, exact compiled closures, the declared Python modules, AST-only committed build/runtime recipes, standalone builder, helper bytes, ordered commands, logs, products, toolchain fingerprints, source reviews, formatting equivalence and original compiler failure are losslessly archived. Complete source exports and SDK/toolchain trees are omitted with full fingerprints retained. The current baseline export tar's original size/hash remains in its original manifest; the huge tar itself is not duplicated. Development logs are historical outcomes and do not claim reproducible source identity except for separately retained tested snapshots. Root's original builder review and the author's later distinct review are preserved at separate paths; the formatting proof explicitly records their original pathname collision.

manifest.json maps every archive member to its exact original path, SHA256, bytes, mode and scope. Archive names are safe relative regular paths; ownership/timestamps are normalized. Deterministic duplicate generation and complete tar-reader byte/mode checks were performed. verify_payload.py performs a standalone reader and deterministic reconstruction without extracting or running archived software; --origins additionally checks retained private originals. SHA256SUMS binds the other four controls. Packaging does not rerun tests/compiler/HUNK or access a target.
''')
 controls=('README.md','manifest.json','payload.tar.gz','verify_payload.py');(out/'SHA256SUMS').write_text(''.join(sha((out/name).read_bytes())+'  '+name+'\n' for name in controls))
 # Directly validate controls and every original after creation; external QA is separately authored.
 for name in controls:assert (out/name).is_file()
 checksum=(out/'SHA256SUMS').read_text().splitlines();assert len(checksum)==4
 for line in checksum:
  h,name=line.split('  ',1);assert name in controls and sha((out/name).read_bytes())==h
 for name,r in members.items():assert Path(r['original_path']).read_bytes()==raws[name]
 qa.write_text(json.dumps({'passed':True,'scope':'Host packaging reader/copy/determinism checks only; no product/compiler/target operation','packet':str(out),'member_count':len(members),'original_bytes':document['original_bytes'],'controls':[rec(out/name) for name in (*controls,'SHA256SUMS')],'all_member_origins_modes_bytes_verified':True,'duplicate_generation_equal':True,'safe_tar_reader_verified':True,'source_inventories_unchanged':inventories,'helper':rec(Path(__file__).resolve())},indent=2)+'\n')
 print(json.dumps({'packet':str(out),'files':5,'bytes':sum(x.stat().st_size for x in out.iterdir()),'members':len(members),'original_bytes':document['original_bytes'],'payload':rec(out/'payload.tar.gz'),'manifest':rec(out/'manifest.json'),'sums':rec(out/'SHA256SUMS'),'qa':rec(qa)},indent=2))
if __name__=='__main__':main()
