#!/usr/bin/env python3
"""Private frozen-source preparation only. Does not import build/test helpers or run a compiler/target."""
from pathlib import Path, PurePosixPath
import ast, hashlib, io, json, os, shutil, stat, subprocess, sys, tarfile, tempfile
REPO=Path('/Users/james1/Documents/Codex/2026-09-18/rev/work/Protracker-2.4A')
COMMIT='dbededed13cd596683867c3f39a5127651f86d74'
AUTHOR=Path('/private/tmp/protracker-scheduled-lineage-fyrcg2b7')
BUILDER=Path('/private/tmp/protracker-lineage-native-builder-hed1g75m/build_scheduled_lineage_test.py')
ROOT_REVIEW=Path('/private/tmp/protracker-lineage-current-closure-before-import.json')
BUILDER_REVIEW=Path('/private/tmp/protracker-lineage-native-builder-independent-review.json')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def rec(p): p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def write(p,x): Path(p).write_text(json.dumps(x,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git','-C',str(REPO),*args])
def snapshot(root):
    result={}
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(),p
        if p.is_file(): result[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
    return result
assert git('rev-parse','HEAD').decode().strip()==COMMIT
assert sha(BUILDER.read_bytes())=='40a9a14b4b3d08b0c7ab278c03ddde5b8dc0d84bdfa0684c8e0b9355ef72c681'
assert sha(ROOT_REVIEW.read_bytes())=='adf30ff196c8c9c6a75229c18cd065bb6b919bb598b262ede5be0ccc2b117354'
assert sha(BUILDER_REVIEW.read_bytes())=='1d5b914f584c41ae4a67b33c0a5da7739d91fb7e9cdf7f9b53a5493838b82acb'
manifest_path=AUTHOR/'source-manifest-v2.json'; host_path=AUTHOR/'host-final-v2/host-checks.json'
assert sha(manifest_path.read_bytes())=='b2fb0521eb1fbdce11100550e69c5c5fefe67f3a8d53673a847f1197f5b2bb6a'
assert sha(host_path.read_bytes())=='548fcec0a63e87864bf26df20d4cb076bd44f6469bb925bbbf41fd471d0165c7'
original=json.loads(manifest_path.read_text()); host=json.loads(host_path.read_text())
overlays=original['overlays'];assert len(overlays)==5
base_tree=git('rev-parse',COMMIT+'^{tree}').decode().strip()
entries={}
for line in git('ls-tree','-rz',COMMIT).split(b'\0'):
    if not line: continue
    metadata,name=line.split(b'\t',1); mode,kind,blob=metadata.decode().split()
    assert kind=='blob' and mode in ('100644','100755')
    entries[name.decode()]={'git_mode':mode,'git_blob':blob}
assert all(row['path'] not in entries for row in overlays)
assert 'tools/build_scheduled_lineage_test.py' not in entries
out=Path(tempfile.mkdtemp(prefix='protracker-lineage-current-source-',dir='/private/tmp'))
base=out/'baseline'; source=out/'source-final';base.mkdir()
raw=git('archive','--format=tar',COMMIT);(out/'baseline-export.tar').write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tf:
    names=set()
    for member in tf:
        path=PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and str(path) not in names
        names.add(str(path));dest=base/str(path)
        if member.isdir(): dest.mkdir(parents=True,exist_ok=True);continue
        assert member.isreg() and member.name in entries
        dest.parent.mkdir(parents=True,exist_ok=True); content=tf.extractfile(member).read();dest.write_bytes(content);os.chmod(dest,member.mode)
        assert sha(b'blob '+str(len(content)).encode()+b'\0'+content) != ''
        assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==entries[member.name]['git_blob']
base_before=snapshot(base);assert set(base_before)==set(entries)
base_record={'base_commit':COMMIT,'base_tree':base_tree,'scope':'Exact immutable current committed export; no dirty overlays','source_path':str(base),'files':{k:v['sha256'] for k,v in base_before.items()},'file_metadata':{k:{**v,**entries[k]} for k,v in base_before.items()},'archive':rec(out/'baseline-export.tar')}
write(out/'baseline-before.json',base_record)
shutil.copytree(base,source)
copy_rows=[]
for row in overlays:
    origin=AUTHOR/'source-final-v2'/row['path']; assert sha(origin.read_bytes())==row['sha256']==original['files'][row['path']]
    dest=source/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,dest)
    copy_rows.append({'path':row['path'],'origin':rec(origin),'copy':rec(dest),'base_sha256':None})
dest=source/'tools/build_scheduled_lineage_test.py';shutil.copy2(BUILDER,dest)
copy_rows.append({'path':'tools/build_scheduled_lineage_test.py','origin':rec(BUILDER),'copy':rec(dest),'base_sha256':None})
final=snapshot(source)
assert len(final)==len(base_before)+6 and set(final)==set(base_before)|{x['path'] for x in copy_rows}
assert all(final[k]==v for k,v in base_before.items())
canonical={}
for k,h in host['canonical_dependencies'].items():
    assert final[k]['sha256']==h
    canonical[k]={'sha256':h,'binding':'exact reviewed new overlay' if k not in entries else 'exact current committed Git blob/export'}
for row in host['module_inputs']:
    k=Path(row['path']).relative_to(AUTHOR/'source-final-v2').as_posix();assert final[k]['sha256']==row['sha256']
# Read declaration/recipe as AST data only; no imported helper or compiler process.
pins_origin=AUTHOR/'tools/toolchain-pins.json';pins=json.loads(pins_origin.read_text())
assert final['tools/build_core_tests.py']['sha256']==pins['canonical_recipe']['sha256']
shutil.copy2(pins_origin,out/'toolchain-pins.json')
for control in (ROOT_REVIEW,BUILDER_REVIEW,AUTHOR/'handoff-v2.json',manifest_path,host_path):
    shutil.copy2(control,out/('origin-'+control.name if control.name!='host-checks.json' else 'origin-host-checks.json'))
# The two source manifests have distinct names and metadata; current full export is never called c055.
prepared={'base_commit':COMMIT,'base_tree':base_tree,'scope':'Current committed export plus exactly five independently reviewed private lineage-v2 paths and unchanged standalone builder; compiler-only preparation, no compiler or target invocation','source_path':str(source),'files':{k:v['sha256'] for k,v in final.items()},'file_metadata':final,'overlays':copy_rows,'author_source_manifest':rec(manifest_path),'prior_host_report':rec(host_path),'baseline_manifest':rec(out/'baseline-before.json'),'canonical_host_equivalence':canonical,'host_declaration_inputs':[rec(source/Path(row['path']).relative_to(AUTHOR/'source-final-v2')) for row in host['module_inputs']], 'canonical_native_recipe':rec(source/'tools/build_core_tests.py'),'canonical_runtime_recipe':rec(source/'tools/build_diagnostic.py')}
write(out/'source-manifest.json',prepared)
base_after=snapshot(base);assert base_after==base_before
assert git('rev-parse','HEAD').decode().strip()==COMMIT
write(out/'baseline-after.json',{'base_commit':COMMIT,'base_tree':base_tree,'source_path':str(base),'files':{k:v['sha256'] for k,v in base_after.items()},'file_metadata':base_after,'equal_before':True,'scope':'Preparation did not mutate committed source export or working repository'})
write(out/'source-preparation.json',{'passed':True,'scope':prepared['scope'],'directory':str(out),'source_files':len(final),'baseline_files':len(base_before),'overlays':6,'compiled_host_equivalence':len(canonical),'source_manifest':rec(out/'source-manifest.json'),'baseline_before':rec(out/'baseline-before.json'),'baseline_after':rec(out/'baseline-after.json'),'pins':rec(out/'toolchain-pins.json'),'builder':rec(dest),'root_current_review':rec(ROOT_REVIEW),'builder_static_review':rec(BUILDER_REVIEW),'author_final_handoff':rec(AUTHOR/'handoff-v2.json'),'compiler_invoked':False,'native_NOT_RUN':True,'next_gate':'Wait for final independent source/host CLEAR and explicit root compiler authorization','python':{'path':sys.executable,'version':sys.version,'sha256':sha(Path(sys.executable).read_bytes())},'preparation_helper':rec(Path(__file__))})
print(json.dumps({'out':str(out),'preparation':rec(out/'source-preparation.json'),'source_manifest':rec(out/'source-manifest.json'),'source_files':len(final),'baseline_files':len(base_before),'overlays':6,'host_dependencies':len(canonical)},indent=2))
