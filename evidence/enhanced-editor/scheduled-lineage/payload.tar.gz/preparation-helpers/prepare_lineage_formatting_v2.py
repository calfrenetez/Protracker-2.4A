#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re,shutil,stat
p=Path('/private/tmp/protracker-lineage-current-source-l2sqyvbp')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def rec(x):return {'path':str(x),'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())}
def write(x,d):x.write_text(json.dumps(d,indent=2)+'\n')
old=json.loads((p/'source-manifest.json').read_text()); before={x.relative_to(p/'source-final').as_posix():sha(x.read_bytes()) for x in sorted((p/'source-final').rglob('*')) if x.is_file()};assert before==old['files']
source=p/'source-final-native-v2';assert not source.exists();shutil.copytree(p/'source-final',source)
test=source/'tests/scheduled_lineage_test.c';original=test.read_bytes();needle=b'    for(i=0;i<3;++i)hold(h+i,i+1);t=trigger(q,&b,h,100,0);assert(pt_lineage_reader_key(q,t,0,&key)==PT_SCHEDULED_OK);';replacement=b'    for(i=0;i<3;++i)hold(h+i,i+1);\n    t=trigger(q,&b,h,100,0);assert(pt_lineage_reader_key(q,t,0,&key)==PT_SCHEDULED_OK);';assert original.count(needle)==1;corrected=original.replace(needle,replacement);test.write_bytes(corrected)
# C-token lexer retains complete strings, char literals, comments and operators;
# whitespace is ignored only between tokens. Preprocessor directive bytes stay exact.
pattern=rb'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*[\s\S]*?\*/|//[^\n]*|[A-Za-z_][A-Za-z_0-9]*|(?:0[xX][0-9a-fA-F]+|[0-9]+(?:\.[0-9]*)?)(?:[eEpP][+-]?[0-9]+)?[uUlLfF]*|>>=|<<=|\.\.\.|->|\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\||\+=|-=|\*=|/=|%=|&=|\^=|\|=|[^\s]'
a=re.findall(pattern,original);b=re.findall(pattern,corrected);assert a==b
old_directives=re.findall(rb'(?m)^\s*#[^\n]*(?:\\\n[^\n]*)*',original);new_directives=re.findall(rb'(?m)^\s*#[^\n]*(?:\\\n[^\n]*)*',corrected);assert old_directives==new_directives
files={x.relative_to(source).as_posix():sha(x.read_bytes()) for x in sorted(source.rglob('*')) if x.is_file()};assert len(files)==7990 and set(files)==set(before);assert [k for k in files if files[k]!=before[k]]==['tests/scheduled_lineage_test.c']
metadata={x.relative_to(source).as_posix():{'sha256':sha(x.read_bytes()),'bytes':x.stat().st_size,'mode':stat.S_IMODE(x.stat().st_mode)} for x in sorted(source.rglob('*')) if x.is_file()}
prepared=dict(old);prepared.update(source_path=str(source),revision='Native formatting-v2: only line392 newline split, C tokens/directives identical; original failed compiler source immutable',files=files,file_metadata=metadata,previous_source_manifest=rec(p/'source-manifest.json'),failed_native_manifest=rec(p/'native-final/manifest.json'))
# Prior overlay rows remain original provenance, not false byte-copy claims for the formatted fixture.
prepared['overlays']=[dict(row) for row in old['overlays']]
for row in prepared['overlays']:
 if row['path']=='tests/scheduled_lineage_test.c':
  row['copy']=rec(test);row['transformation']='Only split the for(...)hold(...); from t=trigger(...) onto a following line; exact tokens/directives unchanged';row['original_frozen_sha256']=sha(original)
for k,row in prepared['canonical_host_equivalence'].items():
 if k=='tests/scheduled_lineage_test.c':
  prepared['canonical_host_equivalence'][k]={'sha256':sha(corrected),'original_host_sha256':sha(original),'binding':'Token/directive-equivalent formatting-only shared fixture; all host production/dependency bytes unchanged; no sanitizer rerun'}
write(p/'source-manifest-native-v2.json',prepared)
root_review=p/'origin-protracker-lineage-native-builder-independent-review.json';author_review=Path('/private/tmp/protracker-lineage-native-builder-independent-review.json');assert sha(root_review.read_bytes())=='1d5b914f584c41ae4a67b33c0a5da7739d91fb7e9cdf7f9b53a5493838b82acb';assert sha(author_review.read_bytes())=='7e4f946cafb6d36e09c928e55c549787432c2f9a7d385a2b5cd737b4f40be1f0';shutil.copy2(author_review,p/'builder-independent-author-review.json')
proof={'passed':True,'scope':'Authorized formatting-only compiler-source revision; no sanitizer/compiler/native/target action from this preparation','original_source':str(p/'source-final'),'corrected_source':str(source),'original_manifest':rec(p/'source-manifest.json'),'corrected_manifest':rec(p/'source-manifest-native-v2.json'),'old_test':rec(p/'source-final/tests/scheduled_lineage_test.c'),'new_test':rec(test),'only_changed_source':'tests/scheduled_lineage_test.c','all_other_source_bytes_unchanged':7989,'token_count':len(a),'token_sequence_sha256':sha(b'\0'.join(a)),'tokens_equal':True,'directives_equal':True,'literal_edit':{'old':needle.decode(),'new':replacement.decode()},'prior_host_proof':old['prior_host_report'],'failed_native_proof':rec(p/'native-final/manifest.json'),'builder':rec(source/'tools/build_scheduled_lineage_test.py'),'root_review_original':rec(root_review),'author_review_separate':rec(p/'builder-independent-author-review.json'),'review_path_collision':'The author later wrote a distinct review at the root original review pathname; both exact records retained separately before current preparation/build','helper':rec(Path(__file__))}
assert {x.relative_to(p/'source-final').as_posix():sha(x.read_bytes()) for x in (p/'source-final').rglob('*') if x.is_file()}==before
write(p/'formatting-native-v2.json',proof);print(json.dumps({'source_manifest':rec(p/'source-manifest-native-v2.json'),'formatting_proof':rec(p/'formatting-native-v2.json'),'new_test':rec(test)},indent=2))
