from pathlib import Path
import hashlib,json,ast
R=Path('/private/tmp/protracker-scheduled-output-lvf80_5i'); S=R/'source-final-v2'; O=R/'host-final-v2'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def inv(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def verify_record(x):
 p=x.get('archive_path',x.get('path'));assert p
 assert sha(p)==x['sha256'],p
 if 'bytes' in x:assert Path(p).stat().st_size==x['bytes'],p
B=json.loads((R/'baseline-manifest.json').read_text());M=json.loads((R/'source-manifest-v2.json').read_text());H=json.loads((O/'host-checks.json').read_text());V=json.loads((R/'source-manifest.json').read_text())
bf={x['path']:x['sha256'] for x in B['files']};fi=inv(S)
assert fi==M['files'];assert len(fi)==7941 and len(bf)==7936
assert inv(R/'baseline')==bf
owned=['src/core/scheduled_output.c','src/core/scheduled_output.h','tests/scheduled_output_test.c','tests/test_scheduled_output.py','docs/SCHEDULED_OUTPUT.md']
assert set(fi)==set(bf)|set(owned) and all(fi[k]==v for k,v in bf.items())
assert inv(R/'source-final')==V['files'];assert [k for k in fi if fi[k]!=V['files'][k]]==['tests/scheduled_output_test.c']
assert H['passed'] and H['modules']==['test_scheduled_output','test_sample_cache'];assert H['source_files_before']==H['source_files_after']==7941
assert all(g['passed'] and not g['failures'] and not g['errors'] for g in H['groups'])
assert len(H['commands'])==4 and len(H['products'])==2 and not H['generated_inputs']
for k,v in H['canonical_dependencies'].items():assert fi[k]==v and sha(S/k)==v
for cat in ['external_sdk_dependencies','sanitizer_runtime_inputs','pinned_sdk_inputs']:
 for p,h in H[cat].items():assert sha(p)==h,p
for x in H['helper_inputs']+H['module_inputs']+H['products']+[H['source_manifest'],H['pins']]:verify_record(x)
for cat in ['compiler','python']:assert sha(H[cat]['path'])==H[cat]['sha256']
queries=0
for c in H['commands']:
 assert c['stage']=='complete' and c['product_returncode']==0 and c['directory']==str(S)
 for x in c['canonical_inputs']:assert fi[x['path']]==x['sha256']
 verify_record(c['output_log'])
 for d in c['dependency_commands']:
  assert d['returncode']==0 and '-M' in d['argv'] and '-MM' not in d['argv'];verify_record(d['output']);queries+=1
 for k in ['produced_binary','input_binary']:
  if k in c:verify_record(c[k])
assert queries==6
assert len(H['canonical_dependencies'])==14 and len(H['external_sdk_dependencies'])==105
assert 'SCHEDULED OUTPUT PASS:' in Path(H['commands'][1]['output_log']['path']).read_text()
assert 'sample-cache' in Path(H['commands'][3]['output_log']['path']).read_text().lower() or 'CACHE PASS' in Path(H['commands'][3]['output_log']['path']).read_text()
# Helpers differ only in the authorized module list and docstring. AST body parity excludes only those nodes.
origin=Path('/private/tmp/protracker-playback-storage-tka8fnd9/tools-v2/host_provenance.py'); current=R/'tools/host_provenance.py'
def stripped(p):
 t=ast.parse(p.read_text());t.body=[n for n in t.body if not(isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)) and not(isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='MODULES' for v in n.targets))];return ast.dump(t,include_attributes=False)
assert stripped(origin)==stripped(current)
assert sha(R/'tools/provenance_common.py')==sha(origin.parent/'provenance_common.py')
assert sha(R/'tools/toolchain-pins.json')==sha(origin.parent/'toolchain-pins.json')
checks={'passed':True,'scope':'Own host-only source/provenance audit; no tests/builds rerun during audit and no native/device/IRQ/timing/listening acceptance','base_commit':B['commit'],'base_tree':B['tree'],'baseline_files':len(bf),'final_files':len(fi),'source_fingerprint':H['export_tree_sha256'],'baseline_unchanged':True,'previous_final_unchanged':True,'previous_to_current_difference':['tests/scheduled_output_test.c'],'owned_new_paths':owned,'host_groups':H['groups'],'host_elapsed_s':H['elapsed_s'],'completed_commands':len(H['commands']),'full_M_queries':queries,'canonical_dependencies':len(H['canonical_dependencies']),'external_system_inputs':len(H['external_sdk_dependencies']),'products':H['products'],'generated_inputs':0,'source_manifest':identity(R/'source-manifest-v2.json'),'patch':identity(R/'final-v2.patch'),'host_report':identity(O/'host-checks.json'),'host_log':identity(O/'host-checks.log'),'helper_origin':identity(origin),'current_helper':identity(current),'preserved_prior_proof':identity(R/'host-final/host-checks.json'),'acceptance':{'host_sanitizers':True,'native_cross_build':False,'native_runtime':False,'exact_hardware_output':False,'interrupt_adapter':False,'song_integration':False}}
(R/'own-final-audit-v2.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(identity(R/'own-final-audit-v2.json')))
