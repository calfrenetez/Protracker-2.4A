#!/usr/bin/env python3
"""Preserve scoped scheduled-output host proof; never import tests or contact targets."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,io,json,os,stat,tarfile
R=Path('/private/tmp/protracker-scheduled-output-lvf80_5i')
OWNED=['src/core/scheduled_output.c','src/core/scheduled_output.h','tests/scheduled_output_test.c','tests/test_scheduled_output.py','docs/SCHEDULED_OUTPUT.md']
def sha(b):return hashlib.sha256(b).hexdigest()
def record(p):
 p=Path(p);assert p.is_file() and not p.is_symlink(),str(p);b=p.read_bytes()
 return {'original_path':str(p.resolve()),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def verify(x,p=None):
 p=Path(p or x.get('archive_path',x.get('path')));assert p.is_file()
 assert sha(p.read_bytes())==x['sha256'],str(p)
 if 'bytes' in x:assert p.stat().st_size==x['bytes'],str(p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--qa',required=True);ap.add_argument('--independent-review',required=True);ap.add_argument('--independent-review-sha256',required=True);a=ap.parse_args()
 out=Path(a.out).resolve();qa=Path(a.qa).resolve();review=Path(a.independent_review).resolve()
 assert not out.exists() and not qa.exists() and out!=R and R not in out.parents and out not in R.parents
 assert qa!=out and out not in qa.parents and qa not in out.parents
 assert sha(review.read_bytes())==a.independent_review_sha256
 review_data=json.loads(review.read_text());assert review_data.get('passed') is True or review_data.get('clear') is True or review_data.get('status')=='CLEAR'
 entries={};blobs={}
 def add(member,p,role):
  q=PurePosixPath(member);assert not q.is_absolute() and '..' not in q.parts and str(q) not in entries and str(q)==member
  x=record(p);x.update(member=member,role=role);entries[member]=x;blobs[member]=Path(p).read_bytes()
 def tree(member,p,role):
  for f in sorted(Path(p).rglob('*')):
   if f.is_file():
    assert not f.is_symlink();assert '__pycache__' not in f.parts and f.suffix!='.pyc'
    add(member+'/'+str(f.relative_to(p)),f,role)
 add('reviews/independent-final-review.json',review,'Independent read-only final source and proof review; exact copied original')
 for name in ['baseline-manifest.json','source-development-v1-manifest.json','source-manifest.json','source-manifest-v2.json','final.patch','final-v2.patch','own-final-audit-v2.json','handoff-v2.json','audit_final.py','package_host_evidence.py']:
  add('records/'+name,R/name,'Exact original source inventory, patch, handoff or host archival/audit helper; earlier finals remain separate')
 for name in ['host_provenance.py','provenance_common.py','toolchain-pins.json']:
  add('tools/'+name,R/'tools'/name,'Executed pinned host logger/helper or toolchain fingerprint controls')
 baseline=json.loads((R/'baseline-manifest.json').read_text());bf={x['path']:x['sha256'] for x in baseline['files']}
 stages=[('development-v1','source-development-v1','source-development-v1-manifest.json','host-development-v1'),('final-v1','source-final','source-manifest.json','host-final'),('final-v2','source-final-v2','source-manifest-v2.json','host-final-v2')]
 allsystem={};sources=set()
 for label,srcn,mn,hn in stages:
  src=R/srcn;m=json.loads((R/mn).read_text());h=json.loads((R/hn/'host-checks.json').read_text())
  assert h['passed'] and len(h['commands'])==4 and h['source_files_before']==h['source_files_after']==7941
  actual={str(f.relative_to(src)):sha(f.read_bytes()) for f in src.rglob('*') if f.is_file()};assert actual==m['files']
  assert set(actual)==set(bf)|set(OWNED) and all(actual[k]==v for k,v in bf.items())
  assert len(h['canonical_dependencies'])==14 and len(h['external_sdk_dependencies'])==105 and len(h['products'])==2 and not h['generated_inputs']
  queries=0
  for c in h['commands']:
   assert c['stage']=='complete' and c['product_returncode']==0;verify(c['output_log'])
   for d in c['dependency_commands']:
    assert d['returncode']==0 and '-M' in d['argv'] and '-MM' not in d['argv'];verify(d['output']);queries+=1
  assert queries==6
  for prod in h['products']:verify(prod)
  for x in h['helper_inputs']+h['module_inputs']+[h['source_manifest'],h['pins']]:verify(x)
  for typ in ['compiler','python']:verify(h[typ])
  for category in ['external_sdk_dependencies','sanitizer_runtime_inputs','pinned_sdk_inputs']:
   for p,v in h[category].items():verify({'path':p,'sha256':v});allsystem[p]=v
  selected=set(h['canonical_dependencies'])|set(OWNED)|{'tests/test_sample_cache.py'}
  for path in sorted(selected):
   assert actual[path]==h['canonical_dependencies'].get(path,actual[path]);add('sources/'+label+'/'+path,src/path,'Exact '+label+' compiled/declaration/document closure; does not copy complete export')
  sources|=selected
  tree('host/'+label,R/hn,'Exact '+label+' recorded host commands/full-M/logs and archived products; historical group is not final-v2 proof')
 # Preserve baseline counterparts for original inherited compiled/module inputs, without duplicating entire baseline export.
 for path in sorted(sources&set(bf)):
  assert sha((R/'baseline'/path).read_bytes())==bf[path];add('sources/baseline/'+path,R/'baseline'/path,'Exact committed baseline inherited compile/declaration input')
 assert len(entries)==len(blobs)
 def archive():
  raw=io.BytesIO()
  with tarfile.open(fileobj=raw,mode='w',format=tarfile.USTAR_FORMAT) as tf:
   for name in sorted(entries):
    e=entries[name];ti=tarfile.TarInfo(name);ti.size=e['bytes'];ti.mode=e['mode'];ti.mtime=0;ti.uid=ti.gid=0;ti.uname=ti.gname='';tf.addfile(ti,io.BytesIO(blobs[name]))
  return gzip.compress(raw.getvalue(),compresslevel=9,mtime=0)
 payload=archive();assert payload==archive()
 verified=[]
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  seen=set()
  for t in tf:
   assert t.isfile() and t.name in entries and t.name not in seen and '..' not in PurePosixPath(t.name).parts and not PurePosixPath(t.name).is_absolute()
   seen.add(t.name);e=entries[t.name];b=tf.extractfile(t).read();assert b==blobs[t.name] and sha(b)==e['sha256'] and len(b)==e['bytes']
   assert t.mode==e['mode'] and t.uid==t.gid==t.mtime==0 and not t.uname and not t.gname;verified.append(t.name)
  assert seen==set(entries)
 # All origins still exact after construction; immutable before/after qualification inventories remain literal originals.
 for e in entries.values():assert record(e['original_path'])=={k:e[k] for k in ['original_path','bytes','sha256','mode']}
 manifest={'scope':'Lossless host-only scheduled-output evidence; no native/device/interrupt/song integration or hardware timing qualification','base_commit':baseline['commit'],'base_tree':baseline['tree'],'baseline_files':7936,'final_files':7941,'owned_new_paths':OWNED,'member_count':len(entries),'original_bytes':sum(e['bytes'] for e in entries.values()),'members':[entries[k] for k in sorted(entries)]}
 provenance={'passed_archive_integrity':True,'native_or_physical_pass':False,'payload_sha256':sha(payload),'payload_bytes':len(payload),'deterministic_second_archive_equal':True,'tar_reader_exact_bytes_modes_checked':len(verified),'external_system_fingerprints_only':allsystem,'source_inventories_preserved_losslessly':True,'qualification_scope':'Final-v2 two host sanitizer groups/four RC0 compile-runtime commands/six full-M queries/14 canonical dependencies/105 external inputs/two archived products. Development-v1 and final-v1 remain separate historical proofs.','independent_review':record(review)}
 readme='''# Scheduled output host evidence\n\nThis packet preserves the exact private host implementation and proof for a new portable future-event ownership contract. It is not integration with `pt_paula_prepared`, song playback, native output or interrupts, and is not hardware timing or listening acceptance. Future integration needs independently held owners and a separately qualified timestamp backend.\n\nFinal-v2 passed two ASan/UBSan groups, four compile/runtime commands and six full-M queries, with 14 canonical inputs, 105 external system inputs and two archived executable products. Refusal/cancellation/uncertain submission and all-reader retirement were tested. The backend capability is a declaration, never hardware proof. Original development-v1 and final-v1 passing checks remain separate historical records.\n\nThe deterministic payload contains exact original source closures, all five new files, complete baseline/final inventories, patches, reports, actual products, logs, executed helpers and independent review. It omits full source exports and system SDK/toolchain trees. Their exact recorded fingerprints are preserved. `manifest.json` maps every archive member to its original path, role, SHA256, bytes and mode. All member bytes and modes were read back and the archive reproduced byte-for-byte. Historical scripts retain original private paths; use preserved source closures and ordered commands for reproduction in a fresh private export rather than running stale paths blindly. No test, native run or target action was performed by packaging.\n'''
 out.mkdir();(out/'payload.tar.gz').write_bytes(payload);(out/'README.md').write_text(readme);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'packet-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 names=['README.md','manifest.json','packet-provenance.json','payload.tar.gz'];(out/'SHA256SUMS').write_text(''.join(sha((out/n).read_bytes())+'  '+n+'\n' for n in sorted(names)))
 actual={p.name:record(p) for p in out.iterdir()};assert len(actual)==5
 sums=(out/'SHA256SUMS').read_text().splitlines();assert len(sums)==4
 for line in sums:
  h,n=line.split('  ',1);assert n in names and sha((out/n).read_bytes())==h
 qa.write_text(json.dumps({'passed':True,'scope':'Archive integrity only, no new product/native/target acceptance','packet':str(out),'files':actual,'member_count':len(entries),'original_bytes':manifest['original_bytes'],'members_verified':len(verified),'second_archive_equal':True,'system_fingerprint_count':len(allsystem)},indent=2)+'\n')
 print(json.dumps({'packet':str(out),'members':len(entries),'original_bytes':manifest['original_bytes'],'files':5,'total_bytes':sum(x['bytes'] for x in actual.values()),'payload_sha256':sha(payload),'manifest_sha256':sha((out/'manifest.json').read_bytes()),'qa':record(qa)},indent=2))
if __name__=='__main__':main()
