from pathlib import Path
import json,hashlib,struct,ast
R=Path('/private/tmp/protracker-scheduled-output-lvf80_5i');S=R/'source-final-v3';O=R/'native-final-v3'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify(x):
 assert sha(x['path'])==x['sha256']
 if 'bytes' in x:assert Path(x['path']).stat().st_size==x['bytes']
def inv(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
m=json.loads((R/'source-manifest-v3.json').read_text());old=json.loads((R/'source-manifest-v2.json').read_text());n=json.loads((O/'manifest.json').read_text());h=json.loads((R/'host-final-v2/host-checks.json').read_text());b='tools/build_scheduled_output_test.py'
assert inv(S)==m['files'];assert len(m['files'])==7942 and len(old['files'])==7941
assert set(m['files'])==set(old['files'])|{b} and all(m['files'][k]==v for k,v in old['files'].items())
assert inv(R/'source-final-v2')==old['files'];assert sha(R/'host-final-v2/host-checks.json')=='2de63fd48beffbe90f9b653e6b1d02834b36abaaf0a9a3dc7e4c173d2931b146'
assert n['passed'] and n['source_files_before']==n['source_files_after']==7942 and len(n['commands'])==15
assert len(n['targets'])==1;t=n['targets']['PTScheduledOutputTest'];units=['tests/scheduled_output_test.c','src/core/scheduled_output.c','src/core/elapsed_clock.c','src/core/sample_cache.c'];assert t['source_inputs']==units
assert len(t['dependencies'])==13 and len(t['external_sdk_dependencies'])==32
for k,v in t['dependencies'].items():assert m['files'][k]==v and sha(S/k)==v
for p,v in t['external_sdk_dependencies'].items():assert sha(p)==v
assert len(n['runtime_inputs'])==len(n['runtime_paths'])==7
for name,p in n['runtime_paths'].items():assert sha(p)==n['runtime_inputs'][name]
verify(n['compiler']);verify(n['python']);verify(n['builder']);verify(n['source_manifest']);verify(n['pins']);verify(n['compile_commands'])
for x in n['recipe_contract'].values():
 if isinstance(x,dict) and 'path' in x and 'sha256' in x:verify(x)
for c in n['commands']:assert c['returncode']==0 and c['directory']==str(S);verify(c['log'])
queries=[c for c in n['commands'] if c['label'].startswith('dependencies-')];assert len(queries)==4 and all('-M' in c['argv'] and '-MM' not in c['argv'] for c in queries)
verify(t['binary']);verify(t['preprocessed_fixture']);verify(t['build_log'])
assert struct.unpack('>I',Path(t['binary']['path']).read_bytes()[:4])[0]==0x3f3
pre=Path(t['preprocessed_fixture']['path']).read_text();assert '__assert_func' in t['last_assert_macro'] and pre.count('__assert_func (')>1
cc=json.loads(Path(n['compile_commands']['path']).read_text())['commands'];assert len(cc)==1 and cc[0]['ordered_translation_units']==units
assert cc[0]['argv']==[n['compiler']['path'],*n['flags'],*units,'-o',t['binary']['path']]
checks={'passed':True,'scope':'Own read-only exact native cross-build/source provenance audit; HUNK never executed','source_manifest':rec(R/'source-manifest-v3.json'),'source_equivalence':rec(R/'v2-v3-source-equivalence.json'),'source_files_before_after':7942,'all_prior7941_files_unchanged':True,'no_redundant_host_rerun':True,'new_only_path':b,'native_manifest':rec(O/'manifest.json'),'compile_commands':rec(O/'compile-commands.json'),'completed_commands':15,'full_M_queries':4,'ordered_translation_units':units,'canonical_dependencies':13,'external_sdk_dependencies':32,'runtime_pins':7,'compiler':n['compiler'],'python':n['python'],'default_SDK_assert_enabled':True,'target':t['binary'],'host_final_proof_unchanged':rec(R/'host-final-v2/host-checks.json'),'host_packet_unchanged':rec('/private/tmp/protracker-scheduled-output-host-evidence-final/payload.tar.gz'),'acceptance':{'cross_build':True,'native_runtime':False,'Exec_pools':False,'Chip_DMA':False,'song_integration':False,'native_or_IRQ_activation':False,'hardware_timing':False,'physical_or_listening':False}}
P=R/'own-native-v3-audit.json';P.write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(rec(P)))
