#!/usr/bin/env python3
"""Lossless archival of the standalone 68k cross-build only; never runs the HUNK."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,io,json,stat,tarfile
R=Path('/private/tmp/protracker-scheduled-output-lvf80_5i');S=R/'source-final-v3';N=R/'native-final-v3'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();return {'original_path':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
def verify(x):
 assert sha(x['path'])==x['sha256']
 if 'bytes' in x:assert Path(x['path']).stat().st_size==x['bytes']
def main():
 a=argparse.ArgumentParser();a.add_argument('--out',required=True);a.add_argument('--qa',required=True);a.add_argument('--independent-review',required=True);a.add_argument('--independent-review-sha256',required=True);args=a.parse_args()
 out=Path(args.out).resolve();qa=Path(args.qa).resolve();review=Path(args.independent_review).resolve()
 assert not out.exists() and not qa.exists() and out!=R and R not in out.parents and out not in R.parents
 assert out!=qa and out not in qa.parents and qa not in out.parents
 assert sha(review)==args.independent_review_sha256 and json.loads(review.read_text()).get('passed') is True
 members={};blobs={}
 def add(name,p,role):
  pp=PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts and str(pp)==name and name not in members
  x=rec(p);x.update(member=name,role=role);members[name]=x;blobs[name]=Path(p).read_bytes()
 def tree(prefix,p,role):
  for f in sorted(Path(p).rglob('*')):
   if f.is_file():assert '__pycache__' not in f.parts and f.suffix!='.pyc';add(prefix+'/'+str(f.relative_to(p)),f,role)
 m=json.loads((R/'source-manifest-v3.json').read_text());old=json.loads((R/'source-manifest-v2.json').read_text());n=json.loads((N/'manifest.json').read_text());t=n['targets']['PTScheduledOutputTest'];new='tools/build_scheduled_output_test.py'
 full={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};assert full==m['files']
 assert set(full)==set(old['files'])|{new} and all(full[k]==v for k,v in old['files'].items()) and len(full)==7942
 assert n['passed'] and n['source_files_before']==n['source_files_after']==7942 and len(n['commands'])==15
 assert len(t['dependencies'])==13 and len(t['external_sdk_dependencies'])==32 and len(n['runtime_inputs'])==7
 for x in [n['source_manifest'],n['pins'],n['compiler'],n['python'],n['builder'],n['compile_commands'],t['binary'],t['preprocessed_fixture'],t['build_log']]:verify(x)
 for x in n['recipe_contract'].values():
  if isinstance(x,dict) and 'path' in x and 'sha256' in x:verify(x)
 for c in n['commands']:assert c['returncode']==0;verify(c['log'])
 for k,v in t['dependencies'].items():assert full[k]==v
 for p,v in t['external_sdk_dependencies'].items():assert sha(p)==v
 for k,p in n['runtime_paths'].items():assert sha(p)==n['runtime_inputs'][k]
 add('reviews/independent-native-build-review.json',review,'Exact independent read-only builder and successful cross-build provenance review')
 for f in ['source-manifest-v3.json','source-manifest-v2.json','v2-v3-source-equivalence.json','final-v3.patch','handoff-v3.json','own-native-v3-audit.json','audit_native_v3.py','package_native_build_supplement.py']:
  add('records/'+f,R/f,'Exact inventory/equivalence/delta/handoff or archival helper; original host proof unchanged')
 tree('native-build',N,'Exact compiler/runtime query/full-M/preprocess/build logs and linked HUNK; not target execution')
 add('pins/toolchain-pins.json',R/'tools/toolchain-pins.json','Exact supplied compiler/Python/runtime pin control; SDK trees omitted')
 selected=set(t['dependencies'])|{x['path'] for x in m['overlays']}|{'tools/build_core_tests.py','tools/build_diagnostic.py','tests/test_scheduled_output.py'}
 for p in sorted(selected):assert sha(S/p)==full[p];add('source/'+p,S/p,'Exact six-file new delta and complete native compile/declaration/flag/runtime-recipe closure')
 for p in ['/private/tmp/protracker-scheduled-output-independent-review.json','/private/tmp/protracker-scheduled-output-host-packet-independent-review.json']:
  add('reviews/'+Path(p).name,p,'Original preceding host/packet review; no new sanitizer run')
 hostpacket=Path('/private/tmp/protracker-scheduled-output-host-evidence-final')
 hostcontrols={}
 for f in sorted(hostpacket.iterdir()):
  if f.name!='payload.tar.gz':add('prior-host-packet-controls/'+f.name,f,'Exact prior host packet control; payload referenced by fingerprint without duplication')
  hostcontrols[f.name]=rec(f)
 def archive():
  raw=io.BytesIO()
  with tarfile.open(fileobj=raw,mode='w',format=tarfile.USTAR_FORMAT) as tf:
   for name in sorted(members):
    x=members[name];ti=tarfile.TarInfo(name);ti.size=x['bytes'];ti.mode=x['mode'];ti.uid=ti.gid=ti.mtime=0;ti.uname=ti.gname='';tf.addfile(ti,io.BytesIO(blobs[name]))
  return gzip.compress(raw.getvalue(),compresslevel=9,mtime=0)
 payload=archive();assert payload==archive();seen=set()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
  for ti in tf:
   assert ti.isfile() and ti.name in members and ti.name not in seen and not PurePosixPath(ti.name).is_absolute() and '..' not in PurePosixPath(ti.name).parts
   seen.add(ti.name);x=members[ti.name];b=tf.extractfile(ti).read();assert b==blobs[ti.name] and len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'] and ti.mode==x['mode']
   assert ti.uid==ti.gid==ti.mtime==0 and not ti.uname and not ti.gname
 assert seen==set(members)
 for x in members.values():assert rec(x['original_path'])=={k:x[k] for k in ['original_path','sha256','bytes','mode']}
 for f,x in hostcontrols.items():assert rec(hostpacket/f)==x
 index={'scope':'Separate portable 68k compile/link supplement; HUNK never executed','base_commit':m['base_commit'],'base_tree':m['base_tree'],'source_files':7942,'six_new_paths':[x['path'] for x in m['overlays']],'member_count':len(members),'original_bytes':sum(x['bytes'] for x in members.values()),'members':[members[k] for k in sorted(members)]}
 provenance={'passed_archive_integrity':True,'native_runtime_pass':False,'payload_sha256':hashlib.sha256(payload).hexdigest(),'payload_bytes':len(payload),'deterministic_second_archive_equal':True,'full_tar_reader_bytes_modes':len(seen),'all_prior7941_source_files_identical':True,'no_repeated_sanitizers':True,'native_build':{'commands':15,'full_M_queries':4,'ordered_translation_units':t['source_inputs'],'canonical_dependencies':13,'SDK_dependencies':32,'runtime_pins':7,'compiler':n['compiler'],'python':n['python'],'target':t['binary'],'SDK_assert_enabled':True},'external_SDK_fingerprints_only':t['external_sdk_dependencies'],'runtime_fingerprints_only':n['runtime_inputs'],'prior_host_packet_unchanged':hostcontrols,'independent_review':rec(review)}
 readme='''# Scheduled output 68k build supplement\n\nThis preserves one pinned portable compile/link check of PTScheduledOutputTest. Fifteen compiler/query commands passed, including four full-M dependency scans, 13 canonical inputs, 32 SDK inputs and seven runtime pins. Default SDK assertions are enabled and the linked product is a HUNK. The binary has not been run. No Exec/Chip/DMA, device output, song/IRQ integration, physical timing or listening acceptance is claimed.\n\nA sixth new file supplies a standalone builder using the committed 68000/nix20 conventions for the shared 030 profile. All preceding 7,941 source files are byte-identical to the reviewed host version; the passing host packet and proofs remain unchanged and sanitizers were not repeated. Existing pt_paula_prepared/song/native lifecycle remains unchanged. Future independently held owners and a qualified timestamp backend are still required.\n\nThe deterministic payload maps exact source closures, complete inventories, ordered commands, logs, linked product, pin controls and reviews to original paths/bytes/SHA256/modes in manifest.json. SDK/toolchain trees and the full source export are omitted; exact fingerprints remain. The preceding host packet payload is referenced without duplication. Both archive construction and tar-reader verification were repeated. Historical private paths are preserved; reproduce in a fresh private export using controls and commands, rather than blindly executing old paths. A later runtime test needs separately approved ownership/identity/cleanup and an explicitly adequate Stack 262144 for the two 64KiB local adversarial images. Packaging ran no tests or targets.\n'''
 out.mkdir();(out/'payload.tar.gz').write_bytes(payload);(out/'manifest.json').write_text(json.dumps(index,indent=2)+'\n');(out/'packet-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');(out/'README.md').write_text(readme)
 names=['README.md','manifest.json','packet-provenance.json','payload.tar.gz'];(out/'SHA256SUMS').write_text(''.join(sha(out/p)+'  '+p+'\n' for p in sorted(names)))
 files={p.name:rec(p) for p in out.iterdir()};assert len(files)==5
 for line in (out/'SHA256SUMS').read_text().splitlines():h,p=line.split('  ',1);assert p in names and sha(out/p)==h
 qa.write_text(json.dumps({'passed':True,'scope':'Archive integrity only; no HUNK/runtime/target execution','packet':str(out),'files':files,'member_count':len(seen),'original_bytes':index['original_bytes'],'second_archive_equal':True,'all_member_origins_unchanged':True},indent=2)+'\n')
 print(json.dumps({'packet':str(out),'files':5,'total_bytes':sum(x['bytes'] for x in files.values()),'members':len(seen),'original_bytes':index['original_bytes'],'payload_sha256':provenance['payload_sha256'],'manifest_sha256':sha(out/'manifest.json'),'qa':rec(qa)},indent=2))
if __name__=='__main__':main()
