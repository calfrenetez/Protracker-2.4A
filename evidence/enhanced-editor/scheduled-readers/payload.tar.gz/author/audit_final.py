import ast,hashlib,json,re,shlex,time
from pathlib import Path
r=Path('/private/tmp/protracker-scheduled-readers-dmuzps6v');source=r/'source-final';baseline=r/'baseline';candidate=r/'candidate'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rec(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':H(p)}
def check(entry):
 p=Path(entry['path']);assert p.is_file() and H(p)==entry['sha256'];assert 'bytes' not in entry or p.stat().st_size==entry['bytes']
def snapshot(p):return {x.relative_to(p).as_posix():H(x) for x in sorted(p.rglob('*')) if x.is_file()}
m=json.loads((r/'source-manifest.json').read_text());bind=json.loads((r/'baseline-binding.json').read_text());b=snapshot(baseline);s=snapshot(source);c=snapshot(candidate)
check(bind['origin_manifest']);origin=json.loads(Path(bind['origin_manifest']['path']).read_text())['files'];origin={n:v if isinstance(v,str) else v['sha256'] for n,v in origin.items()}
assert b==bind['files']==origin and len(b)==8001 and s==c==m['source'] and len(s)==8006
paths=set(m['new_inputs']);assert set(s)-set(b)==paths and len(paths)==5 and all(s[n]==v for n,v in b.items())
report=json.loads((r/'host-final/host-checks.json').read_text());assert report['passed'] and report['source_files_before']==report['source_files_after']==8006 and report['export_tree_sha256']==hashlib.sha256(json.dumps(s,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert report['modules']==['test_scheduled_readers'] and len(report['groups'])==1 and report['groups'][0]['passed'] and report['groups'][0]['tests']==1
assert not report['generated_inputs'] and len(report['products'])==1 and len(report['commands'])==2
canonical={};system={};dep_count=0
for command in report['commands']:
 assert command['stage']=='complete' and command['product_returncode']==0;check(command['output_log'])
 for dep in command['dependency_commands']:
  dep_count+=1;assert dep['returncode']==0 and '-M' in dep['argv'] and '-MM' not in dep['argv'];check(dep['output'])
  text=re.sub(r'\\\r?\n',' ',Path(dep['output']['path']).read_text());tokens=[]
  for line in text.splitlines():
   colon=re.search(r'(?<!\\):',line)
   if colon:tokens+=shlex.split(line[colon.end():])
  if dep['unit']=='tests/scheduled_readers_test.c':assert tokens.count('tests/../src/core/scheduled_readers.c')==1
  for name in tokens:
   p=(source/name).resolve()
   if p.is_relative_to(source):n=p.relative_to(source).as_posix();assert H(p)==s[n];canonical[n]=H(p)
   else:assert str(p).startswith('/Library/Developer/CommandLineTools/');system[str(p)]=H(p)
 for key in ['produced_binary','input_binary']:
  if key in command:product=command[key];assert H(product['archive_path'])==product['sha256'] and Path(product['archive_path']).stat().st_size==product['bytes']
assert dep_count==2 and canonical==report['canonical_dependencies'] and system==report['external_sdk_dependencies']
for key in ['module_inputs','helper_inputs']:
 for entry in report[key]:check(entry)
for key in ['compiler','python']:check(report[key])
for key in ['sanitizer_runtime_inputs','pinned_sdk_inputs']:
 for name,sha in report[key].items():assert H(name)==sha
check(report['pins']);check(report['source_manifest']);check(report['log'])
assert ['tests/scheduled_readers_test.c','src/core/elapsed_clock.c']==[a for a in report['commands'][0]['executed_argv'] if a.endswith('.c')]
py=ast.parse((source/'tests/test_scheduled_readers.py').read_text());decl=next(ast.literal_eval(n.value) for n in py.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCES' for t in n.targets));assert decl==['tests/scheduled_readers_test.c','src/core/elapsed_clock.c']
assert (source/'tests/scheduled_readers_test.c').read_text().count('#include "../src/core/scheduled_readers.c"')==1
marker='SCHEDULED READERS PASS: independent command detach and persistent reader retirement; 20 controls with command capacity2'
assert Path(report['commands'][1]['output_log']['path']).read_text()==marker+'\n'
prepared=json.loads((r/'tools/prepared-files.json').read_text())
for name,entry in prepared['files'].items():assert H(r/'tools'/name)==entry['sha256'] and (r/'tools'/name).stat().st_size==entry['bytes']
for name,entry in prepared['origin_files'].items():assert H(Path(prepared['origin'])/name)==entry['sha256']
history=[]
for n in range(1,10):
 p=r/('development-%02d'%n);entries=[rec(x) for x in sorted(p.iterdir()) if x.is_file()];history.append({'development':n,'entries':entries,'expected_log_status':'exploratory test-model assertion failure' if n<=3 else 'exploratory focused PASS','scope':'Not final pinned provenance; original exploratory logs and saved source revisions remain unchanged. Earlier transient header inputs were not independently archived.'})
audit={'scope':'Own saved-byte/source/full-M/product/toolchain audit only; no rerun/import/build/target operation','passed':True,'observed_at_unix':time.time(),'source_manifest':rec(r/'source-manifest.json'),'baseline_binding':rec(r/'baseline-binding.json'),'baseline_count':len(b),'final_count':len(s),'exact_five_new':sorted(paths),'all_baseline_and_prior_seams_unchanged':True,'host_report':rec(r/'host-final/host-checks.json'),'host_log':rec(r/'host-final/host-checks.log'),'groups':1,'completed_RC0_commands':2,'full_M_commands':dep_count,'canonical_dependencies':len(canonical),'system_dependencies':len(system),'translation_units':decl,'included_production_once':True,'products':report['products'],'generated_inputs':0,'marker':marker,'helpers_preparation':rec(r/'tools/prepared-files.json'),'development_history':history,'limits':['Synthetic independent holders/backend only; no real sampler cache pins','No native compilation/execution, IRQ exclusion, ref-transfer qualification, device/MMIO/DMA/audio/timing/physical/listening proof','Caller-issued session freshness is an explicit contract; no unbounded global identity history'],'elapsed_host_s':report['groups'][0]['seconds']}
(r/'own-final-review.json').write_text(json.dumps(audit,indent=2)+'\n')
handoff={'scope':'Portable private split-domain command/persistent-reader seam; five new files only','source_final':str(source),'source_manifest':rec(r/'source-manifest.json'),'baseline_binding':rec(r/'baseline-binding.json'),'baseline_count':8001,'final_count':8006,'new_inputs':m['new_inputs'],'final_patch':rec(r/'final.patch'),'host_report':rec(r/'host-final/host-checks.json'),'host_log':rec(r/'host-final/host-checks.log'),'host_invocation':rec(r/'host-final-invocation.log'),'own_final_review':rec(r/'own-final-review.json'),'host_helpers':rec(r/'tools/prepared-files.json'),'host_scope':{'groups':1,'completed_RC0':2,'full_M':dep_count,'canonical':len(canonical),'system':len(system),'products':1,'generated':0,'elapsed_s':report['groups'][0]['seconds']},'source_declarations':decl,'compiled_production_included_exactly_once':'src/core/scheduled_readers.c','marker':marker,'immutable_old_apis':['scheduled_output','scheduled_lineage','sampler_paula_future','sampler_paula_lineage'],'behavior':['Independent fixed command and reader limits1..8/up to4actions','20 sequential controls with commandcapacity2 and one persistent original','Positive actual adoption and exact original tuple before key permission','Exact command detachment never releases sample/cache refs','Separate independently exact reader retirement plus zero command refs releases once','Positive replacement permission closure permanent after replacement retirement','Uncertainty/wrong-domain/forged retains; exact proof may release appropriate domain with invalid classification and unchanged output','Local cancel origin explicit; no invented ACTIVE or backend ticks','Full capacities/output/control spans before callbacks; metadata snapshot before current checks','Monotone bad retirement classification; release reentry refuses'],'history_preserved':[x['development'] for x in history],'unqualified':audit['limits'],'native_target_state':'NOT BUILT / NOT RUN in this author scope','repository_state':'No shared source/index/Git mutations; private TMP only'}
(r/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'handoff':rec(r/'handoff.json'),'own_audit':rec(r/'own-final-review.json'),'report':rec(r/'host-final/host-checks.json'),'host_log':rec(r/'host-final/host-checks.log'),'count':len(s),'dependencies':{'canonical':len(canonical),'system':len(system)},'passed':True}))
