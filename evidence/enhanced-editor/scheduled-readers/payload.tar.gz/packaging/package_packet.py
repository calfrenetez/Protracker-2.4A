#!/usr/bin/env python3
"""Private deterministic packet assembly, after actual native independent review.
No producer import/test/compiler/HUNK/target/lock/Git operation is used.
"""
import argparse,hashlib,json,os,stat,sys
from pathlib import Path,PurePosixPath
# Pure packet byte helpers only, not product/producer software.
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_payload import regular,archive,need,sha

def record(p):
    raw,mode=regular(p);return {'path':str(p),'bytes':len(raw),'sha256':sha(raw),'mode':mode}
def checked(entry):
    raw,mode=regular(entry['path']);need(sha(raw)==entry['sha256'] and len(raw)==entry['bytes'] and mode==entry['mode'],'origin changed '+entry['path']);return raw

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--origins',required=True,type=Path);ap.add_argument('--origins-sha256',required=True);ap.add_argument('--native-review',required=True,type=Path);ap.add_argument('--native-review-sha256',required=True);ap.add_argument('--out',required=True,type=Path);a=ap.parse_args()
    raw,_=regular(a.origins);need(sha(raw)==a.origins_sha256,'preparation changed');cfg=json.loads(raw)
    # No output creation before actual successful independent native review.
    review_raw,_=regular(a.native_review);need(sha(review_raw)==a.native_review_sha256,'native review changed');review=json.loads(review_raw);need(review.get('passed') is True,'actual native review must pass')
    host=json.loads(regular(cfg['host_report']['path'])[0]);native=json.loads(regular(cfg['native_report']['path'])[0]);need(host['passed'] is True and native['passed'] is True,'proof must pass')
    target=native['targets']['PTScheduledReadersTest'];binary=cfg['native_binary'];need(target['binary']==binary and binary['bytes']==61416 and binary['sha256']=='9e62dea2cc6ed4c4d544bd7bd59fec79bee90b0db88c6273642ec73f0bbe0a6c','candidate mismatch')
    members=dict(cfg['members']);new={'reviews/actual-native-build.json':{**record(a.native_review),'scope':'Actual independent saved native build review; no runtime claim'},'packaging/prepared-origins.json':{**record(a.origins),'scope':'Historical packet preparation with WAITING review label; actual review is separate'},'packaging/package_packet.py':{**record(Path(__file__).resolve()),'scope':'Executed packet-only assembly helper; no producer operations'},'packaging/verify_payload.py':{**record(Path(__file__).with_name('verify_payload.py')),'scope':'Standalone read-only packet verifier source'}}
    need(not(set(members)&set(new)),'member collision');members.update(new);raws={}
    for name,row in members.items():
        p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and str(p)==name,'unsafe destination');raws[name]=checked(row)
    need(checked(members['native-build/manifest.json'])==regular(cfg['native_report']['path'])[0],'native manifest changed')
    need(raws['native-build/PTScheduledReadersTest'][:4]==b'\0\0\x03\xf3','HUNK header missing')
    marker=b'SCHEDULED READERS PASS: independent command detach and persistent reader retirement; 20 controls with command capacity2';need(raws['native-build/PTScheduledReadersTest'].count(marker)==1,'marker missing')
    # Bind literal native audit to this actual candidate, rather than unrelated PASS.
    need(binary['sha256'].encode() in review_raw and cfg['native_report']['sha256'].encode() in review_raw,'review does not bind candidate/manifest')
    out=a.out.absolute();need(str(out).startswith('/private/tmp/') and not out.exists() and not any(out==Path(v['path']).parent or out in Path(v['path']).parents for v in members.values()),'fresh private output required');out.mkdir(mode=0o755)
    payload=archive(raws,members);need(payload==archive(raws,members),'duplicate generation changed')
    manifest={'scope':'host_and_native_compile_only','member_count':len(members),'original_bytes':sum(v['bytes'] for v in members.values()),'payload':{'bytes':len(payload),'sha256':sha(payload)},'members':{name:{'original_path':v['path'],'bytes':v['bytes'],'sha256':v['sha256'],'mode':v['mode'],'scope':v['scope']} for name,v in sorted(members.items())},'host':cfg['host_counts'],'native':cfg['native_counts'],'native_binary':binary,'source_manifests':{'author':cfg['source_manifest'],'current_native':cfg['native_manifest']},'independent_actual_native_review':record(a.native_review),'native_NOT_RUN':True,'limits':cfg['limits'],'complete_source_exports_or_SDK_trees_archived':False,'archive_excludes':cfg['archive_excludes'],'packet_reproduction':'verify_payload.py reconstructs deterministic payload in memory; --origins verifies exact retained originals'}
    readme='''This packet preserves the new opt-in scheduled_readers split-domain portable contract. Legacy scheduled flags7, scheduled_lineage v1 and ALL_RETIRED remain unchanged. Commands own only small event/control storage; authoritative master/cache spans belong to independently retained persistent readers. The synthetic fixture performs 20 sequential CONTROLs with command capacity 2 while retaining the original reader, exact key and original timing after command-slot reuse. It covers independent retirement orders, uncertain/unadopted ownership, forged/reused keys and envelopes, monotone bad retirement classification, permanent actual replacement closure, local-vs-backend receipt origins, full-capacity alias guards, whole-batch activation refusal, four grids and reentry. Synthetic holders are not real sampler/cache-pin acceptance or an installed native activation backend.

The final immutable author export has 8,006 files: accepted 8,001 baseline inputs unchanged plus exactly five new paths. One pinned host ASan/UBSan group completed two RC0 commands and two full-M queries, with 12 canonical sources/headers, 99 external system fingerprints, one archived executable and no generated inputs. One packet-only marker-literal refusal occurred before output creation; its executed helper and log are preserved separately and it changed no source/product. Initial development 1/2/3 fixture assertion failures remain original and separate; development 4–9 PASS logs and retained source revisions are historical, not the final pinned proof. Early transient headers were not independently archived, so no complete historical reproducibility is claimed. Final immutable proof and source identities are complete.

The distinct current native source is clean committed 1d89ef86a577919cddc580d46c261bfce4e3335a of 8,006 files plus the exact five author inputs and one standalone builder, totaling 8,012. The actual compiler-only build completed 13 RC0 command records, two ordered translation units (the fixture includes production C exactly once), 12 canonical dependencies, 30 external SDK fingerprints and seven pinned runtime libraries. Optimizer safety flags and enabled default SDK assertions remain. PTScheduledReadersTest is 61,416 bytes, SHA256 9e62dea2cc6ed4c4d544bd7bd59fec79bee90b0db88c6273642ec73f0bbe0a6c; its full PASS marker occurs once. The HUNK has NOT RUN. Root external invocation and builder elapsed values are retained literally, with distinct scopes. No adequate-stack/runtime/Exec Fast/Chip/device/IRQ/reference-transfer/DMA/audio/timing/physical/listening acceptance follows from compilation.

All final full source inventories, host/native full-M compiled closures, actual helpers/ordered recipes/commands/logs/products, development originals, initial/final/source/export/builder/actual-build reviews and the original frozen documentation are archived losslessly. Complete source exports, the 116MB Git export tar and SDK/compiler/runtime trees are omitted; their original recorded identities remain. Original documentation is byte-exact: its callback restriction applies to current/status/terminal callbacks, while the designated release callback performs release. Later current-status prose clarification belongs separately and does not alter compiled proof.

manifest.json maps every regular archive member to its original path/hash/bytes/mode and literal scope. Archive names are finite safe relative paths; ownership/timestamps are normalized. SHA256SUMS binds the other four controls. verify_payload.py reads and reconstructs the payload in memory without extraction or archived software execution; --origins also verifies retained originals. Packaging itself performs no product/compiler/HUNK/target operation.
'''
    (out/'payload.tar.gz').write_bytes(payload);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'README.md').write_text(readme);(out/'verify_payload.py').write_bytes(regular(Path(__file__).with_name('verify_payload.py'))[0])
    controls=['README.md','manifest.json','payload.tar.gz','verify_payload.py'];(out/'SHA256SUMS').write_text(''.join(sha(regular(out/name)[0])+'  '+name+'\n' for name in controls))
    # Final original stability is checked after archive writes, before success.
    for name,row in members.items():need(checked(row)==raws[name],'origin changed after archive')
    qa={'passed':True,'scope':'Own packet assembly/read-byte validation; no archived software run','packet':str(out),'member_count':len(members),'original_bytes':manifest['original_bytes'],'controls':{name:record(out/name) for name in [*controls,'SHA256SUMS']},'native_NOT_RUN':True}
    qpath=out.with_name(out.name+'-own-qa.json');qpath.write_text(json.dumps(qa,indent=2)+'\n');print(json.dumps(qa))
if __name__=='__main__':main()
