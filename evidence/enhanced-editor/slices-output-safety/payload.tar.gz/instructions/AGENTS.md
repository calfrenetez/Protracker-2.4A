# ProTracker shared harness entry point

For Amiga build, debugging and testing infrastructure, read `/Users/james1/Documents/Codex/shared-tools/amiga-dev-infra/docs/PROJECT_ONBOARDING.md`. This repository is registered as `protracker` through root `amiga-test.json`; reuse the shared 030 emulator, transport, locking and evidence tools.

Follow the current task and project handover for product requirements. The adapter's build command builds native core tests, not the full editor. A passing core or infrastructure test does not qualify an editor candidate. Preserve uncommitted work and check the current build/candidate state before tests. Application work remains paused until the owner resumes it in the project task; this instruction file does not authorize a hardware deployment.
