# Shared Amiga harness: entry point for project tasks

Use this installed harness for Amiga build, emulator, debugging and real-A1200 test work. Reuse existing project build systems and pinned compilers. Do not recreate the shared installation in each project.

Harness root: `/Users/james1/Documents/Codex/shared-tools/amiga-dev-infra`.
Read `docs/HARNESS_ACCEPTANCE.md` for qualified checks and limits, `README.md` for operation, and `config/projects.json` plus the selected repository's `amiga-test.json` for project commands. Recheck the live state before guest operations; evidence timestamps do not prove current availability.

## Scope and targets

The default target is `amiberry-030`: the owned 68030 emulator with 2 MiB Chip and 128 MiB Fast memory. Physical target `real-a1200` is the owner's ACA1234 A1200, using Plipbox at the address in `config/devbench.toml`. The emulator is an approximation, not timing or peripheral proof. Stock qualification is deferred unless the current project task explicitly needs it. AmiGUS is not required for ordinary app tests; its hardware checks remain separate.

These instructions describe reuse, not permission to resume paused work or deploy a candidate. Follow the current user request and project-specific acceptance boundaries. Preserve existing uncommitted work. Do not infer full application acceptance from a passing bridge or core-test run.

## Existing integrations

- `amiconnect`: registered project adapter, build and host tests, isolated emulator authentication/capture/files/reconnect/input/lifecycle tests. Automatic physical AmiConnect replacement is not enabled. Product reliability findings remain separate from harness acceptance.
- `protracker`: registered project adapter, native core tests and emulator UI/sampler adapters. Its declared build builds core-test executables; it is not a full editor build. Check the project task's current candidate/build state before running or deploying anything.

From the harness root, when application work is authorized, select the appropriate project:

```sh
scripts/amiga doctor
scripts/amiga build --project amiconnect
scripts/amiga host-test --project amiconnect
scripts/amiga connect --target amiberry-030
scripts/amiga test --project amiconnect --target amiberry-030
```

Use `--project protracker` for its core workflow. Its `--suite ui` and `--suite sampler` are emulator-only application adapters. The infrastructure-only check is `scripts/amiga test --project bridge --target amiberry-030 --suite harness`. Tests expect the owned emulator to be available; use the documented `scripts/emulator.py` lifecycle wrapper if startup is needed and the resource is free. Do not start a second emulator over the same disk or restart a guest another task is using.

## Shared resource coordination

Coordinate with other active Amiga tasks before emulator lifecycle, guest tests, physical operations or changing the DevBench target. Host-only work can proceed independently. One task controls a guest at a time. The DevBench connection itself is shared even when tasks intend to use different guests.

The CLI and emulator lifecycle wrapper take the nonblocking `runtime/test.lock`. This serializes individual commands, not entire conversations or multi-command workflows. Never bypass a busy lock. A free lock alone does not prove another task has finished an interactive session. Direct MCP/manual orchestration must use the same lock and target guards; prefer the wrappers.

Physical execution needs the current task's hardware authorization and appropriate emulator evidence for the exact candidate bytes. Stop on physical failure instead of automatically retrying. Clean only exact run-owned paths, preserve installed configuration and credentials, and return DevBench to `amiberry-030` after a hardware run. Physical core smoke cleanup is currently the caller's responsibility; the `--suite harness` transport checks perform their own cleanup. Leave AmiConnect streaming paused for timing-sensitive tests and return any acquired browser control to View Only.

## Add a future app

1. Inspect the app's own instructions, build system, hardware needs and current acceptance state.
2. Add a repository-owned `amiga-test.json` describing the actual build/host commands, artifacts, expected assertions and hardware-only requirements. Add its repository path and adapter to `config/projects.json`.
3. Inspect and extend the runner dispatch for that app. Registration alone does not create a working guest test: `scripts/amiga.py` currently has project-specific core branches and suite assumptions, and `scripts/physical.py` accepts only its existing supported projects. Reuse transport, locking, ownership, result recording and promotion checks; keep app assertions in its own adapter. Verify the new integration before claiming support.
4. Add a link to this guide in that project's root `AGENTS.md`, preserving its existing instructions. Qualify host and emulator checks before the corresponding physical checks.

Aqua Bonk, AmiContinuity and future apps are not automatically registered by being in this workspace. They can reuse the established infrastructure once their integration is added and checked.

## Discovery across tasks

`/Users/james1/Documents/Codex/AGENTS.md` points Amiga work in this workspace to this guide. AmiConnect and ProTracker also have direct root instruction links and existing adapters. Already-open tasks should explicitly reread their project instructions and this guide when resuming; this file does not inject a message into another task. Projects outside this workspace need their own instruction link and registration.
