#include <stdio.h>
#include <string.h>
#include "slices.h"
struct storage { int32_t active[8]; size_t count; int32_t tail[6]; };
static void init(struct storage *s)
{
    size_t i; memset(s,0,sizeof(*s));
    for(i=0;i<8;++i)s->active[i]=(int32_t)(i+1);
    s->count=42;for(i=0;i<6;++i)s->tail[i]=42;
}
int main(void)
{
    struct storage s,before;
    struct pt_pcm pcm={(int32_t *)&s,sizeof(s)/sizeof(int32_t),8,48000,1,16};
    struct pt_slice_options options={64,0,500,5};
    uint32_t out[4]={99,99,99,99};size_t count=99;int r,changed,failures=0;
    init(&s);memcpy(&before,&s,sizeof(s));
    r=pt_auto_slice(&pcm,&options,(uint32_t *)&s.tail[5],4,&count);
    changed=memcmp(&before,&s,sizeof(s))!=0;
    printf("marker result=%d source_changed=%d\n",r,changed);
    failures+=(r!=PT_SLICE_ALIAS || changed);
    init(&s);memcpy(&before,&s,sizeof(s));
    r=pt_auto_slice(&pcm,&options,out,4,&s.count);
    changed=memcmp(&before,&s,sizeof(s))!=0;
    printf("count result=%d source_changed=%d\n",r,changed);
    failures+=(r!=PT_SLICE_ALIAS || changed);
    init(&s);memcpy(&before,&s,sizeof(s));
    r=pt_pcm_crossfade_loop(&pcm,0,8,2,(uint32_t *)&s.tail[5]);
    changed=memcmp(&before,&s,sizeof(s))!=0;
    printf("crossfade result=%d source_changed=%d\n",r,changed);
    failures+=(r!=PT_PCM_ALIAS || changed);
    printf("SLICES OUTPUT PROBE failures=%d\n",failures);
    return failures?20:0;
}
