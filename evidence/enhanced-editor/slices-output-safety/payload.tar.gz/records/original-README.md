This private export starts from committed 411aca9 and exactly the reviewed PCM3 overlays already imported by root. The slice change owns only src/core/slices.c, src/core/slices.h and tests/slices_test.c. No dirty display/editor/build recipe was imported and no repository file was edited here.

The same 1,410-byte probe demonstrates three valid baseline corruptions (RC20: marker, count and crossfade each OK0/source_changed1). The candidate returns ALIAS3/source_changed0 for all three and exits RC0. The baseline remains preserved.

The new shared metadata check protects full declared PCM capacity and the source descriptor. Auto-slice protects actual emitted marker bytes, count and options; a scalar in unused output capacity remains legal. Crossfade refuses aliases before editing its tail. Existing validation, geometry, capacity and NULL-output precedence are retained; spare source storage is never treated as audio.

Two focused ASan/UBSan groups, test_slices and the existing direct test_sampler caller, passed from the frozen 7,677-file snapshot. Four exact compile/runtime commands, 19 full-M commands, 33 canonical dependencies, 105 SDK headers and two executable copies are preserved. There were no generated fixture inputs. Helper/source/product/dependency hashes and identical probe bytes were rechecked by final_review.py without rerunning tests.

This package proves host behavior only. Native builds and target/emulator/physical operations were not performed by this lane. Parent owns any later combined native build and qualification. Read handoff.json for exact paths, hashes and source overlay identities.
