"""Read-only host provenance verification; no compiler, test, or target invocation."""
import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def checkrec(d):
 p=Path(d.get('path',d.get('archive_path','')));assert p.is_file(),str(p)
 assert sha(p)==d['sha256'],str(p)
 if 'bytes'in d:assert p.stat().st_size==d['bytes'],str(p)
base=json.loads((r/'baseline-manifest.json').read_text());final=json.loads((r/'source-manifest.json').read_text())
for folder,m in [('baseline',base),('source-final',final)]:
 actual={p.relative_to(r/folder).as_posix():sha(p)for p in sorted((r/folder).rglob('*'))if p.is_file()}
 assert actual==m['source'];assert len(actual)==7677
changed=[p for p in base['source']if base['source'][p]!=final['source'][p]]
assert changed==['src/core/slices.c','src/core/slices.h','tests/slices_test.c']
checks=[]
for name,source in [('baseline-probe',r/'baseline'),('candidate-probe',r/'source-final'),('host-final',r/'source-final')]:
 p=r/name/('host-checks.json'if name=='host-final'else'result.json');d=json.loads(p.read_text());assert d['passed'];assert d['source_files_before']==d['source_files_after']==7677
 for key,value in d['canonical_dependencies'].items():assert sha(source/key)==value
 for key,value in d['external_sdk_dependencies'].items():assert sha(Path(key))==value
 for key,value in d.get('runtime_inputs',d.get('sanitizer_runtime_inputs',{})).items():assert sha(Path(key))==value
 for key,value in d.get('sdk_inputs',d.get('pinned_sdk_inputs',{})).items():assert sha(Path(key))==value
 for key in ['compiler','python']:checkrec(d[key])
 for rec in d.get('helpers',d.get('helper_inputs',[]))+d.get('module_inputs',[]):checkrec(rec)
 for command in d['commands']:
  assert command.get('product_returncode',command.get('returncode')) in (0,20)
  for key in ['log','output_log','produced_binary','input_binary']:
   if key in command:checkrec(command[key])
  for dep in command.get('dependency_commands',[]):assert dep['returncode']==0;checkrec(dep['output'])
 for key in ['binary','probe','probe_origin','source_manifest','log']:
  if key in d:checkrec(d[key])
 for rec in d.get('products',[]):checkrec(rec)
 checks.append({'report':record(p),'commands':len(d['commands']),'canonical_dependencies':len(d['canonical_dependencies']),'sdk_dependencies':len(d['external_sdk_dependencies'])})
assert (r/'baseline-probe/probe.c').read_bytes()==(r/'candidate-probe/probe.c').read_bytes()==(r/'output-probe.c').read_bytes()
assert json.loads((r/'baseline-probe/result.json').read_text())['run_rc']==20
assert json.loads((r/'candidate-probe/result.json').read_text())['run_rc']==0
host=json.loads((r/'host-final/host-checks.json').read_text());assert host['modules']==['test_slices','test_sampler'];assert len(host['commands'])==4 and len(host['products'])==2 and not host['generated_inputs']
assert sum(len(c['dependency_commands'])for c in host['commands'])==19
out={'scope':'Read-only private host proof/source/product/dependency review; no native/device acceptance','passed':True,'source_files':7677,'changed_paths':changed,'reports':checks,'identical_probe':record(r/'output-probe.c'),'native':'NOT RUN','physical':'NOT RUN','review_script':record(Path(__file__))}
(r/'final-review.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out))
