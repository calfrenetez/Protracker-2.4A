#!/usr/bin/env python3
"""Create a private deterministic host-only slices proof packet, without builds or target access."""
import argparse, gzip, hashlib, io, json, os, stat, tarfile
from pathlib import Path, PurePosixPath

ROOT=Path('/private/tmp/protracker-slices-output-safety-LmjGLE')
ROOT_CHECK=Path('/private/tmp/protracker-slices-root-u1w5j02x/import-and-source-check.json')
EXCLUDED=Path('/private/tmp/protracker-studio-output-safety-root-g5p3wv2y/excluded-dirty-before.json')
PINS={
 'baseline-manifest.json':'445c3d5402a8378f07560e52248099dbe22f3a1bbc9c3958d8ad0594dcb5f1af',
 'source-manifest.json':'e8499f3aa398fba7a99b63653e452cc62811e1805462e4ec20c883ddd829d882',
 'handoff.json':'633be8088f6c050ed3f20deac1e5c5c2c8934da60491e02acc23dc5d0a85ba3b',
 'final.patch':'93c79524fa50487a7036bf97c97a6df956ff32b9f372d585231f3540ba011f7a',
 'final-review.json':'5505981fb02fb845e4f57bc421eb0ef3fc5236f6681262fc5f6923a07d59a92d',
 'host-final/host-checks.json':'99742cd13c061993cdaf29bc5d5533f2afbb16c54c0bdc1626c25692b8d0d2e6',
 'baseline-probe/result.json':'208fd411d5e7103a3da69e963297c4e973bf9323028ae137733c9b1aa063675f',
 'candidate-probe/result.json':'2fd7b78167ac82b544094fefc5b4de64d00f2b004d1bddd341fb2023ac3716d8'}
ROOT_CHECK_SHA='a2649743cbcc74fda4f39bd836fa5d62724b4b200c9505bef97d6a0cfe7943b4'

def sha(data):return hashlib.sha256(data).hexdigest()
def read_regular(path):
 path=Path(path)
 st=path.lstat()
 if not stat.S_ISREG(st.st_mode):raise ValueError('Nonregular archive origin '+str(path))
 data=path.read_bytes();after=path.lstat()
 if (st.st_dev,st.st_ino,st.st_mode,st.st_size,st.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_mode,after.st_size,after.st_mtime_ns):raise ValueError('Origin changed '+str(path))
 return data,stat.S_IMODE(st.st_mode)
def pinned(path,wanted):
 data,_=read_regular(path)
 if sha(data)!=wanted:raise ValueError('Pin differs '+str(path))
 return json.loads(data)
def verify_record(rec,external_fingerprint=False):
 path=Path(rec.get('path',rec.get('archive_path','')))
 if external_fingerprint:path=path.resolve(strict=True)
 data,_=read_regular(path)
 assert sha(data)==rec['sha256'],str(path)
 if 'bytes'in rec:assert len(data)==rec['bytes'],str(path)
 return path

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--qa',type=Path,required=True);args=parser.parse_args()
 out=args.out.absolute();qa=args.qa.absolute()
 assert out.parent==Path('/private/tmp') and qa.parent==Path('/private/tmp') and out!=qa
 assert not out.exists() and not qa.exists()
 assert out not in ROOT.parents and ROOT not in out.parents
 documents={name:pinned(ROOT/name,wanted) if name.endswith('.json') else None for name,wanted in PINS.items()}
 for name,wanted in PINS.items():assert sha(read_regular(ROOT/name)[0])==wanted
 baseline=documents['baseline-manifest.json'];final=documents['source-manifest.json'];handoff=documents['handoff.json'];host=documents['host-final/host-checks.json'];before=documents['baseline-probe/result.json'];after=documents['candidate-probe/result.json']
 rootcheck=pinned(ROOT_CHECK,ROOT_CHECK_SHA);excluded=json.loads(read_regular(EXCLUDED)[0])
 assert isinstance(excluded,dict) and isinstance(excluded['paths'],list) and len(excluded['paths'])==16
 assert baseline['base_commit']==final['base_commit']=='411aca9ae7a5323a031973ac2b64f1b0862b3a6f'
 assert baseline['base_tree']==final['base_tree'] and len(baseline['source'])==len(final['source'])==7677
 assert set(baseline['source'])==set(final['source'])
 changed=[p for p in baseline['source']if baseline['source'][p]!=final['source'][p]]
 assert changed==['src/core/slices.c','src/core/slices.h','tests/slices_test.c']
 assert rootcheck['passed'] and rootcheck['own_imported']==final['own_overlays']
 assert rootcheck['canonical_inputs']==33 and rootcheck['SDK_inputs']==105 and rootcheck['products_exact']==2 and rootcheck['unrelated_dirty_unchanged']==16
 assert rootcheck['host_report_sha256']==PINS['host-final/host-checks.json']
 assert host['passed'] and host['modules']==['test_slices','test_sampler'] and len(host['commands'])==4 and len(host['products'])==2 and host['generated_inputs']==[]
 assert len(host['canonical_dependencies'])==33 and len(host['external_sdk_dependencies'])==105
 assert sum(len(c['dependency_commands'])for c in host['commands'])==19
 assert before['passed'] and before['run_rc']==20 and after['passed'] and after['run_rc']==0
 assert before['probe']['sha256']==after['probe']['sha256']==handoff['same_probe']['sha256']
 assert before['source_files_before']==before['source_files_after']==after['source_files_before']==after['source_files_after']==host['source_files_before']==host['source_files_after']==7677
 expected_before='marker result=0 source_changed=1\ncount result=0 source_changed=1\ncrossfade result=0 source_changed=1\nSLICES OUTPUT PROBE failures=3\n'
 expected_after='marker result=3 source_changed=0\ncount result=3 source_changed=0\ncrossfade result=3 source_changed=0\nSLICES OUTPUT PROBE failures=0\n'
 assert read_regular(ROOT/'baseline-probe/run.log')[0].decode()==expected_before
 assert read_regular(ROOT/'candidate-probe/run.log')[0].decode()==expected_after

 members={}
 def add(path,name,role):
  name=str(PurePosixPath(name));p=PurePosixPath(name)
  assert not p.is_absolute() and '..'not in p.parts and name not in members
  data,mode=read_regular(path);members[name]={'data':data,'origin':str(Path(path).absolute()),'sha256':sha(data),'bytes':len(data),'mode':mode,'role':role}
 for name in PINS:add(ROOT/name,'records/'+name,'exact original host/source control')
 add(ROOT/'README.md','records/original-README.md','original private handoff note')
 add(ROOT/'output-probe.c','records/output-probe.c','identical valid before/after probe')
 add(ROOT_CHECK,'root/import-and-source-check.json','exact root-reported import/current-source review')
 add(EXCLUDED,'root/excluded-dirty-before.json','original excluded-path metadata; root-reported current preservation is separate')
 add(Path(__file__),'tools/package_slices_output_safety.py','exact executed packet helper')
 for folder in ['host-final','baseline-probe','candidate-probe','tools']:
  for path in sorted((ROOT/folder).rglob('*')):
   if path.is_dir():continue
   name='records/'+path.relative_to(ROOT).as_posix()
   if name not in members:add(path,name,'exact original '+folder+' member')
 selected=set(host['canonical_dependencies'])|set(before['canonical_dependencies'])|set(after['canonical_dependencies'])|set(final['inherited_overlays'])|set(changed)
 selected|={'tests/test_slices.py','tests/test_sampler.py'}
 for folder,manifest in [('baseline',baseline),('source-final',final)]:
  # Full inventories are validated but only actual scoped closure/overlay bytes are archived.
  actual={p.relative_to(ROOT/folder).as_posix():sha(read_regular(p)[0])for p in sorted((ROOT/folder).rglob('*'))if p.is_file()}
  assert actual==manifest['source']
  for name in sorted(selected):
   assert name in manifest['source'];path=ROOT/folder/name;assert sha(read_regular(path)[0])==manifest['source'][name]
   add(path,'source/'+folder+'/'+name,'scoped canonical execution/overlay/module closure')
 for key,value in baseline['instruction_inputs'].items():
  data,_=read_regular(Path(key));assert sha(data)==value['sha256'] and len(data)==value['bytes']
  label='AGENTS.md'if Path(key).name=='AGENTS.md'else'PROJECT_ONBOARDING.md'
  add(Path(key),'instructions/'+label,'exact author instruction input, outside frozen source')
 external={}
 for report,source in [(host,ROOT/'source-final'),(before,ROOT/'baseline'),(after,ROOT/'source-final')]:
  for key,value in report['canonical_dependencies'].items():assert sha(read_regular(source/key)[0])==value
  for key,value in report['external_sdk_dependencies'].items():
   assert sha(Path(key).read_bytes())==value;assert key not in external or external[key]==value;external[key]=value
  for key in ['compiler','python']:verify_record(report[key],external_fingerprint=True)
  for key,value in report.get('runtime_inputs',report.get('sanitizer_runtime_inputs',{})).items():assert sha(Path(key).read_bytes())==value
  for key,value in report.get('sdk_inputs',report.get('pinned_sdk_inputs',{})).items():assert sha(Path(key).read_bytes())==value
  for rec in report.get('helpers',report.get('helper_inputs',[]))+report.get('module_inputs',[]):verify_record(rec)
  for command in report['commands']:
   assert command.get('product_returncode',command.get('returncode'))in (0,20)
   for key in ['log','output_log','produced_binary','input_binary']:
    if key in command:verify_record(command[key])
   for dep in command.get('dependency_commands',[]):assert dep['returncode']==0;verify_record(dep['output'])
  for key in ['binary','probe','probe_origin','source_manifest','log']:
   if key in report:verify_record(report[key])
  for rec in report.get('products',[]):verify_record(rec)
 assert len(external)==105
 index={'scope':'Exact original regular-file bytes/modes with deterministic archive metadata; no SDK/compiler trees archived','members':{name:{k:v for k,v in entry.items()if k!='data'}for name,entry in sorted(members.items())}}
 def make_archive():
  result=io.BytesIO()
  with gzip.GzipFile(fileobj=result,mode='wb',filename='',mtime=0,compresslevel=9)as zipped:
   with tarfile.open(fileobj=zipped,mode='w',format=tarfile.USTAR_FORMAT)as archive:
    for name,entry in sorted(members.items()):
     info=tarfile.TarInfo(name);info.size=entry['bytes'];info.mode=entry['mode'];info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     archive.addfile(info,io.BytesIO(entry['data']))
  return result.getvalue()
 payload=make_archive();assert payload==make_archive()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:
  seen=set()
  for info in archive:
   assert info.name not in seen and info.name in members and info.isfile();seen.add(info.name);entry=members[info.name]
   assert info.mode==entry['mode'] and info.uid==info.gid==info.mtime==0 and info.uname==info.gname==''
   data=archive.extractfile(info).read();assert data==entry['data'] and len(data)==entry['bytes'] and sha(data)==entry['sha256']
  assert seen==set(members)
 # Recheck captured origins and full source inventories before creating any output.
 for entry in members.values():data,mode=read_regular(Path(entry['origin']));assert data==entry['data'] and mode==entry['mode']
 for folder,manifest in [('baseline',baseline),('source-final',final)]:
  assert {p.relative_to(ROOT/folder).as_posix():sha(read_regular(p)[0])for p in sorted((ROOT/folder).rglob('*'))if p.is_file()}==manifest['source']
 provenance={'scope':'Archival integrity of original host-only slices proof; not a new test/build/native/device qualification','helper':{'path':str(Path(__file__).absolute()),'sha256':sha(read_regular(Path(__file__))[0])},'base_commit':baseline['base_commit'],'source_files_each':7677,'own_paths':changed,'inherited_pcm_paths':sorted(final['inherited_overlays']),'host_groups':host['groups'],'host_commands':4,'host_full_M_commands':19,'host_canonical_dependencies':33,'host_sdk_fingerprints':external,'host_products':2,'host_generated_inputs':0,'baseline_probe_rc':20,'candidate_probe_rc':0,'root_receipt_sha256':ROOT_CHECK_SHA,'root_preserved_dirty_paths':16,'root_preservation_attribution':'Copied root import receipt; this packet makes no fresh current-checkout comparison','members':len(members),'original_member_bytes':sum(e['bytes']for e in members.values()),'payload':{'sha256':sha(payload),'bytes':len(payload)},'source_reproduction':'Reconstruct committed411aca9, apply the three archived inherited PCM overlays, then candidate slices3; verify full original inventories. Historical commands retain original private paths and must be rebased explicitly for reproduction.','native':'NOT RUN in slices host lane; any later cache build is outside this packet','physical':'NOT RUN in slices host lane'}
 readme='''This packet preserves the narrow public slice/crossfade output fix and its original host proof. It owns src/core/slices.c, src/core/slices.h and tests/slices_test.c. The frozen baseline was committed411aca9 plus exactly three inherited reviewed PCM overlays; both complete 7,677-file inventories are preserved in payload.tar.gz. Only scoped execution closures and overlays are copied, rather than the original84MB export or SDK/compiler trees.

The identical valid three-case probe is preserved with its baseline RC20 (three OK0/source_changed1 corruptions) and candidate RC0 (three ALIAS3/source_changed0 refusals). Earlier validation/geometry/capacity/NULL-output precedence and actual emitted marker extent remain; spare source PCM is protected without becoming audio. Crossfade aliases are refused before the destructive tail edit.

Two original ASan/UBSan groups, slices and its direct sampler caller, passed. The original four compile/runtime commands,19 full-M closures,33 canonical inputs,105 SDK fingerprints,two executable products and all logs/helpers are preserved. No generated fixture is claimed. A copied root receipt records current imported-source/product equality and16 unrelated dirty paths preserved; its original excluded metadata is copied separately. These are root-reported facts, not a new packet-time checkout audit.

member-index.json binds every regular archive member to original path, bytes, SHA256 and mode. Archive ownership/time are fixed for deterministic reconstruction; a second archive write and tar-reader verification checked all member bytes. External compiler/runtime/header pins remain in the original reports and provenance but their trees are not copied.

Original scripts and commands retain their original private paths. Reproduction starts from the recorded Git commit plus archived PCM overlays and slices overlays, verifies the full inventories, and explicitly rebinds paths; this packet is not an unchanged-path turnkey rerun. Packaging ran no tests, builds, emulator, physical target, locks or browser operations. Later combined cache builds and any target qualification are outside these claims.
'''
 contents={'payload.tar.gz':payload,'member-index.json':(json.dumps(index,indent=2,sort_keys=True)+'\n').encode(),'packet-provenance.json':(json.dumps(provenance,indent=2,sort_keys=True)+'\n').encode(),'README.md':readme.encode()}
 contents['SHA256SUMS']=''.join(sha(data)+'  '+name+'\n'for name,data in sorted(contents.items())).encode()
 out.mkdir()
 for name,data in contents.items():
  with (out/name).open('xb')as f:f.write(data)
 assert {p.name for p in out.iterdir()}==set(contents)
 for name,data in contents.items():assert read_regular(out/name)[0]==data
 rows=(out/'SHA256SUMS').read_text().splitlines();assert len(rows)==4 and len(set(row.split('  ',1)[1]for row in rows))==4
 for row in rows:digest,name=row.split('  ',1);assert sha(read_regular(out/name)[0])==digest
 qa_record={'scope':'Private packet integrity only; no product/runtime qualification','passed':True,'output':str(out),'files':len(contents),'bytes':sum(len(x)for x in contents.values()),'members':len(members),'original_member_bytes':sum(e['bytes']for e in members.values()),'deterministic_second_write_equal':True,'all_original_member_bytes_modes_preserved':True,'full_source_before_after_equal':True,'payload':provenance['payload'],'controls':{name:{'sha256':sha(data),'bytes':len(data)}for name,data in contents.items()}}
 with qa.open('x')as f:f.write(json.dumps(qa_record,indent=2,sort_keys=True)+'\n')
 print(json.dumps(qa_record))
if __name__=='__main__':main()
