from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
import unittest

WORK = Path(__file__).resolve().parent
SOURCE = WORK / 'source-final'
MANIFEST = WORK / 'source-final-manifest.json'
GROUPS = ['test_studio_song.py', 'test_studio_mix.py', 'test_studio_plan.py']
record = {'scope': 'host ASan/UBSan only; no cross-build/target/hardware acceptance',
          'source': str(SOURCE), 'source_manifest': str(MANIFEST),
          'source_manifest_sha256': hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
          'commands': [], 'groups': [], 'dependencies': {}}
expected = json.loads(MANIFEST.read_text())['source']

def verify_source():
    actual = {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in SOURCE.rglob('*') if p.is_file()}
    assert actual == expected
    return len(actual)

record['source_files_before'] = verify_source()
real_run = subprocess.run
compiler = Path(shutil.which('cc')).resolve()
version = real_run([str(compiler), '--version'], capture_output=True, text=True, check=True)
record['compiler'] = {'path': str(compiler), 'sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
                      'version': version.stdout}
os.chdir(SOURCE)
sys.path.insert(0, str(SOURCE / 'tests'))

with (WORK / 'core-host.log').open('w') as log:
    def logged_run(argv, **kwargs):
        args = [str(arg) for arg in argv]
        cwd = str(kwargs.get('cwd', Path.cwd()))
        check = kwargs.pop('check', False)
        start = time.monotonic()
        result = real_run(args, **kwargs, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        item = {'argv': args, 'directory': cwd, 'returncode': result.returncode,
                'seconds': time.monotonic() - start}
        log.write(result.stdout + result.stderr)
        log.flush()
        if '-o' in args and result.returncode == 0:
            binary = Path(args[args.index('-o') + 1])
            item['output'] = str(binary)
            item['binary_bytes'] = binary.stat().st_size
            item['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
            dep_args = [args[0], '-MM'] + args[1:args.index('-o')]
            deps = real_run(dep_args, cwd=cwd, capture_output=True, text=True, check=True)
            item['dependency_argv'] = dep_args
            for line in deps.stdout.replace('\\\n', '').splitlines():
                if ':' not in line:
                    continue
                for name in shlex.split(line.split(':', 1)[1]):
                    path = (Path(cwd) / name).resolve()
                    record['dependencies'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        elif len(args) == 1 and Path(args[0]).is_file():
            item['binary_sha256'] = hashlib.sha256(Path(args[0]).read_bytes()).hexdigest()
        record['commands'].append(item)
        if check and result.returncode:
            raise subprocess.CalledProcessError(result.returncode, args, result.stdout, result.stderr)
        return result

    subprocess.run = logged_run
    success = True
    for name in GROUPS:
        start = time.monotonic()
        suite = unittest.defaultTestLoader.discover(str(SOURCE / 'tests'), pattern=name)
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
        entry = {'module': name, 'tests': result.testsRun, 'passed': result.wasSuccessful(),
                 'seconds': time.monotonic() - start}
        record['groups'].append(entry)
        success &= result.wasSuccessful()
        log.flush()
    subprocess.run = real_run
record['source_files_after'] = verify_source()
record['passed'] = success
record['log_sha256'] = hashlib.sha256((WORK / 'core-host.log').read_bytes()).hexdigest()
(WORK / 'core-host.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'passed': success, 'groups': record['groups'], 'commands': len(record['commands']),
                  'dependencies': len(record['dependencies']), 'files': record['source_files_after']}))
sys.exit(0 if success else 1)
