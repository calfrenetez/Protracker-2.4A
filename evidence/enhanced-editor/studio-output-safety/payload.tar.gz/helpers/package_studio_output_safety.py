#!/usr/bin/env python3
"""Package completed, authorized Studio output-safety evidence privately.

This tool has no compiler, test, target, Git, browser, network or lock operations.
Run only after root supplies completed outputs and authorizes private packaging.
Qualification is optional; original top/nested results remain independent copies.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import time


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_bytes())


def record(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": digest(raw)}


def require_regular(path: Path) -> None:
    if path.is_symlink() or not path.is_file():
        raise ValueError("Expected nonsymlink regular file: " + str(path))


def require_identity(path: Path, expected: dict) -> None:
    require_regular(path)
    raw = path.read_bytes()
    if len(raw) != expected["bytes"] or digest(raw) != expected["sha256"]:
        raise ValueError("Recorded file identity changed: " + str(path))


def require_source(root: Path, source: dict) -> None:
    expected = source["files"]
    actual = {}
    for p in sorted((root / "source").rglob("*")):
        if p.is_symlink():
            raise ValueError("Symlink in immutable export: " + str(p))
        if p.is_file():
            actual[str(p.relative_to(root / "source"))] = record(p)
    if set(actual) != set(expected):
        raise ValueError("Immutable export path inventory changed")
    for name, fingerprint in expected.items():
        if any(actual[name][k] != fingerprint[k] for k in ("bytes", "sha256")):
            raise ValueError("Immutable export bytes changed: " + name)


def verify_embedded_artifact_records(value, roots: tuple[Path, ...]) -> None:
    """Verify output archive/log identities without following arbitrary input refs."""
    if isinstance(value, dict):
        if all(k in value for k in ("path", "bytes", "sha256")):
            p = Path(value["path"])
            if p.is_absolute() and any(p.is_relative_to(r) for r in roots):
                require_identity(p, value)
        if all(k in value for k in ("archive_path", "bytes", "sha256")):
            p = Path(value["archive_path"])
            if not p.is_absolute() or not any(p.is_relative_to(r) for r in roots):
                raise ValueError("Unexpected archived artifact location: " + str(p))
            require_identity(p, value)
        for child in value.values():
            verify_embedded_artifact_records(child, roots)
    elif isinstance(value, list):
        for child in value:
            verify_embedded_artifact_records(child, roots)


class Package:
    def __init__(self, out: Path):
        self.out = out
        self.rows: dict[str, dict] = {}
        self.derivations = []

    def destination(self, relative: str) -> Path:
        p = Path(relative)
        if p.is_absolute() or ".." in p.parts or not p.parts:
            raise ValueError("Invalid package relative path: " + relative)
        return self.out / p

    def copy(self, source: Path, relative: str, scope: str, compressed=False):
        require_regular(source)
        original = source.read_bytes()
        raw = gzip.compress(original, compresslevel=9, mtime=0) if compressed else original
        if compressed:
            relative += ".gz"
            if gzip.decompress(raw) != original:
                raise ValueError("Gzip exact-byte derivation failed")
        if relative in self.rows:
            raise ValueError("Duplicate package destination: " + relative)
        target = self.destination(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        if target.read_bytes() != raw or source.read_bytes() != original:
            raise ValueError("Copy/source changed while packaging: " + str(source))
        target.chmod(0o644)
        row = {"path": relative, "bytes": len(raw), "sha256": digest(raw),
               "kind": "gzip_exact_byte_derivation" if compressed else "exact_byte_copy",
               "scope": scope, "origin": {"path": str(source), "bytes": len(original), "sha256": digest(original)}}
        self.rows[relative] = row
        if compressed:
            self.derivations.append({"path": relative,
                "derivation": "gzip level9 with mtime0; uncompressed original bytes are unchanged, including all JSON fields/order/whitespace",
                "original": row["origin"], "compressed": {k: row[k] for k in ("bytes", "sha256")}})
        return row

    def tree(self, source: Path, relative: str, scope: str, skip=(), compressed_names=()):
        if source.is_symlink() or not source.is_dir():
            raise ValueError("Expected nonsymlink directory: " + str(source))
        for p in sorted(source.rglob("*")):
            if p.is_symlink():
                raise ValueError("Symlink in evidence outputs: " + str(p))
            if not p.is_file():
                continue
            name = str(p.relative_to(source))
            if name in skip:
                continue
            self.copy(p, relative + "/" + name, scope,
                      compressed=name in compressed_names or (p.suffix == ".json" and p.stat().st_size >= 1_000_000))

    def author(self, relative: str, value, scope: str):
        if relative in self.rows:
            raise ValueError("Duplicate authored destination: " + relative)
        raw = (json.dumps(value, indent=2) + "\n").encode() if not isinstance(value, str) else value.encode()
        target = self.destination(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        self.rows[relative] = {"path": relative, "bytes": len(raw), "sha256": digest(raw),
                               "kind": "authored_package_metadata", "scope": scope}

    def verify(self):
        for row in self.rows.values():
            p = self.destination(row["path"])
            require_identity(p, row)
            if "origin" not in row:
                continue
            origin = row["origin"]
            require_identity(Path(origin["path"]), origin)
            copied = p.read_bytes()
            raw = gzip.decompress(copied) if row["kind"] == "gzip_exact_byte_derivation" else copied
            if len(raw) != origin["bytes"] or digest(raw) != origin["sha256"]:
                raise ValueError("Packaged original byte identity failed: " + row["path"])


def extra_argument(value: str):
    if "=" not in value:
        raise argparse.ArgumentTypeError("Use RELATIVE=ABSOLUTE_FILE")
    relative, absolute = value.split("=", 1)
    if not relative or not Path(absolute).is_absolute():
        raise argparse.ArgumentTypeError("Use RELATIVE=ABSOLUTE_FILE")
    return relative, Path(absolute)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True, help="Completed combined source/host-final/native-final parent")
    p.add_argument("--source-manifest-sha256", required=True)
    p.add_argument("--tools", type=Path, required=True)
    p.add_argument("--before", type=Path, required=True, help="Original independent expected-failure probe directory")
    p.add_argument("--core-development", type=Path, required=True)
    p.add_argument("--integration-development", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True, help="New private output directory under /private/tmp")
    p.add_argument("--prelaunch", type=Path, action="append", default=[], help="Original separately scoped HOST PRELAUNCH NOT RUN record directory/file; retained without merging into later qualification")
    p.add_argument("--qualification", type=Path, help="Completed original top qualification JSON; optional, failure retained literally")
    p.add_argument("--qualification-helper", type=Path, help="Root-supplied historical orchestration helper bytes; attribution remains in original records/root report")
    p.add_argument("--coordination-record", type=Path, help="Optional explicit root-reported ownership/release record, copied without invented ACK")
    p.add_argument("--qualification-file", type=extra_argument, action="append", default=[], help="Explicit supplementary RELATIVE=ABSOLUTE_FILE under native-qualification/extra/")
    return p


def main():
    args = parser().parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    if not args.out.is_absolute() or not out.is_relative_to(Path("/private/tmp")) or out.exists():
        raise ValueError("Output must be a NEW absolute private directory under /private/tmp")
    for origin in (root, args.tools.resolve(), args.before.resolve(), args.core_development.resolve(), args.integration_development.resolve()):
        if out.is_relative_to(origin) or origin.is_relative_to(out):
            raise ValueError("Output and origin directories must be separate")
    sm = root / "source-manifest.json"
    if digest(sm.read_bytes()) != args.source_manifest_sha256:
        raise ValueError("Wrong combined source manifest")
    source = read_json(sm)
    require_source(root, source)
    host_path, native_path = root / "host-final/host-checks.json", root / "native-final/manifest.json"
    host, native = read_json(host_path), read_json(native_path)
    if host.get("passed") is not True or native.get("passed") is not True:
        raise ValueError("Completed PASS host/build outputs must be supplied by root; failed native qualification is separately retainable")
    if len(host.get("groups", [])) != 10 or len(native.get("targets", {})) != 5:
        raise ValueError("Unexpected final host/native-build scopes")
    if not all(g.get("passed") is True for g in host["groups"]):
        raise ValueError("Host group did not pass")
    for proof in (host, native):
        if proof.get("source_files_before") != len(source["files"]) or proof.get("source_files_after") != len(source["files"]):
            raise ValueError("Final before/after source inventory mismatch")
        require_identity(sm, proof["source_manifest"])
        for helper in proof["helper_inputs"]:
            require_identity(Path(helper["path"]), helper)
    verify_embedded_artifact_records(host, (root / "host-final",))
    verify_embedded_artifact_records(native, (root / "native-final",))
    for target, values in native["targets"].items():
        require_identity(root / "native-final" / target,
                         {"bytes": values["binary_bytes"], "sha256": values["binary_sha256"]})
    before, after = read_json(args.before / "result.json"), read_json(root / "baseline-after/result.json")
    if before["probe_sha256"] != after["probe_sha256"]:
        raise ValueError("Independent regression before/after did not use the same probe bytes")
    require_identity(args.before / "probe.c", {"bytes": (args.before / "probe.c").stat().st_size, "sha256": before["probe_sha256"]})
    after_probe = root / "baseline-after/probe.c"
    if after_probe.exists() and after_probe.read_bytes() != (args.before / "probe.c").read_bytes():
        raise ValueError("After regression probe source differs from before source")
    for directory, result in ((args.before, before), (root / "baseline-after", after)):
        require_identity(directory / "probe", {"bytes": (directory / "probe").stat().st_size, "sha256": result["binary_sha256"]})
    for origin in args.prelaunch:
        if origin.is_symlink() or not origin.exists():
            raise ValueError("Missing/symlink prelaunch history: " + str(origin))
        if origin.is_dir():
            p = origin.resolve()
            if p in (root, root / "source", Path("/private/tmp")) or out.is_relative_to(p) or p.is_relative_to(out):
                raise ValueError("Prelaunch and package directories must be separately scoped")
    qualification = None
    if args.qualification:
        require_regular(args.qualification)
        qualification = read_json(args.qualification)
        qroot = args.qualification.parent.resolve()
        if qroot in (root, root / "source", Path("/private/tmp")) or qroot == qroot.parent:
            raise ValueError("Qualification must have a separately scoped record parent directory")
        # Existing runner schema: cases[].run names nested record directories.
        # Never follow arbitrary absolute strings/source/SDK/guest paths.
        for case in qualification.get("cases", []):
            run = case.get("run")
            if run:
                path = Path(run).resolve()
                if not path.is_dir() or not path.is_relative_to(qroot):
                    raise ValueError("Nested run outside scoped qualification parent; supply separately through --qualification-file: " + run)
        if out.is_relative_to(qroot) or qroot.is_relative_to(out):
            raise ValueError("Qualification and package directories must be separate")
    elif args.qualification_helper or args.coordination_record or args.qualification_file:
        raise ValueError("Qualification helper/coordination/extras require the original top --qualification result")

    out.mkdir()
    package = Package(out)
    package.copy(sm, "source/source-manifest.json", "Exact combined source inventory; every original field retained", compressed=True)
    package.copy(root / "owned-files.json", "source/owned-files.json", "Authorized22-overlay inventory")
    package.copy(root / "excluded-dirty-before.json", "source/excluded-dirty-before.json", "Unrelated dirty-version preservation snapshot, excluded from candidate")
    dirty_after = root / "excluded-dirty-after.json"
    if dirty_after.exists():
        package.copy(dirty_after, "source/excluded-dirty-after.json", "Root-provided later dirty-version preservation snapshot; no live repository read by packager")
    package.tree(root / "host-final", "host", "Exact final host ASan/UBSan evidence; generated source/object definitions retained", compressed_names=("host-checks.json",))
    package.tree(root / "native-final", "native-build", "Exact five pinned Exec cross-builds; no native execution inferred", compressed_names=("manifest.json",))
    package.tree(args.tools, "helpers/provenance", "Exact reviewed provenance helper/pin bytes")
    package.copy(Path(__file__).resolve(), "helpers/package_studio_output_safety.py", "Exact private packager bytes; no target/test/build operations")
    package.tree(args.before, "regression/before", "Original independent expected before-fix regression failure", skip=tuple(str(p.relative_to(args.before)) for p in args.before.rglob("*") if "core-candidate-after" in p.parts))
    package.tree(root / "baseline-after", "regression/after", "Same independent probe against exact combined candidate")
    if not after_probe.exists():
        package.copy(args.before / "probe.c", "regression/after/probe.c", "Byte-identical shared independent reproducer source")
    for name in ("baseline.json", "summary.json", "core.patch", "core-host.json", "core-host.log", "run_core_host.py", "run_core_host_v2.py", "source-manifest.json", "source-final-manifest.json", "source-final-v2-manifest.json"):
        p = args.core_development / name
        if p.exists():
            package.copy(p, "development/core/" + name, "Core draft/development records; distinct from final combined acceptance", compressed=p.suffix == ".json" and "manifest" in name)
    for name in ("host-checks-first", "baseline"):
        p = args.core_development / name
        if p.exists():
            package.tree(p, "development/core/" + name, "Original core development/first-run and baseline bytes")
    for name in ("integration-manifest.json", "integration.patch", "development-validation.json", "development-tests.log", "development-tests-2.log", "development-tests-3.log", "development-tests-final.log", "development-publication-final.log", "lane.json"):
        p = args.integration_development / name
        if p.exists():
            package.copy(p, "development/integration/" + name, "Integration successive-draft failures and focused passes; not exact final acceptance", compressed=name == "integration-manifest.json")
    for index, origin in enumerate(args.prelaunch):
        label = f"{index + 1:02d}-" + origin.name
        if origin.is_dir():
            if origin.is_symlink() or origin.resolve() in (root, root / "source", Path("/private/tmp")):
                raise ValueError("Prelaunch history must use a separately scoped directory")
            package.tree(origin, "host-prelaunch-not-run/" + label,
                         "Original host prelaunch failure/NOT RUN history; never native execution or later PASS")
        else:
            package.copy(origin, "host-prelaunch-not-run/" + label,
                         "Original host prelaunch failure/NOT RUN history; never native execution or later PASS")
    if args.qualification:
        package.copy(args.qualification, "native-qualification/qualification-result.json", "Original top qualification result; no nested result substituted and no claims inferred")
        package.tree(args.qualification.parent, "native-qualification/records", "Original separately scoped nested runner, identity, cleanup and independent observation records", skip=(args.qualification.name,))
        if args.qualification_helper:
            package.copy(args.qualification_helper, "native-qualification/historical-orchestration.py", "Root-supplied helper byte copy; execution attribution only as original records/root report state")
        if args.coordination_record:
            package.copy(args.coordination_record, "native-qualification/root-reported-coordination.json", "Explicit root-reported coordination; not independently live verified by packaging")
        for relative, path in args.qualification_file:
            package.copy(path, "native-qualification/extra/" + relative, "Explicit root-supplied supplementary qualification record")
    package.author("DERIVATIONS.json", {"scope": "Exact-byte gzip derivations, never summaries or reformatted source/build manifests", "items": package.derivations}, "Compression derivation metadata")
    summary = {"schema": "protracker-studio-output-safety-evidence-summary-v1",
        "source_manifest": record(sm), "base_commit": source["base_commit"], "base_tree": source["base_tree"],
        "source_files": len(source["files"]), "overlays": len(source["overlays"]), "excluded_dirty_versions": len(source["excluded_dirty"]),
        "host_original_result": {"passed": host["passed"], "groups": len(host["groups"]), "elapsed_s": host["elapsed_s"]},
        "native_build_original_result": {"passed": native["passed"], "targets": list(native["targets"]), "elapsed_s": native["elapsed_s"]},
        "regression_before_runtime_returncode": before["runtime_returncode"], "regression_after_runtime_returncode": after["runtime_returncode"],
        "host_prelaunch_history_records": [str(p) for p in args.prelaunch],
        "qualification_supplied": bool(args.qualification), "qualification_original_top_passed_value": qualification.get("passed") if qualification is not None else None,
        "coordination_record_supplied": bool(args.coordination_record),
        "scope": "Host sanitizer and cross-build evidence; later supplied native records retain original exact scope/status. No physical hardware, audio, timing or human listening acceptance inferred."}
    package.author("package-summary.json", summary, "Labelled metadata derived from copied original records; not independent acceptance")
    package.author("README.md", """# Studio output preservation evidence

This package preserves exact final host sanitizer and five Exec cross-build records for the Studio source/output alias fix. Source inventory,22 authorized overlays, compiler/runtime identities, ordered command/definition records, generated C/object inputs and before/after snapshots remain in the original manifests. Every `.json.gz` decompresses to its original bytes; `DERIVATIONS.json` records the uncompressed byte hash and size. No manifest field was removed, renamed, deduplicated or reformatted.

`regression/before/` preserves the independent expected before-fix failure; `regression/after/` uses the identical probe source against the combined candidate. `development/core/` and `development/integration/` retain draft history and failures separately. These older records are not the final candidate's acceptance evidence. `source/` retains dirty-version exclusion/preservation records without copying dirty source into the candidate.

`host-prelaunch-not-run/` preserves separately supplied host prelaunch failures where no guest was staged or run. A later successful qualification never rewrites those original NOT RUN records. Any root-reported release after a prelaunch failure is coordination evidence, not guest cleanup or native acceptance.

When supplied, `native-qualification/qualification-result.json` is the exact original top result. Its nested runner/cleanup/identity/independent records are separate under `native-qualification/records/`. Packaging does not run targets, confirm cleanup live or invent a release ACK. Any historical-helper execution attribution or coordination statement comes only from its original records or an explicit root-reported record. If that directory is absent, no native qualification was supplied.

Host/build, native fixture execution, physical hardware, device/audio, timing and human listening remain separate acceptance scopes. No physical, audio, timing or listening approval is implied. Original absolute paths are retained intentionally; provenance rows map each copied origin to its package path. `SHA256SUMS` covers every package file except itself, including the unique provenance control manifest. No product sources or tracked evidence were edited by this private packager.
""", "Authored package guide and evidence-scope boundaries")
    require_source(root, source)
    package.verify()
    provenance_name = "provenance-" + str(time.time_ns()) + ".json"
    provenance = {"schema": "protracker-private-exact-evidence-package-v1", "package_scope": summary["scope"],
        "package_directory": str(out), "source_manifest": record(sm), "items": list(package.rows.values()),
        "control_file_exclusions_from_items": [provenance_name, "SHA256SUMS"],
        "verification": "Every copied origin and destination identity checked; gzip decompression checked against original; immutable combined source inventory checked before/after packaging"}
    (out / provenance_name).write_text(json.dumps(provenance, indent=2) + "\n")
    lines = []
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS":
            lines.append(digest(p.read_bytes()) + "  " + str(p.relative_to(out)))
    (out / "SHA256SUMS").write_text("\n".join(lines) + "\n")
    package.verify()
    for line in lines:
        sha, relative = line.split("  ", 1)
        if digest((out / relative).read_bytes()) != sha:
            raise ValueError("Final checksum mismatch: " + relative)
    files = [p for p in out.rglob("*") if p.is_file()]
    print(json.dumps({"package": str(out), "files": len(files), "bytes": sum(p.stat().st_size for p in files),
        "provenance": record(out / provenance_name), "exact_copies": sum(r["kind"] == "exact_byte_copy" for r in package.rows.values()),
        "gzip_derivations": len(package.derivations), "qualification_supplied": bool(args.qualification)}))


if __name__ == "__main__":
    main()
