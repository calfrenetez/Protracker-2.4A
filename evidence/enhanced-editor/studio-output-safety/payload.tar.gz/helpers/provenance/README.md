# Studio output-safety provenance tools

Preparation-only tools. No helper, test, compiler or target was executed while preparing this directory. Run only against the final immutable source and manifest explicitly supplied by the parent task.

Use the pinned Python executable `/opt/homebrew/opt/python@3.14/bin/python3.14`. Both entry points accept the same arguments:

```
--source ABSOLUTE_IMMUTABLE_SOURCE
--source-manifest ABSOLUTE_SOURCE_MANIFEST
--source-manifest-sha256 EXPECTED_MANIFEST_SHA256
--out NEW_EMPTY_PRIVATE_OUTPUT_DIRECTORY
--pins /private/tmp/protracker-studio-alias-tools-fu6u4spm/toolchain-pins.json
--pins-sha256 ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065
```

`host_provenance.py` runs exactly the ten requested host ASan/UBSan groups, including the separate EFx preparation fixture. It records original and executed compiler/runtime commands, per-unit dependency commands with their exact defines, canonical dependency hashes, any SDK dependencies, copied generated C/object inputs and copied test binaries. Temporary generated inputs are copied and byte-verified before their fixture directory is deleted. Complete source inventory and pinned inputs are checked before and after execution. Product errors and provenance errors are separate fields in `host-checks.json`.

`native_build.py` cross-builds exactly the five requested Exec fixtures. It does not run any binary or target operation. It takes ordered translation units and flag declarations from the pinned committed build recipe, compares the existing Python declarations, and records full canonical/SDK header closures, preprocessing and build logs, all seven CRT runtime pins, HUNK headers, binary bytes and SHA256. Included C fixtures are dependencies of their wrapper translation units, never duplicated as separate compilation inputs. `compile-commands.json` records the five ordered link commands; `manifest.json` also records compiler queries, dependency extraction and preprocessing commands.

Pins were recovered from the successful prior host/native evidence under `/private/tmp/protracker-efx-integration-final-u7z20nyz` and the immutable committed recipe under `/private/tmp/protracker-studio-alias-base-dbeb0uu_/source`. The current Python executable and version were captured when preparing the pins. Each helper verifies these identities when later authorized to run.

Host checks, cross-builds, native emulator execution, physical hardware, timing and human listening remain separate acceptance scopes. The tools contain no target, lock, browser, device or Git operations.
