#include "project.h"
unsigned pt_test_project_validations,pt_test_pcm_validations;
enum pt_pcm_result pt_pcm_validate_actual(const struct pt_pcm *);
enum pt_pcm_result pt_pcm_validate(const struct pt_pcm *p)
{++pt_test_pcm_validations;return pt_pcm_validate_actual(p);}
enum pt_project_result pt_project_validate_actual(const struct pt_project *,uint32_t *);
enum pt_project_result pt_project_validate(const struct pt_project *p,uint32_t *n)
{++pt_test_project_validations;return pt_project_validate_actual(p,n);}