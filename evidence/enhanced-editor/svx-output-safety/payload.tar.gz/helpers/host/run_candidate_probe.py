#!/usr/bin/env python3
"""Compare unchanged baseline probe bytes with frozen SVX output guards."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from provenance_common import assert_pinned, classify, digest, file_record, parse_dependencies, require_snapshot, write_json

sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[1]
source=root/'source-final';manifest=root/'source-manifest.json';out=root/'candidate-probe'
assert_pinned(manifest,'4e410e63eb25a853efcf091f37873e2b3f1e4f21c8af0f4d63e84bb0af42c22c')
pinfile=root/'tools/toolchain-pins.json'
assert_pinned(pinfile,'ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065')
pins=json.loads(pinfile.read_text())['host'];expected=json.loads(manifest.read_text())['source']
require_snapshot(source,expected)
assert_pinned(pins['python']['path'],pins['python']['sha256'])
assert Path(sys.executable).resolve()==Path(pins['python']['path']).resolve() and sys.version==pins['python']['version']
cc=pins['compiler'];assert_pinned(cc['path'],cc['sha256'])
for name,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(name,sha)
out.mkdir();probe=out/'probe.c';original=root/'baseline-probe.c'
assert_pinned(original,'1623c8d576cb9888e9f83fd8de5f030ec5404d422e4e60a59d66af27ba7988a8')
shutil.copyfile(original,probe);assert digest(probe)==digest(original)
flags=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core']
units=[str(probe),'src/core/svx.c','src/core/pcm.c']
record={'scope':'Host ASan/UBSan same baseline preservation probe: expected RC0 and original mono8 masters retained through ALIAS; no native/target operation',
        'source_manifest':file_record(manifest),'source_files_before':len(expected),'compiler':cc,
        'runtime_inputs':pins['runtime_inputs'],'helper':file_record(__file__),
        'probe':file_record(probe),'commands':[],'canonical_dependencies':{},'external_sdk_dependencies':{},'passed':False}
def run(argv,label):
    result=subprocess.run(argv,cwd=source,capture_output=True,text=True,timeout=180)
    log=out/(label+'.log');log.write_text(result.stdout+result.stderr)
    record['commands'].append({'argv':argv,'directory':str(source),'returncode':result.returncode,'log':file_record(log)})
    return result
try:
    version=run([cc['path'],'--version'],'compiler-version');assert version.returncode==0 and version.stdout==cc['version']
    for i,unit in enumerate(units):
        dep=run([cc['path'],*flags,'-MM',unit],'dependencies-%02d'%i);assert dep.returncode==0
        for name in parse_dependencies(dep.stdout):
            path=(source/name).resolve()
            if path==probe:continue
            category,key=classify(path,source,expected,pins['allowed_sdk_roots'])
            record['canonical_dependencies' if category=='canonical' else 'external_sdk_dependencies'][key]=digest(path)
    result=run([cc['path'],*flags,*units,'-o',str(out/'probe')],'compile');assert result.returncode==0
    record['binary']=file_record(out/'probe')
    result=run([str(out/'probe')],'run')
    record['passed']=result.returncode==0 and result.stderr=='' and 'SVX SIZE PROBE result=5 before=-128 after=-128' in result.stdout and 'SVX WRITTEN PROBE result=5 before=-128 after=-128' in result.stdout
except Exception as failure:
    record['harness_error']={'kind':type(failure).__name__,'message':str(failure)}
    raise
finally:
    for path,sha in record['external_sdk_dependencies'].items():assert_pinned(path,sha)
    require_snapshot(source,expected);record['source_files_after']=len(expected)
    assert_pinned(cc['path'],cc['sha256'])
    for name,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(name,sha)
    assert_pinned(manifest,record['source_manifest']['sha256']);assert_pinned(__file__,record['helper']['sha256'])
    write_json(out/'result.json',record)
print(json.dumps({'passed':record['passed'],'report':str(out/'result.json')}))
sys.exit(0 if record['passed'] else 1)
