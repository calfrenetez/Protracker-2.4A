#include <stdio.h>
#include <string.h>
#include "svx.h"
static union {size_t scalar;int32_t values[32];} master;
static unsigned char encoded[256], before_encoded[256];
static void reset(void)
{unsigned i;memset(&master,0,sizeof(master));for(i=0;i<5;++i)master.values[i]=(int32_t)i-128;memset(encoded,0x55,sizeof(encoded));memcpy(before_encoded,encoded,sizeof(encoded));}
int main(void)
{
    struct pt_pcm pcm={master.values,32,5,8287,1,8};struct pt_svx_info info={0};
    int size_preserved,written_preserved;enum pt_svx_result size_result,written_result;int32_t first;
    reset();first=master.values[0];size_result=pt_svx_size(&pcm,&info,&master.scalar);
    size_preserved=size_result==PT_SVX_ALIAS && master.values[0]==first;
    printf("SVX SIZE PROBE result=%d before=%ld after=%ld\n",size_result,(long)first,(long)master.values[0]);
    reset();first=master.values[0];written_result=pt_svx_encode(&pcm,&info,encoded,sizeof(encoded),&master.scalar);
    written_preserved=written_result==PT_SVX_ALIAS && master.values[0]==first && !memcmp(encoded,before_encoded,sizeof(encoded));
    printf("SVX WRITTEN PROBE result=%d before=%ld after=%ld\n",written_result,(long)first,(long)master.values[0]);
    return size_preserved && written_preserved?0:20;
}
