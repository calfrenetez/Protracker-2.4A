#!/usr/bin/env python3
"""Freeze only reviewed WAV overlays over the already reviewed inherited RAW baseline."""
import difflib,json,shutil,sys
from pathlib import Path
from provenance_common import assert_pinned,digest,file_record,require_snapshot,snapshot,write_json
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[1]
manifest=root/'baseline-manifest.json'
assert_pinned(manifest,'b0bfdc75aae343a8cff064ab9d1c251e6d5349cd29985dd8259888859393f1f4')
base=json.loads(manifest.read_text()); before=base['source']; require_snapshot(root/'baseline',before)
owned=['src/core/wav.c','src/core/wav.h','tests/pcm_test.c'];current=snapshot(root/'candidate')
assert set(current)==set(before) and {p for p in current if current[p]!=before[p]}==set(owned)
patch=''
for rel in owned:
 patch+='diff --git a/'+rel+' b/'+rel+'\n'
 patch+=''.join(difflib.unified_diff((root/'baseline'/rel).read_text().splitlines(True),(root/'candidate'/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(root/'final.patch').write_text(patch)
final=root/'source-final';shutil.copytree(root/'candidate',final);require_snapshot(final,current)
for path in final.rglob('*'):path.chmod(0o555 if path.is_dir() else 0o444)
final.chmod(0o555)
own={rel:current[rel] for rel in owned};overlays={**base['prior_overlays'],**own}
write_json(root/'source-manifest.json',{'scope':'Immutable inherited project4/SVX6/RAW3 plus reviewed WAV3; no dirty checkout inputs',
 'base_commit':base['base_commit'],'base_tree':base['base_tree'],'baseline_manifest':file_record(manifest),
 'prior_overlays':base['prior_overlays'],'wav_overlays':own,'overlays':overlays,'source':current})
source_manifest_sha=digest(root/'source-manifest.json')
s=(root/'tools/run_baseline_probe.py').read_text().replace('Preserve valid WAV baseline master/output corruption observations.','Qualify identical WAV probe refusal with preserved master and encoded output images.')
s=s.replace("source=root/'baseline';manifest=root/'baseline-manifest.json';out=root/'baseline-probe'", "source=root/'source-final';manifest=root/'source-manifest.json';out=root/'candidate-probe'")
s=s.replace(digest(manifest),source_manifest_sha).replace('expected RC20 and two24bit master corruptions through size/written','RC0 and two 24-bit master preservations through size/written')
s=s.replace("result.returncode==20 and result.stderr=='' and 'WAV SIZE PROBE result=0 before=257 after=56' in result.stdout and 'WAV WRITTEN PROBE result=0 before=257 after=56' in result.stdout", "result.returncode==0 and result.stderr=='' and 'WAV SIZE PROBE result=5 before=257 after=257' in result.stdout and 'WAV WRITTEN PROBE result=5 before=257 after=257' in result.stdout")
(root/'tools/run_candidate_probe.py').write_text(s)
files=['host_provenance.py','provenance_common.py','toolchain-pins.json','run_baseline_probe.py','run_candidate_probe.py','freeze_source.py']
write_json(root/'tools/prepared-files.json',{'scope':'Reviewed narrow WAV host/probe helpers only; no native/target operation', 'inputs':{name:file_record(root/'tools'/name) for name in files}})
print(json.dumps({'manifest':file_record(root/'source-manifest.json'),'patch':file_record(root/'final.patch'),'overlays':own,'source_count':len(current)}))
