#!/usr/bin/env python3
"""Preserve valid WAV baseline master/output corruption observations."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from provenance_common import assert_pinned, classify, digest, file_record, parse_dependencies, require_snapshot, write_json

sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[1]
source=root/'baseline';manifest=root/'baseline-manifest.json';out=root/'baseline-probe'
assert_pinned(manifest,'b0bfdc75aae343a8cff064ab9d1c251e6d5349cd29985dd8259888859393f1f4')
pinfile=root/'tools/toolchain-pins.json'
assert_pinned(pinfile,'ad2ecef26f9d50b2899d057b92efc7ffeb9e6ea9fa48042c1d623d009e059065')
pins=json.loads(pinfile.read_text())['host'];expected=json.loads(manifest.read_text())['source']
require_snapshot(source,expected)
assert_pinned(pins['python']['path'],pins['python']['sha256'])
assert Path(sys.executable).resolve()==Path(pins['python']['path']).resolve() and sys.version==pins['python']['version']
cc=pins['compiler'];assert_pinned(cc['path'],cc['sha256'])
for name,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(name,sha)
out.mkdir();probe=out/'probe.c';original=root/'baseline-probe.c'
assert_pinned(original,'520dd929f26f04b305cf70861df789f861883d42d587ead3c2915fa9986a2006')
shutil.copyfile(original,probe);assert digest(probe)==digest(original)
flags=['-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-Isrc/core']
units=[str(probe),'src/core/wav.c','src/core/pcm.c']
record={'scope':'Host ASan/UBSan baseline preservation probe: expected RC20 and two24bit master corruptions through size/written; no native/target operation',
        'source_manifest':file_record(manifest),'source_files_before':len(expected),'compiler':cc,
        'runtime_inputs':pins['runtime_inputs'],'helper':file_record(__file__),
        'probe':file_record(probe),'commands':[],'canonical_dependencies':{},'external_sdk_dependencies':{},'passed':False}
def run(argv,label):
    result=subprocess.run(argv,cwd=source,capture_output=True,text=True,timeout=180)
    log=out/(label+'.log');log.write_text(result.stdout+result.stderr)
    record['commands'].append({'argv':argv,'directory':str(source),'returncode':result.returncode,'log':file_record(log)})
    return result
try:
    version=run([cc['path'],'--version'],'compiler-version');assert version.returncode==0 and version.stdout==cc['version']
    for i,unit in enumerate(units):
        dep=run([cc['path'],*flags,'-MM',unit],'dependencies-%02d'%i);assert dep.returncode==0
        for name in parse_dependencies(dep.stdout):
            path=(source/name).resolve()
            if path==probe:continue
            category,key=classify(path,source,expected,pins['allowed_sdk_roots'])
            record['canonical_dependencies' if category=='canonical' else 'external_sdk_dependencies'][key]=digest(path)
    result=run([cc['path'],*flags,*units,'-o',str(out/'probe')],'compile');assert result.returncode==0
    record['binary']=file_record(out/'probe')
    result=run([str(out/'probe')],'run')
    record['passed']=result.returncode==20 and result.stderr=='' and 'WAV SIZE PROBE result=0 before=257 after=56' in result.stdout and 'WAV WRITTEN PROBE result=0 before=257 after=56' in result.stdout
except Exception as failure:
    record['harness_error']={'kind':type(failure).__name__,'message':str(failure)}
    raise
finally:
    for path,sha in record['external_sdk_dependencies'].items():assert_pinned(path,sha)
    require_snapshot(source,expected);record['source_files_after']=len(expected)
    assert_pinned(cc['path'],cc['sha256'])
    for name,sha in {**pins['runtime_inputs'],**pins['sdk_inputs']}.items():assert_pinned(name,sha)
    assert_pinned(manifest,record['source_manifest']['sha256']);assert_pinned(__file__,record['helper']['sha256'])
    write_json(out/'result.json',record)
print(json.dumps({'passed':record['passed'],'report':str(out/'result.json')}))
sys.exit(0 if record['passed'] else 1)
