#!/usr/bin/env python3
"""Private lossless FAILED WAV evidence handoff; host archival only, HOLD without recovery or release."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import stat
import sys
import tempfile
import types

INPUT = Path('/private/tmp/protracker-wav-output-safety-n00_vv8l')
ROOT = Path('/private/tmp/protracker-wav-output-root-blltiblv')
SUPPORT = Path('/private/tmp/package_project_output_safety_v2.py')
SUPPORT_SHA = 'a9f0e287c8b69b315dce2e097d2548250597c54aebe4743c7bcd0c2891c8f6d8'
PINS = {
    'source-manifest.json': 'cf9088034834cc14e69b7b000d08a44f015fc43bd2f42692f66197e0664fb04f',
    'baseline-manifest.json': 'b0bfdc75aae343a8cff064ab9d1c251e6d5349cd29985dd8259888859393f1f4',
    'host-final/host-checks.json': '9934924d352364674495772780d58b0fa05fa77515f31f3c59a5f70104df60a2',
    'native-final/manifest.json': '530e7af2bab3c16f3516ae96c18afe8c64be7650220826eacb103a6f1b5ad921',
    'tools-native/native_build.py': '0d993d9bdc8c7104e089e5c307607928b4ed3c2de45377fa9ffceb9a42f2f3df',
    'tools-native/provenance_common.py': 'a08b779ebcb48911e66d45473dd2e15243806bd6c1e32c1833a5fa436d726447',
    'tools-native/prepared-files.json': '4c920498bb2f79408f09bafeac86ad3f895d6ec3f3dbdd98848dd09c6e01c819',
    'tools-native-v2/provenance_common.py': 'b701b26fe5193bfff7ccfcf2b5637a518d7d8d295b708e38ba6aee1e16aba728',
    'native-final-v2/manifest.json': '1a37f834d8fd3f19869e78241a14d0a20145b0bbf52597d060017df77b5fe657',
    'baseline-probe/result.json': '404eaa5791faf9875925969c0ef5f64394aa3c59cbaa2e70b0be109783eb2910',
    'candidate-probe/result.json': '9bb25e314654ecddd985cc683640c28cb95b1910c4e588eac81ab435d7dbdeeb',
    'final.patch': '5c91be8a8bfa9c7b2332426aab283441333052d79411db3cc4c17632dea2c8b7',
}
QUALIFICATION_SHA = 'f37734aa70730973fe40783bee9eef6eaa9f0b8466d6cf634f3ed5548221f1e3'
PREPARED_INPUTS = Path('/private/tmp/package-wav-failed-prepared-inputs.json')
PREPARED_INPUTS_SHA = '479d87d7553aaa0bc1006fc13884e8c7edf8541dd6951463975dca42c4cefc87'
SOURCE_COMMIT = '04bd3fb5e89c3562b4521938cdd98fa7abd5da53'
SAMPLE_CAPTURE = 'runner-sample-wav/build/dev/render-files-1790998016536947000'
QUALIFIED_TREE = '457d908c20480aa1d74c3ae52a1324ca0892ad2b'
TARGETS = {'wav-core': 'PTPcmTest', 'sample-wav': 'PTExecSampleFileTest'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=INPUT)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--support-helper', type=Path, default=SUPPORT)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--qualification', type=Path, required=True)
    parser.add_argument('--qualification-helper', type=Path, required=True)
    parser.add_argument('--coordination-record', type=Path, required=True)
    parser.add_argument('--extra-record', type=Path, action='append', default=[])
    parser.add_argument('--qa-out', type=Path)
    parser.add_argument('--execute-reviewed-failure-package', action='store_true',
                        help='Explicit root-authorized archival execution after static review; never recovery/retry/release authority')
    args = parser.parse_args()
    if not args.execute_reviewed_failure_package:
        raise ValueError('Prepared only: root archival execution authorization after static review is required')
    support = args.support_helper.resolve()
    support_bytes = support.read_bytes()
    if hashlib.sha256(support_bytes).hexdigest() != SUPPORT_SHA:
        raise ValueError('Reviewed pure archive/identity utility source changed')
    # Execute trusted metadata utility definitions under a non-main name, never its project packaging main.
    # Using exec rather than importlib avoids generating a bytecode file beside the immutable helper.
    module = types.ModuleType('_reviewed_exact_evidence_utilities')
    module.__file__ = str(support)
    exec(compile(support_bytes, str(support), 'exec'), module.__dict__)
    require, sha, fingerprint = module.require, module.sha, module.fingerprint
    safe, files, source_check = module.safe, module.files, module.source_check
    encoded = module.encoded
    verify_recorded_file = module.verify_recorded_file
    write_payload, verify_payload = module.write_payload, module.verify_payload
    input_root, root, out, qualification, qualifier, coordination = [p.resolve() for p in
        (args.input, args.root, args.out, args.qualification, args.qualification_helper, args.coordination_record)]
    extras = [p.resolve() for p in args.extra_record]
    qa_out = (args.qa_out or Path(str(out) + '-qa.json')).resolve()
    origins = [input_root, root, support, qualification.parent, qualifier, coordination,
               PREPARED_INPUTS.resolve(), Path('/private/tmp/package_wav_output_safety.prepared.py'), Path(__file__).resolve(), *extras]
    for origin in origins:
        require(out != origin and out not in origin.parents and origin not in out.parents,
                'Output overlaps original input: ' + str(origin))
        require(qa_out != origin and origin not in qa_out.parents,
                'External QA output overlaps original: ' + str(origin))
    require(out != qa_out and out not in qa_out.parents and qa_out not in out.parents,
            'Package and external QA overlap')
    require(not out.exists() and not qa_out.exists(), 'Fresh private package and QA destinations required')
    for relative, expected in PINS.items():
        verify_recorded_file(input_root / relative, expected)
    verify_recorded_file(qualification, QUALIFICATION_SHA)
    verify_recorded_file(PREPARED_INPUTS, PREPARED_INPUTS_SHA)
    prepared_inputs = json.loads(PREPARED_INPUTS.read_bytes())
    for name, identity in prepared_inputs['selected_root_originals'].items():
        require(str(root / name) == identity['path'], 'Pinned root original location changed')
        verify_recorded_file(root / name, identity['sha256'], identity['bytes'])
    captured_files = {path.relative_to(qualification.parent).as_posix(): fingerprint(path)
                      for path in files(qualification.parent)}
    require(captured_files == prepared_inputs['qualification_records'],
            'Historical failed qualification captured-host inventory changed; no new records silently accepted')
    old_prepared = prepared_inputs['preserved_prepared_pass_packager']
    verify_recorded_file(Path(old_prepared['path']), old_prepared['sha256'], old_prepared['bytes'])
    source_scopes = [(input_root / 'baseline', input_root / 'baseline-manifest.json'),
                     (input_root / 'source-final', input_root / 'source-manifest.json')]
    source_before = [source_check(*pair) for pair in source_scopes]
    final = json.loads((input_root / 'source-manifest.json').read_bytes())
    baseline_manifest = json.loads((input_root / 'baseline-manifest.json').read_bytes())
    host = json.loads((input_root / 'host-final/host-checks.json').read_bytes())
    native = json.loads((input_root / 'native-final-v2/manifest.json').read_bytes())
    before = json.loads((input_root / 'baseline-probe/result.json').read_bytes())
    after = json.loads((input_root / 'candidate-probe/result.json').read_bytes())
    root_inputs = json.loads((root / 'root-inputs.json').read_bytes())
    top = json.loads(qualification.read_bytes())
    coordination_object = json.loads(coordination.read_bytes())
    native_review = json.loads((root / 'root-native-failure-review.json').read_bytes())
    build_review = json.loads((root / 'root-native-build-review.json').read_bytes())
    failed = json.loads((input_root / 'native-final/manifest.json').read_bytes())
    require(failed['passed'] is False and failed['targets'] == {} and
            len(failed['commands']) == 9 and all(c['returncode'] == 0 for c in failed['commands']) and
            failed['failure']['kind'] == 'KeyError' and failed['failure']['message'] == "'PTPcmTest'",
            'Preserved V1 host-only wrapper-map failure changed')
    require(json.loads((input_root / 'native-final/compile-commands.json').read_bytes())['commands'] == [],
            'Failed V1 must retain zero target build commands')
    require(failed['source_files_before'] == failed['source_files_after'] == 7531 and
            failed['source_manifest']['sha256'] == PINS['source-manifest.json'],
            'V1 failure source inventory identity changed')
    document_path = root / 'committed-source-sample-memory.md'
    verify_recorded_file(document_path, '0431c08e0d86f5ed07f7d52b375d84e9aeb3fbd66aed906a0ed4afc4b2bf49ea', 304172)
    committed_source = {'schema': 'derived-root-provided-source-attribution-v1',
        'source_commit': SOURCE_COMMIT, 'source_tree': QUALIFIED_TREE,
        'documentation': fingerprint(document_path),
        'scope': 'Derived from exact root-provided commit/tree and pinned committed documentation bytes; documentation is outside compiled source closure; no Git or target operations by package'}
    require(host['passed'] is True and len(host['groups']) == 2 and
            host['modules'] == ['test_pcm', 'test_sample_file'], 'Final host scope changed')
    require(native['passed'] is True and set(native['targets']) == set(TARGETS.values()), 'Native target scope changed')
    require(len(final['wav_overlays']) == 3 and len(final['prior_overlays']) == 13,
            'Three WAV overlays/thirteen inherited project-SVX-RAW overlays changed')
    require(top['passed'] is False and len(top['cases']) == 1 and top['source_tree'] == QUALIFIED_TREE and
            top.get('error') == 'Independent exact paths reappeared; no retry' and
            [case['candidate']['label'] for case in top['cases']] == ['wav-core'],
            'Original FAILED qualification/core-only completion/error changed')
    require(top['verified_manifest'] == native, 'Top qualification embeds a different native build')
    require(native_review['passed'] is False and native_review['top_sha256'] == QUALIFICATION_SHA and
            native_review['source_tree'] == QUALIFIED_TREE and native_review['completed_independent_cases'] == ['wav-core'] and
            native_review['sample_independent_release_not_qualified'] is True,
            'Copied root FAILED native review references another qualification or claims sample release')
    require(build_review['passed'] is True and build_review['manifest_sha256'] == PINS['native-final-v2/manifest.json'],
            'Separate successful cross-build review changed')
    for record in (host, native, after):
        require(record['source_manifest']['sha256'] == PINS['source-manifest.json'], 'Final proof references another source manifest')
    require(before['source_manifest']['sha256'] == PINS['baseline-manifest.json'], 'Baseline proof references another manifest')
    require(before['passed'] is True and before['commands'][-1]['returncode'] == 20 and
            after['passed'] is True and after['commands'][-1]['returncode'] == 0,
            'Original expected before/after probe statuses changed')
    require((input_root / 'baseline-probe/probe.c').read_bytes() == (input_root / 'candidate-probe/probe.c').read_bytes(),
            'Independent before/after probe source differs')
    require(host['generated_inputs'] == [], 'Do not invent a generated fixture absent from the original host report')
    for item in host['products']:
        verify_recorded_file(Path(item['archive_path']), item['sha256'], item['bytes'])
    for record in (host, native, failed):
        for helper in record['helper_inputs']:
            verify_recorded_file(Path(helper['path']), helper['sha256'], helper['bytes'])
    for record in (native, failed):
        verify_recorded_file(Path(record['compile_commands']), record['compile_commands_sha256'], record['compile_commands_bytes'])
    verify_recorded_file(Path(native['canonical_recipe']['path']), native['canonical_recipe']['sha256'], native['canonical_recipe']['bytes'])
    for command in [*native['commands'], *failed['commands']]:
        log = command['log']
        verify_recorded_file(Path(log['path']), log['sha256'], log['bytes'])
    for target_name, target in native['targets'].items():
        verify_recorded_file(input_root / 'native-final-v2' / target_name, target['binary_sha256'], target['binary_bytes'])
    verify_recorded_file(root / 'shared_infra_render_files.py', root_inputs['runner_after_sha256'])
    verify_recorded_file(qualifier, root_inputs['qualifier_sha256'])
    for path, digest in final['prior_overlays'].items():
        require(baseline_manifest['source'][path] == digest, 'Inherited project/SVX/RAW fix differs from baseline inventory')
    # Require the captured HOLD response. Its completed chat turn is not a completed qualification or release.
    require('release_response' not in coordination_object and coordination == root / 'coordination-hold.json',
            'Failure package must retain HOLD, without substituting release or recovery records')
    acknowledgment = coordination_object.get('response', {})
    require(acknowledgment.get('isError') is False and acknowledgment.get('content'), 'Captured HOLD acknowledgment missing')
    acknowledgment_text = next((item['text'] for item in acknowledgment['content'] if item.get('type') == 'text'), None)
    require(acknowledgment_text is not None, 'Captured HOLD response text missing')
    acknowledgment_record = json.loads(acknowledgment_text)
    hold_polls = [item for item in acknowledgment_record.get('polls', []) if item.get('revision') == 60 and
                  item.get('latestTurn', {}).get('status') == 'completed']
    require(len(hold_polls) == 1 and 'recovery hold' in hold_polls[0]['latestAssistantMessage']['text'] and
            'not released' in hold_polls[0]['latestAssistantMessage']['text'], 'Exact captured HOLD60 changed')
    require(prepared_inputs['hold_revision'] == 60 and prepared_inputs['source_commit'] == SOURCE_COMMIT and
            prepared_inputs['source_tree'] == QUALIFIED_TREE, 'Prepared failure scope attribution changed')
    members = {}
    def add(name, origin, scope, expected=None):
        safe(name)
        require(name not in members, 'Duplicate payload member destination: ' + name)
        require(not origin.is_symlink() and stat.S_ISREG(origin.stat().st_mode), 'Nonregular original refused')
        identity = fingerprint(origin)
        if expected is not None:
            require(identity['sha256'] == expected, 'Scoped original hash mismatch: ' + str(origin))
        members[name] = {'path': name, 'bytes': identity['bytes'], 'sha256': identity['sha256'],
                         'mode': stat.S_IMODE(origin.stat().st_mode), 'kind': 'exact_original_archive_member',
                         'origin': identity, 'scope': scope}
    def tree(prefix, directory, scope, skip=()):
        skips = {p.resolve() for p in skip}
        for path in files(directory):
            if path.resolve() not in skips:
                add(prefix + '/' + path.relative_to(directory).as_posix(), path, scope)
    for prefix, sub, scope in [
        ('host-final', 'host-final', 'Exact two-group ASan/UBSan report/commands/logs/products; no generated fixture exists'),
        ('native-failed-v1', 'native-final', 'Original host-only V1 helper KeyError after nine successful compiler/runtime queries; zero compiled targets or binaries'),
        ('native-final-v2', 'native-final-v2', 'Exact two cross-build recipes/logs/binaries/SDK/compiler/runtime identities; portable versus Exec scopes retained'),
        ('regression/before', 'baseline-probe', 'Original expected RC20 preservation failure before three WAV fixes'),
        ('regression/after', 'candidate-probe', 'Identical probe source after three fixes; original RC0/master preservation'),
        ('helpers/host', 'tools', 'Exact host provenance/probe helpers/toolchain pins'),
        ('helpers/native-v1', 'tools-native', 'Exact executed V1 preparation/build helper, pins and original prepared record before preserved host-only wrapper-map failure'),
        ('helpers/native-v2', 'tools-native-v2', 'Exact native build/provenance helpers/toolchain pins/declared preparation inputs'),
    ]:
        tree(prefix, input_root / sub, scope)
    for name, destination, scope in [
        ('baseline-manifest.json', 'source/baseline-manifest.json', 'Original full7531 baseline inventory with thirteen inherited project/SVX/RAW overlays'),
        ('source-manifest.json', 'source/source-manifest.json', 'Original full7531 final inventory/three WAV overlays plus thirteen inherited project/SVX/RAW overlays'),
        ('final.patch', 'source/final-three-file.patch', 'Exact reviewed three-file WAV product/test patch'),
        ('baseline-probe.c', 'regression/original-probe.c', 'Original independent probe source retained alongside identical before/after copies'),
    ]:
        add(destination, input_root / name, scope)
    inherited_manifest = baseline_manifest['input_source_manifest']
    verify_recorded_file(Path(inherited_manifest['path']), inherited_manifest['sha256'], inherited_manifest['bytes'])
    add('source/inherited-raw-svx-project-source-manifest.json', Path(inherited_manifest['path']),
        'Exact inherited project/SVX/RAW source manifest with thirteen overlays; no completed RAW/SVX evidence duplication or new acceptance')
    dependencies = {}
    for item in [host['canonical_dependencies'], after['canonical_dependencies'], final['overlays'], native['python_declaration_inputs'],
                 *[target['dependencies'] for target in native['targets'].values()]]:
        for path, digest in item.items():
            require(path not in dependencies or dependencies[path] == digest, 'Conflicting execution closure hash')
            dependencies[path] = digest
    recipe = Path(native['canonical_recipe']['path']).relative_to(input_root / 'source-final').as_posix()
    dependencies[recipe] = final['source'][recipe]
    for module_name in host['modules']:
        path = 'tests/' + module_name + '.py'
        dependencies[path] = final['source'][path]
    if 'tests/__init__.py' in final['source']:
        dependencies['tests/__init__.py'] = final['source']['tests/__init__.py']
    for path, digest in sorted(dependencies.items()):
        add('source/final-scoped/' + path, input_root / 'source-final' / path,
            'Exact final canonical execution/module/recipe closure and product overlay bytes', digest)
    baseline_dependencies = dict(before['canonical_dependencies'])
    baseline_dependencies.update({path: baseline_manifest['source'][path] for path in final['wav_overlays']})
    baseline_dependencies.update(final['prior_overlays'])
    for path, digest in sorted(baseline_dependencies.items()):
        add('source/baseline-scoped/' + path, input_root / 'baseline' / path,
            'Exact baseline probe closure and before-fix source overlays, inherited project/SVX/RAW guards retained', digest)
    for path in sorted(final['wav_overlays']):
        add('history/working-candidate-scoped/' + path, input_root / 'candidate' / path,
            'Working private candidate bytes observed at packaging time, may equal final; not an immutable initial draft')
    for name in prepared_inputs['selected_root_originals']:
        add('root/' + name, root / name,
            'Exact selected pre-recovery root WAV preparation/host/build/failure/inventory/coordination-HOLD/documentation original; no recovery or release inference')
    add('qualification/top/qualification-result.json', qualification,
        'Exact original FAILED top/core-only completion/error; never replaced with nested runner PASS or release claim')
    tree('qualification/records', qualification.parent,
         'Exact captured nested runners/results/logs/identities/core independent cleanup; missing sample independent observations are not synthesized', skip=(qualification,))
    add('qualification/historical-orchestration.py', qualifier,
        'Exact supplied historical qualifier bytes; execution attribution only from original/root reports')
    add('qualification/root-reported-coordination.json', coordination,
        'Exact captured root-reported HOLD60 acknowledgment only; no live packaging verification, release or recovery claim')
    for n, path in enumerate(extras, 1):
        add('qualification/extra/%02d-%s' % (n, path.name), path, 'Additional exact root-reported control/review')
    add('helpers/inherited-raw-packager.py', Path('/private/tmp/package_raw_output_safety.py'),
        'Exact reviewed RAW helper used as preparation reference only; not executed by WAV package, no completed RAW/SVX artifact duplication',
        '3b94c159767e24411a9eeddc890fc5a06b655306aa090765ddf01facb748efb6')
    add('helpers/preserved-pass-prepared-packager.py', Path(old_prepared['path']),
        'Exact original69d4 guarded PASS-preparation draft retained unchanged and NOT RUN; not a successful package/qualification')
    add('helpers/failure-prepared-inputs.json', PREPARED_INPUTS,
        'Exact static failure-helper selected-input inventory/HOLD60/pending recovery attribution, not original target observations')
    add('helpers/packager.py', Path(__file__).resolve(), 'Exact private FAILED WAV packaging helper; no tests/builds/Git/UI/target/recovery calls')
    add('helpers/packager-support-project-v2.py', support,
        'Reviewed pure identity/archive utility definitions only; its project main is never invoked by this WAV package')
    case_consistency = []
    seen_labels = set()
    for case in top['cases']:
        label, target_name = case['candidate']['label'], case['candidate']['binary']
        require(label not in seen_labels and TARGETS.get(label) == target_name, 'Unexpected/duplicate native case')
        seen_labels.add(label)
        target = native['targets'][target_name]
        require(case['candidate']['sha256'] == target['binary_sha256'] and case['candidate']['bytes'] == target['binary_bytes'],
                'Native executed candidate does not match original cross-build')
        run = Path(case['run']).resolve()
        require(qualification.parent in run.parents, 'Original nested run outside qualification tree')
        require(json.loads((run / 'result.json').read_bytes()) == case['result'], 'Top/nested original result mismatch')
        require(json.loads((run / 'independent-cleanup.json').read_bytes()) == case['independent_cleanup'], 'Independent original cleanup mismatch')
        result = case['result']
        require(result[label + '_returncode'] == '0' and result['passed'] is True, 'Recorded exact native case status changed')
        require(len(case['independent_cleanup']['observations']) == 11, 'Original independent observation count changed')
        require(result.get('run_files_cleaned') is True and
                all('ch%d_dma=0' % i in result.get('cleanup_audio', '').split('\t') for i in range(4)),
                'Original exact cleanup/fresh DMA-off evidence changed')
        independent = case['independent_cleanup']
        require(independent.get('passed') is True and
                all(all(value is False for value in row.values()) for row in independent['observations']) and
                len(independent['processes']) == 1 and independent['processes'][0][0] == 19081 and
                'Paused=false' in independent['status'].split('\t') and
                all('ch%d_dma=0' % i in independent['audio'].split('\t') for i in range(4)) and
                'Paused=false' in independent['final_idle']['status'].split('\t') and
                all('ch%d_dma=0' % i in independent['final_idle']['audio'].split('\t') for i in range(4)),
                'Original independent absence/process/running/final-idle evidence changed')
        log = case['native_log']
        require((run / (label + '.log')).read_text() == log, 'Top/native original log mismatch')
        require(case['candidate']['marker'] in log, 'Original fixture marker missing')
        require(label == 'wav-core' and 'EXEC MEMORY PASS:' not in log and 'no Exec Fast allocator' in result['scope'],
                'Only portable core has completed independent cleanup; it must not imply Exec allocation proof')
        scope = 'Portable PCM/WAV codec assertions and original independent cleanup completed; no Exec Fast/TypeOfMem acceptance'
        case_consistency.append({'label': label, 'binary': target_name, 'sha256': target['binary_sha256'],
                                 'scope': scope, 'original_top_nested_independent_equal': True,
                                 'independent_observations': 11})
    require(seen_labels == {'wav-core'}, 'FAILED top must keep only the completed core case')
    sample_run = qualification.parent / SAMPLE_CAPTURE
    require(qualification.parent in sample_run.parents and sample_run.is_dir(), 'Exact captured sample host evidence missing')
    sample = json.loads((sample_run / 'result.json').read_bytes())
    sample_log = (sample_run / 'sample-wav.log').read_text()
    sample_target = native['targets']['PTExecSampleFileTest']
    require(sample['passed'] is True and sample['sample-wav_returncode'] == '0' and
            sample['PTExecSampleFileTest_sha256'] == sample_target['binary_sha256'] and
            sample['sample_staging_clean'] is True and sample['run_files_cleaned'] is True and
            sample['independent_release_check_required'] is True and sample['cleanup_method'] == 'host-exact-run-once' and
            all('ch%d_dma=0' % i in sample['cleanup_audio'].split('\t') for i in range(4)),
            'Original nested sample execution/runner cleanup scope changed')
    require('SAMPLE WAV STREAM PASS:' in sample_log and 'fixed workspace=11240' in sample_log and
            '18 Fast allocations, zero owned bytes' in sample_log and
            'budget refusal without Chip fallback' in sample_log, 'Original sample Exec allocation/workspace facts changed')
    observations = sample['cleanup_absence_observations']
    require(len(observations) == 9 and all(all(value is False for value in row['paths'].values()) for row in observations),
            'Original nine nested runner absence observations changed')
    require(not (sample_run / 'independent-cleanup.json').exists() and
            not any(path.endswith(SAMPLE_CAPTURE + '/independent-cleanup.json') for path in captured_files),
            'Sample independent-cleanup record was not captured; refusal rather than invented/future observations')
    require(native_review['sample_native_rc'] == '0' and native_review['sample_native_fast_allocations'] == 18 and
            native_review['sample_native_zero_owned_bytes'] is True and native_review['sample_workspace_bytes'] == 11240 and
            native_review['sample_runner_record_passed'] is True, 'Root failure review and original sample facts disagree')
    case_consistency.append({'label': 'sample-wav', 'binary': 'PTExecSampleFileTest',
        'sha256': sample_target['binary_sha256'], 'scope': 'Native file fixture RC0 and Exec Fast workspace/own cleanup reported; subsequent independent absence qualification FAILED',
        'original_nested_runner_passed': True, 'original_nested_runner_absence_observations': 9,
        'independent_cleanup_record': 'MISSING_IN_ORIGINAL_CAPTURE', 'independent_cleanup_status': 'NOT_QUALIFIED',
        'partial_failed_independent_observations': 'NOT_PERSISTED; no failed index/time/path/contents invented',
        'present_in_original_top_cases': False, 'recovery_status': 'PENDING_SEPARATELY_AUTHORIZED_RECOVERY',
        'release_status': 'NOT_RELEASED; captured HOLD60, no release record'})
    out.mkdir()
    payload = out / 'payload.tar.gz'
    with payload.open('xb') as writer:
        write_payload(members, writer)
    archive_verification = verify_payload(payload, members)
    with tempfile.TemporaryFile() as second:
        write_payload(members, second)
        second.seek(0)
        with payload.open('rb') as first:
            while True:
                a, b = first.read(1024 * 1024), second.read(1024 * 1024)
                require(a == b, 'Repeated deterministic payload differs')
                if not a:
                    break
    archive_verification['second_archive_write_byte_identical'] = True
    controls = []
    def record(name, kind, scope, origin=None, derivation=None):
        row = fingerprint(out / name)
        row['path'] = name
        row.update(kind=kind, scope=scope)
        if origin is not None:
            row['origin'] = fingerprint(origin)
        if derivation is not None:
            row['derivation'] = derivation
        controls.append(row)
    def copy(name, origin, scope):
        require(not (out / name).exists(), 'Duplicate readable control')
        original = origin.read_bytes()
        (out / name).write_bytes(original)
        require((out / name).read_bytes() == original, 'Exact control byte copy failed')
        record(name, 'exact_byte_copy', scope, origin)
    def compressed(name, origin, scope):
        require(not (out / name).exists(), 'Duplicate readable gzip control')
        original = origin.read_bytes()
        with (out / name).open('xb') as writer:
            with gzip.GzipFile(fileobj=writer, filename='', mode='wb', mtime=0, compresslevel=9) as gz:
                gz.write(original)
        require(gzip.decompress((out / name).read_bytes()) == original, 'Exact control original gzip failed')
        record(name, 'gzip_exact_byte_derivation', scope, origin,
               {'method': 'gzip level9/mtime0/emptyfilename; no source JSON fields/order/whitespace altered'})
    record('payload.tar.gz', 'lossless_archive_derivation', 'Every selected wav original byte/source closure/helper/history',
           derivation=archive_verification)
    for name, origin, scope in [
        ('source-manifest.json.gz', input_root / 'source-manifest.json', 'Original complete7531 source manifest/three WAV plus thirteen inherited project/SVX/RAW overlays'),
        ('baseline-manifest.json.gz', input_root / 'baseline-manifest.json', 'Original complete7531 before-WAV manifest'),
        ('host-checks.json.gz', input_root / 'host-final/host-checks.json', 'Original two-group host sanitizer report/allcommands/products; generated_inputs[] retained'),
        ('native-build-failed-v1.json.gz', input_root / 'native-final/manifest.json', 'Original host-only V1 KeyError after nine RC0 compiler/runtime queries, empty target/build commands; not a product assertion failure'),
        ('native-build.json.gz', input_root / 'native-final-v2/manifest.json', 'Original successful corrected V2 two-target cross-build report/orderedTUs/SDKclosures/pinpaths/scopes'),
        ('qualification-result.json.gz', qualification, 'Original actual top native report fields/status/scopes, distinct nested copies in payload'),
        ('committed-sample-memory.md.gz', root / 'committed-source-sample-memory.md', 'Exact committed documentation only, separate from immutable7531 compiled source/dependencies'),
    ]:
        compressed(name, origin, scope)
    for name, origin, scope in [
        ('baseline-before.json', input_root / 'baseline-probe/result.json', 'Original expected before-WAV RC20 preservation failure'),
        ('probe-after.json', input_root / 'candidate-probe/result.json', 'Original identical-source RC0 preservation probe after three fixes'),
        ('root-host-review.json', root / 'root-host-review.json', 'Original root host review'),
        ('root-native-build-review.json', root / 'root-native-build-review.json', 'Original root cross-build review, unmodified portable/Exec scopes'),
        ('root-native-failure-review.json', root / 'root-native-failure-review.json', 'Original root FAILED qualification review; portable core completed, sample execution distinct from failed independent cleanup'),
        ('reappeared-inventory.json', root / 'reappeared-inventory.json', 'Exact root historical read-only owned-path inventory; no new/live packaging inspection and no recreation cause inferred'),
        ('coordination-before-native.json', root / 'coordination-before-native.json', 'Original captured request57/take59; earlier no hold is not current release'),
        ('root-inputs.json', root / 'root-inputs.json', 'Original root separate runner/qualifier fingerprints'),
        ('root-reported-coordination.json', coordination, 'Original captured HOLD60; no live verification/release/recovery claims'),
    ]:
        copy(name, origin, scope)
    for n, path in enumerate(extras, 1):
        copy('extra-%02d-%s' % (n, path.name), path, 'Original supplied extra control/review, no changed field')
    (out / 'committed-source-attribution.json').write_bytes(encoded(committed_source))
    record('committed-source-attribution.json', 'authored_root_provided_attribution',
           'Derived root-provided full04bd commit/tree and exact committed documentation identity; not an original Git/target proof',
           derivation={'prepared_inputs': fingerprint(PREPARED_INPUTS), 'document': fingerprint(document_path)})
    source_after = [source_check(*pair) for pair in source_scopes]
    require(source_before == source_after, 'Immutable source inventories changed during packaging')
    for member in members.values():
        require(fingerprint(Path(member['origin']['path'])) == member['origin'], 'Original archived input changed during packaging')
    provenance = {
        'schema': 'protracker-wav-output-safety-failed-member-provenance-v1',
        'scope': 'Private archive/control/source integrity only; no new product/build/test/target/cleanup/release/device/audio/physical/timing/listening acceptance',
        'source_before': source_before, 'source_after': source_after, 'source_inventories_before_after_identical': True,
        'wav_new_product_overlays': final['wav_overlays'], 'inherited_project_svx_raw_overlays': final['prior_overlays'],
        'separate_runner_overlay': fingerprint(root / 'shared_infra_render_files.py'),
        'separate_committed_documentation': fingerprint(root / 'committed-source-sample-memory.md'),
        'committed_source_attribution': committed_source,
        'attempted_source_tree': top['source_tree'], 'original_top_passed': False,
        'original_top_error': top['error'], 'sample_independent_cleanup': 'FAILED; partial observations missing in original capture',
        'captured_coordination_status': 'HOLD60_NOT_RELEASED', 'recovery_status': 'PENDING_SEPARATELY_AUTHORIZED_RECOVERY', 'actual_native_cases': case_consistency,
        'preserved_native_v1_failure': {'manifest': fingerprint(input_root / 'native-final/manifest.json'), 'kind': failed['failure']['kind'], 'message': failed['failure']['message'], 'compiler_runtime_queries': len(failed['commands']), 'targets': failed['targets'], 'scope': 'Original host-only preparation-map failure before compilation, not a product/native test failure'},
        'generated_fixture_retention': 'Original host report generated_inputs is empty; streamed fixture was deleted by its test, no generated fixture invented/copied',
        'coordination_attribution': 'Exact captured/root-reported request57/take59/HOLD60 only; no live verification, recovered or release fact. Later recovery/release, if any, belongs in separate evidence',
        'archive': fingerprint(payload), 'archive_verification': archive_verification,
        'members': [members[name] for name in sorted(members)],
    }
    wav_provenance = encoded(provenance)
    with (out / 'member-provenance.json.gz').open('xb') as writer:
        with gzip.GzipFile(fileobj=writer, filename='', mode='wb', mtime=0, compresslevel=9) as gz:
            gz.write(wav_provenance)
    require(gzip.decompress((out / 'member-provenance.json.gz').read_bytes()) == wav_provenance, 'Member provenance gzip failed')
    record('member-provenance.json.gz', 'authored_member_provenance_gzip', 'All selected original member/origin/byte/hash/mode identities and source inventories',
           derivation={'uncompressed_bytes': len(wav_provenance), 'uncompressed_sha256': sha(wav_provenance),
                       'method': 'Authored full original-member index, gzip level9 mtime0 emptyfilename'})
    readme = '''# WAV output preservation — failed independent cleanup

The original WAV qualification is **FAILED**: `Independent exact paths reappeared; no retry`. Its unchanged top record contains only the completed portable `wav-core` case. That case has its original 11-observation independent absence record. The `sample-wav` file fixture separately completed RC0 and recorded 18 Fast allocations, zero owned bytes, workspace11240, master preservation and transactional staging cleanup. Its nested runner reported nine absence observations through2.048s. These execution and nested-runner facts do not clear the later independent absence failure.

The qualifier raised before saving the sample's partial independent observations or appending its completed fixture to the top. No sample `independent-cleanup.json` exists in the captured host records. The failed index/time/path/contents and recreation cause are therefore unknown; no observations are synthesized. The copied root read-only inventory is historical evidence only. Packaging never inspects the live shared paths.

Captured coordination is request57/take59 followed by **HOLD60, not released**. Recovery remains pending separate authorization; this package contains no recovered state or release claim. The unexecuted root recovery script is excluded. The unchanged original69d4 PASS-preparation helper is retained as guarded, NOT RUN history; it is not a completed package or qualification.

Two host ASan/UBSan groups and two pinned native cross-builds remain separately successful. Portable `PTPcmTest` codec assertions are distinct from the `PTExecSampleFileTest` Exec allocator/file fixture. The original V1 helper KeyError after nine RC0 compiler/runtime queries and empty targets/build commands is retained separately from corrected V2 builds. Baseline expectedRC20 and identical-source candidateRC0 probes remain original. No generated fixture is invented: the host file test deleted its temporary output and `generated_inputs:[]` stays unchanged.

`payload.tar.gz` preserves selected original commands/logs/products/helpers/toolchain identities, execution/module/recipe source closures and all three WAV overlays. Full7531 baseline/final inventories retain thirteen inherited project/SVX/RAW overlays. Separate runner and pinned04bd committed documentation remain outside compiled source attribution. The inherited helper/source-manifest history does not duplicate completed RAW/SVX artifacts. Working-candidate bytes are labelled as observed at packaging time.

`qualification-result.json.gz` is the literal FAILED top, also under `qualification/top/` in the payload; nested records stay distinct. `member-provenance.json.gz` identifies every member/origin/size/hash/mode. Every original byte and gzip derivation, safe unique regular archive member, deterministic repeated archive, checksum/control, and immutable source inventory is verified. Authored summaries are labelled derived. No product/build/test/target/recovery/release operation is performed by packaging, and no device/card/MMIO, audio, physical hardware, timing or human listening acceptance is claimed.
'''
    (out / 'README.md').write_text(readme)
    record('README.md', 'authored_scope_note', 'Precise portable/Exec/host/native/history/coordination tiers and selected-payload navigation')
    index = {'schema': 'protracker-wav-output-safety-failed-compact-controls-v1',
             'scope': 'Copy/archive/derivation integrity only; no new execution or live coordination acceptance',
             'items': controls, 'control_exclusions': ['compact-index.json', 'SHA256SUMS'],
             'archive_verification': archive_verification, 'original_native_status': top['passed'],
             'source_inventories_before_after_identical': True}
    (out / 'compact-index.json').write_bytes(encoded(index))
    package_files = files(out)
    (out / 'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + p.relative_to(out).as_posix() + '\n' for p in package_files))
    final_files = files(out)
    expected_paths = {row['path'] for row in controls} | {'compact-index.json', 'SHA256SUMS'}
    require({p.relative_to(out).as_posix() for p in final_files} == expected_paths, 'Unindexed package member')
    sums = {}
    for line in (out / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        safe(name)
        require(name not in sums, 'Duplicate checksum path')
        sums[name] = digest
    require(set(sums) == expected_paths - {'SHA256SUMS'}, 'Checksum coverage mismatch')
    for name, digest in sums.items():
        require(sha((out / name).read_bytes()) == digest, 'Checksum identity mismatch')
    for row in controls:
        data = (out / row['path']).read_bytes()
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'Indexed control bytes changed')
        if 'origin' in row:
            original = Path(row['origin']['path']).read_bytes()
            require(len(original) == row['origin']['bytes'] and sha(original) == row['origin']['sha256'], 'Control origin changed')
            observed = gzip.decompress(data) if row['kind'] == 'gzip_exact_byte_derivation' else data
            require(observed == original, 'Exact original control bytes changed')
    require([source_check(*pair) for pair in source_scopes] == source_before, 'Source changed during final control verification')
    qa = {'scope': 'Private archive/control/source integrity only; no targets or new acceptance',
          'package': str(out), 'files': len(final_files), 'bytes': sum(p.stat().st_size for p in final_files),
          'archive_verification': archive_verification, 'payload': fingerprint(payload),
          'compact_index': fingerprint(out / 'compact-index.json'), 'sha256sums': fingerprint(out / 'SHA256SUMS'),
          'checksum_rows': len(sums), 'all_original_member_control_bytes_and_gzip_hashes_verified': True,
          'all_source_inventories_before_after_identical': True, 'native_cases': case_consistency,
          'original_top_passed': False, 'captured_coordination_status': 'HOLD60_NOT_RELEASED',
          'sample_independent_record_missing_not_synthesized': True,
          'recovery_status': 'PENDING_SEPARATELY_AUTHORIZED_RECOVERY',
          'portable_assertions_distinct_from_exec_allocation_proof': True,
          'no_missing_generated_fixture_invented': True, 'historical_coordination_copied_root_report_only': True}
    qa_out.write_bytes(encoded(qa))
    print(json.dumps({'package': str(out), 'qa': fingerprint(qa_out), 'files': qa['files'], 'bytes': qa['bytes'],
                      'payload': qa['payload'], 'archive_verification': archive_verification,
                      'index': qa['compact_index'], 'sha256sums': qa['sha256sums']}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('FAILED-WAV ARCHIVAL PACKAGING REFUSED/FAILED; original qualification/HOLD/input records and any new output preserved: ' + repr(error), file=sys.stderr)
        raise
