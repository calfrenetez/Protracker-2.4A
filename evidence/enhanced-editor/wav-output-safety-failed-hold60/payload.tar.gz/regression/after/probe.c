#include <stdio.h>
#include <string.h>
#include "wav.h"
static union {size_t scalar;int32_t values[32];} master;
static unsigned char encoded[256], before_encoded[256];
static void reset(void)
{unsigned i;memset(&master,0,sizeof(master));for(i=0;i<4;++i)master.values[i]=257+(int32_t)i;memset(encoded,0x55,sizeof(encoded));memcpy(before_encoded,encoded,sizeof(encoded));}
int main(void)
{
 struct pt_pcm pcm={master.values,32,4,48000,1,24};
 enum pt_wav_result size_result,written_result;int size_ok,written_ok;int32_t first;
 reset();first=master.values[0];size_result=pt_wav_size(&pcm,&master.scalar);
 size_ok=size_result==PT_WAV_ALIAS && master.values[0]==first;
 printf("WAV SIZE PROBE result=%d before=%ld after=%ld\n",size_result,(long)first,(long)master.values[0]);
 reset();first=master.values[0];written_result=pt_wav_encode(&pcm,encoded,sizeof(encoded),&master.scalar);
 written_ok=written_result==PT_WAV_ALIAS && master.values[0]==first && !memcmp(encoded,before_encoded,sizeof(encoded));
 printf("WAV WRITTEN PROBE result=%d before=%ld after=%ld\n",written_result,(long)first,(long)master.values[0]);
 return size_ok && written_ok?0:20;
}
